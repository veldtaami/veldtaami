accept tabname prompt 'owner.table: '
set verify off
set feedback off
set pagesize 1000
set linesize 200
col tablespace_name form a18
col "type" form a14
col column_name form a32
col index_name for a40
select
  owner,
  table_name,
  tablespace_name,
  num_rows,
  blocks, round(((blocks * 8192) / 1048576 ), 2 ) MB ,
  last_analyzed
from
  dba_tables
where
  upper(owner)||'.'||upper(table_name)=upper('&tabname')
/
select
  a.column_name,
  a.data_type||'('||data_length||')' "type",
  a.data_precision "prec",
  a.nullable,
  b.num_distinct, b.density, b.avg_col_len, b.histogram
from
  dba_tab_columns a,
  dba_tab_col_statistics b
where
  upper(a.owner)||'.'||upper(a.table_name)=upper('&tabname')
  and
  a.table_name=b.table_name(+)
  and
  a.owner=b.owner(+)
  and
  a.column_name=b.column_name(+)
order by
  column_id
/
col column_name form a20
col P form 99
select
  a.index_name,
  b.uniqueness,
  a.column_position P,
  a.column_name,
  b.distinct_keys,
  b.clustering_factor
from
  dba_ind_columns a,
  dba_indexes b
where
  upper(b.owner)||'.'||upper(a.table_name)=upper('&tabname')
  and
  a.index_owner=b.owner
  and
  a.index_name=b.index_name
order by b.uniqueness desc, index_name, column_position
/
      

        
