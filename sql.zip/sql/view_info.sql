accept view_name prompt 'view name: '
set long 2000
select
  owner, view_name 
from
  dba_views
where
  view_name like '%&view_name%'
/
select text from dba_views where view_name like '%&view_name%'
/
@sqlplusdefaults
