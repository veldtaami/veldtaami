accept seqname prompt 'owner.seq:'
accept newval prompt 'eind_waarde:'

alter  SEQUENCE  &seqname  INCREMENT BY  &eind_waarde - (
	select last_number from dba_sequences where upper(owner)||'.'||upper(SEQUENCE_NAME)=upper('&seqname')
);

SELECT &seqname.NEXTVAL FROM DUAL;
alter  SEQUENCE  &seqname  INCREMENT BY 1;
