select
  sequence#,
  archived,
  applied,
  deleted,
  backup_count,
  status,
  to_char(first_time,'YYYY-MM-DD HH24:MI:SS') first_time
from v$archived_log order by sequence#
/
