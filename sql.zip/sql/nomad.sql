
drop user nomad cascade;

create user nomad identified by n0mad_u$er
default tablespace tools
temporary tablespace temp
profile admin
quota unlimited on tools;

grant connect to nomad;
grant resource to nomad;
grant select any dictionary to nomad;


