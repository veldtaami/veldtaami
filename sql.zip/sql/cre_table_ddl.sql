set long 900
accept username prompt "Enter username to generate ddl for: "
accept tabel prompt "Enter table_name to generate ddl for: "
SELECT dbms_metadata.get_ddl('TABLE','&&tabel','&&username') FROM dual;
