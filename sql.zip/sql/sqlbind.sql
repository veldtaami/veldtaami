accept hash prompt 'sql hash value: '
set verify off
col DATATYPE_STRING form a20
col VALUE_STRING form a40
set linesize 100
select CHILD_NUMBER, POSITION, DATATYPE_STRING, VALUE_STRING from v$sql_bind_capture where hash_value='&hash' order by 1,2
/
@sqlplusdefaults
