col c form 9
col cost form 999999
col "Mb" form 99999.9
col object_name form a20
col object_type form a20
col step form a90 heading "Operation"
col options form a20
set linesize 200
set trimspool off
set pagesize 1000
set heading on
set verify off
set feedback off
set recsep off
accept hash prompt 'SQL hash value: '

select
  child_number c,
  cost, cardinality "rows",round(bytes/1024*10)/10 "KB",
  --id, parent_id,position,
  lpad('-',depth,'-')||operation||' '||options||' '||object_name||decode(access_predicates,'','','
'||lpad('-',depth,'-')||'access:'||access_predicates)||decode(filter_predicates,'','','
'||lpad('-',depth,'-')||'filter:'||filter_predicates) step
from 
  v$sql_plan
where
  hash_value='&&hash'
order by child_number,id,position
/

@sqlplusdefaults
