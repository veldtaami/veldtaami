set linesize 200
col what form a60 word_wrapped
set pagesize 1000
col job_name for a50
select owner, job_name, state, 
  to_char(LAST_START_DATE,'YYYY-MM-DD HH24:MI:SS') LAST_START_DATE, 
  to_char(NEXT_RUN_DATE,'YYYY-MM-DD HH24:MI:SS') next
from
  DBA_SCHEDULER_JOBS
order by 1,2
/


col log_id for a30
col errors for a20
col output for a20
col job_name for a40
set lines 200
set pages 99
col log_date for a40

select log_id, log_Date, errors, output , job_name from DBA_SCHEDULER_JOB_RUN_DETAILS 
where log_Date > sysdate -1;


-- exec dbms_scheduler.enable(�CLEAR_OP�);

