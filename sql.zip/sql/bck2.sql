set linesize 200
set heading off
col "age_in_hours" form 99
col "latest" form a25
col "type" form a10
select (sysdate-completion_time)*24 age_in_hours, ':FULL' from
(select
 max(b.completion_time) completion_time,
 b.file#
 from
 v$datafile a,
 v$backup_datafile b,
 v$backup_set c,
 v$backup_piece d
 where
 a.file#=b.file#
 and
 b.set_stamp=c.set_stamp
 and
 b.set_count=c.set_count
 and
 c.backup_type='D'
 and
 (c.incremental_level=0 or c.incremental_level is NULL)
 and
 c.set_stamp=d.set_stamp and c.set_count=d.set_count
 group by b.file#)
union
select (sysdate-completion_time)*24 age_in_hours, ':INCR' from
(select
 max(b.completion_time) completion_time,
 b.file#
 from
 v$datafile a,
 v$backup_datafile b,
 v$backup_set c,
 v$backup_piece d
 where
 a.file#=b.file#
 and
 b.set_stamp=c.set_stamp
 and
 b.set_count=c.set_count
 and
 c.backup_type='I'
 and
 c.incremental_level>0
 and
 c.set_stamp=d.set_stamp and c.set_count=d.set_count
 group by b.file#)
union
select
(sysdate-max(a.completion_time))*24 age_in_hours, ':ARCH'
from
v$backup_set a
where
a.backup_type='L'
/
