set lines 200
col  OWNER           for a20
col  DIRECTORY_NAME  for a40
col  DIRECTORY_PATH  for a100

select OWNER           ,
       DIRECTORY_NAME  ,
       DIRECTORY_PATH   from dba_directories;
	   
