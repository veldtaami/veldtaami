stappen: 
0. empty recyclebin

1. rename ooxd naar ooxd_mv
2. creeer nieuwe ooxd
3. verplaats alle objecten naar de nieuwe ooxd
4. controleer ooxd_mv en verwijder. 


ALTER TABLESPACE OOXD RENAME TO OOXD_MV;
  -- create data tablespace
  CREATE BIGFILE TABLESPACE OOXD LOGGING DATAFILE SIZE 32G  AUTOEXTEND on maxsize 300G
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;
  
alter database datafile '+DATA/PHOO1_02/DATAFILE/ooxd.1522.1048145913' autoextend on maxsize 3000G;
alter user owner_oox quota unlimited on OOXD;


-- Moving Tables and Un-partitioned Indexes
set lines 200
set pages 0
set feedback off
spool move.sql
select
'alter ' || segment_type || ' ' || owner || '.' || segment_name || decode( segment_type, 'TABLE', ' move', ' rebuild' ) ||
' parallel 8 tablespace OOXD' || ';'
from dba_segments
where tablespace_name='OOXD_MV' 
and segment_type in('TABLE','INDEX') order by owner, segment_type desc, segment_name;
spool off


select  'alter table ' || owner || '.' || table_name || ' move'  || ' tablespace OOXD' || ';'
from dba_tables  where tablespace_name='OOXD_MV' ;

select  'alter index  ' || owner || '.' || index_name || ' rebuild parallel 8 nologging'  || ' tablespace OOXD' || ';' 
from dba_indexes  where tablespace_name='OOXD_MV' ;


 drop tablespace ooxd_mv;


-- Moving index partitions

set lines 200
set pages 0
set feedback off
spool move.sql
select 'alter index '|| owner||'.'||segment_name || ' rebuild partition '|| partition_name ||' tablespace OOXD;'
from dba_segments where segment_type ='INDEX PARTITION' and tablespace_name='OOXD_MV';
spool off


-- Moving index sub-partitions

set lines 200
set pages 0
set feedback off
spool move.sql
select 'alter index '||owner||'.'||segment_name ||' rebuild subpartition ' || partition_name ||' tablespace OOXD;'      
from dba_segments where tablespace_name='OOXD_MV' and segment_type = 'INDEX SUBPARTITION';
spool off


-- Moving IOT index segments (When only IOT indexes left on the tablespace)

set lines 200
set pages 0
set feedback off
spool move.sql
select 'alter table '||owner||'.'|| table_name || ' move tablespace OOXD;' from dba_indexes where index_name in (
select  segment_name from dba_segments
where tablespace_name='OOXD_MV' and segment_type='INDEX');
spool off

Moving LOB segments

set lines 200
set pages 0
--set feedback off
--spool move.sql
select 'alter table '|| owner || '.' ||table_name|| ' move parallel 32 LOB ('||COLUMN_NAME ||') STORE AS (tablespace OOXD);'
from DBA_LOBS where tablespace_name='OOXD_MV';
spool off


CONTROLE: 
select index_name, STATUS from dba_indexes where OWNER='OWNER_OOX' and status = 'UNUSABLE';

SELECT 'alter index '||owner||'.'||index_name||' rebuild parallel 8 nologging tablespace OOXD;' sql_to_rebuild_index
FROM   dba_indexes 
WHERE  status = 'UNUSABLE' and owner = 'OWNER_OOX';

select table_name from  dba_tables  where tablespace_name = 'OOXD_MV';
select owner, segment_name from  dba_segments where tablespace_name = 'OOXD';
 exec DBMS_UTILITY.ANALYZE_SCHEMA('OWNER_OOX','ESTIMATE', estimate_percent => 1);

--Don't forget to reduce the parallel degree of the rebuild indexes back to one.
SELECT 'alter index ' || owner || '.' || index_name || ' noparallel;' rebuild_sql 
FROM dba_indexes 
WHERE table_name LIKE 'OBJECTS';



-- VOORTGANG



 select sum(bytes)/1024/1024/1024 GB from dba_segments where tablespace_name = 'OOXD_MV';
 
 select sum(bytes)/1024/1024/1024 GB from dba_segments where tablespace_name = 'OOXD';
 
 select table_name , segment_name from dba_lobs where segment_name in (select distinct(segment_name) from dba_segments where tablespace_name = 'OOXD_MV');
  select distinct(segment_name), segment_type, sum(bytes)/1024/1024 MB  from dba_segments where tablespace_name = 'OOXD_MV' group by  segment_name, segment_type;
 