set feedback off
set pagesize 1000
set linesize 200
set verify off
col name form a50
accept latch prompt 'latch# :'
select * from (
select child#,
       addr,
       name,
       decode(gets,0,0,round(misses/gets*10000)/100) "miss%",
       decode(immediate_gets,0,0,round(immediate_misses/immediate_gets*10000)/100) "imm miss%",
       decode(gets,0,0,round(spin_gets/gets*10000)/100) "spinget%",
       decode(gets,0,0,round(sleeps/gets*10000)/100) "sleep%",
       round(wait_time/1000000) "sec waited"
from	v$latch_children
where	latch#=&latch
order by wait_time desc 
) where rownum<40
/
@sqlplusdefaults
