set lines 200
col OS_USERNAME for a40
col USERNAME  for a30
col TIMESTAMP for a30
col action_name for a50
select distinct OS_USERNAME , USERNAME ,TIMESTAMP, action_name from DBA_AUDIT_SESSION
where TIMESTAMP > sysdate -5
and action_name = 'LOGON'
order by 3;


--and username like upper('%&db_user%')
