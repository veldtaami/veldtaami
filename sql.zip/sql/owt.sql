system@bcm1p.duo.local> @data_as_insert
Voer waarde voor tabel in: 
Voer waarde voor owner in: 
oud  16:                 WHERE table_name = upper('&TABEL') and owner = upper('&OWNER')
nieuw  16:                 WHERE table_name = upper('') and owner = upper('')

PL/SQL-procedure is geslaagd.

system@bcm1p.duo.local> 
system@bcm1p.duo.local> 
system@bcm1p.duo.local> 
system@bcm1p.duo.local> @data_as_insert
Voer waarde voor tabel in: 
Voer waarde voor owner in: /
oud  16:                 WHERE table_name = upper('&TABEL') and owner = upper('&OWNER')
nieuw  16:                 WHERE table_name = upper('') and owner = upper('/')

PL/SQL-procedure is geslaagd.

system@bcm1p.duo.local> /
Voer waarde voor tabel in: OWT_BO_OND_INHOUDEN
Voer waarde voor owner in: OWT
oud  16:                 WHERE table_name = upper('&TABEL') and owner = upper('&OWNER')
nieuw  16:                 WHERE table_name = upper('OWT_BO_OND_INHOUDEN') and owner = upper('OWT')

PL/SQL-procedure is geslaagd.

system@bcm1p.duo.local> exit
