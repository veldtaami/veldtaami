accept evtname char prompt 'event name: '
set linesize 200
set pagesize 12
col end_interval_time form a25
select 
  hi.end_interval_time,
  es.TOTAL_WAITS-bs.TOTAL_WAITS TOTAL_WAITS,
  es.TOTAL_TIMEOUTS-bs.TOTAL_TIMEOUTS TOTAL_TIMEOUTS,
  round((es.TIME_WAITED_MICRO-bs.TIME_WAITED_MICRO)/1E6) "wait time (s)",
  decode(es.TOTAL_WAITS-bs.TOTAL_WAITS,0,-1,round(1000*(es.TIME_WAITED_MICRO-bs.TIME_WAITED_MICRO)/(es.TOTAL_WAITS-bs.TOTAL_WAITS)/1E6)) "avg wait (ms)"
from
(select SNAP_ID, TOTAL_WAITS, TOTAL_TIMEOUTS, TIME_WAITED_MICRO from DBA_HIST_SYSTEM_EVENT where event_name='&evtname') bs,
(select SNAP_ID, TOTAL_WAITS, TOTAL_TIMEOUTS, TIME_WAITED_MICRO from DBA_HIST_SYSTEM_EVENT where event_name='&evtname') es,
dba_hist_snapshot hi
where
 bs.snap_id=es.snap_id-1
  and
 es.snap_id=hi.snap_id
order by hi.end_interval_time
/
@sqlplusdefaults
