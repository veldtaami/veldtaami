accept sql_iden prompt 'geef de sql_iden op: '

SET linesize 200
SET LONG 999999999
SET pages 1000
SET longchunksize 20000 
set feedback on


EXECUTE dbms_sqltune.drop_tuning_task('Task1');

DECLARE
 stmt_task VARCHAR2(64);
BEGIN
 stmt_task:=dbms_sqltune.create_tuning_task(sql_id => '&&sql_iden',  time_limit => 3600, task_name => 'Task1', description => 'task1');
END;
/

-- uitvoeren van de task:
EXECUTE dbms_sqltune.execute_tuning_task('Task1');

SELECT dbms_sqltune.report_tuning_task('Task1', 'TEXT', 'ALL') FROM dual;
  
EXECUTE dbms_sqltune.drop_tuning_task('Task1');

 