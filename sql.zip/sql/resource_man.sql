set lines 200
set pages 99
col plan for a32
col status for a10
col comments for a100
col grantee for a20
col granted_group for a40

desc DBA_RSRC_CONSUMER_GROUP_PRIVS
SELECT * FROM DBA_RSRC_CONSUMER_GROUP_PRIVS;

SELECT PLAN,COMMENTS,STATUS FROM DBA_RSRC_PLANS;

SELECT SID,SERIAL#,USERNAME,RESOURCE_CONSUMER_GROUP FROM GV$SESSION;


prompt:  "wait resmgr:cpu quantum" 
show parameter resource
prompt "alter system set resource_manager_plan='' scope=both sid='*'; "
prompt "of "
prompt "alter system  set resource_manager_plan='DEFAULT_PLAN' scope=both sid='*';"