set lines 200
 
select * from (
select name, to_char(time_stamp,'DD-MON-YYYY hh24:mi') as timestamp, 
 round(sum(size_Gb)) as db_size_in_Gb  
from FOTDBA.database_size, v$database where ts_name not like 'TEMP%' and ts_name not like 'UNDO%'
group by time_stamp, name order by time_stamp desc)
where rownum < 5;



--select * from FOTDBA.database_size where 
--to_char(time_stamp,'DD-MON-YYYY hh24:mi') = '08-SEP-2021 18:00';