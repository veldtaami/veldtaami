        SELECT 3, SYSDATE, 'Object ' || S.Owner || '.' || S.Segment_name ||
               ' cannot extent 2 times in ' || F.Tablespace_name as x, 2, Next_extents
        FROM   ( SELECT Tablespace_name, Owner, Segment_name,
                        DECODE (Next_extent, NULL, bytes, Next_extent+(Next_extent*pct_increase/100)) Next_extents
                 FROM   DBA_segments
) S ,
               DBA_Free_space F
        WHERE  F.Bytes >= S.Next_Extents
        AND    F.Tablespace_Name = S.Tablespace_Name
        GROUP  BY S.Owner, S.Segment_name, S.Next_Extents, F.Tablespace_name
        HAVING FLOOR(SUM(F.Bytes)/S.next_extents) <= 2
/
