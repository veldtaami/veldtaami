set lines 200
col name for a40

show parameter db_recovery_file_dest

SELECT * FROM V$RECOVERY_FILE_DEST;

SELECT * FROM V$RECOVERY_AREA_USAGE;

select name from v$restore_point;