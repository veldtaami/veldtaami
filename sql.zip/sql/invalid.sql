col OWNER format a10
col OBJECT_NAME format a30
col OBJECT_Type format a12
select owner, object_name, object_type from dba_objects where status != 'VALID';


 select 'alter '||object_type|| ' ' || owner ||'.'||object_name || ' compile;' from dba_objects where status='INVALID';