@defaults
col grantee for a30
col privilege for a30
col granted_role for a40
col admin_option for a30

SELECT grantee, PRIVILEGE, admin_option FROM sys.dba_sys_privs WHERE grantee = upper('&&USERNAAM');
SELECT grantee, granted_role, admin_option FROM dba_role_privs  WHERE grantee = upper('&USERNAAM');
select grantee, PRIVILEGE, GRANTABLE , OWNER, table_name from  dba_Tab_privs where grantee = upper('&USERNAAM');

select 'grant ' || PRIVILEGE  || ' to ' || grantee || ';' from  sys.dba_sys_privs where grantee = upper('&USERNAAM');
select 'grant '||granted_role||' to '||grantee ||case when admin_option = 'YES' then ' with admin option' else null end  ||';'
	from dba_role_privs  WHERE grantee = upper('&USERNAAM');
select 'grant ' || PRIVILEGE  || ' on ' || OWNER || '.' || table_name || ' to ' || grantee ||case when grantable = 'YES' then ' with grant option' else null end  ||';'
	from  dba_Tab_privs where grantee = upper('&USERNAAM');

undefine USERNAAM
--set pages 100
--
--select 'grant ' || PRIVILEGE  || ' to ' || grantee ||case when admin_option = 'YES' then ' with admin option' else null end  ||';'
--from  sys.dba_sys_privs 
--where grantee not in ('RESOURCE', 'APEX_030200' ,'GSMUSER' , ' XDB' , 'DBSNMP' , 'IMP_FULL_DATABASE' , 'XDB' , 'RECOVERY_CATALOG_OWNER' , 'EM_EXPRESS_ALL','DATAPUMP_EXP_FULL_DATABASE','DATAPUMP_IMP_FULL_DATABASE' , 'EXP_FULL_DATABASE') 
--and grantee not like '%SYS%' and grantee not like '%APEX%'and grantee not like '%DBA%' and grantee not like '%GSM%' 
--order by grantee;
-- 
--  
-- 
-- 
-- 
--select 'grant '||granted_role||' to '||grantee ||case when admin_option = 'YES' then ' with admin option' else null end  ||';'
--	from dba_role_privs  WHERE grantee = upper('&USERNAAM');