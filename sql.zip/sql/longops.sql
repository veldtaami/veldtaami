set linesize 200
col pct form 999.9
col hrs_remain form 999.9
col message form a100
col done form a29
col opname form a40
col target form a30
select
  a.sid,
  round((a.time_remaining/360))/10 hrs_remain,
  a.sofar||'/'||a.totalwork||' '||a.units done,
  round(1000*a.sofar/a.totalwork)/10 pct,
  a.opname,
  a.target
from v$session_longops a
where
  a.totalwork>0  and a.totalwork!=a.sofar
  and a.sid in (select b.sid from v$session b)
order by a.sid, a.opname
/
