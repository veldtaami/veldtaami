set lines 200
col table_name for a40
col segment_name for a40
col owner for a30
set pages 99


select table_name, l.segment_name, sum(bytes)/1024/1024 MB , s.owner from dba_segments s, dba_lobs l
 where s.segment_name = l.segment_name group by table_name, l.segment_name, s.owner order by 3;