@defaults
col grantee for a30
col privilege for a30
col granted_role for a40
col admin_option for a30


select grantee, PRIVILEGE, GRANTABLE , OWNER, table_name from  dba_Tab_privs where owner = upper('&USERNAAM');


select 'grant ' || PRIVILEGE  || ' on ' || OWNER || '.' || table_name || ' to ' || grantee ||case when grantable = 'YES' then ' with grant option' else null end  ||';'
	from  dba_Tab_privs where owner = upper('&USERNAAM');

undefine USERNAAM;

