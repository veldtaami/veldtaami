accept statname char prompt 'statistic name: '
col end_interval_time form a25
set pagesize 80
select
  hi.end_interval_time,
  es.value-bs.value value
from
  (select snap_id, value from dba_hist_sysstat where stat_name='&statname') bs,
  (select snap_id, value from dba_hist_sysstat where stat_name='&statname') es,
  dba_hist_snapshot hi
where
  es.snap_id-1=bs.snap_id
  and
  bs.snap_id=hi.snap_id
order by end_interval_time
/
@sqlplusdefaults
