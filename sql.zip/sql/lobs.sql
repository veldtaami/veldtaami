@defaults
col lobs_name for a40
col table_name for a40
--select table_name, owner, last_analyzed, NUM_ROWS ,blocks,  blocks*8192/1024/1024/1024 Gb, degree, chain_cnt as chained_blocks  from dba_Tables where owner = upper('&schema_naam')
--order by 5,6 ;


select  s.SEGMENT_NAME lobs_name,  sum(bytes)/1024/1024 MB  , s.TABLESPACE_NAME , d.table_name , d.COMPRESSION from dba_segments  s, dba_lobs d
where s.segment_name = d.segment_name and 
s.segment_name in
(select segment_name from dba_lobs where owner = upper('&schema_naam') )
group by s.segment_name,  s.TABLESPACE_NAME,  d.table_name, d.COMPRESSION
order by 2,1;


--select  s.SEGMENT_NAME lobs_name,  sum(bytes)/1024/1024 MB  , s.TABLESPACE_NAME , d.table_name from dba_segments  s, dba_lobs d
--where s.segment_name = d.segment_name and 
--s.segment_name in
--(select segment_name from dba_lobs where tablespace_name = upper('&tablespace_naam') )
--group by s.segment_name,  s.TABLESPACE_NAME,  d.table_name
--order by 2,1;