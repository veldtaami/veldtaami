
-- Tabel creeeren 
create table fotdba.database_size (
time_stamp  date,
ts_name  varchar2(30),
size_gb  number,
contents  varchar2(21));

---procedure creeren
grant select on dba_data_files to fotdba;
grant select on dba_tablespaces to fotdba;
grant select on dba_Temp_files to fotdba;
CREATE OR REPLACE PROCEDURE fotdba.ins_dbsize_report AS 
BEGIN
  INSERT INTO fotdba.database_size  
     (select sysdate, t.TABLESPACE_NAME,  sum(bytes)/1024/1024/1024, contents from dba_data_files d, dba_tablespaces t
		where d.tablespace_name = t.tablespace_name 
		group by t.tablespace_name, contents
		union
		select sysdate, tf.TABLESPACE_NAME,  sum(bytes)/1024/1024/1024, contents from dba_tablespaces t, dba_Temp_files tf
		where tf.tablespace_name = t.tablespace_name 
		group by tf.tablespace_name, contents);
END;
/

---Job creeeren
BEGIN
  DBMS_SCHEDULER.CREATE_JOB(
   job_name           =>  'dbsize_report',
   job_type           =>  'STORED_PROCEDURE',
   job_action         =>  'fotdba.ins_dbsize_report',
   start_date         =>  trunc(sysdate)+18/24,
   repeat_interval    =>  'FREQ=DAILY;INTERVAL=1', 
   comments           =>  'insert database size in table');
END;
/

BEGIN
      DBMS_SCHEDULER.enable(name=>'"SYS"."DBSIZE_REPORT"');
END;
/
BEGIN
    DBMS_SCHEDULER.RUN_JOB(job_name => '"SYS"."DBSIZE_REPORT"', USE_CURRENT_SESSION => FALSE);
END;
/

set lines 200
col job_name for a30
col NEXT_RUN_DATE for a30
col start_date for a30
col job_Action for a60
select JOB_NAME, JOB_ACTION, START_DATE, NEXT_RUN_DATE , enabled from dba_scheduler_jobs where job_name = 'DBSIZE_REPORT';

select count(1) from fotdba.database_size;
select * from fotdba.database_size;
