col name form a30
col value form a50
set pagesize 10000
select name, value from v$parameter where isdefault='FALSE' order by name;
@sqlplusdefaults
