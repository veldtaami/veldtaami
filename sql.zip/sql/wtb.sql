break on wait_class skip 1 on event
set pagesize 1000
set linesize 162
col wait_class form a14
col time_waited form 999999999
col average_wait form 99999.99
col PCT form 999.99
set define off
set feedback off

select wait_class, event, round(time_waited/100/60) "time waited (min)", round(average_wait*100)/10 "average wait (ms)", round(10000*time_waited/total.stotal)/100 PCT
from
(
  select 
    rownum pos,
    wait_class,
    'Total' event,
    time_waited,
    null average_wait
  from
    (select
       wait_class,
       sum(time_waited) time_waited
     from
       (select 'CPU' wait_class, 'cpu usage' event, value time_waited from v$sysstat where upper(name)='CPU USED BY THIS SESSION'
        union
        select en.wait_class , se.event, se.time_waited from v$system_event se, v$event_name en where se.event=en.name and en.wait_class != 'Idle'
       )
     group by wait_class 
     order by time_waited desc
    ) 
  union
  select 
    grp.pos, 
    en.wait_class,
    se.event, 
    se.time_waited,
    se.average_wait 
  from 
    v$system_event se, 
    v$event_name en,
    (select 
       rownum pos, 
       wait_class, 
       'Total' event, 
       time_waited 
     from 
       (select 
          wait_class, 
          sum(time_waited) time_waited 
        from 
          (select 
             'CPU' wait_class, 
             'cpu usage' event, 
             value time_waited 
           from 
             v$sysstat 
           where 
             upper(name)='CPU USED BY THIS SESSION' 
           union 
           select 
             en.wait_class, 
             se.event, 
             se.time_waited 
           from 
             v$system_event se,
             v$event_name en
           where 
             en.name=se.event and en.wait_class != 'Idle' ) 
           group by wait_class 
           order by time_waited desc 
          ) 
       ) grp 
  where en.name=se.event and en.wait_class != 'Idle' and en.wait_class = grp.wait_class
  order by pos, time_waited desc
),
(
  select sum(time_waited) stotal from
  (
    select value time_waited from v$sysstat where upper(name)='CPU USED BY THIS SESSION'
    union
    select se.time_waited from v$system_event se, v$event_name en where en.name=se.event and en.wait_class != 'Idle'
  )
) total     
/
@sqlplusdefaults 
