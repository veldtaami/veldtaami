set pages 200
set lines 200
col name for a50
col value for a60

select name, value, ISSPECIFIED from v$spparameter where ISSPECIFIED = 'TRUE';