with t as (
 select ss.run_time,ts.name,round(su.tablespace_size*dt.block_size/1024/1024/1024,2) alloc_size_gb,
 round(su.tablespace_usedsize*dt.block_size/1024/1024/1024,2) used_size_gb
 from
 dba_hist_tbspc_space_usage su,
 (select trunc(BEGIN_INTERVAL_TIME) run_time,max(snap_id) snap_id from dba_hist_snapshot
 group by trunc(BEGIN_INTERVAL_TIME) ) ss,
 v$tablespace ts,
 dba_tablespaces dt
 where su.snap_id = ss.snap_id
 and su.tablespace_id = ts.ts#
-- and ts.name =upper('USERS')
 and ts.name = dt.tablespace_name )
 select e.run_time,e.name,e.alloc_size_gb,e.used_size_gb curr_used_size_gb,
 b.used_size_gb prev_used_size_gb,
 case when e.used_size_gb > b.used_size_gb
 then to_char(e.used_size_gb - b.used_size_gb)
 when e.used_size_gb = b.used_size_gb
 then '***NO DATA GROWTH'
 when e.used_size_gb < b.used_size_gb
 then '******DATA PURGED' end variance
 from t e, t b
 where e.run_time = b.run_time + 1
 order by 1,2;




select ss.run_time,ts.name,round(su.tablespace_size*dt.block_size/1024/1024/1024,2) alloc_size_gb,
 round(su.tablespace_usedsize*dt.block_size/1024/1024/1024,2) used_size_gb
 from
 dba_hist_tbspc_space_usage su,
 (select trunc(BEGIN_INTERVAL_TIME) run_time,max(snap_id) snap_id from dba_hist_snapshot
 group by trunc(BEGIN_INTERVAL_TIME) ) ss,
 v$tablespace ts,
 dba_tablespaces dt
 where su.snap_id = ss.snap_id
 and su.tablespace_id = ts.ts#
-- and ts.name =upper('USERS')
 and ts.name = dt.tablespace_name
 order by 2,1;
 
 
 select run_time, sum(used_size_gb) from
 (select ss.run_time,ts.name,round(su.tablespace_size*dt.block_size/1024/1024/1024,2) alloc_size_gb,
 round(su.tablespace_usedsize*dt.block_size/1024/1024/1024,2) used_size_gb
 from
 dba_hist_tbspc_space_usage su,
 (select trunc(BEGIN_INTERVAL_TIME) run_time,max(snap_id) snap_id from dba_hist_snapshot
 group by trunc(BEGIN_INTERVAL_TIME) ) ss,
 v$tablespace ts,
 dba_tablespaces dt
 where su.snap_id = ss.snap_id
 and su.tablespace_id = ts.ts#
-- and ts.name =upper('USERS')
 and ts.name = dt.tablespace_name
 order by 2,1) 
 where name not in ('UNDOTBS1', 'UNDOTBS2', 'TOOLS', 'TEMP', 'RABO_TEMP') 
 group by run_time
 order by run_time;



-- Tabel creeeren 
create table fotdba.database_size (
time_stamp  date,
ts_name  varchar2(30),
size_gb  number,
contents  varchar2(21));

---    select sysdate, t.TABLESPACE_NAME,  sum(bytes)/1024/1024/1024, contents from dba_data_files d, dba_tablespaces t
---    where d.tablespace_name = t.tablespace_name 
---    group by t.tablespace_name, contents
---    union
---    select sysdate, tf.TABLESPACE_NAME,  sum(bytes)/1024/1024/1024, contents from dba_tablespaces t, dba_Temp_files tf
---    where tf.tablespace_name = t.tablespace_name 
---    group by tf.tablespace_name, contents; 
---    
---procedure creeren

grant select on dba_data_files to fotdba;
grant select on dba_tablespaces to fotdba;
grant select on dba_Temp_files to fotdba;
CREATE OR REPLACE PROCEDURE fotdba.ins_dbsize_report AS 
BEGIN
  INSERT INTO fotdba.database_size  
     (select sysdate, t.TABLESPACE_NAME,  sum(bytes)/1024/1024/1024, contents from dba_data_files d, dba_tablespaces t
		where d.tablespace_name = t.tablespace_name 
		group by t.tablespace_name, contents
		union
		select sysdate, tf.TABLESPACE_NAME,  sum(bytes)/1024/1024/1024, contents from dba_tablespaces t, dba_Temp_files tf
		where tf.tablespace_name = t.tablespace_name 
		group by tf.tablespace_name, contents);
END;
/

---Job creeeren

BEGIN
  DBMS_SCHEDULER.CREATE_JOB(
   job_name           =>  'dbsize_report',
   job_type           =>  'STORED_PROCEDURE',
   job_action         =>  'fotdba.ins_dbsize_report',
   start_date         =>  trunc(sysdate)+18/24,
   repeat_interval    =>  'FREQ=DAILY;INTERVAL=1', 
   comments           =>  'insert database size in table');
END;
/

BEGIN
      DBMS_SCHEDULER.enable(name=>'"SYS"."DBSIZE_REPORT"');
END;
/
BEGIN
    DBMS_SCHEDULER.RUN_JOB(job_name => '"SYS"."DBSIZE_REPORT"', USE_CURRENT_SESSION => FALSE);
END;
/


begin
      dbms_scheduler.set_attribute (
        name      => '"SYS"."DBSIZE_REPORT"',
        attribute => 'start_date',
        value     => trunc(sysdate)+18/24);
end;
/

set lines 200
col job_name for a30
col NEXT_RUN_DATE for a30
col start_date for a30
col job_Action for a60
select JOB_NAME, JOB_ACTION, START_DATE, NEXT_RUN_DATE , enabled from dba_scheduler_jobs where job_name = 'DBSIZE_REPORT';

select count(1) from fotdba.database_size;
