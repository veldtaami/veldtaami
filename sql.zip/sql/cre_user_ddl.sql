accept username prompt "Enter username to generate ddl for: "
SELECT dbms_metadata.get_ddl('USER','&&username') FROM dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('ROLE_GRANT','&&username') from dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('OBJECT_GRANT','&&username') from dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT','&&username') from dual;
