-- script lists info on an oracle server process based
-- on the OS process id
exec dbms_output.enable( 100000 );
set serveroutput on
set verify off
set feedback off
accept spid char prompt 'Enter the OS process id: '
declare
  proc_addr v$session.paddr%TYPE;
  cursor c_session(the_addr char) is select * from v$session where paddr=the_addr;
  r_session c_session%ROWTYPE;
  r_bgprocess v$bgprocess%ROWTYPE;
  cursor c_seswait( the_sid number ) is select * from v$session_wait where sid=the_sid order by seq#;
  cursor c_sql( the_addr char, the_hash char ) is select sql_text from v$sqltext where address=the_addr and hash_value=the_hash order by piece; 
  cursor c_sesevt( the_sid number ) is select * from v$session_event where sid=the_sid and time_waited>0 order by time_waited desc;
  cursor c_access( the_sid number ) is select * from v$access where sid=the_sid;
  ses_logreads number;
  total_logreads number;
begin
  -- find the pid
  begin
    select addr into proc_addr from v$process where spid='&spid';
    dbms_output.put_line( 'paddr     : '||proc_addr );
  exception
    when NO_DATA_FOUND then
      dbms_output.put_line( 'specified pid is not an existing Oracle session' );
      return;
  end;
  open c_session( proc_addr );
  fetch c_session into r_session;
  close c_session;
  dbms_output.put_line( 'SID       : ' || r_session.sid );
  if ( r_session.type = 'BACKGROUND' )
  then
    select * into r_bgprocess from v$bgprocess where paddr=proc_addr;
    dbms_output.put_line( 'BG process: ' || r_bgprocess.name );
  else
    dbms_output.put_line( 'Username  : ' || r_session.username );
    dbms_output.put_line( 'Machine   : ' || r_session.machine );
    dbms_output.put_line( 'Program   : ' || r_session.program );
    dbms_output.put_line( 'Status    : ' || r_session.status );
    dbms_output.put_line( 'OS User   : ' || r_session.osuser );
    dbms_output.put_line( 'Logged On : ' || to_char(r_session.logon_time, 'DD-MM-YYYY HH24:MI:SS' ) );
  end if;
  -- waiting
  for r_seswait in c_seswait( r_session.sid )
  loop
    dbms_output.put_line( 'Waiting   : ' || r_seswait.event || ' '
                                         || r_seswait.seconds_in_wait || ' secs, '  
                                         || r_seswait.state || ' ' 
                                         || r_seswait.p1text|| '='
                                         || r_seswait.p1 || ', '
                                         || r_seswait.p2text|| '='
                                         || r_seswait.p2 || ', '
                                         || r_seswait.p3text|| '='
                                         || r_seswait.p3 );
  end loop;
  --events
  for r_sesevt in c_sesevt( r_session.sid ) loop
    dbms_output.put_line( 'Event     : ' || r_sesevt.event || ', waited ' || r_sesevt.time_waited || ' secs' );
  end loop;
  -- logical read % among sessions
  select sum(a.value) into total_logreads from v$sesstat a, v$statname b where a.statistic#=b.statistic# and b.name='session logical reads';
  select sum(a.value) into ses_logreads from v$sesstat a, v$statname b where a.statistic#=b.statistic# and sid=r_session.sid and b.name='session logical reads';
  dbms_output.put_line( 'Log read% : ' || round(ses_logreads / total_logreads * 100) );
  -- sql
  dbms_output.put_line( 'Cur SQL   : ' );
  dbms_output.put_line( '------------' );
  dbms_output.put_line( 'SQL Address   : '||r_session.sql_address );
  dbms_output.put_line( 'SQL Hash value: '||r_session.sql_hash_value );
  dbms_output.put_line( '------------------------------------------' );
  for r_sql in c_sql( r_session.sql_address, r_session.sql_hash_value ) loop
    dbms_output.put_line( r_sql.sql_text );
  end loop;
end;
/

