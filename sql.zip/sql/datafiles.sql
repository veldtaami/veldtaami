col datafile form a80
col tempfile form a80
set linesize 250
set pagesize 100
set feedback off
select
  file_id,
  file_name datafile,
  autoextensible,
  round(bytes/(1024*1024*1024)) SizeGb,
  round(maxbytes/(1024*1024*1024)) MaxGb,
  status
from dba_data_files
order by file_id
/
select
  file_id,
  file_name tempfile,
  autoextensible,
  round(bytes/(1024*1024*1024)) SizeGb,
  round(maxbytes/(1024*1024*1024)) MaxGb,
  status
from dba_temp_files
/
@sqlplusdefaults
