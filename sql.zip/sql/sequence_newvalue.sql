CREATE OR REPLACE PROCEDURE SYS.SEQUENCE_NEWVALUE(
seqowner VARCHAR2,
seqname VARCHAR2,
newvalue NUMBER) AS
ln NUMBER;
ib NUMBER;
BEGIN
SELECT last_number, increment_by INTO ln, ib FROM dba_sequences WHERE sequence_owner = upper(seqowner) AND sequence_name = upper(seqname);
EXECUTE IMMEDIATE 'ALTER SEQUENCE ' || seqowner || '.' || seqname ||' INCREMENT BY ' || (newvalue - ln);sq
EXECUTE IMMEDIATE 'SELECT ' || seqowner || '.' || seqname ||'.NEXTVAL FROM DUAL' INTO ln;
EXECUTE IMMEDIATE 'ALTER SEQUENCE ' || seqowner || '.' || seqname  || ' INCREMENT BY ' || ib;
END;
/

GRANT EXECUTE ON sequence_newvalue TO gokhan;
 
EXEC sequence_newvalue( 'GOKHAN', 'SAMPLE_SEQ', 10000 );


select 'exec sequence_newvalue( ''' || SEQUENCE_OWNER || ''',''' || SEQUENCE_NAME  || ''',' || LAST_NUMBER || ');' 
from dba_sequences
where 
SEQUENCE_OWNER in ('AVH','BER','BES','BET','DAV','DIP','DOM','DRA','DRI','DSB','EMR','GCO','GEG','KFX','KSB','MPI'
,'OEA','OGV','OMT','ONP','OWD','OWI','OWT','OXE','PNC','REL','RFG','TRS','TVH','WER','ZMT');

select 'exec sequence_newvalue( ''' || SEQUENCE_OWNER || ''',''' || SEQUENCE_NAME  || ''',' || LAST_NUMBER || ');' 
from dba_sequences
where 
SEQUENCE_OWNER in ('OWD' );



select SEQUENCE_OWNER , SEQUENCE_NAME  , LAST_NUMBER from dba_sequences
where SEQUENCE_NAME = 'OWD_MBS_SEQ1'