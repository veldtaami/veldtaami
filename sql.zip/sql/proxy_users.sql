set lines 150
col PROXY for a30
col CLIENT for a40
select PROXY, CLIENT from proxy_users;

select 'alter user ' || client || ' grant connect through '|| PROXY from proxy_users;

