accept keuze prompt 'exec, gets, cpu, ela, rds, rws: '
set linesize 120
set pagesize 2000
set heading off
set verify off
col shash form a20
col sexec form a4
col sgets form a4
col scpu form a3
col sela form a3
col srds form a3
col srow form a4
select * from (
select 
  executions exec,
  'exec'sexec,
  buffer_gets gets,  
  'gets' sgets,
  round(cpu_time/100000)/10 cpu,
  'cpu' scpu,
  round(elapsed_time/100000)/10 ela,    
  'ela' sela,
  disk_reads rds,
  'rds' srds,
  rows_processed rws,
  'rows' srow,
  'hash='||hash_value shash,  
  '------------------------------------------------------------------------------------------------------------------------',  
  sql_text
from
  v$sqlarea
order by
  &keuze desc)
where rownum<16
/
@sqlplusdefaults
