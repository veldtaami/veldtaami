RABO_USER @ srv0phoo101 > select 'alter table '|| owner || '.' ||table_name|| ' move parallel 16 LOB ('||COLUMN_NAME ||') STORE AS (tablespace OOXD);'
  2  from DBA_LOBS where tablespace_name='OOXD_MV';
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                                                           
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                            
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                        
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                           
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                                                          
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                                                                  
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                                                               
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                     
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                                                             
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CP_FILES_ROLLBACK move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_SUSPENDED_EXECUTIONS move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_FINISHED_BRANCHES move parallel 16 LOB (BRANCH_EXCEPTION) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_FINISHED_BRANCHES move parallel 16 LOB (BRANCH_CONTEXT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_EXECUTION_BOUND_INPUTS move parallel 16 LOB (BIG_VALUE) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_STEP_LOG_ENDED move parallel 16 LOB (TRANSITION_DESCRIPTION_BIG_C) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_FLOW_EVENT move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_BLOB_TRIGGERS move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                     
alter table OWNER_OOX.OO_BKP9_BUILD_INFO move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_BKP9_DASHBOARD_DEF move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_BKP9_FLOW_VARS move parallel 16 LOB (VAR_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_BKP9_GROUPS move parallel 16 LOB (ANNOTATION) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_BKP9_GROUPS move parallel 16 LOB (MAPPINGS) STORE AS (tablespace OOXD);                                                                                                        
alter table OWNER_OOX.OO_BKP9_KEYVAL move parallel 16 LOB (META) STORE AS (tablespace OOXD);                                                                                                            
alter table OWNER_OOX.OO_BKP9_KEYVAL move parallel 16 LOB (VALUE) STORE AS (tablespace OOXD);                                                                                                           
alter table OWNER_OOX.OO_BKP9_QRTZ_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_BKP9_QRTZ_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_BKP9_USERS move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (RESULT_STRING) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (SCRIPTLET_RESULT_STRING) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (BOUND_INPUTS) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (TRANSITION_STRING) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (EXCEPTION_TRACE) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (STEP_CONTEXT) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                      
RABO_USER @ srv0phoo101 > set feedback on
RABO_USER @ srv0phoo101 > l
  1  select 'alter table '|| owner || '.' ||table_name|| ' move parallel 16 LOB ('||COLUMN_NAME ||') STORE AS (tablespace OOXD);'
  2* from DBA_LOBS where tablespace_name='OOXD_MV'
RABO_USER @ srv0phoo101 > /
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                                                           
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                            
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                        
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                           
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                                                          
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                                                                  
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                                                               
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                     
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                                                             
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CP_FILES_ROLLBACK move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_SUSPENDED_EXECUTIONS move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_FINISHED_BRANCHES move parallel 16 LOB (BRANCH_EXCEPTION) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_FINISHED_BRANCHES move parallel 16 LOB (BRANCH_CONTEXT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_EXECUTION_BOUND_INPUTS move parallel 16 LOB (BIG_VALUE) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_STEP_LOG_ENDED move parallel 16 LOB (TRANSITION_DESCRIPTION_BIG_C) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_FLOW_EVENT move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_BLOB_TRIGGERS move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                     
alter table OWNER_OOX.OO_BKP9_BUILD_INFO move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_BKP9_DASHBOARD_DEF move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_BKP9_FLOW_VARS move parallel 16 LOB (VAR_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_BKP9_GROUPS move parallel 16 LOB (ANNOTATION) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_BKP9_GROUPS move parallel 16 LOB (MAPPINGS) STORE AS (tablespace OOXD);                                                                                                        
alter table OWNER_OOX.OO_BKP9_KEYVAL move parallel 16 LOB (META) STORE AS (tablespace OOXD);                                                                                                            
alter table OWNER_OOX.OO_BKP9_KEYVAL move parallel 16 LOB (VALUE) STORE AS (tablespace OOXD);                                                                                                           
alter table OWNER_OOX.OO_BKP9_QRTZ_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_BKP9_QRTZ_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_BKP9_USERS move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (RESULT_STRING) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (SCRIPTLET_RESULT_STRING) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (BOUND_INPUTS) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (TRANSITION_STRING) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (EXCEPTION_TRACE) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (STEP_CONTEXT) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                      

75 rows selected.

RABO_USER @ srv0phoo101 > /
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                                                           
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                            
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                        
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                           
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                                                          
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                                                                  
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                                                               
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                     
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                                                             
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CP_FILES_ROLLBACK move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_SUSPENDED_EXECUTIONS move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_FINISHED_BRANCHES move parallel 16 LOB (BRANCH_EXCEPTION) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_FINISHED_BRANCHES move parallel 16 LOB (BRANCH_CONTEXT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_EXECUTION_BOUND_INPUTS move parallel 16 LOB (BIG_VALUE) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_STEP_LOG_ENDED move parallel 16 LOB (TRANSITION_DESCRIPTION_BIG_C) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_FLOW_EVENT move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_BLOB_TRIGGERS move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                     
alter table OWNER_OOX.OO_BKP9_BUILD_INFO move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_BKP9_DASHBOARD_DEF move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_BKP9_FLOW_VARS move parallel 16 LOB (VAR_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_BKP9_USERS move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (RESULT_STRING) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (SCRIPTLET_RESULT_STRING) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (BOUND_INPUTS) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (TRANSITION_STRING) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (EXCEPTION_TRACE) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (STEP_CONTEXT) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                      

69 rows selected.

RABO_USER @ srv0phoo101 > l
  1  select 'alter table '|| owner || '.' ||table_name|| ' move parallel 16 LOB ('||COLUMN_NAME ||') STORE AS (tablespace OOXD);'
  2* from DBA_LOBS where tablespace_name='OOXD_MV'
RABO_USER @ srv0phoo101 > /
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                                                           
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                            
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                        
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                           
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                                                          
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                                                                  
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                                                               
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                     
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                                                             
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CP_FILES_ROLLBACK move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_STEP_LOG_ENDED move parallel 16 LOB (TRANSITION_DESCRIPTION_BIG_C) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_FLOW_EVENT move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_BLOB_TRIGGERS move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                     
alter table OWNER_OOX.OO_BKP9_BUILD_INFO move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_BKP9_DASHBOARD_DEF move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_BKP9_FLOW_VARS move parallel 16 LOB (VAR_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_BKP9_USERS move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (RESULT_STRING) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (SCRIPTLET_RESULT_STRING) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (BOUND_INPUTS) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (TRANSITION_STRING) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (EXCEPTION_TRACE) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (STEP_CONTEXT) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                      

65 rows selected.

RABO_USER @ srv0phoo101 > /
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                                                           
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                            
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                        
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                           
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                                                          
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                                                                  
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                                                               
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                     
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                                                             
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CP_FILES_ROLLBACK move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_STEP_LOG_ENDED move parallel 16 LOB (TRANSITION_DESCRIPTION_BIG_C) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_FLOW_EVENT move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_BLOB_TRIGGERS move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                     
alter table OWNER_OOX.OO_BKP9_BUILD_INFO move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_BKP9_DASHBOARD_DEF move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_BKP9_FLOW_VARS move parallel 16 LOB (VAR_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_BKP9_USERS move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (RESULT_STRING) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (SCRIPTLET_RESULT_STRING) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (BOUND_INPUTS) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (TRANSITION_STRING) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (EXCEPTION_TRACE) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (STEP_CONTEXT) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                      

65 rows selected.

RABO_USER @ srv0phoo101 > /
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                                                           
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                            
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                        
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                                                           
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                                                          
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                                                                  
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                                                               
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                                                                       
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                     
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                                                             
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                               
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                                                              
alter table OWNER_OOX.OO_CP_FILES_ROLLBACK move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                                                         
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                                                                       
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_STEP_LOG_ENDED move parallel 16 LOB (TRANSITION_DESCRIPTION_BIG_C) STORE AS (tablespace OOXD);                                                                                 
alter table OWNER_OOX.OO_FLOW_EVENT move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_BLOB_TRIGGERS move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                     
alter table OWNER_OOX.OO_BKP9_BUILD_INFO move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                                                                   
alter table OWNER_OOX.OO_BKP9_DASHBOARD_DEF move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                 
alter table OWNER_OOX.OO_BKP9_FLOW_VARS move parallel 16 LOB (VAR_VALUE) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_BKP9_USERS move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                                                         
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (RESULT_STRING) STORE AS (tablespace OOXD);                                                                                          
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (SCRIPTLET_RESULT_STRING) STORE AS (tablespace OOXD);                                                                                
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (BOUND_INPUTS) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (TRANSITION_STRING) STORE AS (tablespace OOXD);                                                                                      
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (EXCEPTION_TRACE) STORE AS (tablespace OOXD);                                                                                        
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (STEP_CONTEXT) STORE AS (tablespace OOXD);                                                                                           
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                  
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                      
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                                                                    
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                                                            
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                                                                      

65 rows selected.

RABO_USER @ srv0phoo101 > @table_info
owner.table: OWNER_OOX.OO_EXECUTION_BOUND_INPUTS

OWNER                          TABLE_NAME                               TABLESPACE_NAME      NUM_ROWS     BLOCKS LAST_ANAL                                      
------------------------------ ---------------------------------------- ------------------ ---------- ---------- ---------                                      
OWNER_OOX                      OO_EXECUTION_BOUND_INPUTS                OOXD                  3539910      34428 19-APR-20                                      

COLUMN_NAME                      type                 prec N NUM_DISTINCT    DENSITY AVG_COL_LEN HISTOGRAM                                                      
-------------------------------- -------------- ---------- - ------------ ---------- ----------- ---------------                                                
ID                               NUMBER(22)             38 N      3539910 2.8249E-07           8 NONE                                                           
INPUT_NAME                       VARCHAR2(1020)            N          624 .001602564           9 NONE                                                           
DOMAIN_TERM_NAME                 VARCHAR2(1020)            Y            0          0           0 NONE                                                           
VALUE                            VARCHAR2(4000)            Y       572352 1.7472E-06          31 NONE                                                           
BIG_VALUE                        CLOB(4000)                Y            0          0           2 NONE                                                           
EXECUTION_ID                     VARCHAR2(1020)            Y      2036736 4.9098E-07          12 NONE                                                           

INDEX_NAME                                                                                                                       UNIQUENES   P                  
-------------------------------------------------------------------------------------------------------------------------------- --------- ---                  
COLUMN_NAME          DISTINCT_KEYS CLUSTERING_FACTOR                                                                                                            
-------------------- ------------- -----------------                                                                                                            
PK_OO_EXECUTION_BOUND_INPUTS                                                                                                     UNIQUE      1                  
ID                         3731368           2061883                                                                                                            
                                                                                                                                                                
EXEC_BND_INPUTS_EXEC_ID                                                                                                          NONUNIQUE   1                  
EXECUTION_ID               2160498           2102014                                                                                                            
                                                                                                                                                                
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > @table_info
owner.table: OWNER_OOX.OO_STEP_LOG_ENDED

OWNER                          TABLE_NAME                               TABLESPACE_NAME      NUM_ROWS     BLOCKS LAST_ANAL                                      
------------------------------ ---------------------------------------- ------------------ ---------- ---------- ---------                                      
OWNER_OOX                      OO_STEP_LOG_ENDED                        OOXD                324021105   11390868 25-APR-20                                      

COLUMN_NAME                      type                 prec N NUM_DISTINCT    DENSITY AVG_COL_LEN HISTOGRAM                                                      
-------------------------------- -------------- ---------- - ------------ ---------- ----------- ---------------                                                
OPERATION_GROUP                  VARCHAR2(256)             Y           10         .1          13 NONE                                                           
WORKER_UUID                      VARCHAR2(256)             Y            5         .2          26 NONE                                                           
END_TIME                         NUMBER(22)             38 N     96763904 1.0334E-08           9 NONE                                                           
EXECUTION_TIME                   NUMBER(22)             38 Y       264640 3.7787E-06           3 NONE                                                           
RESPONSE_TYPE                    VARCHAR2(64)              Y            5         .2           8 NONE                                                           
RESPONSE_NAME                    VARCHAR2(1020)            Y          130 .007692308           7 NONE                                                           
TRANSITION_NAME                  VARCHAR2(1020)            Y          844 .001184834           8 NONE                                                           
TRANSITION_DESCRIPTION           VARCHAR2(4000)            Y       429568 2.3279E-06           3 NONE                                                           
TRANSITION_DESCRIPTION_BIG       NCLOB(4000)               Y            0          0           0 NONE                                                           
TRANSITION_VALUE                 FLOAT(22)             126 Y           35 .028571429           3 NONE                                                           
PRIMARY_RESULT                   VARCHAR2(4000)            Y     16902144 5.9164E-08          92 NONE                                                           
PRIMARY_RESULT_BIG               NCLOB(4000)               Y            0          0           0 NONE                                                           
ERROR_LIST                       NCLOB(4000)               Y            0          0           0 NONE                                                           
STEP_ENDED_HASH_ID               VARCHAR2(168)             N    313032704 3.1946E-09          41 NONE                                                           
STEP_STATUS                      VARCHAR2(64)              Y            2         .5          10 NONE                                                           
ID                               NUMBER(22)             38 N    316216678 3.1624E-09           8 NONE                                                           
ERROR_LIST_C                     CLOB(4000)                Y            0          0           2 NONE                                                           
PRIMARY_RESULT_BIG_C             CLOB(4000)                Y            0          0           2 NONE                                                           
TRANSITION_DESCRIPTION_BIG_C     CLOB(4000)                Y            0          0           2 NONE                                                           
ACTIVITY_GROUP                   VARCHAR2(1020)            Y            0          0           0 NONE                                                           
CONSUMER_WORKER_UUID             VARCHAR2(256)             Y            0          0           0 NONE                                                           
ROBOT_UUID                       VARCHAR2(256)             Y            0          0           0 NONE                                                           

INDEX_NAME                                                                                                                       UNIQUENES   P                  
-------------------------------------------------------------------------------------------------------------------------------- --------- ---                  
COLUMN_NAME          DISTINCT_KEYS CLUSTERING_FACTOR                                                                                                            
-------------------- ------------- -----------------                                                                                                            
PK_OO_STEP_END                                                                                                                   UNIQUE      1                  
ID                       312696774         285466542                                                                                                            
                                                                                                                                                                
STEP_LOG_EN_HASH                                                                                                                 NONUNIQUE   1                  
STEP_ENDED_HASH_ID       313032704         331423587                                                                                                            
                                                                                                                                                                
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > select 'alter table '|| owner || '.' ||table_name|| ' move parallel 16 LOB ('||COLUMN_NAME ||') STORE AS (tablespace OOXD);'
  2  from DBA_LOBS where tablespace_name='OOXD_MV';

'ALTERTABLE'||OWNER||'.'||TABLE_NAME||'MOVEPARALLEL16LOB('||COLUMN_NAME||')STOREAS(TABLESPACEOOXD);'                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                        
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                   
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                               
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                    
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                   
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                  
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                         
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                          
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                       
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                               
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                               
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                             
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                     
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                         
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                  
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CP_FILES_ROLLBACK move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                  
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                               
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                 
alter table OWNER_OOX.OO_STEP_LOG_ENDED move parallel 16 LOB (TRANSITION_DESCRIPTION_BIG_C) STORE AS (tablespace OOXD);                                         
alter table OWNER_OOX.OO_FLOW_EVENT move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                              
alter table OWNER_OOX.OO_BLOB_TRIGGERS move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                             
alter table OWNER_OOX.OO_BKP9_BUILD_INFO move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                           
alter table OWNER_OOX.OO_BKP9_DASHBOARD_DEF move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                         
alter table OWNER_OOX.OO_BKP9_FLOW_VARS move parallel 16 LOB (VAR_VALUE) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_BKP9_USERS move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                 
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (RESULT_STRING) STORE AS (tablespace OOXD);                                                  
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (SCRIPTLET_RESULT_STRING) STORE AS (tablespace OOXD);                                        
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (BOUND_INPUTS) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (TRANSITION_STRING) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (EXCEPTION_TRACE) STORE AS (tablespace OOXD);                                                
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (STEP_CONTEXT) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                              
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                              
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > set feedback on
RABO_USER @ srv0phoo101 > l
  1  select 'alter table '|| owner || '.' ||table_name|| ' move parallel 16 LOB ('||COLUMN_NAME ||') STORE AS (tablespace OOXD);'
  2* from DBA_LOBS where tablespace_name='OOXD_MV'
RABO_USER @ srv0phoo101 > /

'ALTERTABLE'||OWNER||'.'||TABLE_NAME||'MOVEPARALLEL16LOB('||COLUMN_NAME||')STOREAS(TABLESPACEOOXD);'                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                        
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                   
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                               
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                    
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                   
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                  
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                         
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                          
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                       
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                               
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                               
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                             
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                     
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                         
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                  
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CP_FILES_ROLLBACK move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                  
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                               
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                 
alter table OWNER_OOX.OO_STEP_LOG_ENDED move parallel 16 LOB (TRANSITION_DESCRIPTION_BIG_C) STORE AS (tablespace OOXD);                                         
alter table OWNER_OOX.OO_FLOW_EVENT move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                              
alter table OWNER_OOX.OO_BLOB_TRIGGERS move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                             
alter table OWNER_OOX.OO_BKP9_BUILD_INFO move parallel 16 LOB (BLOB_DATA) STORE AS (tablespace OOXD);                                                           
alter table OWNER_OOX.OO_BKP9_DASHBOARD_DEF move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                         
alter table OWNER_OOX.OO_BKP9_FLOW_VARS move parallel 16 LOB (VAR_VALUE) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_BKP9_USERS move parallel 16 LOB (XML_BLOB) STORE AS (tablespace OOXD);                                                                 
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (RESULT_STRING) STORE AS (tablespace OOXD);                                                  
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (SCRIPTLET_RESULT_STRING) STORE AS (tablespace OOXD);                                        
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (BOUND_INPUTS) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (TRANSITION_STRING) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (EXCEPTION_TRACE) STORE AS (tablespace OOXD);                                                
alter table OWNER_OOX.OO_BKP9_RUNSTEP_HISTORY move parallel 16 LOB (STEP_CONTEXT) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                              
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                              

65 rows selected.

RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > 
RABO_USER @ srv0phoo101 > /

'ALTERTABLE'||OWNER||'.'||TABLE_NAME||'MOVEPARALLEL16LOB('||COLUMN_NAME||')STOREAS(TABLESPACEOOXD);'                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                        
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                   
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                               
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                    
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                   
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                  
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                         
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                          
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                       
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                               
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                               
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                             
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                     
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                         
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                  
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_CONTENT_PACKS_AUD move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CP_FILES_ROLLBACK move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                  
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                               
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                 
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                              
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                              

52 rows selected.

RABO_USER @ srv0phoo101 > /

'ALTERTABLE'||OWNER||'.'||TABLE_NAME||'MOVEPARALLEL16LOB('||COLUMN_NAME||')STOREAS(TABLESPACEOOXD);'                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS2 move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_RUNNING_EXEC_CONFIGS move parallel 16 LOB (EXECUTION_CONFIGURATION) STORE AS (tablespace OOXD);                                        
alter table OWNER_OOX.OO_EXECUTION_INTERRUPTS move parallel 16 LOB (EXECUTION_INTERRUPT_REGISTRY) STORE AS (tablespace OOXD);                                   
alter table OWNER_OOX.OO_CACHED_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                               
alter table OWNER_OOX.OO_FLOW_GRAPH move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                    
alter table OWNER_OOX.OO_JOB_DETAILS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                
alter table OWNER_OOX.OO_TRIGGERS move parallel 16 LOB (JOB_DATA) STORE AS (tablespace OOXD);                                                                   
alter table OWNER_OOX.OO_CALENDARS move parallel 16 LOB (CALENDAR) STORE AS (tablespace OOXD);                                                                  
alter table OWNER_OOX.OO_WORKER_MONITOR move parallel 16 LOB (MONITOR_INFO) STORE AS (tablespace OOXD);                                                         
alter table OWNER_OOX.OO_AUDIT move parallel 16 LOB (DATA) STORE AS (tablespace OOXD);                                                                          
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (RESULT) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_RUNNING_EXECUTION_PLANS move parallel 16 LOB (EXECUTION_PLAN_ZIPPED) STORE AS (tablespace OOXD);                                       
alter table OWNER_OOX.OO_EXECUTION_STATES move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_STATE move parallel 16 LOB (EXECUTION_OBJECT) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEBUGGER_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                               
alter table OWNER_OOX.OO_PAUSE_DATA move parallel 16 LOB (PAUSE_DATA) STORE AS (tablespace OOXD);                                                               
alter table OWNER_OOX.OO_DEPLOYMENT_PROCESSES move parallel 16 LOB (DEPLOYMENT_RESULT) STORE AS (tablespace OOXD);                                              
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (FILE_CONTENT) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (DEPENDENCY_FILE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (PROPERTIES_FILE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_DEPLOYMENT_CP_FILES move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                             
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_DOMAIN_TERM_VALUES move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CONFIG_ITEM_VALUES move parallel 16 LOB (CLOB_VALUE) STORE AS (tablespace OOXD);                                                       
alter table OWNER_OOX.OO_FORM_ITEMS move parallel 16 LOB (DEFAULT_VALUE) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_ARTIFACTS move parallel 16 LOB (DATA_) STORE AS (tablespace OOXD);                                                                     
alter table OWNER_OOX.OO_CONTENT_PACKS_FILES move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (CONTENT_PACK_ZIP) STORE AS (tablespace OOXD);                                                      
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (DESCRIPTION) STORE AS (tablespace OOXD);                                                           
alter table OWNER_OOX.OO_CONTENT_PACKS move parallel 16 LOB (SIGN_DETAILS) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_DATA) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SYSTEM_PROPERTY_VALUE) STORE AS (tablespace OOXD);                                         
alter table OWNER_OOX.OO_DEPLOYED_ENTITIES_AUD move parallel 16 LOB (SOURCE_FILE) STORE AS (tablespace OOXD);                                                   
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_VALUE) STORE AS (tablespace OOXD);                                                 
alter table OWNER_OOX.OO_STEP_LOG_BINDINGS move parallel 16 LOB (BINDING_BIG_C_VALUE) STORE AS (tablespace OOXD);                                               
alter table OWNER_OOX.OO_CACHED_GRAPHS move parallel 16 LOB (GRAPH) STORE AS (tablespace OOXD);                                                                 
alter table OWNER_OOX.OO_EXECUTION_STATES_1 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_EXECUTION_STATES_2 move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                          
alter table OWNER_OOX.OO_EXECUTION_EVENTS move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                              
alter table OWNER_OOX.OO_EXECUTION_EVENTS_1 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_2 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_3 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_EXECUTION_EVENTS_4 move parallel 16 LOB (DATA4) STORE AS (tablespace OOXD);                                                            
alter table OWNER_OOX.OO_RAS_UPGRADE_PACKAGES move parallel 16 LOB (RAS_PACKAGE) STORE AS (tablespace OOXD);                                                    
alter table OWNER_OOX.OO_STEP_EXEC_DATA move parallel 16 LOB (PAYLOAD) STORE AS (tablespace OOXD);                                                              

48 rows selected.

RABO_USER @ srv0phoo101 > exit
