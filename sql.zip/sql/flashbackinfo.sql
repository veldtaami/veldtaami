col OLDEST_FLASHBACK_TIME format a20
SELECT OLDEST_FLASHBACK_SCN, to_char(OLDEST_FLASHBACK_TIME,'YYYY-MM-DD HH24:MI:SS') OLDEST_TIME
      FROM V$FLASHBACK_DATABASE_LOG;

SELECT ESTIMATED_FLASHBACK_SIZE FROM V$FLASHBACK_DATABASE_LOG;

prompt CURRENT SPACE USAGE
select file_type, space_used*percent_space_used/100/1024/1024 used,
space_reclaimable*percent_space_reclaimable/100/1024/1024 reclaimable, frau.number_of_files
from v$recovery_file_dest rfd, v$flash_recovery_area_usage frau where file_type like '%FLASHBACK%';

