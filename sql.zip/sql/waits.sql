
SET LINESIZE 200
SET PAGESIZE 1000

COLUMN username FORMAT A20
COLUMN event FORMAT A30
COLUMN wait_class FORMAT A15

prompt " waits die niet idle zijn "
SELECT NVL(s.username, '(oracle)') AS username,
       s.sid,
       s.serial#,
       sw.event,
       sw.wait_class,
       sw.wait_time,
       sw.seconds_in_wait,
       sw.state
FROM   gv$session_wait sw,
       gv$session s
WHERE  s.sid = sw.sid and sw.wait_class <> 'Idle'
ORDER BY sw.seconds_in_wait DESC;

select  wait_class,
       sum(total_waits), sum(time_waited)
    from gv$session_wait_class
    where wait_class !='Idle'
    group by wait_class
    order by 3 desc;
	
	
col owner format a10
col object_name format a20
col tsname format a10
col value format 9999999
col subobject_name for a40
col object_type for a20
prompt  "Buffer Busy Waits op welke objecten" 
show parameter db_cache_size

SELECT *
FROM (
  SELECT owner, object_name, subobject_name, object_type, tablespace_name TSNAME, value
  FROM gv$segment_statistics
  WHERE statistic_name='buffer busy waits'
  ORDER BY value DESC)
WHERE ROWNUM < 11;

column event format a22
select event,
       total_waits,
       average_wait,
       time_waited_micro,
       wait_class
from v$system_event
where event in ('read by other session','buffer busy waits')
/


prompt " totaal wait voor genoemde event" 
col event for a30
select * from (
select active_session_history.event,
sum(active_session_history.wait_time +
active_session_history.time_waited) ttl_wait_time
from gv$active_session_history active_session_history
where active_session_history.event is not null
group by active_session_history.event
order by 2 desc)
where rownum <= 10;


prompt " invalidations is een performance vreter" 
select inst_id,type,sum(invalidations) from gV$DB_OBJECT_CACHE group by inst_id,type having sum(invalidations) > 20 order by 3;
 