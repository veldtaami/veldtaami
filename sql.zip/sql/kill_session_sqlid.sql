accept query_id prompt "Enter sqlid to KILL: "

select username,  sid, serial#, inst_id  from gv$session where SQL_ID=upper('&&query_id'); 
select 'alter system kill session ''' || sid || ',' || serial# || ',@'||  inst_id || ''';' from gv$session where sql_id=('&&query_id'); 