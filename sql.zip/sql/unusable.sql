
select index_name, owner, table_name from dba_indexes where status = 'UNUSABLE';
select 'alter index ' || owner || '.' ||index_name || ' rebuild online parallel 8;' from dba_indexes where status = 'UNUSABLE';