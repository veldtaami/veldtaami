-- speciaal voor de snapshot db nu. 
select status, to_char(created,'DD-MM-YYYY HH:MI') from system.SNAPSHOT_STATUS;  

select sysdate from dual;