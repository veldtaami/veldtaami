set feedback off
set pagesize 10000
set lines 200
select
  tablespace_name, BLOCK_SIZE,
  status,
  contents,
  extent_management,
  segment_space_management
from
  dba_tablespaces
order by tablespace_name
/
@sqlplusdefaults
