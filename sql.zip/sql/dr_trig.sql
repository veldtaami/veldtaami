system@bis3o> /

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger BIS.BIS_DMV_BRIUD;                                                 
drop trigger BIS.BIS_DMV_ARIUD;                                                 
drop trigger BIS.BIS_VRB_BSIUD;                                                 
drop trigger BIS.BIS_HLP_ARIUD;                                                 
drop trigger BIS.BIS_ACI_BRIUD;                                                 
drop trigger BIS.BIS_MDI_BRIUD;                                                 
drop trigger BIS.BIS_VRB_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger BIS.BIS_VRB_ARIUD;                                                 
drop trigger BIS.BIS_VRB_BRIUD;                                                 
drop trigger BIS.BIS_SCH_ARIUD;                                                 
drop trigger BIS.BIS_SCH_BSIUD;                                                 
drop trigger BIS.BIS_SCH_ASIUD;                                                 
drop trigger BIS.BIS_MLD_BRIUD;                                                 
drop trigger BIS.BIS_DMN_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger BIS.BIS_MLD_BSIUD;                                                 
drop trigger BIS.BIS_MLD_ASIUD;                                                 
drop trigger BIS.BIS_MLD_ARIUD;                                                 
drop trigger BIS.BIS_JBL_BSIUD;                                                 
drop trigger BIS.BIS_JBL_BRIUD;                                                 
drop trigger BIS.BIS_SCH_BRIUD;                                                 
drop trigger BIS.BIS_JBL_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger BIS.BIS_DMO_ASIUD;                                                 
drop trigger BIS.BIS_DMO_ARIUD;                                                 
drop trigger BIS.BIS_DMO_BRIUD;                                                 
drop trigger BIS.BIS_ACA_ARIUD;                                                 
drop trigger BIS.BIS_DMO_BSIUD;                                                 
drop trigger BIS.BIS_ACI_ASIUD;                                                 
drop trigger BIS.BIS_ACI_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger BIS.BIS_ACI_BSIUD;                                                 
drop trigger BIS.BIS_HLP_BSIUD;                                                 
drop trigger BIS.BIS_HLP_ASIUD;                                                 
drop trigger BIS.BIS_HLP_BRIUD;                                                 
drop trigger BIS.BIS_GRP_ASIUD;                                                 
drop trigger BIS.BIS_GRP_BRIUD;                                                 
drop trigger BIS.BIS_GRP_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger BIS.BIS_MDI_ASIUD;                                                 
drop trigger BIS.BIS_MDI_BSIUD;                                                 
drop trigger BIS.BIS_MDI_ARIUD;                                                 
drop trigger BIS.BIS_TKS_BRIUD;                                                 
drop trigger BIS.BIS_TKS_ASIUD;                                                 
drop trigger BIS.BIS_TKS_ARIUD;                                                 
drop trigger BIS.BIS_TKS_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger BIS.BIS_GRP_BSIUD;                                                 
drop trigger BIS.BIS_SCA_ASIUD;                                                 
drop trigger BIS.BIS_SCA_ARIUD;                                                 
drop trigger BIS.BIS_SCA_BRIUD;                                                 
drop trigger BIS.BIS_SCA_BSIUD;                                                 
drop trigger BIS.BIS_DMV_ASIUD;                                                 
drop trigger BIS.BIS_DMV_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger BIS.BIS_ACA_BRIUD;                                                 
drop trigger BIS.BIS_ACA_ASIUD;                                                 
drop trigger BIS.BIS_ACA_BSIUD;                                                 
drop trigger IAR.IAR_OEN_ASIUD;                                                 
drop trigger IAR.IAR_EXD_BRIUD;                                                 
drop trigger IAR.IAR_OEN_BSIUD;                                                 
drop trigger IAR.IAR_EXD_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IAR.IAR_OEN_BRIUD;                                                 
drop trigger IAR.IAR_EXD_ASIUD;                                                 
drop trigger IOS.IOS_RLT_ASIUD;                                                 
drop trigger IOS.IOS_TET_BRIUD;                                                 
drop trigger IOS.IOS_RLT_ARIUD;                                                 
drop trigger IOS.IOS_RLT_BRIUD;                                                 
drop trigger IOS.IOS_RLT_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_MDF_ASIUD;                                                 
drop trigger IOS.IOS_MDF_BRIUD;                                                 
drop trigger IOS.IOS_MDF_ARIUD;                                                 
drop trigger IOS.IOS_MDF_BSIUD;                                                 
drop trigger IOS.IOS_INV_ARIUD;                                                 
drop trigger IOS.IOS_TMM_ARIUD;                                                 
drop trigger IOS.IOS_INV_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_INV_ASIUD;                                                 
drop trigger IOS.IOS_ELM_ARIUD;                                                 
drop trigger IOS.IOS_ELM_BRIUD;                                                 
drop trigger IOS.IOS_ELM_ASIUD;                                                 
drop trigger IOS.IOS_ARE_ASIUD;                                                 
drop trigger IOS.IOS_ARE_BSIUD;                                                 
drop trigger IOS.IOS_ELR_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_ELR_ARIUD;                                                 
drop trigger IOS.IOS_ELR_BRIUD;                                                 
drop trigger IOS.IOS_EET_BRIUD;                                                 
drop trigger IOS.IOS_BTF_ASIUD;                                                 
drop trigger IOS.IOS_ELT_BSIUD;                                                 
drop trigger IOS.IOS_ELT_ASIUD;                                                 
drop trigger IOS.IOS_REG_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_REG_ARIUD;                                                 
drop trigger IOS.IOS_REG_BRIUD;                                                 
drop trigger IOS.IOS_REG_BSIUD;                                                 
drop trigger IOS.IOS_ELM_BSIUD;                                                 
drop trigger IOS.IOS_EAR_ASIUD;                                                 
drop trigger IOS.IOS_EAR_ARIUD;                                                 
drop trigger IOS.IOS_ELA_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_ELA_BSIUD;                                                 
drop trigger IOS.IOS_ELA_BRIUD;                                                 
drop trigger IOS.IOS_MSF_ASIUD;                                                 
drop trigger IOS.IOS_MSF_BRIUD;                                                 
drop trigger IOS.IOS_MSF_ARIUD;                                                 
drop trigger IOS.IOS_SKT_ARIUD;                                                 
drop trigger IOS.IOS_TZG_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_TZG_ARIUD;                                                 
drop trigger IOS.IOS_TZG_ASIUD;                                                 
drop trigger IOS.IOS_TZG_BSIUD;                                                 
drop trigger IOS.IOS_MDW_ASIUD;                                                 
drop trigger IOS.IOS_TMM_BSIUD;                                                 
drop trigger IOS.IOS_FNC_BRIUD;                                                 
drop trigger IOS.IOS_TMM_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_TMM_BRIUD;                                                 
drop trigger IOS.IOS_BTR_BRIUD;                                                 
drop trigger IOS.IOS_BTR_BSIUD;                                                 
drop trigger IOS.IOS_ART_ASIUD;                                                 
drop trigger IOS.IOS_ELR_BSIUD;                                                 
drop trigger IOS.IOS_ART_BRIUD;                                                 
drop trigger IOS.IOS_ART_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_ART_ARIUD;                                                 
drop trigger IOS.IOS_KNA_BSIUD;                                                 
drop trigger IOS.IOS_ADR_BRIUD;                                                 
drop trigger IOS.IOS_KNA_BRIUD;                                                 
drop trigger IOS.IOS_TMS_BSIUD;                                                 
drop trigger IOS.IOS_ELA_ARIUD;                                                 
drop trigger IOS.IOS_TMS_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_TMS_ARIUD;                                                 
drop trigger IOS.IOS_TMS_ASIUD;                                                 
drop trigger IOS.IOS_INK_ARIUD;                                                 
drop trigger IOS.IOS_INK_ASIUD;                                                 
drop trigger IOS.IOS_INK_BSIUD;                                                 
drop trigger IOS.IOS_INK_BRIUD;                                                 
drop trigger IOS.IOS_MSF_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_PLT_BRIUD;                                                 
drop trigger IOS.IOS_PLT_ARIUD;                                                 
drop trigger IOS.IOS_LNK_BRIUD;                                                 
drop trigger IOS.IOS_LNK_ASIUD;                                                 
drop trigger IOS.IOS_ELF_BSIUD;                                                 
drop trigger IOS.IOS_ELF_ARIUD;                                                 
drop trigger IOS.IOS_ELF_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_ELF_ASIUD;                                                 
drop trigger IOS.IOS_MDV_ARIUD;                                                 
drop trigger IOS.IOS_MDW_BSIUD;                                                 
drop trigger IOS.IOS_MDV_BRIUD;                                                 
drop trigger IOS.IOS_MDV_BSIUD;                                                 
drop trigger IOS.IOS_MDV_ASIUD;                                                 
drop trigger IOS.IOS_TMK_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_TMK_ASIUD;                                                 
drop trigger IOS.IOS_TMK_BSIUD;                                                 
drop trigger IOS.IOS_TMK_BRIUD;                                                 
drop trigger IOS.IOS_LND_ASIUD;                                                 
drop trigger IOS.IOS_BTR_ARIUD;                                                 
drop trigger IOS.IOS_BTR_ASIUD;                                                 
drop trigger IOS.IOS_TET_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_TET_ARIUD;                                                 
drop trigger IOS.IOS_TET_ASIUD;                                                 
drop trigger IOS.IOS_EET_ARIUD;                                                 
drop trigger IOS.IOS_EET_BSIUD;                                                 
drop trigger IOS.IOS_EET_ASIUD;                                                 
drop trigger IOS.IOS_TEM_ARIUD;                                                 
drop trigger IOS.IOS_TEM_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_TEM_ASIUD;                                                 
drop trigger IOS.IOS_TEM_BSIUD;                                                 
drop trigger IOS.IOS_SKT_BSIUD;                                                 
drop trigger IOS.IOS_SKT_ASIUD;                                                 
drop trigger IOS.IOS_SKT_BRIUD;                                                 
drop trigger IOS.IOS_GMN_ASIUD;                                                 
drop trigger IOS.IOS_GMN_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_ADR_ASIUD;                                                 
drop trigger IOS.IOS_ADR_BSIUD;                                                 
drop trigger IOS.IOS_ELE_ARIUD;                                                 
drop trigger IOS.IOS_ADR_ARIUD;                                                 
drop trigger IOS.IOS_ELE_BSIUD;                                                 
drop trigger IOS.IOS_GMN_ARIUD;                                                 
drop trigger IOS.IOS_GMN_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_SPI_ASIUD;                                                 
drop trigger IOS.IOS_SPI_BSIUD;                                                 
drop trigger IOS.IOS_SPI_ARIUD;                                                 
drop trigger IOS.IOS_KNA_ARIUD;                                                 
drop trigger IOS.IOS_SPI_BRIUD;                                                 
drop trigger IOS.IOS_KNA_ASIUD;                                                 
drop trigger IOS.IOS_MDW_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_MDW_ARIUD;                                                 
drop trigger IOS.IOS_LND_ARIUD;                                                 
drop trigger IOS.IOS_LND_BRIUD;                                                 
drop trigger IOS.IOS_LND_BSIUD;                                                 
drop trigger IOS.IOS_LNK_BSIUD;                                                 
drop trigger IOS.IOS_LNK_ARIUD;                                                 
drop trigger IOS.IOS_ELT_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_ELT_BRIUD;                                                 
drop trigger IOS.IOS_TGR_BRIUD;                                                 
drop trigger IOS.IOS_TGR_ARIUD;                                                 
drop trigger IOS.IOS_EAR_BSIUD;                                                 
drop trigger IOS.IOS_EAR_BRIUD;                                                 
drop trigger IOS.IOS_ELE_BRIUD;                                                 
drop trigger IOS.IOS_PLT_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_PLT_BSIUD;                                                 
drop trigger IOS.IOS_ELE_ASIUD;                                                 
drop trigger IOS.IOS_MDS_ARIUD;                                                 
drop trigger IOS.IOS_MDS_ASIUD;                                                 
drop trigger IOS.IOS_MDS_BRIUD;                                                 
drop trigger IOS.IOS_MDS_BSIUD;                                                 
drop trigger IOS.IOS_TGR_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_TGR_BSIUD;                                                 
drop trigger IOS.IOS_FNC_ARIUD;                                                 
drop trigger IOS.IOS_FNC_BSIUD;                                                 
drop trigger IOS.IOS_FNC_ASIUD;                                                 
drop trigger IOS.IOS_ARE_BRIUD;                                                 
drop trigger IOS.IOS_INV_BRIUD;                                                 
drop trigger IOS.IOS_ARE_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS.IOS_BTF_BRIUD;                                                 
drop trigger IOS.IOS_BTF_BSIUD;                                                 
drop trigger IOS.IOS_BTF_ARIUD;                                                 
drop trigger IPC.IPC_NTF_ARIUD;                                                 
drop trigger IPC.IPC_NTF_ASIUD;                                                 
drop trigger IPC.IPC_ACT_ASIUD;                                                 
drop trigger IPC.IPC_NTF_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IPC.IPC_MBB_BSIUD;                                                 
drop trigger IPC.IPC_MBB_BRIUD;                                                 
drop trigger IPC.IPC_NTF_BRIUD;                                                 
drop trigger IPC.IPC_MBB_ARIUD;                                                 
drop trigger IPC.IPC_MBB_ASIUD;                                                 
drop trigger IPC.IPC_ACT_BSIUD;                                                 
drop trigger IPC.IPC_ACT_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IPC.IPC_MDA_BSIUD;                                                 
drop trigger IPC.IPC_MDA_BRIUD;                                                 
drop trigger IPC.IPC_MDA_ASIUD;                                                 
drop trigger IPC.IPC_MDA_ARIUD;                                                 
drop trigger IPC.IPC_MDN_ASIUD;                                                 
drop trigger IPC.IPC_OEA_BRIUD;                                                 
drop trigger IPC.IPC_ACT_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IPC.IPC_NMAU_ARIUD;                                                
drop trigger IPC.IPC_NMAU_BRIUD;                                                
drop trigger IPC.IPC_NMAU_ASIUD;                                                
drop trigger IPC.IPC_NMAU_BSIUD;                                                
drop trigger IPC.IPC_OEA_ARIUD;                                                 
drop trigger IPC.IPC_OEA_BSIUD;                                                 
drop trigger IPC.IPC_OEA_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IPC.IPC_MDN_ARIUD;                                                 
drop trigger IPC.IPC_MDN_BSIUD;                                                 
drop trigger IPC.IPC_MDN_BRIUD;                                                 
drop trigger IPC.IPC_SVT_BRIUD;                                                 
drop trigger IPC.IPC_SVT_ARIUD;                                                 
drop trigger IPC.IPC_SVT_BSIUD;                                                 
drop trigger IPC.IPC_SVT_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_RPO_BSIUD;                                                 
drop trigger ITS.ITS_IGC_BRIUD;                                                 
drop trigger ITS.ITS_IGC_ASIUD;                                                 
drop trigger ITS.ITS_IGC_BSIUD;                                                 
drop trigger ITS.ITS_OTS_ASIUD;                                                 
drop trigger ITS.ITS_IGC_ARIUD;                                                 
drop trigger ITS.ITS_OTS_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_OTS_BRIUD;                                                 
drop trigger ITS.ITS_OTS_BSIUD;                                                 
drop trigger ITS.ITS_STO_ARIUD;                                                 
drop trigger ITS.ITS_SDS_ARIUD;                                                 
drop trigger ITS.ITS_SDS_BRIUD;                                                 
drop trigger ITS.ITS_STA_BSIUD;                                                 
drop trigger ITS.ITS_ONI_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_ONI_BRIUD;                                                 
drop trigger ITS.ITS_ONI_ARIUD;                                                 
drop trigger ITS.ITS_IIT_ARIUD;                                                 
drop trigger ITS.ITS_IIT_BRIUD;                                                 
drop trigger ITS.ITS_IIT_BSIUD;                                                 
drop trigger ITS.ITS_IIT_ASIUD;                                                 
drop trigger ITS.ITS_RTO_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_ONT_BRIUD;                                                 
drop trigger ITS.ITS_ETN_BSIUD;                                                 
drop trigger ITS.ITS_RPO_ASIUD;                                                 
drop trigger ITS.ITS_RPO_BRIUD;                                                 
drop trigger ITS.ITS_ORT_ARIUD;                                                 
drop trigger ITS.ITS_ORT_BRIUD;                                                 
drop trigger ITS.ITS_STP_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_STP_ASIUD;                                                 
drop trigger ITS.ITS_OTK_BSIUD;                                                 
drop trigger ITS.ITS_OTK_ASIUD;                                                 
drop trigger ITS.ITS_OTK_ARIUD;                                                 
drop trigger ITS.ITS_AFS_BSIUD;                                                 
drop trigger ITS.ITS_AFS_BRIUD;                                                 
drop trigger ITS.ITS_AFS_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_AFS_ASIUD;                                                 
drop trigger ITS.ITS_ETN_ARIUD;                                                 
drop trigger ITS.ITS_ETN_ASIUD;                                                 
drop trigger ITS.ITS_ETN_BRIUD;                                                 
drop trigger ITS.ITS_NVL_ASIUD;                                                 
drop trigger ITS.ITS_ONE_BSIUD;                                                 
drop trigger ITS.ITS_VRI_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_VRI_BSIUD;                                                 
drop trigger ITS.ITS_VRI_ASIUD;                                                 
drop trigger ITS.ITS_SSP_ARIUD;                                                 
drop trigger ITS.ITS_SSP_BSIUD;                                                 
drop trigger ITS.ITS_SSP_ASIUD;                                                 
drop trigger ITS.ITS_OWM_BRIUD;                                                 
drop trigger ITS.ITS_OWM_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_OWM_BSIUD;                                                 
drop trigger ITS.ITS_ONT_ASIUD;                                                 
drop trigger ITS.ITS_ONT_BSIUD;                                                 
drop trigger ITS.ITS_ONT_ARIUD;                                                 
drop trigger ITS.ITS_STP_BSIUD;                                                 
drop trigger ITS.ITS_STP_ARIUD;                                                 
drop trigger ITS.ITS_ONE_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_ONE_ASIUD;                                                 
drop trigger ITS.ITS_ONE_ARIUD;                                                 
drop trigger ITS.ITS_VRI_BRIUD;                                                 
drop trigger ITS.ITS_RPO_ARIUD;                                                 
drop trigger ITS.ITS_RPI_BSIUD;                                                 
drop trigger ITS.ITS_RPI_ASIUD;                                                 
drop trigger ITS.ITS_ONI_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_RPI_BRIUD;                                                 
drop trigger ITS.ITS_RPI_ARIUD;                                                 
drop trigger ITS.ITS_ONS_BSIUD;                                                 
drop trigger ITS.ITS_ONS_BRIUD;                                                 
drop trigger ITS.ITS_ONS_ASIUD;                                                 
drop trigger ITS.ITS_ONS_ARIUD;                                                 
drop trigger ITS.ITS_SDS_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_SDS_ASIUD;                                                 
drop trigger ITS.ITS_RTI_BRIUD;                                                 
drop trigger ITS.ITS_RTI_ASIUD;                                                 
drop trigger ITS.ITS_RTI_BSIUD;                                                 
drop trigger ITS.ITS_RTI_ARIUD;                                                 
drop trigger ITS.ITS_RPT_ASIUD;                                                 
drop trigger ITS.ITS_ROG_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_RPT_BSIUD;                                                 
drop trigger ITS.ITS_ROG_ARIUD;                                                 
drop trigger ITS.ITS_ROG_BSIUD;                                                 
drop trigger ITS.ITS_ROG_BRIUD;                                                 
drop trigger ITS.ITS_IND_BSIUD;                                                 
drop trigger ITS.ITS_IND_BRIUD;                                                 
drop trigger ITS.ITS_SDP_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_SDP_ASIUD;                                                 
drop trigger ITS.ITS_SDP_ARIUD;                                                 
drop trigger ITS.ITS_SDP_BSIUD;                                                 
drop trigger ITS.ITS_OTK_BRIUD;                                                 
drop trigger ITS.ITS_OWA_BRIUD;                                                 
drop trigger ITS.ITS_OWA_BSIUD;                                                 
drop trigger ITS.ITS_TZP_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_OWA_ASIUD;                                                 
drop trigger ITS.ITS_TZP_BSIUD;                                                 
drop trigger ITS.ITS_TZP_ASIUD;                                                 
drop trigger ITS.ITS_OOR_BRIUD;                                                 
drop trigger ITS.ITS_OOR_ASIUD;                                                 
drop trigger ITS.ITS_OOR_BSIUD;                                                 
drop trigger ITS.ITS_STO_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_STO_ASIUD;                                                 
drop trigger ITS.ITS_STO_BSIUD;                                                 
drop trigger ITS.ITS_OOR_ARIUD;                                                 
drop trigger ITS.ITS_OMD_ASIUD;                                                 
drop trigger ITS.ITS_OMD_BRIUD;                                                 
drop trigger ITS.ITS_OMD_ARIUD;                                                 
drop trigger ITS.ITS_OMD_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_ORT_BSIUD;                                                 
drop trigger ITS.ITS_STR_ASIUD;                                                 
drop trigger ITS.ITS_STR_BSIUD;                                                 
drop trigger ITS.ITS_ORT_ASIUD;                                                 
drop trigger ITS.ITS_STR_ARIUD;                                                 
drop trigger ITS.ITS_STR_BRIUD;                                                 
drop trigger ITS.ITS_RPT_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_RPT_BRIUD;                                                 
drop trigger ITS.ITS_OWO_BSIUD;                                                 
drop trigger ITS.ITS_OWO_ASIUD;                                                 
drop trigger ITS.ITS_OWO_BRIUD;                                                 
drop trigger ITS.ITS_SSP_BRIUD;                                                 
drop trigger ITS.ITS_NAV_BSIUD;                                                 
drop trigger ITS.ITS_NAV_ARIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_NAV_ASIUD;                                                 
drop trigger ITS.ITS_NAV_BRIUD;                                                 
drop trigger ITS.ITS_NVL_ARIUD;                                                 
drop trigger ITS.ITS_NVL_BRIUD;                                                 
drop trigger ITS.ITS_NVL_BSIUD;                                                 
drop trigger ITS.ITS_IND_ASIUD;                                                 
drop trigger ITS.ITS_TZP_BRIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_IND_ARIUD;                                                 
drop trigger ITS.ITS_STA_BRIUD;                                                 
drop trigger ITS.ITS_STA_ARIUD;                                                 
drop trigger ITS.ITS_STA_ASIUD;                                                 
drop trigger ITS.ITS_RTO_ARIUD;                                                 
drop trigger ITS.ITS_RTO_BRIUD;                                                 
drop trigger ITS.ITS_RTO_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_DIM_BRIUD;                                                 
drop trigger ITS.ITS_DIM_ASIUD;                                                 
drop trigger ITS.ITS_DIM_BSIUD;                                                 
drop trigger ITS.ITS_DIM_ARIUD;                                                 
drop trigger ITS.ITS_ONG_ARIUD;                                                 
drop trigger ITS.ITS_ONG_BRIUD;                                                 
drop trigger ITS.ITS_ONG_BSIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_ONG_ASIUD;                                                 
drop trigger ITS.ITS_SSS_ASIUD;                                                 
drop trigger ITS.ITS_SSS_ARIUD;                                                 
drop trigger ITS.ITS_SSS_BSIUD;                                                 
drop trigger ITS.ITS_SSS_BRIUD;                                                 
drop trigger ITS.ITS_STT_ARIUD;                                                 
drop trigger ITS.ITS_STT_ASIUD;                                                 

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger ITS.ITS_STT_BRIUD;                                                 
drop trigger ITS.ITS_STT_BSIUD;                                                 
drop trigger ITS.ITS_ARR_BSIUD;                                                 
drop trigger ITS.ITS_ARR_ARIUD;                                                 
drop trigger ITS.ITS_ARR_ASIUD;                                                 
drop trigger ITS.ITS_ARR_BRIUD;                                                 
drop trigger IOS_GO.IOS_ELB_ASIUD;                                              

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS_GO.IOS_ELB_BSIUD;                                              
drop trigger IOS_GO.IOS_ELB_ARIUD;                                              
drop trigger IOS_GO.IOS_ELB_BRIUD;                                              
drop trigger IOS_GO.IOS_ELA_BRIUD;                                              
drop trigger IOS_GO.IOS_ELA_ASIUD;                                              
drop trigger IOS_GO.IOS_ELA_BSIUD;                                              
drop trigger IOS_GO.IOS_ELA_ARIUD;                                              

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS_GO.IOS_ELE_BSIUD;                                              
drop trigger IOS_GO.IOS_ELE_BRIUD;                                              
drop trigger IOS_GO.IOS_ELE_ASIUD;                                              
drop trigger IOS_GO.IOS_ELE_ARIUD;                                              
drop trigger IOS_GO.IOS_ELM_ASIUD;                                              
drop trigger IOS_GO.IOS_ELM_BRIUD;                                              
drop trigger IOS_GO.IOS_ELM_ARIUD;                                              

'DROPTRIGGER'||OWNER||'.'||TRIGGER_NAME||';'                                    
---------------------------------------------------------------------------     
drop trigger IOS_GO.IOS_ELM_BSIUD;                                              

407 rijen zijn geselecteerd.

system@bis3o> spool off
