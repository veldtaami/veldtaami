@defaults.sql

--SELECT O.OBJECT_NAME, S.SID, S.SERIAL#, P.SPID, S.PROGRAM,S.USERNAME,
--S.MACHINE,S.PORT , S.LOGON_TIME,SQ.SQL_FULLTEXT 
--FROM V$LOCKED_OBJECT L, DBA_OBJECTS O, V$SESSION S, 
--V$PROCESS P, V$SQL SQ 
--WHERE L.OBJECT_ID = O.OBJECT_ID 
--AND L.SESSION_ID = S.SID AND S.PADDR = P.ADDR 
--AND S.SQL_ADDRESS = SQ.ADDRESS;


select object_name, s.sid, s.serial#, p.spid 
from v$locked_object l, dba_objects o, v$session s, v$process p
where l.object_id = o.object_id and l.session_id = s.sid and s.paddr = p.addr;


--ALTER SESSION SET ddl_lock_timeout=30;