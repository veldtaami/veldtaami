https://www.techonthenet.com/oracle/primary_keys.php

ALTER INDEX index_name RENAME TO new_index_name;

DROP INDEX index_name;

ALTER INDEX index_name ON table_name DISABLE;

ALTER TABLE index_name ON table_name REBUILD; -- ONLINE

ALTER TABLE table_name
ADD CONSTRAINT constraint_name PRIMARY KEY (column1, column2, ... column_n);

ALTER TABLE table_name
DROP CONSTRAINT constraint_name;


ALTER TABLE supplier
DROP CONSTRAINT supplier_pk;

ALTER TABLE table_name
DISABLE CONSTRAINT constraint_name;

ALTER TABLE table_name
ENABLE CONSTRAINT constraint_name;