
@defaults.sql

prompt  "USERS de de rol DBA hebben."
@dba_users.sql

prompt  "Users die  RESOURCE rechten hebben "
@resource_roles.sql


prompt voor inspectie: Bestaat de Deploy_user, en wat zijn zijn rechten


select username from dba_users where username like 'DEPLOY_USER%'; 
define usernaam = deploy_user
set echo off
set feedback off
set  off
@grants 

--- DEPLOY_USER heeft alleen DBA_rechten. moet nog alle rechten krijgen!

prompt controle of DEPLOY_USER de goede proxy clients heeft. 
select * from proxy_users order by 1,2;

prompt moet 11 proxies zijn. 

prompt  Controle van de VIEWER en EXTENDED_VIEWER
select grantee, GRANTED_ROLE from dba_role_privs where granted_role like '%VIEWER%' order by 2,1;



SELECT grantee, PRIVILEGE, admin_option FROM sys.dba_sys_privs WHERE grantee in 
  (select distinct owner from dba_Tables where owner not like '%SYS%' and owner not in ('PERFSTAT','ORDDATA','OUTLN','SCOTT','DBSNMP'))
order by 1,2;

 

prompt zijn de quotas goed? 
select USERNAME, TABLESPACE_NAME,MAX_BYTES from DBA_TS_QUOTAS order by 1,2;