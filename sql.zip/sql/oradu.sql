
set pagesize 80
set linesize 100
col tablespace_name format a20

select tablespace_name , trunc(sum(bytes)/1024/1024) as freespace_Mb 
from dba_free_space group by tablespace_name;
