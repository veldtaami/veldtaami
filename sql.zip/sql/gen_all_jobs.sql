 declare
    job_body varchar2(32767);
begin
    dbms_job.user_export(45,job_body);
    dbms_output.put_line(job_body);
end;
/