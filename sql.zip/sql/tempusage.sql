col SID_SERIAL form  a15
col tablespace form a10
col size form a8
col USERNAME form a20
col program form a80
set linesize 200
set pages 99
set heading on




SELECT b.tablespace,
       ROUND(((b.blocks*p.value)/1024/1024),2)||'M' "SIZE",
       a.sid||','||a.serial# SID_SERIAL,
       a.username,
       a.program
FROM sys.v_$session a,
        sys.v_$sort_usage b,
        sys.v_$parameter p
WHERE p.name  = 'db_block_size'
AND a.saddr = b.session_addr
ORDER BY b.tablespace, b.blocks; 


SELECT tablespace_name, SUM(bytes_used)/1024/1024/1024 GB_USED, SUM(bytes_free)
FROM   V$temp_space_header
GROUP  BY tablespace_name;


prompt ALTER TABLESPACE tablespace SHRINK SPACE;


prompt : uit de v$sort_Segment
SELECT tablespace_name,
total_blocks,
used_blocks,
free_blocks,
total_blocks*16/1024 as total_MB,
used_blocks*16/1024 as used_MB,
free_blocks*16/1024 as free_MB
FROM v$sort_segment;