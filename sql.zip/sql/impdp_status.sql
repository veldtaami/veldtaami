prompt "Status van de IMPDP"
prompt " eerste is van de Job zelf" 

set linesize 200
set pagesize 200
col owner_name format a12
col job_name format a20
col operation format a12
col job_mode format a20
SELECT 
owner_name, 
job_name, 
operation, 
job_mode, 
state 
FROM 
dba_datapump_jobs
where 
state='EXECUTING';


prompt "   	wat zijn de IMPORT Sessies" 

select owner_name, job_name, session_type 
from dba_datapump_sessions;


prompt "wachten de sessies op iets"

select v.status, v.sid,v.serial#,io.block_changes,event 
from v$sess_io io, v$session v 
where io.sid = v.sid 
and v.saddr in (
    select saddr 
    from dba_datapump_sessions
) order by sid;


prompt " wat zijn de sessies aan het doen "
select s.sid, s.module, s.state, 
       substr(s.event, 1, 31) as event,
       s.seconds_in_wait as secs, 
       substr(sql.sql_text, 1, 60) as sql_text
from v$session s
join v$sql sql on sql.sql_id = s.sql_id
where s.module like 'Data Pump%'
order by s.module, s.sid;


