
drop table system.dba_logonhist
/

create table system.dba_logonhist
(
	username varchar2(30) not null primary key,
	last_logon date,
	logon_count number,
	last_logoff date,
	logoff_count number
)
initrans 4
tablespace tools
/

grant select on sys.v_$session to system;


create or replace trigger system.dba_logon_trigger after logon on database
begin
  begin
    if user in ( 'SYS','SYSTEM' )
    then
      insert into system.dba_logonhist values (user, sysdate, 1, null, 0);
    end if;
  exception
    when DUP_VAL_ON_INDEX then
    begin
      update system.dba_logonhist set last_logon = sysdate, logon_count=logon_count+1 where username=user;	
    exception
      when others then
  	null;
    end;
    when others then
      null;
  end;
end;
/

create or replace trigger system.dba_logoff_trigger before logoff on database
begin
  begin
    if user in ( 'SYS','SYSTEM' )
    then	
      update system.dba_logonhist set last_logoff = sysdate, logoff_count=logoff_count+1  where username=user;	
    end if;
   exception
     when others then
       null;
   end;
end;
/

create or replace view system.v_dba_logons as
select
  l.username,
  greatest(l.stamp,nvl(s.stamp,sysdate-10000)) last_seen,
  decode(greatest(l.active,nvl(s.active,0)),0,'NO','YES') logged_on,
  l.logon_count,
  l.logoff_count
from
  (select distinct username, sysdate stamp, 1 active from v$session where username is not null) s,
  (select username, greatest(last_logon,nvl(last_logoff,sysdate-10000)) stamp, 0 active, logon_count, logoff_count from system.dba_logonhist) l
where
  l.username=s.username(+)
order by last_seen desc
/






