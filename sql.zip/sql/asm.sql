

SET VERIFY Off
SET PAGESIZE 0 EMBEDDED on
SET TERM ON
prompt 

select 'Database Instance : '||INSTANCE_NAME Database from   v$instance 
union all
select 'Oracle version    : '||VERSION from   v$instance
/

prompt 
-------------------------------------------------------------------------

SET ECHO OFF
SET TERM OFF

define groot = 0
define total_mb = 0
define ruimte = 0
define free_mb = 0
define erbij = 0

column version new_value version
select lpad(version,2) version from v$instance;


column versie new_value versie
select decode((lpad(version,2)), '10', '', ' OS_MB, ') versie from v$instance;

SET TERM ON

set lines 150

col NR format 999
col HEADER_STATUS format a15
col name format a25
col PATH format a40
col TOTAL_MB format 99999999
col FREE_MB format 9999999

BREAK ON NR SKIP 1
compute sum of TOTAL_MB on NR
compute sum of FREE_MB on NR

select GROUP_NUMBER as NR,name,MOUNT_STATUS, header_status, path , &versie TOTAL_MB,FREE_MB,CREATE_DATE,MOUNT_DATE FROM V$ASM_DISK order by 1,2,3;
--select GROUP_NUMBER as NR,name,MOUNT_STATUS, header_status, path , &versie TOTAL_MB,FREE_MB,CREATE_DATE,MOUNT_DATE FROM V$ASM_DISK_STAT order by 1,2,3;

CLEAR BREAKS
-------------------------------------------------------------------------
prompt 
prompt 

col nr format 99
col name format a15
col Freespace format a9
set lines 105


select GROUP_NUMBER as NR
,name
,block_size
,total_mb
,free_mb
,round(free_mb/1000,0) free_gb
,round((free_mb/total_mb)*100,0)||'%' Freespace 
from v$asm_diskgroup_stat;

prompt 
prompt 

/*
accept free_goal prompt 'Geef het percentage vrij ruimte dat je wilt of druk <enter> voor 10: ' DEFAULT 10

-------------------------------------------------------------------------

SET ECHO Off
SET TERM Off

define dus = ""

column welniet new_value welniet
select decode((select name naam from v$asm_diskgroup_stat where round((free_mb/total_mb)*100,0) < &free_goal and rownum < 2 ), '', 'SET TERM OFF; ', '') welniet from v$instance;

spool dus.sql
prompt &welniet
spool &spool_lok&&DB_SID-&Menu_Optie-&p_datetime..log append;

@dus



create global temporary table DG
   (
     Groep varchar2(10) default NULL,
     Groot NUMBER default NULL,
     RDev NUMBER(2) default NULL
   );




---------Groep loop begin--------------------------------------------------------------
define groeppie = 1



@@501loop

---------DGDB01 eind--------------------------------------------------------------




select * from DG;

col disks new_value disks 
SELECT SUM(RDev) as disks FROM DG where RDEV > 0;

define naam = "1"

column naam new_value naam 
select decode((select &disks from dual ), '1', '', 's') naam  from v$instance;

define naam2 = "1"
column naam2 new_value naam2 
select decode((select &disks from dual ), '1', '', ' elk') naam2  from v$instance;

--drop table DG;

SET TERM On

@dus

set lines 150
col action format a130
prompt
--select HOST_NAME || ': Please add '|| rtrim(&disks)||' extra raw disk&naam (of '|| rtrim(&groot)||' MB&naam2), that we can add to ASM.' Action from v$instance;
--select 'Graag '|| rtrim(&disks)||' extra raw disk&naam (van '|| rtrim(&groot)||' MB&naam2), om aan ASM toe te voegen t.b.v. ICI database '|| upper (INSTANCE_NAME)  || ' op ' || HOST_NAME Action from v$instance;




select 'Graag '|| rtrim(rdev)||' extra raw disk (van '|| rtrim(groot)||' MB), voor groep '|| groep ||' om aan ASM toe te voegen t.b.v. ICI database '|| upper (p.INSTANCE_NAME)  || ' op ' || p.HOST_NAME Action 
from DG,(select INSTANCE_NAME,HOST_NAME from v$instance) p
where rdev >0
/

drop table DG;

*/

prompt
SET TERM On
