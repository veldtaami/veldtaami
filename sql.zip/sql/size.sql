@defaults
col lobs_name for a30
col table_name for a30
col COLUMN_NAME for a30
set lines 200

select table_name, owner, last_analyzed, NUM_ROWS ,blocks,  blocks*8192/1024/1024/1024 Gb, 
degree, chain_cnt, tablespace_name as chained_blocks  
from dba_Tables where owner = upper('&schema_naam') and table_name = upper('&table_naam');



select  s.SEGMENT_NAME lobs_name,  sum(bytes)/1024/1024 MB  , s.TABLESPACE_NAME , d.table_name , d.COMPRESSION , d.column_name, d.owner from dba_segments  s, dba_lobs d
where s.segment_name = d.segment_name and 
s.segment_name in
(select segment_name from dba_lobs where owner = upper('&schema_naam') and table_name = upper('&table_naam') )
group by s.segment_name,  s.TABLESPACE_NAME,  d.table_name, d.COMPRESSION, d.column_name, d.owner; 
