@defaults
col grantee for a30
col privilege for a30
col granted_role for a40
col admin_option for a30
set pages 500


select 'grant ' || PRIVILEGE  || ' to ' || grantee || ';' from  sys.dba_sys_privs where grantee = upper('&&USERNAAM');
select 'grant '||granted_role||' to '||grantee ||case when admin_option = 'YES' then ' with admin option' else null end  ||';'
        from dba_role_privs  WHERE grantee = upper('&&USERNAAM');
select 'grant ' || PRIVILEGE  || ' on ' || OWNER || '."' || table_name || '" to ' || grantee ||case when grantable = 'YES' then ' with grant option' else null end  ||';'
        from  dba_Tab_privs where grantee = upper('&&USERNAAM');

undefine USERNAAM;
