
col osproc format a8
col username format a12
col program format a18
col clienthost format a30
col clientuser format a10
col command format a15
set pagesize 80
set linesize 100

select
   p.spid osproc ,
   substr(s.username,1,12) username,
   substr(s.program,1,18) program,
   substr(s.machine,1,30) clienthost,
   substr(s.osuser,1,10) clientuser,
   decode(s.command,
       0,'No Command',
       1,'Create Table',
       2,'Insert',
       3,'Select',
       6,'Update',
       7,'Delete',
       9,'Create Index',
      15,'Alter Table',
      21,'Create View',
      23,'Validate Index',
      35,'Alter Database',
      39,'Create Tablespace',
      41,'Drop Tablespace',
      40,'Alter Tablespace',
      53,'Drop User',
      62,'Analyze Table',
      63,'Analyze Index',
         s.command||': Other') command
from 
   v$session     s,
   v$process     p,
   v$transaction t,
   v$rollstat    r,
   v$rollname    n
where s.paddr = p.addr
and   s.taddr = t.addr (+)
and   t.xidusn = r.usn (+)
and   r.usn = n.usn (+)
and s.username is not null
order by 1
;
