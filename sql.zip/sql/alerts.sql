set pagesize 1
select
  object_name,
  reason,
  suggested_action
from dba_outstanding_alerts
/

