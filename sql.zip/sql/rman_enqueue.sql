
col osproc format a8
col dbuser format a12
col program format a15
col clienthost format a15
col clientuser format a12
col command format a15
set pagesize 80
set linesize 100
set heading off

select
   'alter system kill session '''||s.sid||','||s.serial#||''' immediate; osprocess: '|| p.spid,
   substr(s.program,1,15) program
from 
   v$session     s,
   v$process     p,
   v$transaction t,
   v$rollstat    r,
   v$rollname    n
where s.paddr = p.addr
and   s.taddr = t.addr (+)
and   t.xidusn = r.usn (+)
and   r.usn = n.usn (+)
and s.username is not null
and s.sid = (select s.sid
from v$session s, v$enqueue_lock l
where l.sid = s.sid and l.type = 'CF' and l.id1 = 0 and l.id2 = 2)
order by 1
;
