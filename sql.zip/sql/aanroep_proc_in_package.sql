
SET serveroutput on size 1000000;
SET linesize 120;

declare
	p_melding   varchar2 (32767);
begin
	p_melding := null;

	owi_cache_util.owi_insert_cache_delta (p_melding);

	dbms_output.put_line('p_melding: '||p_melding);
exception
	when others then
		dbms_output.put_line('ORACLE Error: '||SQLCODE||', errormsg: '||SQLERRM);
end;
/
