set linesize 140
col parent_name form a20
col location form a40
select * from (
select
  parent_name,
  location,
  sleep_count,
longhold_count
from v$latch_misses
where sleep_count>0
order by sleep_count desc
) where rownum<20
/
@sqlplusdefaults
