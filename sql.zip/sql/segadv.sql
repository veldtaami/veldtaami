set verify off
set feedback off
accept ts char prompt 'tablespace: '
DECLARE
  task_id NUMBER;
  task_name VARCHAR2(30);
  workload_name VARCHAR2(30);
  attribute VARCHAR2(100);
  rec_id NUMBER;
  obj_id NUMBER;
BEGIN
  task_name := 'adhoc segment';
  workload_name := 'segment advisor';
  begin
    DBMS_ADVISOR.DELETE_TASK( task_name );
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  DBMS_ADVISOR.CREATE_TASK( 'Segment Advisor',  task_id, task_name);
  DBMS_ADVISOR.CREATE_OBJECT( task_name, 'TABLESPACE', '&ts', NULL, NULL, NULL, obj_id );
  DBMS_ADVISOR.SET_TASK_PARAMETER( task_name, 'RECOMMEND_ALL', 'FALSE');
  DBMS_ADVISOR.EXECUTE_TASK( task_name );
END;
/
set pagesize 0
set linesize 120
select b.attr1||'.'||b.attr2||' '||MESSAGE ||' - '||MORE_INFO from USER_ADVISOR_FINDINGS a, USER_ADVISOR_OBJECTS b where a.task_name='adhoc segment' and a.task_id=b.task_id and a.object_id=b.object_id
/
@sqlplusdefaults

