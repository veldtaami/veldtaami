set feedback off
set pagesize 10
set linesize 120
SELECT name pool, round(set_msize*block_size/1024/1024) "SIZE MB" , PHYSICAL_READS reads, PHYSICAL_WRITES writes, DB_BLOCK_GETS+CONSISTENT_GETS gets, FREE_BUFFER_INSPECTED fbi, DIRTY_BUFFERS_INSPECTED dbi, 1-(physical_reads/(db_block_gets+consistent_gets)) "hitratio" FROM v$buffer_pool_statistics order by name;
@sqlplusdefaults
