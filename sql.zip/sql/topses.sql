set verify off
set linesize 220
set pagesize 10000
accept k prompt '1=CPU, 2=logical reads, 3=read IO, 4=write IO, 5=redo size, 6=executions : '
@topsesc &k
  
