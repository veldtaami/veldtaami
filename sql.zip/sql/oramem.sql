select
  free.pool,
  round(10*free.bytes/1048576)/10 freeMb,
  round(10*decode(used.bytes, NULL, 0, used.bytes)/1048576)/10 usedMb,
  round(10*decode(used.bytes, NULL, 0, used.bytes)/(free.bytes+decode(used.bytes, NULL, 0, used.bytes))*10) pctused
from
  (select pool, bytes from v$sgastat where pool is not null and name='free memory') free,
  (select pool, sum(bytes) bytes from v$sgastat where pool is not null and name!='free memory' group by pool) used
where
  free.pool = used.pool (+)
order by 1
/

