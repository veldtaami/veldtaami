set verify off
set feedback off
col index form a50
set linesize 120
accept idxname prompt 'owner.index: '
select
  a.owner||'.'||a.index_name||' on '||a.table_name "index",
  a.num_rows "rows",
  a.leaf_blocks "leaf blocks",
  b.blocks-a.leaf_blocks "branch blocks",
  round(b.bytes/1024/1024) "size (MB)",
  clustering_factor "clust factor"
from
  dba_indexes a,
  dba_segments b
where
  upper(a.owner)||'.'||upper(a.index_name)=upper('&idxname')
  and a.owner=b.owner and a.index_name=b.segment_name
/
col column form a32
select
  column_name "column",
  column_length "col length",
  char_length "char length",
  descend "descend"
from
  dba_ind_columns
where
  upper(index_owner)||'.'||upper(index_name)=upper('&idxname')
order by column_position
/
@sqlplusdefaults
