col type format a30
set feedback off
set pagesize 100
select  type, group_number, round(sum(bytes)/(1024*1024*1024)) space_GB from v$asm_file group by group_number, type;
