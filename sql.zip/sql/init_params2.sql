
set lines 200
col name for a40
col value for a120
set pages 200
select name, value from v$parameter;

