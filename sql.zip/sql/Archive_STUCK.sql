-- 1. temporary increase FRA from 115GB to 200GB to clear incident : "

alter system set db_recovery_file_dest_size=200G scope=both sid='*'; 


--2. Delete archievlogs: "
delete archivelog all BACKED UP 1 TIMES TO DISK;   -- " System reports that some archielogs need more backups and cannot be deleted

--3. backup all archivelogs : "
backup archivelog all ;

-- 4. Second attempt to delete archivelogs : "
delete archivelog all BACKED UP 1 TIMES TO DISK; 



