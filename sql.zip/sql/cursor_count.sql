select substr(a.sid,1,10) sid,
substr(nvl(b.program,machine),1,30) program,
count(*)
from v$open_cursor a, v$session b
where a.saddr=b.saddr
group by substr(a.sid,1,10),
substr(nvl(b.program,machine),1,30)
order by 3 desc ;

