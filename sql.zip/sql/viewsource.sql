set pagesize 0

SELECT TEXT
FROM DBA_SOURCE
WHERE NAME = '&object_name'
AND TYPE = '&type'
ORDER BY LINE; 
