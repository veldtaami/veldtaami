(@jobs)
set linesize 200
col what form a60 word_wrapped
set pagesize 1000
break on job
select 
  job, broken, 
  to_char(last_date,'YYYY-MM-DD HH24:MI:SS') last,
  decode(broken,'Y','Broken!!!',to_char(next_date,'YYYY-MM-DD HH24:MI:SS')) next,
  total_time,
  what
from
  dba_jobs
order by next_date-sysdate
/


aanpassen van de datum : next-date

execute DBMS_JOB.NEXT_DATE(42, TO_DATE('14-DEC-09','DD-MON-YY'));

(als Job-owner) 

EXEC DBMS_JOB.NEXT_DATE(45 ,to_date('19/09/2018 02:30:00','dd/mm/yyyy hh24:mi:ss'));
EXEC DBMS_JOB.NEXT_DATE(42 ,to_date('02/10/2018 02:00:00','dd/mm/yyyy hh24:mi:ss'));

exec dbms_job.broken(63,TRUE);
exec dbms_job.broken(63,FALSE);


add job:


DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( job       => X 
   ,what      => 'dbms_refresh.refresh('DWH_OWNER.DWH_REFRESH_GROUP');'
   ,next_date => to_date('18/09/2018 02:30:00','dd/mm/yyyy hh24:mi:ss')
   ,interval  => 'TRUNC(SYSDATE+1)'
   ,no_parse  => FALSE
  );
END;
/

exec dbms_job.remove(45) ;

