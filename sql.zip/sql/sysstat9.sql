col "#time" form a8
col "cpu_sec/s" form 9999.99
col "exec/s" form 999999.9
col "usercalls/s" form 9999.9
col "phyrds/s" form 999999.9
col "phywrts/s" form 9999.9
col "net in kb/s" form 99999.9
col "net out kb/s" form 9999.9
col "gets/s" form 9999999.9
col "changes/s" form 9999999.9
col "commits/s" form 9999.99
col "logons/s" form 9999.99
col "redo kb/s" form 9999999.9
set pages 0
set lines 200
set UND #
set feedback off
set verify off
set heading off
accept deet prompt 'date (yyyy-mm-dd): '
prompt # date: &deet
select '# database '||name from v$database;
select '# instance '||instance_name from v$instance;
select '# host '||host_name from v$instance;
prompt #time    cpu_sec/s    exec/s usercalls/s  phyrds/s phywrts/s net in kb/s net out kb/s     gets/s  changes/s commits/s logons/s  redo kb/s
select 
  to_char(snap2.snap_time,'HH24:MI:SS') "#time",
  cpu.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60/100 "cpu_sec/s",
  execute_count.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60 "exec/s",
  user_calls.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60 "usercalls/s",
  phyrds.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60 "phyrds/s",
  phywrts.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60 "phywrts/s",
  bytesin.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60/1024 "net in kb/s",
  bytesout.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60/1024 "net out kb/s",
  gets.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60 "gets/s",
  changes.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60 "changes/s",
  commits.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60 "commits/s",
  logons.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60 "logons/s",
  redo.value/(cast(snap.snap_time as date)-cast(snap2.snap_time as date))/24/60/60/1024 "redo kb/s"
from
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='CPU used by this session' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) CPU, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='execute count' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) execute_count, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='user calls' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) user_calls, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='physical reads' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) phyrds, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='physical writes' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) phywrts, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='bytes received via SQL*Net from client' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) bytesin, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='bytes sent via SQL*Net to client' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) bytesout, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='session logical reads' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) gets, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='db block changes' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) changes, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='user commits' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) commits, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='logons cumulative' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) logons, 
  (select b.snap_id, b.value-a.value value from stats$sysstat a, stats$sysstat b where a.name='redo size' and a.statistic#=b.statistic# and a.snap_id=b.snap_id-1) redo, 
  stats$snapshot snap,
  stats$snapshot snap2
where
  snap.snap_id=cpu.snap_id
  and
  snap.snap_id=execute_count.snap_id
  and
  snap.snap_id=user_calls.snap_id
  and
  snap.snap_id=phyrds.snap_id
  and
  snap.snap_id=phywrts.snap_id
  and
  snap.snap_id=bytesin.snap_id
  and
  snap.snap_id=bytesout.snap_id
  and
  snap.snap_id=gets.snap_id
  and
  snap.snap_id=changes.snap_id
  and
  snap.snap_id=commits.snap_id
  and
  snap.snap_id=logons.snap_id
  and
  snap.snap_id=redo.snap_id
  and
  snap.startup_time not between snap2.snap_time and snap2.snap_time
  and
  to_char(snap2.snap_time,'YYYY-MM-DD')='&deet'
  and
  snap2.snap_id=snap.snap_id-1
order by snap.snap_id
/
@sqlplusdefaults
