-- table_frag
accept table_name prompt  "table_name:  "
accept owner prompt  "owner:  "
select table_name,last_analyzed,stale_stats from dba_tab_statistics where table_name='&TABLE_NAME' and owner = '&OWNER';

-- EXEC dbms_stats.gather_table_stats(ownname => '&OWNER', tabname => '&TABLE_NAME', method_opt=> 'for all indexed columns size skewonly', granularity => 'ALL', degree => 8 ,cascade => true,estimate_percent => 5);

-- Step 2: Check table size from dba_segments
select sum(bytes)/1024/1024/1024 from dba_segments where segment_name='&TABLE_NAME' and owner='&OWNER';


-- STEP 3: Check actual table size, fragmented size and percentage of fragmentation in a table.
select table_name,avg_row_len,round(((blocks*16/1024)),2)||'MB' "TOTAL_SIZE",
round((num_rows*avg_row_len/1024/1024),2)||'Mb' "ACTUAL_SIZE",
round(((blocks*16/1024)-(num_rows*avg_row_len/1024/1024)),2) ||'MB' "FRAGMENTED_SPACE",
(round(((blocks*16/1024)-(num_rows*avg_row_len/1024/1024)),2)/round(((blocks*16/1024)),2))*100 "percentage"
from all_tables WHERE table_name='&TABLE_NAME' and owner = '&OWNER';



STEP 4:  Check the indexes on the table
--select index_name from dba_indexes where table_name='&TABLE_NAME';

