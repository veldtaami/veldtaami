select object_id, SESSION_ID, ORACLE_USERNAME, OS_USER_NAME, LOCKED_MODE from gv$locked_object

 v$sql.sql_text for the locking session and also its entry in v$session_wait. 
 
 select sid, username, command, sql_id from v$sql where sid=157
 
 
 SELECT SID, SERIAL#, STATUS, SERVER
FROM V$SESSION
WHERE USERNAME = 'ONP_OUE'

ALTER SYSTEM DISCONNECT SESSION '9,6503' IMMEDIATE



Process status ROLLBACK


select s.sid,
 s.program,
 t.status as transaction_status,
 s.status as session_status,
 s.lockwait,
 s.pq_status,
 t.used_ublk as undo_blocks_used,
 decode(bitand(t.flag, 128), 0, 'NO', 'YES') rolling_back
from v$session s, v$transaction t
where s.taddr = t.addr;


select *
from v$session_wait
where sid in (select sid from v$session
 where username = 'ONP_OUE'
 and status = 'KILLED');
 
 select sid, event, p1text, wait_class, state
from v$session_wait
where sid in (select sid from v$session
 where username = 'ONP_OUE'
 and status = 'KILLED');