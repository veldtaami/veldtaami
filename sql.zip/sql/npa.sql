 
select username from dba_users where account_status = 'LOCKED'
and (username not in (select distinct(owner) from dba_objects ) 
or username in (
 select distinct owner from dba_objects where object_type = 'SYNONYM' 
minus 
  select distinct owner from dba_objects where object_type <> 'SYNONYM'
))
and username not in 'ANONYMOUS'
order by 1;