break on index_name
set lines 200

col index_owner for a20
col index_name for a30
col column_name for a30
col COLUMN_POSITION for 99
col dba_ind_expressions for a80

prompt " List alle tabellen, indexen en zijn kolommen (ook FBI)"

accept index_owner prompt "geef naam van de owner:  "

select i.index_owner, i.index_name, i.column_name, i.COLUMN_POSITION, e.column_expression from dba_ind_columns i, dba_ind_expressions e
where i.index_owner = upper('&&index_owner') 
and i.index_owner = e.index_owner(+)
and i.index_name = e.index_name(+)
order by 1,2,4;