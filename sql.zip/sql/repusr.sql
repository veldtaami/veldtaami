set trimspool on
set pages 1024
set heading off
set feedback off
set lines 1024
 
spool temp.sql
SELECT 'set trimspool on' FROM Dual;
SELECT 'set pages 1024' FROM Dual;
SELECT 'set heading off' FROM Dual;
SELECT 'set feedback off' FROM Dual;
SELECT 'set long 1024 ' FROM Dual;
SELECT 'col USERNAME for a500' FROM Dual;
SELECT 'spool creusr.sql' FROM Dual
/
SELECT 'SELECT DBMS_MetaData.Get_DDL(''USER'',''' ||
       UserName || ''')||'';'' "USERNAME" FROM Dual;'
FROM   DBA_Users
WHERE  UserName NOT IN ('SYS','SYSTEM','OUTLN',
                        'OPS$ORACLE','DBSNMP','WMSYS',
                        'OPS$ORAEMDEV','IFSAPP')
/
SELECT 'SELECT ''GRANT CONNECT TO "' || USERName || '";'' FROM Dual;'
FROM   DBA_Users
WHERE  UserName NOT IN ('SYS','SYSTEM','OUTLN',
                        'OPS$ORACLE','DBSNMP','WMSYS',
                        'OPS$ORAEMDEV','IFSAPP')
/
SELECT 'spool off' FROM Dual
/
spool off

