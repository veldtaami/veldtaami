set linesize 200
col what form a60 word_wrapped
set pagesize 1000
break on job
select 
  job, broken, 
  to_char(last_date,'YYYY-MM-DD HH24:MI:SS') last,
  decode(broken,'Y','Broken!!!',to_char(next_date,'YYYY-MM-DD HH24:MI:SS')) next,
  total_time,
  what, schema_user
from
  dba_jobs
order by next_date-sysdate
/
