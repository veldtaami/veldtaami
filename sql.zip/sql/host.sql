-- @defaults

select INSTANCE_NAME, host_name, status, name , DB_UNIQUE_NAME from  gv$instance, v$database;


prompt Actieve instance is : 


select INSTANCE_NAME, host_name, status, name , DB_UNIQUE_NAME from  v$instance, v$database;