set pages 99
set linesize 200
col OCCUPANT_DESC for a60

select tablespace_name, sum(bytes)/1024/1024 mb_totaal ,sum(MAXBYTES)/1024/1024 max from dba_data_files where tablespace_name = 'SYSAUX' group by tablespace_name;

break on report
compute sum OF MB on report

select occupant_desc, space_usage_kbytes/1024 MB
from v$sysaux_occupants
where space_usage_kbytes > 0
order by space_usage_kbytes;

 
COLUMN "Item" FORMAT A25
COLUMN "Space Used (GB)" FORMAT 999.99
COLUMN "Schema" FORMAT A25
COLUMN "Move Procedure" FORMAT A40
 
SELECT  occupant_name "Item",
    space_usage_kbytes/1048576 "Space Used (GB)",
    schema_name "Schema",
    move_procedure "Move Procedure"
FROM v$sysaux_occupants
ORDER BY 1
/

col owner for a6
col segment_name for a50
select * from
(select owner,segment_name||'~'||partition_name segment_name,bytes/(1024*1024) size_m
from dba_segments
where tablespace_name = 'SYSAUX' ORDER BY BLOCKS desc) where rownum < 6;



prompt  Schonen van de Sysaux  
prompt  de Unified_audit_trail 

select count(*) from unified_audit_trail;

prompt   BEGIN
prompt   DBMS_AUDIT_MGMT.CLEAN_AUDIT_TRAIL(
prompt   audit_trail_type => DBMS_AUDIT_MGMT.AUDIT_TRAIL_UNIFIED,
prompt   use_last_arch_timestamp => FALSE);
prompt   END;
prompt   /
prompt   
prompt   select count(*) from unified_audit_trail;



--How long old stats are kept
select count(*) from unified_audit_trail;

--Set retention of old stats to 10 days
prompt exec dbms_stats.alter_stats_history_retention(10);

--Purge stats older than 10 days (best to do this in stages if there is a lot of data (sysdate-30,sydate-25 etc)
prompt exec DBMS_STATS.PURGE_STATS(SYSDATE-10);

--Show available stats that have not been purged
select dbms_stats.get_stats_history_availability from dual;

--Show how big the tables are and rebuild after stats have been purged
col Mb form 9,999,999
col SEGMENT_NAME form a40
col SEGMENT_TYPE form a6
set lines 120
select sum(bytes/1024/1024) Mb, segment_name,segment_type from dba_segments
where  tablespace_name = 'SYSAUX'
and segment_name like 'WRI$_OPTSTAT%'
and segment_type='TABLE'
group by segment_name,segment_type order by 1 asc;


--Show how big the indexes are ready for a rebuild after stats have been purged

col Mb form 9,999,999
col SEGMENT_NAME form a40
col SEGMENT_TYPE form a6
set lines 120
select sum(bytes/1024/1024) Mb, segment_name,segment_type from dba_segments
where  tablespace_name = 'SYSAUX'
and segment_name like '%OPT%'
and segment_type='INDEX'
group by segment_name,segment_type order by 1 asc;


-- shrink the tables
select 'alter table '||segment_name||'  move tablespace SYSAUX;' from dba_segments where tablespace_name = 'SYSAUX'
and segment_name like '%OPT%' and segment_type='TABLE';

-- rebuild indexes 
select 'alter index '||segment_name||'  rebuild online parallel (degree 14);' from dba_segments where tablespace_name = 'SYSAUX'
and segment_name like '%OPT%' and segment_type='INDEX';


prompt  :  is Unified auditing enabled? 
select * from audit_unified_enabled_policies;


col POLICY_NAME       for a30
col AUDIT_OPTION      for a30
col AUDIT_OPTION_TYPE for a30
col OBJECT_SCHEMA     for a30
col OBJECT_NAME       for a30
col OBJECT_TYPE       for a30
--select POLICY_NAME,AUDIT_OPTION,AUDIT_OPTION_TYPE,OBJECT_SCHEMA,OBJECT_NAME,OBJECT_TYPE
-- from audit_unified_policies
--   where policy_name in ('ORA_SECURECONFIG','ORA_LOGON_FAILURES')
--  order by 1,2,3,4,5;

prompt om te disablen:
prompt noaudit policy ora_secureconfig

prompt exec DBMS_AUDIT_MGMT.FLUSH_UNIFIED_AUDIT_TRAIL;
prompt BEGIN
prompt DBMS_AUDIT_MGMT.CLEAN_AUDIT_TRAIL(
prompt audit_trail_type         =>  DBMS_AUDIT_MGMT.AUDIT_TRAIL_UNIFIED,
prompt use_last_arch_timestamp  =>  TRUE);
prompt END;
prompt /



---- select owner, table_name, (BLOCKS*8192)/1024/1024/1024 gb from dba_Tables where tablespace_name= 'SYSAUX' order by 3
----  select segment_name, SEGMENT_TYPE , (BLOCKS*8192)/1024/1024/1024 gb from dba_Segments where tablespace_name= 'SYSAUX' order by 3;
----  
----  select sum((BLOCKS*8192)/1024/1024/1024) GB from dba_Segments where tablespace_name= 'SYSAUX' order by 3;
----  
----  -- shrink the tables
----select 'alter table '||segment_name||'  move online tablespace SYSAUX;' from dba_segments where tablespace_name = 'SYSAUX'
----and segment_name like '%WRI%' and segment_type='TABLE';
----
------ rebuild indexes 
----select 'alter index '||segment_name||'  rebuild online ;' from dba_segments where tablespace_name = 'SYSAUX'
----and segment_name like '%WRI%' and segment_type='INDEX';
----
----prompt : Wat staat er aan het eind?
----
----SELECT de.file_id, owner, segment_name, partition_name, segment_type  
----FROM dba_extents de,      (SELECT file_id, MAX(block_id) mblock_id         
----   FROM dba_extents       WHERE tablespace_name = 'SYSAUX'       GROUP BY file_id      ) fmax
----WHERE de.file_id = fmax.file_id AND de.block_id = fmax.mblock_id ORDER BY file_id; 
----
----
----Promp: rest rebuild
----select 'alter index '|| owner || '.'||segment_name||'  rebuild online ;' from dba_segments where tablespace_name = 'SYSAUX'
----and segment_name not like '%WRI%' and segment_name not like '%OPT%' and segment_type='INDEX';
----
----select 'alter table '||owner || '.' || segment_name||'  move online tablespace SYSAUX;' from dba_segments where tablespace_name = 'SYSAUX'
----and segment_name like '%WRI%' and segment_type='TABLE';
----
----
----
----select 'alter table  '||owner||'.'||table_name||' move lob ('||column_name||') store as (tablespace sysaux);' 
----from dba_lobs where TABLESPACE_NAME='SYSAUX' order by owner, table_name;
----
----select owner, table_name, segment_name from dba_lobs where tablespace_name = 'SYSAUX';



prompt  in 12.2.0.1 the EXECUTION_DAYS_TO_EXPIRE parameter is set to UNLIMITED which means the old records would never be purged.
prompt col TASK_NAME format a25
prompt col parameter_name format a35
prompt col parameter_value format a20
prompt set lines 120
prompt select TASK_NAME,parameter_name, parameter_value FROM DBA_ADVISOR_PARAMETERS WHERE task_name='AUTO_STATS_ADVISOR_TASK' and PARAMETER_NAME='EXECUTION_DAYS_TO_EXPIRE';


prompt The expired statistics advisor records can be purged manually
prompt exec prvt_advisor.delete_expired_tasks;
prompt EXEC DBMS_ADVISOR.SET_TASK_PARAMETER(task_name=> 'AUTO_STATS_ADVISOR_TASK', parameter=> 'EXECUTION_DAYS_TO_EXPIRE', value => 10);
prompt EXEC DBMS_SQLTUNE.SET_TUNING_TASK_PARAMETER (task_name => 'AUTO_STATS_ADVISOR_TASK', parameter => 'EXECUTION_DAYS_TO_EXPIRE', value => 10);
prompt select TASK_NAME,parameter_name, parameter_value FROM DBA_ADVISOR_PARAMETERS WHERE task_name='AUTO_STATS_ADVISOR_TASK' and PARAMETER_NAME='EXECUTION_DAYS_TO_EXPIRE';
