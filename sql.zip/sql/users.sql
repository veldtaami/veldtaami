@defaults
set lines 300
col username for a40
col profile for a30
col account_status for a30
col default_tablespace for a30
col temporary_tablespace for a30
select username , account_status , profile , default_tablespace, temporary_tablespace, PASSWORD_VERSIONS from dba_users order by 1;
