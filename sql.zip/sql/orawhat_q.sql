
col osproc format a8
col username format a8
col program format a18
col clienthost format a30
col clientuser format a10
col command format a15
--col sql_hash format a20
set long 2000
set pagesize 80
set linesize 160

break on osproc on username on program on clienthost on clientuser on sql_hash_value  on sql_text;
  
select
   p.spid osproc ,
   substr(s.username,1,8) username,
   substr(s.program,1,18) program,
   substr(s.machine,1,30) clienthost,
   substr(s.osuser,1,10) clientuser,
   s.sql_hash_value , 
   x.sql_text
from 
   v$session     s,
   v$process     p,
   v$transaction t,
   v$rollstat    r,
   v$rollname    n,
   v$sqltext     x
where s.paddr = p.addr
and   s.taddr = t.addr (+)
and   t.xidusn = r.usn (+)
and   r.usn = n.usn (+)
and   s.sql_hash_value=x.hash_value(+)
and s.username is not null
;


