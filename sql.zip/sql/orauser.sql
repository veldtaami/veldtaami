
col users format a12
col lockdate format a10
col profile format a10
col expdate format a10
col STATUS format a20
set pagesize 80
set linesize 100

select USERNAME users , profile, LOCK_DATE lockdate, 
EXPIRY_DATE expdate,ACCOUNT_STATUS status from dba_users;
