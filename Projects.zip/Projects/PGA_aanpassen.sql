pga_aggregate_limit aanpassen voor:

DB				NU LIMIT : TARGET			

PCTI31  :   	3G		1536M	
SRV0PHOO101		4		2G
SRV0TCTI201		2G		1G
SRV0GSIB101		4G		2G
SRV0PHOO101		4G		2G
SRV0THNA201		2G		1G
SRV0TSIB101		3g		1.5
SRV0OCTI501		4		2
SRV0GUDB201		3		1,5


select prc.inst_id, ses.sid, ses.serial#, prc.pid, prc.spid, 
round(prc.pga_used_mem/1024/1024) used_mb, 
round(prc.pga_alloc_mem/1024/1024) alloc_mb, 
round((prc.pga_alloc_mem - prc.pga_used_mem)/1024/1024, 0) unused_mb, 
round(prc.pga_freeable_mem/1024/1024) freeable_mb, 
round(prc.pga_max_mem/1024/1024) max_mb
from gv$process prc
  left outer join gv$session ses on (ses.inst_id = prc.inst_id and ses.paddr = prc.addr and ses.type = 'USER')
order by used_mb desc
fetch first 10 rows only;
