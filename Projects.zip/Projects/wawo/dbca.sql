export TNS_ADMIN=/tmp/TMP97079; export ORACLE_HOME=/u01/app/oracle/product/12.2.0.1/db_200; /u01/app/oracle/product/12.2.0.1/db_200/bin/dbca -silent -configuredatabase -sourceDB GHOO1_01 -unregisterWithDirService true -dirServiceUserName "cn=OrclEcoProv,cn=serviceaccounts,dc=oracle,dc=rabobank,dc=nl" -dirServicePassword HSVMS4nd9UaD3k_llHhj -walletPassword dih1wwvdw -sysDBAUserName sys -sysDBAPassword z0mr_IN_s33landt


/u01/app/oracle/product/12.2.0.1/db_200/bin/dbca -silent -configuredatabase -sourceDB GHOO1_01 -unregisterWithDirService true -dirServiceUserName "cn=OrclEcoProv,
cn=serviceaccounts,
dc=oracle.rabobank.nl
-dirServicePassword HSVMS4nd9UaD3k_llHhj 

-walletPassword dih1wwvdw 


sys/z0mr_IN_s33landt