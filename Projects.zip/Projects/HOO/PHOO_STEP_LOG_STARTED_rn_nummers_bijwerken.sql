
-- SET parameters for sqlplus client. May be commented out if irrelevant
SET serveroutput ON SIZE 100000
SET LINESIZE 15000
SET PAGESIZE 1500


--Creeer tussen tabel met de rn_nummer en id, zoals in de proc. 
create table owner_ooy.ave_test1 as (SELECT ID,EXECUTION_ID, ROW_NUMBER() OVER (PARTITION BY EXECUTION_ID ORDER BY STEP_SEQ_ORDER ASC) AS RN FROM owner_ooy.OO_STEP_LOG_STARTED);

--creeer een status tabel, waar voor tijdens het proces. 
create table owner_ooy.ave_stat ( rn_nummer number,  tijdstip date);

creeer indexen. 
	  create index owner_ooy.ave_t_rn_idx1 on owner_ooy.ave_test1(rn);
	  create index owner_ooy.ave_t_id_idx1 on owner_ooy.ave_test1(id);
	  create index owner_ooy.ave_t_id_rn_idx1 on owner_ooy.ave_test1(id,rn);
	  

-- de update die altijd werkt is maar doet alles in 1 keer. 
---update owner_ooy.OO_STEP_LOG_STARTED SLS SET SLS.STEP_START_ORDER = 1 where SLS.ID in (select id from owner_ooy.ave_test1 CRN where rn =1 );

-- gooi dit in een loop, met wat extra  parallelisatie


ALTER SESSION FORCE PARALLEL DML PARALLEL 32;
ALTER SESSION ENABLE PARALLEL DML; 
ALTER SESSION FORCE PARALLEL DDL PARALLEL 32;
ALTER SESSION ENABLE PARALLEL DDL; 

set serveroutput on
Declare
teller number := 1;

Begin
For teller in 1..1
Loop
DBMS_OUTPUT.PUT_LINE(teller);
update owner_ooy.OO_STEP_LOG_STARTED SLS SET SLS.STEP_START_ORDER = teller where SLS.ID in (select id from owner_ooy.ave_test1 CRN where rn = teller );
insert into owner_ooy.ave_stat values (teller, sysdate);
commit;
End Loop;
COMMIT;
End;
/


controle: 
select * from owner_ooy.ave_stat order by 2;
select count(1) From owner_ooy.OO_STEP_LOG_STARTED;

select count(1) From owner_ooy.OO_STEP_LOG_STARTED where STEP_START_ORDER is null;


13:13:57 rabo_user@phoo1> select count(1) From owner_ooy.OO_STEP_LOG_STARTED;

  COUNT(1)
----------
 258511996

1 row selected.

Elapsed: 00:00:53.99
13:15:06 rabo_user@phoo1> select count(1) From owner_ooy.OO_STEP_LOG_STARTED where STEP_START_ORDER is null;

  COUNT(1)
----------
 258511996


13:15:39 rabo_user@phoo1> select max(rn) from owner_ooy.ave_test1;

   MAX(RN)
----------
    395160

1 row selected.

Elapsed: 00:00:00.08

de LOOP hierboven moet dus tot 395160 gaan!!!

select count(1) from owner_ooy.ave_test1 where rn = 2;


