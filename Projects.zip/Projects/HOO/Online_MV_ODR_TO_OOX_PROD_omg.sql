SCRIPTS AAN DE HAND VAN WAT WEG MOET.   dus:  kleiner dan 01012020  gaat weg!
1. maak lijst uit summary wat weg mag. 
2. maak lijst van started wat weg mag. (aan de hand van 1). 
3. maak lijst van ended wat weg mag aan de hand van 2. 
4. verwijder uit step_log_Bindings aan de hand van lijst 3. 
5. verwijder uit OO_EXECUTION_BOUND_OUTPUTS aan de hnad van lijst  1 (summary)
6. verwijder uit OO_EXECUTION_BOUND_INPUTS  aan de hand van lijst uit 2.



-- # 1
-- maak tabel met id uit owner_odr.OO_EXECUTION_SUMMARY die weg mogen!   
-- (2 sec)
drop table owner_odr.mv_exec_sum_id;
create table owner_odr.mv_exec_sum_id as 
select EXECUTION_ID from owner_odr.OO_EXECUTION_SUMMARY; 


-- 2 # 
-- maak een tabel met HASH_ID rm_sls_hash_id van wat uit step_log_ended weg mag, aan de hand van wat van started weg mag. 

    -- 1 min. 
drop table owner_odr.mv_sls_hash_id;
create table owner_odr.mv_sls_hash_id as (select STEP_HASH_ID FROM owner_odr.OO_STEP_LOG_STARTED
 WHERE EXECUTION_ID IN (SELECT EXECUTION_ID FROM owner_odr.mv_exec_sum_id));

select count(1) FROM owner_odr.OO_STEP_LOG_STARTED  WHERE EXECUTION_ID IN (SELECT EXECUTION_ID FROM owner_odr.mv_exec_sum_id);
													
-- # 3   duur: 2 min. 
--- maak tabel met SELECT ID FROM OO_STEP_LOG_ENDED wat weg mag. de step_ended_hash_id is de step_hash_id uit SLS
drop table owner_odr.mv_sle_id;
create table owner_odr.mv_sle_id as (select id from owner_odr.oo_step_log_ended where STEP_ENDED_HASH_ID IN (SELECT STEP_HASH_ID FROM owner_odr.mv_sls_hash_id));
select count(1) from owner_odr.mv_sle_id;



set timing on
set serveroutput on
ALTER SESSION ENABLE PARALLEL DML;
ALTER SESSION ENABLE PARALLEL DDL;
alter table owner_odr.OO_EXECUTION_SUMMARY parallel 32;
alter table owner_odr.OO_STEP_LOG_STARTED parallel 32;
alter table owner_odr.OO_STEP_LOG_ENDED parallel 32;
alter table owner_odr.OO_STEP_LOG_BINDINGS parallel 32;
alter table owner_odr.OO_EXECUTION_BOUND_OUTPUTS parallel 32;
alter table owner_odr.OO_EXECUTION_BOUND_INPUTS parallel 32;


-- Counts before											VOOR              NA
SELECT COUNT(*) FROM owner_odr.OO_EXECUTION_SUMMARY;        16962			1663
SELECT COUNT(*) FROM owner_odr.OO_STEP_LOG_STARTED;         3264871			29737
SELECT COUNT(*) FROM owner_odr.OO_STEP_LOG_ENDED;           3264870			29737
SELECT COUNT(*) FROM owner_odr.OO_STEP_LOG_BINDINGS;        30702080		246942
SELECT COUNT(*) FROM owner_odr.OO_EXECUTION_BOUND_OUTPUTS;  26714			1712
SELECT COUNT(*) FROM owner_odr.OO_EXECUTION_BOUND_INPUTS;   26900			196


SELECT S.OWNER "Owner",NVL(S.SEGMENT_NAME, 'TABLE TOTAL SIZE') "Segment name",ROUND(SUM(S.BYTES)/1024/1024/1024,1) "Segment size (GB)"
FROM DBA_SEGMENTS S
WHERE S.OWNER = 'OWNER_ODR' and 
(S.SEGMENT_NAME IN ('OO_EXECUTION_SUMMARY', 'OO_STEP_LOG_STARTED', 'OO_STEP_LOG_ENDED', 'OO_STEP_LOG_BINDINGS', 'OO_EXECUTION_BOUND_OUTPUTS', 'OO_EXECUTION_BOUND_INPUTS')
OR S.SEGMENT_NAME IN (
                    (
                        SELECT L.SEGMENT_NAME FROM DBA_LOBS L WHERE L.TABLE_NAME in ('OO_EXECUTION_SUMMARY', 'OO_STEP_LOG_STARTED', 'OO_STEP_LOG_ENDED', 'OO_STEP_LOG_BINDINGS', 'OO_EXECUTION_BOUND_OUTPUTS', 'OO_EXECUTION_BOUND_INPUTS')
                    )
))
GROUP BY S.OWNER,ROLLUP(S.SEGMENT_NAME)
ORDER BY 1,2,3;



-- delete uit de OO_Execution_summary, waar exection+id in de tabel #1 zit
insert into owner_oox.OO_EXECUTION_SUMMARY (select * from owner_odr.OO_EXECUTION_SUMMARY where execution_id in (select EXECUTION_ID from owner_odr.mv_exec_sum_id));  --  16948 rows created.  (5 sec)
delete from owner_odr.OO_EXECUTION_SUMMARY where execution_id in (select EXECUTION_ID from owner_odr.mv_exec_sum_id);   -- prod: 1 min 


--delete uit OO_EXECUTION_BOUND_INPUTS  aan de hand van execution_id die in execution_summery komt. 
insert into owner_oox.OO_EXECUTION_BOUND_INPUTS (select * from owner_odr.OO_EXECUTION_BOUND_INPUTS WHERE EXECUTION_ID IN (SELECT EXECUTION_ID FROM owner_odr.mv_exec_sum_id));  -- 26900 rows created.  Elapsed: 00:00:02.34
delete from owner_odr.OO_EXECUTION_BOUND_INPUTS WHERE EXECUTION_ID IN (SELECT EXECUTION_ID FROM owner_odr.mv_exec_sum_id);    -- prod: 3 min 

--delete uit OO_EXECUTION_BOUND_OUTPUTS  aan de hand van execution_id die in execution_summery komt. 
insert into owner_oox.OO_EXECUTION_BOUND_OUTPUTS (
select * from owner_odr.OO_EXECUTION_BOUND_OUTPUTS WHERE EXECUTION_ID IN (SELECT EXECUTION_ID FROM owner_odr.mv_exec_sum_id));  -- 26700 rows created. Elapsed: 00:00:02.29
delete from owner_odr.OO_EXECUTION_BOUND_OUTPUTS WHERE EXECUTION_ID IN (SELECT EXECUTION_ID FROM owner_odr.mv_exec_sum_id);    -- prod: 3 min 



-- delete uit de oo_step_log_Started. kan aan de hand van de execu tion_id die in execution_summery zit
-- delete from owner_odr.OO_STEP_LOG_STARTED where execution_id in (select EXECUTION_ID from owner_odr.rm_exec_sum_id);   te groot: te lang op prod, daarom met procedure.


create table owner_odr.mv_exec_sum_id_sls as (select EXECUTION_ID from owner_odr.mv_exec_sum_id);
create table owner_odr.mv_exec_sum_id_sls_tmp as (select EXECUTION_ID from owner_odr.mv_exec_sum_id where 1=0);

select count(1) from owner_odr.mv_exec_sum_id_sls;   -- start:    16948
select count(1) from owner_odr.OO_STEP_LOG_STARTED;   -- start: 3265472

-- we hebben een rm_exec_sum_id_sls en een rm_exec_sum_id_sls_tmp
--  move 1000 van sls naar sls_tmp  (dus cp en del)
-- del uit step_log_Started, waar id uit de sls_tmp zit. 
-- voor de voortgang: hou aantal in sls bij. 

set serveroutput on
Declare
teller number := 1;

Begin
For teller in 1..16
Loop
DBMS_OUTPUT.PUT_LINE(teller);
insert into owner_odr.mv_exec_sum_id_sls_tmp ( select * from  owner_odr.mv_exec_sum_id_sls where rownum < 1000);
commit;
delete from owner_odr.mv_exec_sum_id_sls where EXECUTION_ID in (select EXECUTION_ID from owner_odr.mv_exec_sum_id_sls_tmp);
-- insert into owner_oox.OO_STEP_LOG_STARTED (select * from owner_odr.OO_STEP_LOG_STARTED where execution_id IN (SELECT execution_id FROM owner_odr.mv_exec_sum_id_sls_tmp));
delete from owner_odr.OO_STEP_LOG_STARTED where execution_id IN (SELECT execution_id FROM owner_odr.mv_exec_sum_id_sls_tmp);
execute immediate 'truncate table owner_odr.mv_exec_sum_id_sls_tmp'; 
commit;
End Loop;
End;
/




-- delete uit de OO_STEP_LOG_ENDED, aan de hand van id uit #3.  mv_sle_id  (is zelfde als de hash_id uit de STEP_LOG_STARTED)
delete from owner_odr.oo_step_log_ended where STEP_ENDED_HASH_ID IN (SELECT STEP_HASH_ID FROM owner_odr.rm_sls_hash_id);     ---11 uur     
--- OF
delete from owner_odr.oo_step_log_ended where ID IN (SELECT ID FROM owner_odr.mv_sle_id);     

create table owner_odr.sle_id as (select id from owner_odr.mv_sle_id);
create table owner_odr.sle_id_tmp as (select id from owner_odr.sle_id where 1=0);



set serveroutput on
Declare
teller number := 1;

Begin
For teller in 1..100
Loop
DBMS_OUTPUT.PUT_LINE(teller);
insert into owner_odr.sle_id_tmp ( select * from  owner_odr.sle_id where rownum < 10000);
commit;
delete from owner_odr.sle_id where id in (select id from owner_odr.sle_id_tmp);
--insert into owner_oox.oo_step_log_ended (select * from owner_odr.oo_step_log_ended where ID IN (SELECT ID FROM owner_odr.sle_id_tmp));
--insert into owner_oox.OO_STEP_LOG_BINDINGS (select * from owner_odr.OO_STEP_LOG_BINDINGS where STEP_LOG_ENDED_ID IN (SELECT ID FROM owner_odr.sle_id_tmp));
delete from owner_odr.OO_STEP_LOG_BINDINGS where STEP_LOG_ENDED_ID IN (SELECT ID FROM owner_odr.sle_id_tmp);
delete from owner_odr.oo_step_log_ended where ID IN (SELECT ID FROM owner_odr.sle_id_tmp);
execute immediate 'truncate table owner_odr.sle_id_tmp'; 
insert into owner_odr.status_ave values (teller);
commit;
End Loop;
End;
/


--e OO_STEP_LOG_BINDINGS die er moeten zijn zijn hebben de id uit sle_ids
--select count(1) from owner_odr.OO_STEP_LOG_BINDINGS where STEP_LOG_ENDED_ID in (select id from owner_odr.SLE_ids);
--create table owner_odr.OO_STEP_LOG_BINDINGS_1 as select * from owner_odr.OO_STEP_LOG_BINDINGS where STEP_LOG_ENDED_ID in (select id from owner_odr.SLE_ids);  ( max 1.30 uur)
-- create table owner_odr.SLE_ids as (select STEP_ENDED_HASH_ID, id from owner_odr.oo_step_log_ended where STEP_ENDED_HASH_ID in (select STEP_HASH_ID from owner_odr.oo_step_log_Started))






-- STEP_LOG_BINDINGS   --- onderstaand bij een CTAS

alter table owner_odr.OO_STEP_LOG_BINDINGS parallel 32;
alter index owner_odr.PK_OO_STEP_BND parallel 32;

CREATE TABLE owner_odr.OO_STEP_LOG_BINDINGS2 parallel 32 as
SELECT /*+ parallel(32) */ * FROM owner_odr.OO_STEP_LOG_BINDINGS
WHERE STEP_LOG_ENDED_ID IN (SELECT ID FROM owner_odr.OO_STEP_LOG_ENDED);

DROP TABLE OO_STEP_LOG_BINDINGS;
alter session set current_Schema=owner_odr;

ALTER TABLE OO_STEP_LOG_BINDINGS RENAME to OO_STEP_LOG_BINDINGS_org;
ALTER TABLE OO_STEP_LOG_BINDINGS2 RENAME to OO_STEP_LOG_BINDINGS;

CREATE UNIQUE INDEX "owner_odr"."PK_OO_STEP_BND1" ON "owner_odr"."OO_STEP_LOG_BINDINGS" ("ID") TABLESPACE "OOXD" parallel 32;
CREATE INDEX "owner_odr"."FK_ID1" ON "owner_odr"."OO_STEP_LOG_BINDINGS" ("STEP_LOG_ENDED_ID") TABLESPACE "OOXD" parallel 32;

ALTER TABLE OO_STEP_LOG_BINDINGS
ADD CONSTRAINT PK_OO_STEP_BND1
PRIMARY KEY (ID);







--------------------------------------------------------------------------------------------------------------------------------------------
-- delete uit de OO_STEP_LOG_ENDED, aan de hand van id uit #3.  rm_sle_id  (is zelfde als de hash_id uit de STEP_LOG_STARTED)
delete from owner_odr.oo_step_log_ended where STEP_ENDED_HASH_ID IN (SELECT STEP_HASH_ID FROM owner_odr.rm_sls_hash_id);     ---11 uur    240 milj uit sls_hash. 
delete from owner_odr.oo_step_log_ended where ID IN (SELECT ID FROM owner_odr.rm_sle_id);     
create 
create table owner_odr.rm_sle_id_temp (id number);
create table owner_odr.rm_sle_id_bck as (select * from owner_odr.rm_sle_id);
create table owner_odr.status_ave(teller number);


--------------------------------------------------------------------------------------------------------------------------------------------








-- tussen tabellen
create table owner_odr.rm_sle_id_temp (id number);
create table owner_odr.rm_sle_id_bck as (select * from owner_odr.rm_sle_id);
create table owner_odr.status_ave(teller number);
alter table owner_odr.rm_sle_id_temp parallel 32;
alter table owner_odr.rm_exec_sum_id parallel 32;
alter table owner_odr.rm_sls_hash_id parallel 32;
alter table owner_odr.rm_sle_id parallel 32;
dan de DELETES: 

controle tijdelijke tabellen:
select count(1) from owner_odr.rm_exec_sum_id;
select count(1) from owner_odr.rm_sls_hash_id;
select count(1) from owner_odr.rm_sle_id;

