tabel met de te importeren nummer aanmaken en vullen.
create table owner_oox.lookup_table(id number);

insert into owner_oox.lookup_table (
select execution_id from  owner_oox.oo_execution_summary where
START_TIME_LONG > ( (to_date('01/01/2020 00:00:00', 'MM/DD/YYYY HH24:MI:SS') - to_date('19700101', 'YYYYMMDD')) * 24 * 60 * 60 * 1000))


insert into owner_oox.lookup_table(id)values(8196001961); 
insert into owner_oox.lookup_table(id)values(8263420506); 

 (select id from owner_oox.lookup_table)


Export de tabellen.
PAR file:   HOO_CP.par  
userid="/ AS SYSDBA"
directory=DPUMP_EXPDIR
dumpfile=HOO_CP.dmp
logfile=exp_HOO_CP.log
tables=owner_oox.oo_execution_summary,owner_oox.OO_EXECUTED_FLOW_GRAPH,owner_oox.oo_flow_graph,owner_oox.OO_STEP_LOG_STARTED,owner_oox.OO_STEP_LOG_ENDED,
        owner_oox.oo_step_log_bindings,owner_oox.OO_EXECUTION_BOUND_INPUTS,owner_oox.OO_EXECUTION_BOUND_OUTPUTS
query=owner_oox.oo_execution_summary:"where execution_id in (select id from owner_oox.lookup_table)"
query=owner_oox.OO_EXECUTED_FLOW_GRAPH:"where execution_id in (select id from owner_oox.lookup_table)"
query=owner_oox.oo_flow_graph:"where id in (select FLOW_GRAPH_ID from owner_oox.OO_EXECUTED_FLOW_GRAPH where execution_id in (select id from owner_oox.lookup_table))"
query=owner_oox.OO_STEP_LOG_STARTED:"where execution_id in  (select id from owner_oox.lookup_table)"
query=owner_oox.OO_STEP_LOG_ENDED:"where STEP_ENDED_HASH_ID in (select STEP_HASH_ID from owner_oox.OO_STEP_LOG_STARTED where execution_id in  (select id from owner_oox.lookup_table))"
query=owner_oox.oo_step_log_bindings:"where STEP_LOG_ENDED_ID in
        (select id from owner_oox.OO_STEP_LOG_ENDED where STEP_ENDED_HASH_ID in (select STEP_HASH_ID from owner_oox.OO_STEP_LOG_STARTED where execution_id in  (select id from owner_oox.lookup_table)))"
query=owner_oox.OO_EXECUTION_BOUND_INPUTS:"where execution_id in (select id from owner_oox.lookup_table)"
query=owner_oox.OO_EXECUTION_BOUND_OUTPUTS:"where execution_id in (select id from owner_oox.lookup_table)"


scp exdb3301-adm:/orabackup1/GHOO1/export/HOO_GA_2_D1.dmp .
chmod 777  /orabackup1/GHOO1/export/HOO_GA_2_D1.dmp  


IMPORT:  eerste de meeste, o.a. parent tabellen. dan not een laatste child. 

userid="/ AS SYSDBA"
directory=DPUMP_EXPDIR
dumpfile=HOO_GA_2_D.dmp
logfile=imp_hoo_ga_2_d2.log
tables=owner_oox.oo_execution_summary,owner_oox.oo_flow_graph,owner_oox.OO_STEP_LOG_STARTED,owner_oox.OO_STEP_LOG_ENDED,owner_oox.oo_step_log_bindings,owner_oox.OO_EXECUTION_BOUND_INPUTS,owner_oox.OO_EXECUTION_BOUND_OUTPUTS
CONTENT=DATA_ONLY
DATA_OPTIONS=SKIP_CONSTRAINT_ERRORS
TABLE_EXISTS_ACTION=APPEND



userid="/ AS SYSDBA"
directory=DPUMP_EXPDIR
dumpfile=HOO_GA_2_D.dmp
logfile=imp_hoo_ga_2_d2.log
tables=OWNER_OOX.OO_EXECUTED_FLOW_GRAPH
CONTENT=DATA_ONLY
DATA_OPTIONS=SKIP_CONSTRAINT_ERRORS
TABLE_EXISTS_ACTION=APPEND

