DECLARE x integer := 0;
BEGIN
  STEP_LOG_MIGRATION.StepOrderCreator(
    x       /* ReturnValue */
  );
END;

-- SET parameters for sqlplus client. May be commented out if irrelevant
SET serveroutput ON SIZE 100000
SET LINESIZE 15000
SET PAGESIZE 1500

 

DECLARE x integer := 0;
BEGIN
  STEP_LOG_MIGRATION.StepOrderCreator(
    x       /* ReturnValue */
  );
END;

 
  WHILE vGeneralCount >= vBatchSize
  LOOP
    BEGIN
      MERGE INTO OO_STEP_LOG_STARTED SLS
      USING (WITH CTE AS (SELECT ID,EXECUTION_ID, ROW_NUMBER() OVER (PARTITION BY EXECUTION_ID ORDER BY STEP_SEQ_ORDER ASC) AS RN FROM OO_STEP_LOG_STARTED) SELECT ID,RN FROM CTE WHERE RN BETWEEN vMinStepOrder AND vMaxStepOrder) CRN
      ON (SLS.ID = CRN.ID)
      WHEN MATCHED THEN 
      UPDATE SET SLS.STEP_START_ORDER = CRN.RN;
	  vGeneralCount := SQL%ROWCOUNT;
	  EXCEPTION WHEN resrcBusyExcptn THEN
	    dbms_output.put_line(TO_CHAR(CURRENT_DATE, 'dd/mm/yyyy hh24:mi:ss') || ' ERROR: OO_STEP_LOG_STARTED table is busy, could not lock it for update.');
		vGeneralError := 1;
		GOTO summary;
	  WHEN OTHERS THEN
	    dbms_output.put_line(SUBSTR(SQLERRM, 1, 200));
		vGeneralError := 1;
		GOTO summary;
	  END;
	  COMMIT;
	  end loop;
	  
	  
	  
	  
Werkt voor geen meter. kan niet online:




--Creeer tussen tabel met de rn_nummer en id, zoals in de proc. 
create table owner_oox.ave_test1 as (SELECT ID,EXECUTION_ID, ROW_NUMBER() OVER (PARTITION BY EXECUTION_ID ORDER BY STEP_SEQ_ORDER ASC) AS RN FROM owner_oox.OO_STEP_LOG_STARTED);

--creeer een status tabel, waar voor tijdens het proces. 
create table owner_oox.ave_stat ( rn_nummer number,  tijdstip date);

creeer indexen. 
	  create index owner_oox.ave_t_rn_idx1 on owner_oox.ave_test1(rn);
	  create index owner_oox.ave_t_id_idx1 on owner_oox.ave_test1(id);
	  create index owner_oox.ave_t_id_rn_idx1 on owner_oox.ave_test1(id,rn);
	  

-- de update die altijd werkt is: 
update owner_oox.OO_STEP_LOG_STARTED SLS SET SLS.STEP_START_ORDER = 1 where SLS.ID in (select id from owner_oox.ave_test1 CRN where rn =1 );

-- gooi dit in een loop, met wat extra  parallelisatie


ALTER SESSION FORCE PARALLEL DML PARALLEL 32;
ALTER SESSION ENABLE PARALLEL DML; 
ALTER SESSION FORCE PARALLEL DDL PARALLEL 32;
ALTER SESSION ENABLE PARALLEL DDL; 

set serveroutput on
Declare
teller number := 1;

Begin
For teller in 1..100
Loop
DBMS_OUTPUT.PUT_LINE(teller);
update owner_oox.OO_STEP_LOG_STARTED SLS SET SLS.STEP_START_ORDER = teller where SLS.ID in (select id from owner_oox.ave_test1 CRN where rn = teller );
insert into owner_oox.ave_stat values (teller, sysdate);
commit;
End Loop;
COMMIT;
End;
/

