SCRIPTS AAN DE HAND VAN WAT WEG MOET.   dus:  kleiner dan 01012020  gaat weg!
1. maak lijst uit summary wat weg mag. 
2. maak lijst van started wat weg mag. (aan de hand van 1). 
3. maak lijst van ended wat weg mag aan de hand van 2. 
4. verwijder uit step_log_Bindings aan de hand van lijst 3. 
5. verwijder uit OO_EXECUTION_BOUND_OUTPUTS aan de hnad van lijst  1 (summary)
6. verwijder uit OO_EXECUTION_BOUND_INPUTS  aan de hand van lijst uit 2.



-- # 1
-- maak tabel met id uit owner_oox.OO_EXECUTION_SUMMARY die weg mogen!   
-- (2 sec)
drop table owner_oox.rm_exec_sum_id;
create table owner_oox.rm_exec_sum_id as 
select EXECUTION_ID from owner_oox.OO_EXECUTION_SUMMARY 
WHERE (TIMESTAMP '1970-01-01 00:00:00 GMT' + numtodsinterval(START_TIME_LONG/1000, 'SECOND')) AT TIME ZONE 'Europe/Amsterdam' < TO_DATE('01-01-2020', 'DD-MM-YYYY'); 
==>  681314

select count(1) from owner_oox.OO_EXECUTION_SUMMARY 
WHERE (TIMESTAMP '1970-01-01 00:00:00 GMT' + numtodsinterval(START_TIME_LONG/1000, 'SECOND')) AT TIME ZONE 'Europe/Amsterdam' < TO_DATE('01-01-2020', 'DD-MM-YYYY'); 


-- 2 # 
-- maak een tabel met HASH_ID rm_sls_hash_id van wat uit step_log_ended weg mag, aan de hand van wat van started weg mag. 

    -- 1 min. 
drop table owner_oox.rm_sls_hash_id;
create table owner_oox.rm_sls_hash_id as (select STEP_HASH_ID FROM owner_oox.OO_STEP_LOG_STARTED
 WHERE EXECUTION_ID IN (SELECT EXECUTION_ID FROM owner_oox.rm_exec_sum_id));


													
-- # 3   duur: 2 min. 
--- maak tabel met SELECT ID FROM OO_STEP_LOG_ENDED wat weg mag. de step_ended_hash_id is de step_hash_id uit SLS
drop table owner_oox.rm_sle_id;
create table owner_oox.rm_sle_id as (select id from owner_oox.oo_step_log_ended where STEP_ENDED_HASH_ID IN (SELECT STEP_HASH_ID FROM owner_oox.rm_sls_hash_id));
select count(1) from owner_oox.rm_sle_id;


select count(1) from owner_oox.rm_sle_id;
select count(1) from owner_oox.rm_sle_id_temp;
select count(1) from owner_oox.OO_STEP_LOG_BINDINGS;
select count(1) from owner_oox.oo_step_log_ended;

set timing on
set serveroutput on
ALTER SESSION ENABLE PARALLEL DML;
ALTER SESSION ENABLE PARALLEL DDL;
alter table owner_oox.OO_EXECUTION_SUMMARY parallel 32;
alter table owner_oox.OO_STEP_LOG_STARTED parallel 32;
alter table owner_oox.OO_STEP_LOG_ENDED parallel 32;
alter table owner_oox.OO_STEP_LOG_BINDINGS parallel 32;
alter table owner_oox.OO_EXECUTION_BOUND_OUTPUTS parallel 32;
alter table owner_oox.OO_EXECUTION_BOUND_INPUTS parallel 32;


-- Counts before											VOOR              NA
SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_SUMMARY;        
SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_STARTED;         
SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_ENDED;           
SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_BINDINGS;        
SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_BOUND_OUTPUTS;  
SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_BOUND_INPUTS;   


SELECT S.OWNER "Owner",NVL(S.SEGMENT_NAME, 'TABLE TOTAL SIZE') "Segment name",ROUND(SUM(S.BYTES)/1024/1024/1024,1) "Segment size (GB)"
FROM DBA_SEGMENTS S
WHERE S.OWNER = 'OWNER_OOX' and S.SEGMENT_NAME IN ('OO_EXECUTION_SUMMARY', 'OO_STEP_LOG_STARTED', 'OO_STEP_LOG_ENDED', 'OO_STEP_LOG_BINDINGS', 'OO_EXECUTION_BOUND_OUTPUTS', 'OO_EXECUTION_BOUND_INPUTS')
OR S.SEGMENT_NAME IN (
                    (
                        SELECT L.SEGMENT_NAME FROM DBA_LOBS L WHERE L.TABLE_NAME in ('OO_EXECUTION_SUMMARY', 'OO_STEP_LOG_STARTED', 'OO_STEP_LOG_ENDED', 'OO_STEP_LOG_BINDINGS', 'OO_EXECUTION_BOUND_OUTPUTS', 'OO_EXECUTION_BOUND_INPUTS')
                    )
)
GROUP BY S.OWNER,ROLLUP(S.SEGMENT_NAME)
ORDER BY 1,2,3;



-- tussen tabellen
create table owner_oox.rm_sle_id_temp (id number);
create table owner_oox.rm_sle_id_bck as (select * from owner_oox.rm_sle_id);
create table owner_oox.status_ave(teller number);
alter table owner_oox.rm_sle_id_temp parallel 32;
alter table owner_oox.rm_exec_sum_id parallel 32;
alter table owner_oox.rm_sls_hash_id parallel 32;
alter table owner_oox.rm_sle_id parallel 32;
dan de DELETES: 

controle tijdelijke tabellen:
select count(1) from owner_oox.rm_exec_sum_id;
select count(1) from owner_oox.rm_sls_hash_id;
select count(1) from owner_oox.rm_sle_id;


-- delete uit de OO_Execution_summary, waar exection+id in de tabel #1 zit
delete from owner_oox.OO_EXECUTION_SUMMARY where execution_id in (select EXECUTION_ID from owner_oox.rm_exec_sum_id);   -- prod: 1 min 


--delete uit OO_EXECUTION_BOUND_INPUTS  aan de hand van execution_id die in execution_summery komt. 
delete from owner_oox.OO_EXECUTION_BOUND_INPUTS WHERE EXECUTION_ID IN (SELECT EXECUTION_ID FROM owner_oox.rm_exec_sum_id);    -- prod: 3 min 

--delete uit OO_EXECUTION_BOUND_OUTPUTS  aan de hand van execution_id die in execution_summery komt. 
delete from owner_oox.OO_EXECUTION_BOUND_OUTPUTS WHERE EXECUTION_ID IN (SELECT EXECUTION_ID FROM owner_oox.rm_exec_sum_id);    -- prod: 3 min 



-- delete uit de oo_step_log_Started. kan aan de hand van de execu tion_id die in execution_summery zit
-- delete from owner_oox.OO_STEP_LOG_STARTED where execution_id in (select EXECUTION_ID from owner_oox.rm_exec_sum_id);   te groot: te lang op prod, daarom met procedure.


create table owner_oox.rm_exec_sum_id_sls as (select EXECUTION_ID from owner_oox.rm_exec_sum_id);
create table owner_oox.rm_exec_sum_id_sls_tmp as (select EXECUTION_ID from owner_oox.rm_exec_sum_id where 1=0);

select count(1) from owner_oox.rm_exec_sum_id_sls;   -- start:    1.824.202
select count(1) from owner_oox.OO_STEP_LOG_STARTED;   -- start: 335.986.304

-- we hebben een rm_exec_sum_id_sls en een rm_exec_sum_id_sls_tmp
--  move 1000 van sls naar sls_tmp  (dus cp en del)
-- del uit step_log_Started, waar id uit de sls_tmp zit. 
-- voor de voortgang: hou aantal in sls bij. 

set serveroutput on
Declare
teller number := 1;

Begin
For teller in 1..100
Loop
DBMS_OUTPUT.PUT_LINE(teller);
insert into owner_oox.rm_exec_sum_id_sls_tmp ( select * from  owner_oox.rm_exec_sum_id_sls where rownum < 1000);
commit;
delete from owner_oox.rm_exec_sum_id_sls where EXECUTION_ID in (select EXECUTION_ID from owner_oox.rm_exec_sum_id_sls_tmp);
delete from owner_oox.OO_STEP_LOG_STARTED where execution_id IN (SELECT execution_id FROM owner_oox.rm_exec_sum_id_sls_tmp);
execute immediate 'truncate table owner_oox.rm_exec_sum_id_sls_tmp'; 
commit;
End Loop;
End;
/




-- delete uit de OO_STEP_LOG_ENDED, aan de hand van id uit #3.  rm_sle_id  (is zelfde als de hash_id uit de STEP_LOG_STARTED)
delete from owner_oox.oo_step_log_ended where STEP_ENDED_HASH_ID IN (SELECT STEP_HASH_ID FROM owner_oox.rm_sls_hash_id);     ---11 uur     
--- OF
delete from owner_oox.oo_step_log_ended where ID IN (SELECT ID FROM owner_oox.rm_sle_id);     



set serveroutput on
Declare
teller number := 1;

Begin
For teller in 1..100
Loop
DBMS_OUTPUT.PUT_LINE(teller);
insert into owner_oox.rm_sle_id_temp ( select * from  owner_oox.rm_sle_id where rownum < 1000);
commit;
delete from owner_oox.rm_sle_id where id in (select id from owner_oox.rm_sle_id_temp);
-- delete from owner_oox.OO_STEP_LOG_BINDINGS where STEP_LOG_ENDED_ID IN (SELECT ID FROM owner_oox.rm_sle_id_temp);
delete from owner_oox.oo_step_log_ended where ID IN (SELECT ID FROM owner_oox.rm_sle_id_temp);
execute immediate 'truncate table owner_oox.rm_sle_id_temp'; 
insert into owner_oox.status_ave values (teller);
commit;
End Loop;
End;
/


--e OO_STEP_LOG_BINDINGS die er moeten zijn zijn hebben de id uit sle_ids
--select count(1) from owner_oox.OO_STEP_LOG_BINDINGS where STEP_LOG_ENDED_ID in (select id from owner_oox.SLE_ids);
--create table owner_oox.OO_STEP_LOG_BINDINGS_1 as select * from owner_oox.OO_STEP_LOG_BINDINGS where STEP_LOG_ENDED_ID in (select id from owner_oox.SLE_ids);  ( max 1.30 uur)
-- create table owner_oox.SLE_ids as (select STEP_ENDED_HASH_ID, id from owner_oox.oo_step_log_ended where STEP_ENDED_HASH_ID in (select STEP_HASH_ID from owner_oox.oo_step_log_Started))






-- STEP_LOG_BINDINGS
alter table owner_oox.OO_STEP_LOG_BINDINGS parallel 32;
alter index owner_oox.PK_OO_STEP_BND parallel 32;

CREATE TABLE owner_oox.OO_STEP_LOG_BINDINGS2 parallel 32 as
SELECT /*+ parallel(32) */ * FROM owner_oox.OO_STEP_LOG_BINDINGS
WHERE STEP_LOG_ENDED_ID IN (SELECT ID FROM owner_oox.OO_STEP_LOG_ENDED);

DROP TABLE OO_STEP_LOG_BINDINGS;
alter session set current_Schema=owner_oox;

ALTER TABLE OO_STEP_LOG_BINDINGS RENAME to OO_STEP_LOG_BINDINGS_org;
ALTER TABLE OO_STEP_LOG_BINDINGS2 RENAME to OO_STEP_LOG_BINDINGS;

CREATE UNIQUE INDEX "OWNER_OOX"."PK_OO_STEP_BND1" ON "OWNER_OOX"."OO_STEP_LOG_BINDINGS" ("ID") TABLESPACE "OOXD" parallel 32;
CREATE INDEX "OWNER_OOX"."FK_ID1" ON "OWNER_OOX"."OO_STEP_LOG_BINDINGS" ("STEP_LOG_ENDED_ID") TABLESPACE "OOXD" parallel 32;

ALTER TABLE OO_STEP_LOG_BINDINGS
ADD CONSTRAINT PK_OO_STEP_BND1
PRIMARY KEY (ID);






Declare
teller number := 1;

Begin
For teller in 1..100
Loop
DBMS_OUTPUT.PUT_LINE(teller);
insert into owner_oox.rm_sle_id_temp ( select * from  owner_oox.rm_sle_id where rownum < 1000);
commit;
delete from owner_oox.rm_sle_id where id in (select id from owner_oox.rm_sle_id_temp);
delete from owner_oox.OO_STEP_LOG_BINDINGS where STEP_LOG_ENDED_ID IN (SELECT ID FROM owner_oox.rm_sle_id_temp);
delete from owner_oox.oo_step_log_ended where ID IN (SELECT ID FROM owner_oox.rm_sle_id_temp);
execute immediate 'truncate table owner_oox.rm_sle_id_temp'; 
insert into owner_oox.status_ave values (teller);
commit;
End Loop;
End;
/



--------------------------------------------------------------------------------------------------------------------------------------------
-- delete uit de OO_STEP_LOG_ENDED, aan de hand van id uit #3.  rm_sle_id  (is zelfde als de hash_id uit de STEP_LOG_STARTED)
delete from owner_oox.oo_step_log_ended where STEP_ENDED_HASH_ID IN (SELECT STEP_HASH_ID FROM owner_oox.rm_sls_hash_id);     ---11 uur    240 milj uit sls_hash. 
delete from owner_oox.oo_step_log_ended where ID IN (SELECT ID FROM owner_oox.rm_sle_id);     
create 
create table owner_oox.rm_sle_id_temp (id number);
create table owner_oox.rm_sle_id_bck as (select * from owner_oox.rm_sle_id);
create table owner_oox.status_ave(teller number);


--------------------------------------------------------------------------------------------------------------------------------------------







------------------------------------------------
TEllingen vooral:

Owner                          Segment name                               Segment size (GB)
------------------------------ ------------------------------------------ -----------------
OWNER_OOX                      OO_EXECUTION_BOUND_INPUTS                                 .3
OWNER_OOX                      OO_EXECUTION_BOUND_OUTPUTS                                .2
OWNER_OOX                      OO_EXECUTION_SUMMARY                                       1
OWNER_OOX                      OO_STEP_LOG_BINDINGS                                   742.8
OWNER_OOX                      OO_STEP_LOG_ENDED                                       89.4
OWNER_OOX                      OO_STEP_LOG_STARTED                                    116.7

OWNER_OOX                      TABLE TOTAL SIZE                                       955.9


RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_SUMMARY;           2529320
RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_STARTED;          335986304
RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_ENDED;            335966922
RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_BINDINGS;        3154198094
RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_BOUND_OUTPUTS;     3001439
RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_BOUND_INPUTS;      3731368


TEllingen achteraf:
OWNER_OOX                      OO_EXECUTION_BOUND_INPUTS                            .3
OWNER_OOX                      OO_EXECUTION_BOUND_OUTPUTS                           .2
OWNER_OOX                      OO_EXECUTION_SUMMARY                                   1
OWNER_OOX                      OO_STEP_LOG_BINDINGS                                217
OWNER_OOX                      OO_STEP_LOG_ENDED                                  89.4
OWNER_OOX                      OO_STEP_LOG_STARTED                               116.7
OWNER_OOX                      TABLE TOTAL SIZE                                  447.9


RABO_USER @srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_SUMMARY;           705118
RABO_USER @srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_STARTED;          97404679
RABO_USER @srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_ENDED;            97386206
RABO_USER @srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_BINDINGS;        906316610
RABO_USER @srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_BOUND_OUTPUTS;     861266
RABO_USER @srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_BOUND_INPUTS;     1116595


NA de toevoeging van ODR:


16:23:55 RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_SUMMARY;          722066
16:25:45 RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_STARTED;        100669432
16:25:46 RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_ENDED;          100650959
16:25:46 RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_STEP_LOG_BINDINGS;       937017700
16:25:49 RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_BOUND_OUTPUTS;    887966
16:25:49 RABO_USER @ srv0phoo101 > SELECT COUNT(*) FROM owner_oox.OO_EXECUTION_BOUND_INPUTS;    1143495


