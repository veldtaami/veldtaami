1. Stop all execution activity on Central (incoming triggers, schedules) and wait for all normal (healthy) executions to finish their jobs.
!! Only the corrupted executions should be remaining as running/paused.
2. Stop all Central and RAS services


TRUNCATE TABLE owner_ooy.OO_FINISHED_BRANCHES;
Truncate table owner_ooy.OO_SUSPENDED_EXECUTIONS;
TRUNCATE TABLE owner_ooy.OO_EXECUTION_QUEUES_1;
TRUNCATE TABLE owner_ooy.OO_EXECUTION_QUEUES;
TRUNCATE TABLE owner_ooy.OO_EXECUTION_STATES_1;
TRUNCATE TABLE owner_ooy.OO_EXECUTION_STATES_2;
TRUNCATE TABLE owner_ooy.OO_EXECUTION_STATES;
TRUNCATE TABLE owner_ooy.OO_DEBUGGER_EVENTS; 

//only if you used remote debugging towards that environment

UPDATE owner_ooy.OO_EXECUTION_SUMMARY SET STATUS='CANCELED', RESULT_STATUS_TYPE=NULL, RESULT_STATUS_NAME=NULL, ROI=NULL where STATUS NOT IN ('COMPLETED','CANCELED','SYSTEM_FAILURE');

Restart Centrals, RASes and check the state of the OO.




select count(1) from owner_ooy.OO_FINISHED_BRANCHES;
select count(1) from  owner_ooy.OO_SUSPENDED_EXECUTIONS;
select count(1) from owner_ooy.OO_EXECUTION_QUEUES_1;
select count(1) from owner_ooy.OO_EXECUTION_QUEUES;
select count(1) from owner_ooy.OO_EXECUTION_STATES_1;
select count(1) from owner_ooy.OO_EXECUTION_STATES_2;
select count(1) from owner_ooy.OO_EXECUTION_STATES;
select count(1) from owner_ooy.OO_DEBUGGER_EVENTS; 


create table owner_ooy.OO_FINISHED_BRANCHES_bck as select * From     owner_ooy.OO_FINISHED_BRANCHES;
create table owner_ooy.OO_SUSPENDED_EXECUTIONS_bck as select * From owner_ooy.OO_SUSPENDED_EXECUTIONS;
create table owner_ooy.OO_EXECUTION_QUEUES_1_bck as select * From owner_ooy.OO_EXECUTION_QUEUES_1;
create table owner_ooy.OO_EXECUTION_QUEUES_bck as select * From owner_ooy.OO_EXECUTION_QUEUES;
create table owner_ooy.OO_EXECUTION_STATES_1_bck as select * From owner_ooy.OO_EXECUTION_STATES_1;
create table owner_ooy.OO_EXECUTION_STATES_2_bck as select * From owner_ooy.OO_EXECUTION_STATES_2;
create table owner_ooy.OO_EXECUTION_STATES_bck as select * From owner_ooy.OO_EXECUTION_STATES;
create table owner_ooy.OO_DEBUGGER_EVENTS_bck as select * From owner_ooy.OO_DEBUGGER_EVENTS;
