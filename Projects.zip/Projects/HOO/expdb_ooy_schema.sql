DPUMP_EXPDIR                             /orabackup1/GHOO1/export


  
userid="/ AS SYSDBA" 
schemas=OWNER_OOY 
directory=DPUMP_EXPDIR 
dumpfile=owner_ooy_2605.dmp
logfile=owner_ooy_exp.dmp
parallel=4

