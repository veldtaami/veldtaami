3702

cat /u01/app/grid/diag/tnslsnr/exdb3702-adm/listener_scan1/trace/listener_scan1.log | grep -i srv0psib101 >> listener_scan1.log
cat /u01/app/grid/diag/tnslsnr/exdb3702-adm/listener/trace/listener.log  | grep -i srv0psib101 >> listener.log
 
op de 3701:

cat /u01/app/grid/diag/tnslsnr/exdb3701-adm/listener_scan3/trace/listener_scan3.log | grep -i srv0psib101 >> listener_scan3.log 
cat /u01/app/grid/diag/tnslsnr/exdb3701-adm/listener_scan2/trace/listener_scan2.log | grep -i srv0psib101 >> listener_scan2.log



for t in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 ; do echo Tijdstip: "$t";
for i in psib lsrv0635 lsrv0634 ;  do echo "$i"; cat listener_scan1.18_*.log | grep '18-JUN-2020 '"$t" | grep -c -i $i ; done; done;


date; for i in psib lsrv0635 lsrv0634 ;  do echo "$i"; cat /u01/app/grid/diag/tnslsnr/exdb3702-adm/listener_scan1/trace/listener_scan1.log | grep -c -i $i; done;

for i in {1..50} ; do echo "$i";  for n in lsrv0635 lsrv0634 ; do cat /u01/app/grid/diag/tnslsnr/exdb3702-adm/listener_scan1/trace/listener_scan1.log | grep -c -i $n ; done; sleep 5; done;



for t in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 ; do echo Tijdstip: "$t";
for i in  lsrv0635 lsrv0634 ;  do echo "$i"; cat listener_scan1.log | grep '16-OCT-2020 '"$t" | grep -c -i $i ; done; done;



per dag:
 cd /u01/app/grid/diag/tnslsnr/exdb3702-adm/listener_scan1/trace/
for i in psib lsrv0635 lsrv0634 ;  do echo "$i"; cat listener_scan1* | grep '10-AUG-2020' | grep -c -i $i ; done; 


today=date +%d-%b-%Y
for t in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 ; do echo Tijdstip: "$t";
for i in  srv0psib101 lsrv0635 lsrv0634 ;  
do echo -n "$i"; 
cat /u01/app/grid/diag/tnslsnr/exdb3702-adm/listener/trace/listener.log | grep "$today $t" | grep -c -i $i ; done; done;






mailen:
cat ... | mail -s "aantallen request naar de listener"  anwar.van.der.veldt@rabobank.nl

/orabackup1/PSIB1/scripts/monitor_lsnr_request.sh


