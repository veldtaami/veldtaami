-- creeer de task
7v74ngaw3rb04
DECLARE
 stmt_task VARCHAR2(64);
BEGIN
 stmt_task:=dbms_sqltune.create_tuning_task(sql_id => '9cmw23g3uj2sc', plan_hash_value => '3353700438', time_limit => 3600, task_name => 'prob_sum_q1', description => 'probsummary');
END;
/

DECLARE
 stmt_task VARCHAR2(64);
BEGIN
 stmt_task:=dbms_sqltune.create_tuning_task(sql_id => '7v74ngaw3rb04', time_limit => 7200, task_name => 'task1', description => 'task');
END;
/


-- uitvoeren van de task:
EXECUTE dbms_sqltune.execute_tuning_task('task1');


--voortgang bekijken

ALTER SESSION SET nls_date_format='dd-mon-yyyy hh24:mi:ss';

col description FOR a40
SELECT task_name, description, advisor_name, execution_start, execution_end, status
 FROM dba_advisor_tasks
 WHERE owner='    '
 ORDER BY task_id DESC;
 
-- resultaat bekijken 
SET linesize 200
SET LONG 999999999
SET pages 1000
SET longchunksize 20000
SELECT dbms_sqltune.report_tuning_task('task1', 'TEXT', 'ALL') FROM dual;
 
 
 EXECUTE dbms_sqltune.drop_tuning_task('prob_sum_q1');

 
 
 
 
 
 
execute dbms_stats.gather_table_stats(ownname => 'OWNER_OOX', tabname =>'RM_EXEC_SUM_ID_SLS_TMP', estimate_percent =>  DBMS_STATS.AUTO_SAMPLE_SIZE, method_opt => 'FOR ALL COLUMNS SIZE AUTO');



gz48m5m94a9fr


DECLARE
 stmt_task VARCHAR2(64);
BEGIN
 stmt_task:=dbms_sqltune.create_tuning_task(sql_id => '&sql_id',  time_limit => 3600, task_name => 'Task1', description => 'task1');
END;
/


-- uitvoeren van de task:
EXECUTE dbms_sqltune.execute_tuning_task('Task1');


SET linesize 200
SET LONG 999999999
SET pages 1000
SET longchunksize 20000
SELECT dbms_sqltune.report_tuning_task('Task1', 'TEXT', 'ALL') FROM dual;
 
  
EXECUTE dbms_sqltune.drop_tuning_task('Task1');

 

7q2cnwh4fj0t0	
