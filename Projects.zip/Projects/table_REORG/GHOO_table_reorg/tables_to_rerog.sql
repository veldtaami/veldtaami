set lines 200
set pages 99
col table_name for a30
col owner for a30
set serveroutput on

select * from (
SELECT TABLE_NAME, owner ,
         ROUND((BLOCKS * 8/1024),2) "SIZE (MB)",
         ROUND((NUM_ROWS * AVG_ROW_LEN / 1024/1024), 2) "ACTUAL DATA (MB)",
         (ROUND((BLOCKS * 8/1024),2) - ROUND((NUM_ROWS * AVG_ROW_LEN / 1024/1024), 2)) "WASTED (MB)"
    FROM DBA_TABLES
   WHERE (ROUND((BLOCKS * 8/1024),2) > ROUND((NUM_ROWS * AVG_ROW_LEN / 1024/1024), 2))
       --AND OWNER = 'OWNER_SM1' --  and table_name = 'DBDICTM1'
ORDER BY 4 DESC )
where rownum < 10;


TABLE_NAME                     OWNER                           SIZE (MB) ACTUAL DATA (MB) WASTED (MB)
------------------------------ ------------------------------ ---------- ---------------- -----------
OO_STEP_LOG_BINDINGS           OWNER_ODR                       295834.67        158994.66   136840.01
OO_STEP_LOG_BINDINGS           OWNER_OOX                       227372.41        151750.64    75621.77
OO_STEP_LOG_STARTED            OWNER_ODR                        34778.18         29631.21     5146.97
OO_STEP_LOG_STARTED            OWNER_OOX                        25466.14         21617.57     3848.57
OO_STEP_LOG_ENDED              OWNER_ODR                           26786         21358.23     5427.77
OO_STEP_LOG_ENDED              OWNER_OOX                        14968.65         12175.11     2793.54
OO_STEP_LOG_BINDINGS           OWNER_OOY                        16172.38         10642.58      5529.8
OO_STEP_LOG_STARTED            OWNER_OOY                         2425.84          2066.96      358.88
OO_EXECUTED_FLOW_GRAPH         OWNER_OOX                         2163.08          1733.22      429.86




DECLARE
    v_TableCol VARCHAR2(100) := '';
    v_Size NUMBER := 0;
    v_TotalSize NUMBER := 0;
BEGIN
    FOR v_Rec IN (
                  SELECT OWNER || '.' || TABLE_NAME || '.' || COLUMN_NAME AS TableAndColumn,
                      'SELECT SUM(DBMS_LOB.GetLength("' || COLUMN_NAME || '"))/1024/1024 AS SizeMB FROM ' || OWNER || '.' || TABLE_NAME AS sqlstmt
                  FROM DBA_TAB_COLUMNS
                  WHERE DATA_TYPE LIKE '_LOB'
                        AND OWNER = 'OWNER_ODR' and table_name = 'OO_STEP_LOG_BINDINGS'
                                      )
    LOOP
        DBMS_OUTPUT.PUT_LINE (v_Rec.sqlstmt);
        EXECUTE IMMEDIATE v_Rec.sqlstmt INTO v_Size;

        DBMS_OUTPUT.PUT_LINE (v_Rec.TableAndColumn || ' size in MB is ' || ROUND(NVL(v_Size,0),2));
        v_TotalSize := v_TotalSize + NVL(v_Size,0);
    END LOOP;

    DBMS_OUTPUT.PUT_LINE ('Total size in MB is ' || ROUND(v_TotalSize,2));
END;
/


 select SEGMENT_NAME, TABLE_NAME, OWNER from dba_lobs where owner = 'OWNER_ODR' and table_name = 'OO_STEP_LOG_BINDINGS';
 select sum(bytes)/1024/1024 MB   , SEGMENT_NAME from dba_segments where segment_name in 
   (select SEGMENT_NAME from dba_lobs where owner = 'OWNER_ODR' and table_name = 'OO_STEP_LOG_BINDINGS')
   group by segment_name;
 
 
select sum(bytes)/1024/1024 MB   , SEGMENT_NAME, TABLESPACE_NAME from dba_segments where segment_name in
(select SEGMENT_NAME from dba_lobs where owner = 'OWNER_ODR' and table_name = 'OO_STEP_LOG_BINDINGS')
group by segment_name, TABLESPACE_NAME;

        MB SEGMENT_NAME
---------- --------------------------------------------------------------------------------------------------------------------------------
      .125 SYS_LOB0000808761C00005$$
 20856.125 SYS_LOB0000808761C00008$$    ---- en met  de procedure getlenght komt eruit:    Total size in MB is 9865.28

2 rows selected.

RABO_USER @ srv0ghoo101 >


 
Stappen: Nieuwe tablespace aanmaken. 
Tabel verplaatsen. 

create tablespace ODRD_MV datafile '+DATA' size 1G autoextend on maxsize 300G ;
alter user owner_odr quota unlimited on odrd_mv;

alter table owner_odr.OO_STEP_LOG_BINDINGS move tablespace odrd_mv;   --   Elapsed: 00:35:00.90


move LOB-segs. 

alter table owner_odr.OO_STEP_LOG_BINDINGS move lob (BINDING_BIG_C_VALUE) store as SYS_LOB0000808761C00008$$ ( tablespace ODRD_MV);
alter table owner_odr.OO_STEP_LOG_BINDINGS move lob (BINDING_BIG_VALUE) store as SYS_LOB0000808761C00005$$ ( tablespace ODRD_MV);

select table_name,COLUMN_NAME,SEGMENT_NAME,TABLESPACE_NAME from dba_lobs where OWNER='OWNER_ODR' and table_name = 'OO_STEP_LOG_BINDINGS';





 