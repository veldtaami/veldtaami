set lines 200
set pages 99
col table_name for a30
col owner for a30
set serveroutput on

SELECT TABLE_NAME, owner ,
         ROUND((BLOCKS * 8/1024),2) "SIZE (MB)",
         ROUND((NUM_ROWS * AVG_ROW_LEN / 1024/1024), 2) "ACTUAL DATA (MB)",
         (ROUND((BLOCKS * 8/1024),2) - ROUND((NUM_ROWS * AVG_ROW_LEN / 1024/1024), 2)) "WASTED (MB)"
    FROM DBA_TABLES
   WHERE (ROUND((BLOCKS * 8/1024),2) > ROUND((NUM_ROWS * AVG_ROW_LEN / 1024/1024), 2))  
       AND OWNER = 'OWNER_SM1'   
	   and table_name in  
('CM3RM1',
'CM3RA1',
'CM3RA2',
'CM3RA3',
'CM3RA4',
'CM3RA5',
'CM3RA6',
'CM3RA7',
'PROBSUMMARYM1',
'PROBSUMMARYA1',
'PROBSUMMARYA2',
'PROBSUMMARYA3',
'INCIDENTSM1',
'INCIDENTSA1',
'INCIDENTSA2',
'REQUESTM1',
'REQUESTA1',
'CM3TM1',
'CM3TA1',
'CM3TA2',
'CM3TA3',
'CONTCTSM1',
'CONTCTSA1')
ORDER BY 5 DESC ;


DECLARE
    v_TableCol VARCHAR2(100) := '';
    v_Size NUMBER := 0;
    v_TotalSize NUMBER := 0;
BEGIN
    FOR v_Rec IN (
                  SELECT OWNER || '.' || TABLE_NAME || '.' || COLUMN_NAME AS TableAndColumn,
                      'SELECT SUM(DBMS_LOB.GetLength("' || COLUMN_NAME || '"))/1024/1024 AS SizeMB FROM ' || OWNER || '.' || TABLE_NAME AS sqlstmt
                  FROM DBA_TAB_COLUMNS
                  WHERE DATA_TYPE LIKE '_LOB'
                        AND OWNER = 'OWNER_SM1' and table_name='INCIDENTSM1'
					   )
    LOOP
        DBMS_OUTPUT.PUT_LINE (v_Rec.sqlstmt);
        EXECUTE IMMEDIATE v_Rec.sqlstmt INTO v_Size;
 
        DBMS_OUTPUT.PUT_LINE (v_Rec.TableAndColumn || ' size in MB is ' || ROUND(NVL(v_Size,0),2));
        v_TotalSize := v_TotalSize + NVL(v_Size,0);
    END LOOP;
 
    DBMS_OUTPUT.PUT_LINE ('Total size in MB is ' || ROUND(v_TotalSize,2));
END;
/


SELECT SUM(DBMS_LOB.GetLength("DESCRIPTION"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1     453M
SELECT SUM(DBMS_LOB.GetLength("RESOLUTION"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1			134M
SELECT SUM(DBMS_LOB.GetLength("TEMP_UPDATE"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1		0M
SELECT SUM(DBMS_LOB.GetLength("UPDATE_ACTION"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1		497M
SELECT SUM(DBMS_LOB.GetLength("UPDATE_ACTION_ESS"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1	497M
SELECT SUM(DBMS_LOB.GetLength("SVC_OPTIONS"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1		45M
SELECT SUM(DBMS_LOB.GetLength("AGREEMENT_IDS"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1		7M

Tabel is 5.1G groot:  659882 blocks. 
RABO_USER @ srv0psib101 > select 659882*8/1024 mb from dual;

        MB
----------
5155.32813

de lob segmenten zijn:   RABO_USER @ srv0psib101 > select sum(bytes)/1024/1024 mb from dba_Segments where segment_name in (select SEGMENT_NAME from dba_lobs where table_name ='INCIDENTSM1');

        MB
----------
   7759.25
RABO_USER @ srv0psib101 >



totaal is tabel dus 13G



-- Enable row movement.
ALTER TABLE scott.emp ENABLE ROW MOVEMENT;

-- Recover space and amend the high water mark (HWM).
ALTER TABLE scott.emp SHRINK SPACE;

-- Recover space, but don't amend the high water mark (HWM).
ALTER TABLE scott.emp SHRINK SPACE COMPACT;

-- Recover space for the object and all dependant objects.
ALTER TABLE scott.emp SHRINK SPACE CASCADE;
-- Shrink a LOB segment (basicfile only).
ALTER TABLE table_name MODIFY LOB(lob_column) (SHRINK SPACE);
ALTER TABLE table_name MODIFY LOB(lob_column) (SHRINK SPACE CASCADE);





INCIDENTSM1    
FBI`	Set long 999

select dbms_metadata.get_ddl('INDEX', index_name , owner )
 from dba_indexes
 where index_type like 'FUNCTION-BASED%' and owner = 'OWNER_SM1' and table_name = 'INCIDENTSM1'


select 'select dbms_metadata.get_ddl(''INDEX'',''' || index_name || ''',''' || owner || ''') from dual;' 
 from dba_indexes
 where index_type like 'FUNCTION-BASED%' and owner = 'OWNER_SM1' and table_name = 'INCIDENTSM1'


  CREATE INDEX "OWNER_SM1"."INCIDENTSM1_MF_MP_MARTIJN1" ON "OWNER_SM1"."INCIDENTSM1" (NLSSORT("OPENED_BY_UID",'nls_sort=''BINARY_CI'''), "OPENED_BY_UID", 
  NLSSORT("CALLBACK_CONTACT",'nls_sort=''BINARY_CI'''), "CALLBACK_CONTACT", NLSSORT("CONTACT_NAME",'nls_sort=''BINARY_CI'''), "CONTACT_NAME", 
  NLSSORT("OPEN",'nls_sort=''BINARY_CI'''), "OPEN", NLSSORT("APPROVAL_STATUS",'nls_sort=''BINARY_CI'''), "APPROVAL_STATUS", NLSSORT("CATEGORY",'nls_sort=''BINARY_CI'''), "CATEGORY")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 TABLESPACE "SM1D";

  CREATE INDEX "OWNER_SM1"."INCIDENTSM1_MF_MP_MARTIJN2" ON "OWNER_SM1"."INCIDENTSM1" ("INCIDENT_ID", NLSSORT("OPENED_BY_UID",'nls_sort=''BINARY_CI'''), 
  NLSSORT("CALLBACK_CONTACT",'nls_sort=''BINARY_CI'''), NLSSORT("CONTACT_NAME",'nls_sort=''BINARY_CI'''), NLSSORT("OPEN",'nls_sort=''BINARY_CI'''),
NLSSORT("APPROVAL_STATUS",'nls_sort=''BINARY_CI'''), NLSSORT("CATEGORY",'nls_sort=''BINARY_CI'''))
  PCTFREE 10 INITRANS 2 MAXTRANS 255  TABLESPACE "SM1D";

  CREATE INDEX "OWNER_SM1"."INCIDENTSM1_MF_MP_MARTIJN3" ON "OWNER_SM1"."INCIDENTSM1" ("INCIDENT_ID", NLSSORT("OPENED_BY_UID",'nls_sort=''BINARY_CI'''), 
  NLSSORT("CALLBACK_CONTACT",'nls_sort=''BINARY_CI'''), NLSSORT("CONTACT_NAME",'nls_sort=''BINARY_CI'''), NLSSORT("OPEN",'nls_sort=''BINARY_CI'''),
  NLSSORT("APPROVAL_STATUS",'nls_sort=''BINARY_CI'''), NLSSORT("CATEGORY",'nls_sort=''BINARY_CI'''), "OPENED_BY_UID", "CALLBACK_CONTACT", 
  "CONTACT_NAME", "OPEN", "APPROVAL_STATUS", "CATEGORY")
  PCTFREE 10 INITRANS 2 MAXTRANS 255   TABLESPACE "SM1D";

  CREATE INDEX "OWNER_SM1"."INCIDENTSM178D546B1_FBI" ON "OWNER_SM1"."INCIDENTSM1" (NLSSORT("ACTIVE",'nls_sort=''BINARY_CI'''), 
  NLSSORT("CALLBACK_CONTACT",'nls_sort=''BINARY_CI'''), NLSSORT("CONTACT_NAME",'nls_sort=''BINARY_CI'''), "RN_UPDATE_TIME_REVERSED")
  PCTFREE 10 INITRANS 2 MAXTRANS 255   TABLESPACE "SM1D";

  CREATE INDEX "OWNER_SM1"."INCIDENTSM170F7B195_FBI" ON "OWNER_SM1"."INCIDENTSM1" (NLSSORT("OPEN",'nls_sort=''BINARY_CI'''), NLSSORT("CATEGORY",'nls_sort=''BINARY_CI'''))
  PCTFREE 10 INITRANS 2 MAXTRANS 255   TABLESPACE "SM1D";

  CREATE INDEX "OWNER_SM1"."INCIDENTSM1F1588EAF_FBI" ON "OWNER_SM1"."INCIDENTSM1" (NLSSORT("CALLBACK_CONTACT",'nls_sort=''BINARY_CI'''))
  PCTFREE 10 INITRANS 2 MAXTRANS 255   TABLESPACE "SM1D";

  CREATE INDEX "OWNER_SM1"."INCIDENTSM153CE2372_FBI" ON "OWNER_SM1"."INCIDENTSM1" (NLSSORT("CARTID",'nls_sort=''BINARY_CI'''))
  PCTFREE 10 INITRANS 2 MAXTRANS 255   TABLESPACE "SM1D";

  CREATE INDEX "OWNER_SM1"."INCIDENTSM15169F2AD_FBI" ON "OWNER_SM1"."INCIDENTSM1" (NLSSORT("LOGICAL_NAME",'nls_sort=''BINARY_CI'''))
  PCTFREE 10 INITRANS 2 MAXTRANS 255   TABLESPACE "SM1D";

  CREATE UNIQUE INDEX "OWNER_SM1"."INCIDENTSM1BCDE1A6A_FBI" ON "OWNER_SM1"."INCIDENTSM1" (NLSSORT("INCIDENT_ID",'nls_sort=''BINARY_CI'''))
  PCTFREE 10 INITRANS 2 MAXTRANS 255   TABLESPACE "SM1X";

  CREATE UNIQUE INDEX "OWNER_SM1"."INCIDENTSM1_FAT_IDX_FBI" ON "OWNER_SM1"."INCIDENTSM1" (NLSSORT("INCIDENT_ID",'nls_sort=''BINARY_CI'''), 
  NLSSORT("PROPEL_REQUEST_ID",'nls_sort=''BINARY_CI'''), NLSSORT("PROPEL_ORDER_ID",'nls_sort=''BINARY_CI'''), NLSSORT("CALLBACK_CONTACT",'nls_sort=''BINARY_CI'''),
  NLSSORT("OPENED_BY",'nls_sort=''BINARY_CI'''), NLSSORT("ACTIVE",'nls_sort=''BINARY_CI'''))
  PCTFREE 10 INITRANS 2 MAXTRANS 255   TABLESPACE "SM1X";

  CREATE INDEX "OWNER_SM1"."INCIDENTSM1BEA95430_FBI" ON "OWNER_SM1"."INCIDENTSM1" (NLSSORT("CALLBACK_CONTACT",'nls_sort=''BINARY_CI'''),
  NLSSORT("OPEN",'nls_sort=''BINARY_CI'''))
  PCTFREE 10 INITRANS 2 MAXTRANS 255   TABLESPACE "SM1X";







  
	select 'drop index ' || owner || '.' || index_name || ';'    from dba_indexes
 where index_type like 'FUNCTION-BASED%' and owner = 'OWNER_SM1' and table_name = 'INCIDENTSM1';

Size  4699	Set timing on
select sum(bytes)/1024/1024 MB from dba_Segments 
where segment_name ='INCIDENTSM1'and owner = 'OWNER_SM1';




Eind: size 4679
ALTER TABLE owner_sm1.INCIDENTSM1 ENABLE ROW MOVEMENT;
ALTER TABLE owner_sm1.INCIDENTSM1 SHRINK SPACE;		  
ALTER TABLE owner_sm1.INCIDENTSM1 SHRINK SPACE CASCADE;
ALTER TABLE owner_sm1.INCIDENTSM1 DISABLE ROW MOVEMENT;


exec dbms_stats. GATHER_TABLE_STATS('OWNER_SM1', 'INCIDENTSM1', ESTIMATE_PERCENT => 2);

Rebuild  Indexen	SELECT 'ALTER INDEX owner_sm1.' || a.index_name || ' REBUILD online parallel 4;' FROM   dba_indexes a
WHERE   table_name = Upper('INCIDENTSM1') and owner = 'OWNER_SM1';














GSIB1 TEST: 
SELECT SUM(DBMS_LOB.GetLength("AGREEMENT_IDS"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1
ALTER TABLE OWNER_SM1.INCIDENTSM1 MODIFY LOB(AGREEMENT_IDS) (SHRINK SPACE);

SELECT SUM(DBMS_LOB.GetLength("DESCRIPTION"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1     
ALTER TABLE OWNER_SM1.INCIDENTSM1 MODIFY LOB(DESCRIPTION) (SHRINK SPACE);



SQL> GRANT UNLIMITED TABLESPACE TO HR_ADMIN;
SQL> ALTER TABLE HR_ADMIN.EMPLOYEE_PHOTOS MOVE LOB(IMAGE) STORE AS (TABLESPACE
TEMP);
SQL> ALTER TABLE HR_ADMIN.EMPLOYEE_PHOTOS MOVE LOB(IMAGE) STORE AS (TABLESPACE HR_DATA);
SQL> REVOKE UNLIMITED TABLESPACE from HR_ADMIN;
SQL> ALTER TABLE HR_ADMIN.EMPLOYEE_PHOTOS disable row movement;
SQL> DROP TABLESPACE TEMP INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;
4. Check again with query in step 1 and notice the size has shrunk:


SELECT SUM(DBMS_LOB.GetLength("DESCRIPTION"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1     453M
SELECT SUM(DBMS_LOB.GetLength("RESOLUTION"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1			134M
SELECT SUM(DBMS_LOB.GetLength("TEMP_UPDATE"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1		0M
SELECT SUM(DBMS_LOB.GetLength("UPDATE_ACTION"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1		497M
SELECT SUM(DBMS_LOB.GetLength("UPDATE_ACTION_ESS"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1	497M
SELECT SUM(DBMS_LOB.GetLength("SVC_OPTIONS"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1		45M
SELECT SUM(DBMS_LOB.GetLength("AGREEMENT_IDS"))/1024/1024 AS SizeMB FROM OWNER_SM1.INCIDENTSM1		7M
select sum(bytes)/1024/1024 MB from dba_Segments 
where segment_name ='INCIDENTSM1'and owner = 'OWNER_SM1';


col column_name for a40
col segment_name for a40
col owner for a20
col tablespace_name for a20
col table_name for a40
SELECT l.owner,
l.table_name,
l.column_name,
l.segment_name,
l.tablespace_name,
ROUND(s.bytes/1024/1024,2) mb
FROM dba_lobs l
JOIN dba_segments s ON s.owner = l.owner AND s.segment_name = l.segment_name 
where l.table_name = 'INCIDENTSM1' and l.owner ='OWNER_SM1'
ORDER BY 6 DESC;


create tablespace SM1D_MV datafile '+DATA' size 1G autoextend on maxsize 500G;
alter user owner_sm1 quota unlimited on SM1D_MV;

ALTER TABLE OWNER_SM1.INCIDENTSM1 MOVE LOB(RESOLUTION) STORE AS (TABLESPACE SM1D_MV);
ALTER TABLE OWNER_SM1.INCIDENTSM1 MOVE LOB(DESCRIPTION) STORE AS (TABLESPACE SM1D);


OWNER                TABLE_NAME                               COLUMN_NAME                              SEGMENT_NAME                             TABLESPACE_NAME              MB
-------------------- ---------------------------------------- ---------------------------------------- ---------------------------------------- -------------------- ----------
OWNER_SM1            INCIDENTSM1                              UPDATE_ACTION_ESS                        SYS_LOB0002705736C00098$$                SM1D                       2949
OWNER_SM1            INCIDENTSM1                              UPDATE_ACTION                            SYS_LOB0002705736C00097$$                SM1D                    2927.44
OWNER_SM1            INCIDENTSM1                              DESCRIPTION                              SYS_LOB0002705736C00009$$                SM1D                     209.94
OWNER_SM1            INCIDENTSM1                              RESOLUTION                               SYS_LOB0002705736C00016$$                SM1D                      28.25
OWNER_SM1            INCIDENTSM1                              SVC_OPTIONS                              SYS_LOB0002705736C00103$$                SM1D                          4
OWNER_SM1            INCIDENTSM1                              TEMP_UPDATE                              SYS_LOB0002705736C00043$$                SM1D                        .06
OWNER_SM1            INCIDENTSM1                              AGREEMENT_IDS                            SYS_LOB0002705736C00111$$                SM1D                        .06

7 rows selected.



