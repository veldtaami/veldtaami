('CM3RM1','CM3RA1','CM3RA2','CM3RA3','CM3RA4','CM3RA5','CM3RA6','CM3RA7',
'PROBSUMMARYM1','PROBSUMMARYA1','PROBSUMMARYA2','PROBSUMMARYA3',
'INCIDENTSM1','INCIDENTSA1','INCIDENTSA2','REQUESTM1','REQUESTA1','CM3TM1',
'CM3TA1','CM3TA2','CM3TA3','CONTCTSM1','CONTCTSA1')






select sum(BYTES/1024/1024) MB from dba_Segments where owner='OWNER_SM1' and segment_name in ('CM3RM1','CM3RA1','CM3RA2','CM3RA3','CM3RA4','CM3RA5','CM3RA6','CM3RA7',
'PROBSUMMARYM1','PROBSUMMARYA1','PROBSUMMARYA2','PROBSUMMARYA3',
'INCIDENTSM1','INCIDENTSA1','INCIDENTSA2','REQUESTM1','REQUESTA1','CM3TM1',
'CM3TA1','CM3TA2','CM3TA3','CONTCTSM1','CONTCTSA1');

        MB
----------
     19898
	 
	 
select sum(BYTES/1024/1024) MB from dba_Segments where segment_name in (select segment_name from dba_lobs where owner='OWNER_SM1' and table_name in ('CM3RM1','CM3RA1','CM3RA2','CM3RA3','CM3RA4','CM3RA5','CM3RA6','CM3RA7',
'PROBSUMMARYM1','PROBSUMMARYA1','PROBSUMMARYA2','PROBSUMMARYA3',
'INCIDENTSM1','INCIDENTSA1','INCIDENTSA2','REQUESTM1','REQUESTA1','CM3TM1',
'CM3TA1','CM3TA2','CM3TA3','CONTCTSM1','CONTCTSA1' ));

        MB     
		---------- 
		19434.75      
		

TAbellen binnen tbs moven:
select 'alter table owner_SM1.' || table_name || ' move online tablespace SM1D ;' from dba_tables 
where table_name in 
('CM3RM1','CM3RA1','CM3RA2','CM3RA3','CM3RA4','CM3RA5','CM3RA6','CM3RA7',
'PROBSUMMARYM1','PROBSUMMARYA1','PROBSUMMARYA2','PROBSUMMARYA3',
'INCIDENTSM1','INCIDENTSA1','INCIDENTSA2','REQUESTM1','REQUESTA1','CM3TM1',
'CM3TA1','CM3TA2','CM3TA3','CONTCTSM1','CONTCTSA1')
and owner = 'OWNER_SM1';



alter table owner_SM1.CM3RA1 move online tablespace SM1D ;
alter table owner_SM1.CM3RA2 move online tablespace SM1D ;
alter table owner_SM1.CM3RA3 move online tablespace SM1D ;
alter table owner_SM1.CM3RA4 move online tablespace SM1D ;
alter table owner_SM1.CM3RA5 move online tablespace SM1D ;
alter table owner_SM1.CM3RA6 move online tablespace SM1D ;
alter table owner_SM1.CM3RA7 move online tablespace SM1D ;
alter table owner_SM1.CM3TA1 move online tablespace SM1D ;
alter table owner_SM1.CM3TA2 move online tablespace SM1D ;
alter table owner_SM1.CM3TA3 move online tablespace SM1D ;
alter table owner_SM1.REQUESTA1 move online tablespace SM1D ;
alter table owner_SM1.CM3RM1 move online tablespace SM1D ;
alter table owner_SM1.CM3TM1 move online tablespace SM1D ;
alter table owner_SM1.CONTCTSA1 move online tablespace SM1D ;
alter table owner_SM1.CONTCTSM1 move online tablespace SM1D ;
alter table owner_SM1.INCIDENTSA1 move online tablespace SM1D ;
alter table owner_SM1.INCIDENTSA2 move online tablespace SM1D ;
alter table owner_SM1.INCIDENTSM1 move online tablespace SM1D ;

alter table owner_SM1.PROBSUMMARYA1 move online tablespace SM1D ;
alter table owner_SM1.PROBSUMMARYA2 move online tablespace SM1D ;
alter table owner_SM1.PROBSUMMARYA3 move online tablespace SM1D ;
alter table owner_SM1.PROBSUMMARYM1 move online tablespace SM1D ;
alter table owner_SM1.REQUESTM1 move online tablespace SM1D ;

('CM3RM1','CM3RA1','CM3RA2','CM3RA3','CM3RA4','CM3RA5','CM3RA6','CM3RA7',
'INCIDENTSM1','INCIDENTSA1','INCIDENTSA2','REQUESTA1','CM3TM1',
'CM3TA1','CM3TA2','CM3TA3','CONTCTSM1','CONTCTSA1') 


_USER @srv0psib101 > select index_name from dba_indexes  where table_name in ('CM3RM1','CM3RA1','CM3RA2','CM3RA3','CM3RA4','CM3RA5','CM3RA6','CM3RA7',
 'INCIDENTSM1','INCIDENTSA1','INCIDENTSA2','REQUESTA1','CM3TM1',
 'CM3TA1','CM3TA2','CM3TA3','CONTCTSM1','CONTCTSA1') and index_name not like 'SYS%';

select segment_name, sum(BYTES/1024/1024) MB from dba_Segments where owner='OWNER_SM1' and segment_name in ('CM3RM1','CM3RA1','CM3RA2','CM3RA3','CM3RA4','CM3RA5','CM3RA6','CM3RA7',
'PROBSUMMARYM1','PROBSUMMARYA1','PROBSUMMARYA2','PROBSUMMARYA3',
'INCIDENTSM1','INCIDENTSA1','INCIDENTSA2','REQUESTM1','REQUESTA1','CM3TM1',
'CM3TA1','CM3TA2','CM3TA3','CONTCTSM1','CONTCTSA1') group by segment_name order by 1;




SEGMENT_NAME                         MB
---------------------------- ----------
CM3RA1                                6
CM3RA2                                7
CM3RA3                               15
CM3RA4                               39
CM3RA5                               26
CM3RA6                                6
CM3RA7                               80
CM3RM1                             1859
CM3TA1                                3
CM3TA2                                3
CM3TA3                                7
CM3TM1                              420
CONTCTSA1                        2.9375
CONTCTSM1                            80
INCIDENTSA1                    117.9375
INCIDENTSA2                      29.625
INCIDENTSM1                     5228.25
PROBSUMMARYA1                   33.5625
PROBSUMMARYA2                    31.125
PROBSUMMARYA3                   25.5625
PROBSUMMARYM1                      7224
REQUESTA1                            19
REQUESTM1                          4635

23 rows selected.


