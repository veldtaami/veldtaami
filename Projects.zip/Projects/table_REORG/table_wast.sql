set lines 200
set pages 99
col table_name for a30
col owner for a30
set serveroutput on

select * from (
SELECT TABLE_NAME, owner ,
         ROUND((BLOCKS * 8/1024),2) "SIZE (MB)",
         ROUND((NUM_ROWS * AVG_ROW_LEN / 1024/1024), 2) "ACTUAL DATA (MB)",
         (ROUND((BLOCKS * 8/1024),2) - ROUND((NUM_ROWS * AVG_ROW_LEN / 1024/1024), 2)) "WASTED (MB)"
    FROM DBA_TABLES
   WHERE (ROUND((BLOCKS * 8/1024),2) > ROUND((NUM_ROWS * AVG_ROW_LEN / 1024/1024), 2))  
       --AND OWNER = 'OWNER_SM1' --  and table_name = 'DBDICTM1'
ORDER BY 4 DESC )
where rownum < 10;




-- Onderstaand voor de LOB-segmenten
DECLARE
    v_TableCol VARCHAR2(100) := '';
    v_Size NUMBER := 0;
    v_TotalSize NUMBER := 0;
BEGIN
    FOR v_Rec IN (
                  SELECT OWNER || '.' || TABLE_NAME || '.' || COLUMN_NAME AS TableAndColumn,
                      'SELECT SUM(DBMS_LOB.GetLength("' || COLUMN_NAME || '"))/1024/1024 AS SizeMB FROM ' || OWNER || '.' || TABLE_NAME AS sqlstmt
                  FROM DBA_TAB_COLUMNS
                  WHERE DATA_TYPE LIKE '_LOB'
                        AND OWNER = 'OWNER_SM1'
					   )
    LOOP
        DBMS_OUTPUT.PUT_LINE (v_Rec.sqlstmt);
        EXECUTE IMMEDIATE v_Rec.sqlstmt INTO v_Size;
 
        DBMS_OUTPUT.PUT_LINE (v_Rec.TableAndColumn || ' size in MB is ' || ROUND(NVL(v_Size,0),2));
        v_TotalSize := v_TotalSize + NVL(v_Size,0);
    END LOOP;
 
    DBMS_OUTPUT.PUT_LINE ('Total size in MB is ' || ROUND(v_TotalSize,2));
END;
/