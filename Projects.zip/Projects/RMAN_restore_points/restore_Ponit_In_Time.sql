#startup force mount;
#list incarnation;
#list incarnation of database;
#list incarnation of database ODBA9;
reset database to incarnation 1479820889;
# if you did reset incarnation remark all startup force further in the script


run {
  set command id to 'IncompleteRecoverDB';
  sql 'alter session set "_backup_disk_bufcnt"=20';
  sql 'alter session set "_backup_file_bufcnt"=20';
  sql 'alter session set "_backup_disk_bufsz"=2097152';
  sql 'alter session set "_backup_file_bufsz"=2097152';
    #set until time = 'YYMMDD_HHMiSS';
    set until time = '210128_100000';
    #set until sequence 5 thread 1;
    #startup force nomount;
    set DBID = 762533266
    restore controlfile;
    startup force mount;
    sql 'alter database flashback off';
    restore database check readonly;
    #recover database delete archivelog maxsize 5000M;
    #recover database;
    alter database open resetlogs;
}
#startup force mount;
#list incarnation;
#list incarnation of database;
#list incarnation of database ODBA9;
reset database to incarnation 1479820889;
# if you did reset incarnation remark all startup force further in the script


run {
  set command id to 'IncompleteRecoverDB';
  sql 'alter session set "_backup_disk_bufcnt"=20';
  sql 'alter session set "_backup_file_bufcnt"=20';
  sql 'alter session set "_backup_disk_bufsz"=2097152';
  sql 'alter session set "_backup_file_bufsz"=2097152';
    #set until time = 'YYMMDD_HHMiSS';
    set until time = '210128_100000';
    #set until sequence 5 thread 1;
    #startup force nomount;
    #set DBID = 762533266
    #restore controlfile;
    startup force mount;
    sql 'alter database flashback off';
    restore database check readonly;
    #recover database delete archivelog maxsize 5000M;
    recover database;
    #alter database open resetlogs;
}

SYS@GHOO13 SQL> alter database open resetlogs;

Database altered.

SYS@GHOO13 SQL> alter system set cluster_database=true scope=spfile;

System altered.

SYS@GHOO13 SQL> alter database flashback on;

Database altered.

SYS@GHOO13 SQL> shutdown immediate;


PIT-recovery:
shutdown abort
startup nomount
start script: rma / rec.....

run {
    set until time "to_date('2021-05-20_07:00:00','YYYY-MM-DD_HH24:MI:SS')" ;
    startup force mount;
    sql 'alter database flashback off';
    restore database;
    recover database;
	}
	
 sqlplus:   
alter database open resetlogs;
alter database flashback on;
shutdown immediate
srvctl start database -d OSIB1_01



