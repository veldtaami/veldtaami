3701
4701

dgmgrl /
EDIT DATABASE 'PSIB1_02' SET STATE = 'APPLY-OFF'; 


3701:
CREATE RESTORE POINT pre_215012022 GUARANTEE FLASHBACK DATABASE;


4701:

CREATE RESTORE POINT pre_215012022 GUARANTEE FLASHBACK DATABASE;


-- Na afloop:
EDIT DATABASE 'PSIB1_02' SET STATE = 'APPLY-ON'; 
drop restore points: 




truncate table owner_sm1.msglogm1;
truncate table owner_sm1.Syslogm1;
truncate table owner_sm1.Errorlogm1;
truncate table owner_sm1.eventinm1;
truncate table owner_sm1.eventoutm1;
truncate table owner_sm1.systemperformm1;




--- restoren:   3.	Zorg dat de database(s) in de blackout staat.



srvctl stop database -d GHOO1_04
startup mount exclusive;
rma
FLASHBACK DATABASE TO RESTORE POINT 'PRE_INSTALL_28012021';
RMAN>  ALTER DATABASE OPEN RESETLOGS;	
srvctl start database –d <DB_UNIQUE_NAME>



select count(1) from  owner_sm1.msglogm1;
select count(1) from  owner_sm1.Syslogm1;
select count(1) from  owner_sm1.Errorlogm1;
select count(1) from  owner_sm1.eventinm1;
select count(1) from  owner_sm1.eventoutm1;
select count(1) from  owner_sm1.systemperformm1;