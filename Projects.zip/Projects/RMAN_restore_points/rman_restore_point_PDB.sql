SQL> alter session set container=PDB1;
SQL> create restore point TEST1;
SQL> create restore point pre_25112021 guarantee flashback database;


Of zonder the alter session:

SQL> create restore point pre_25112021 for pluggable database GSIB1 guarantee flashback database;



List the restore points:
SQL> select NAME,TIME,SCN,PDB_RESTORE_POINT,GUARANTEE_FLASHBACK_DATABASE from V$RESTORE_POINT;
RMAN> list restore point all;

CENTRAL Undo, of met de PDB OPEN:
RMAN> alter pluggable database PDB1 close;
RMAN> flashback pluggable database PDB1 to restore point TEST1 auxiliary destination '/o122/app/oracle/oradata/stage';   ???
RMAN> alter pluggable database PDB1 open resetlogs;




 alter pluggable database OSIB1 close immediate;
 flashback pluggable database OSIB1 to restore point PRE_06102021;
 alter pluggable database OSIB1 open resetlogs;



alter session set container=OSIB1;



SYS@OC0291 SQL> select name from v$restore_point;

NAME
---------------
PRE_06102021






COLUMN NAME FORMAT A8

SELECT NAME, CON_ID, DBID, CON_UID, GUID FROM V$CONTAINERS ORDER BY CON_ID;

COLUMN NAME FORMAT A15
COLUMN RESTRICTED FORMAT A10
COLUMN OPEN_TIME FORMAT A30
 
SELECT NAME, OPEN_MODE, RESTRICTED, OPEN_TIME FROM V$PDBS;

w





