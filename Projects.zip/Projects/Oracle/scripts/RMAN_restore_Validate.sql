
/eco/scripts/rman/cmd_files/m_db_validate.rmn

run {
restore controlfile to '/dev/null' validate;
restore database validate;
restore archivelog from time '070216_170000' validate;
}



rman_wrapper.sh

Usage         : ./rman_wrapper.sh sid cmdfile

 nohup /eco/scripts/rman/rman_wrapper.sh PBSM17 /home/VeldtAAMI/m_db_validate.rmn &



Mailen naar jezelf:

$ mailx -a /tmp/rman_TBSM11_2108190752.log anwar.van.der.veldt@rabobank.nl
Subject: validatelog
rman validate log van de TBSM1
.
EOT
