show configuration

show database verbose 'GSIB1_03'



Error: ORA-16737: the redo transport service for member "GSIB1_05" has an error

1: select protection_mode, protection_level from v$database; 
select dest_id,status,error from v$archive_dest;
Note: primary &standby online redo log should be same
select group#,thread#,sequence#,bytes,archived,status from v$log;  
Note: primary &standby standby redo log should be same 
select member from v$logfile where type='STANDBY'; 
Check whether maximum Availability is enabled, when you have LogXptMode is synchronization
In DG Broker
DGMGRL> EDIT CONFIGURATION SET PROTECTION MODE AS MAXAVAILABILITY;



show database verbose 'PGAK1_01' LogXptStatus;



EDIT DATABASE 'DB_P _ STANDBy ' SET PROPERTY 'LogXptMode'='SYNC';

EDIT CONFIGURATION SET PROTECTION MODE AS MAXAVAILABILITY;
EDIT CONFIGURATION SET PROTECTION MODE AS MAXPROTECTION;

EDIT CONFIGURATION SET PROTECTION MODE AS MAXPERFORMANCE;

EDIT DATABASE 'POBM1_03' SET PROPERTY 'LogXptMode'='ASYNC';
EDIT DATABASE 'POBM1_04' SET PROPERTY 'LogXptMode'='ASYNC';



EDIT DATABASE 'PGAK1_01' SET PROPERTY 'LogXptMode'='ASYNC';
EDIT DATABASE 'PGAK1_04' SET PROPERTY 'LogXptMode'='ASYNC';



EDIT CONFIGURATION SET PROTECTION MODE AS MAXPERFORMANCE;

EDIT DATABASE 'PSIB1_01' SET PROPERTY 'LogXptMode'='ASYNC';
EDIT DATABASE 'GHOO1_04' SET PROPERTY 'LogXptMode'='ASYNC';


EDIT CONFIGURATION SET PROTECTION MODE AS MAXPERFORMANCE;

EDIT DATABASE 'GOBM1_01' SET PROPERTY 'LogXptMode'='ASYNC';
EDIT DATABASE 'GOBM1_02' SET PROPERTY 'LogXptMode'='ASYNC';

EDIT CONFIGURATION SET PROTECTION MODE AS MAXPERFORMANCE;

EDIT DATABASE 'PHOO1_02' SET PROPERTY 'LogXptMode'='ASYNC';
EDIT DATABASE 'PHOO1_03' SET PROPERTY 'LogXptMode'='ASYNC';


