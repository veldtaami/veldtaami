select 'alter '||object_type||' '||owner||'.'||object_name||' compile;' from dba_objects
where owner in ('PIU')
and object_type in ('TRIGGER', 'PROCEDURE','PACKAGE','TYPE','VIEW','FUNCTION')
order by decode (object_type, 'TYPE',1,'VIEW', 2, 'FUNCTION',3,'PROCEDURE',4,'PACKAGE', 5,6)
