-- #Company: DUO/ICT/TBT, Ministerie van OCW
-- #Purpose: Voorbeeld script datamanipulatie
-- #Verzoek voor een INSERT
-- #Dependencies:
-- #History:
-- #Notes
-- {*} Format voor het aanleveren van een SQL-script 
--
define script_name=11072014-NamenDiakritischeTekensOmzetten.sql
--
set echo off
set feedback off
set define on
--
column ts new_value timestamp noprint
column su new_value user noprint
column db new_value database noprint
--
select to_char(sysdate,'YYYYMMDD-HH24MISS') ts, 
sys_context('USERENV','SESSION_USER') su,
sys_context('USERENV','DB_NAME') db
from
dual;
--
define file_name=&timestamp._&database._&user._&script_name..log
spool &file_name
--
set echo off
set heading on
set pages 9999
set linesize 4096
set trimspool on
--
column ss format a12 heading Start print
column ts format a19 heading Tijd print
column db format a9 heading Database print
column su format a30 heading User print
--
select 'Start Script' ss, 
to_char(sysdate,'DD-MM-YYYY HH24:MI:SS') ts, 
sys_context('USERENV','DB_NAME') db,
sys_context('USERENV','SESSION_USER') su
from
dual;
prompt
set feedback on 
 
--## HIER SQL STATEMENTS PLAATSEN ###############

-- Update RK BS Het Mozaiek
update rel.rel_bo_organisaties
   set naam_kort = 'RK BS Het Mozaiek', 
       naam_volledig =  'Rooms Katholieke Basisschool Het Mozaiek' 
where  
   code_relatie = 10054349 and nr_periode in (3, 4, 5); 
   
-- Update SBO Samuel
update rel.rel_bo_organisaties
  set naam_kort = 'SBO Samuel', 
      naam_volledig =  'School voor SBO Samuel' 
where  
   code_relatie = 10055648 and nr_periode in (3, 4);

--## EINDE SQL STATEMENTS #######################
-- Bij het aanroepen van scripts met eigen logging, de volgende regel de-commentarieren:
-- spool &file_name append
-- 
set feedback off
column es format a12 heading Einde
column ts format a19 heading Tijd
select 'Einde script' es, 
to_char(sysdate,'DD-MM-YYYY HH24:MI:SS') ts 
from
dual;
prompt
prompt Indien er geen fouten zijn ontstaan handmatig commit uitvoeren, anders rollback
prompt
spool off
set echo off
