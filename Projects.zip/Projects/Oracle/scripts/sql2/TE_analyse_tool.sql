
declare
l_melding varchar2(32767) := 'ok' ;
begin
   tbt_inregel.te_impact.init
   (p_component => 'DOM'
,p_te_code => 'TE2015513'
,p_omgeving => 'P'    
,p_melding => l_melding);
end ;
/
