select * from dba_sql_profiles
order by last_modified

SELECT CLIENT_NAME, STATUS
FROM   DBA_AUTOTASK_CLIENT

SELECT PARAMETER_NAME, PARAMETER_VALUE AS "VALUE"
FROM   DBA_ADVISOR_PARAMETERS
WHERE   (TASK_NAME = 'SYS_AUTO_SQL_TUNING_TASK')

SELECT PARAMETER_NAME, PARAMETER_VALUE AS "VALUE"
FROM   DBA_ADVISOR_PARAMETERS
WHERE  ( (TASK_NAME = 'SYS_AUTO_SQL_TUNING_TASK') AND
         ( (PARAMETER_NAME LIKE '%PROFILE%') OR 
           (PARAMETER_NAME = 'LOCAL_TIME_LIMIT') OR
           (PARAMETER_NAME = 'EXECUTION_DAYS_TO_EXPIRE') ) );
           
select * from DBA_ADVISOR_TASKS
where task_name like 'SYS_AUTO_SQL%'

select * from dba_objects
where object_name like 'DBA%TASK%'
and object_type='VIEW'

select count(*) from dba_sql_profiles
order by last_modified

select * from DBA_ADVISOR_DIR_TASK_INST

select * from DBA_AUTOTASK_OPERATION

select * from DBA_AUTOTASK_SCHEDULE
order by start_time desc

select * from DBA_AUTOTASK_CLIENT_JOB

select * from DBA_AUTOTASK_CLIENT_JOB

select * from DBA_AUTOTASK_TASK

select * from DBA_AUTOTASK_STATUS

select * from DBA_AUTOTASK_CLIENT_HISTORY

select * from dba_scheduler_jobs

select owner, task_name, execution_start, execution_end from dba_advisor_executions where task_name like '%SYS_AUTO_SQL%';