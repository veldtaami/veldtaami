set lines 300
set trimspool on
set pages 1000
set verify off
set feedback off
 
accept tes char prompt "Geef alle TE's met een spatie ertussen: "
accept db char prompt "Geef de database: "

column list new_value teslist noprint

select ''''||replace('&&tes',' ',''',''')||'''' list from dual;

column te heading TE
column te2 heading "Afhankelijk van"

select distinct unl1.te_code te, unl2.te_code te2
from   mge_unloads unl1
,         mge_unloads unl2
where unl1.te_code in (&&teslist)
and   instr(upper(unl1.afhankelijkheid) ,upper( unl2.te_code)) > 0
and   unl2.te_code not in (&&teslist)
and not exists (
select 'x' from mge_deployments dep, mge_omgevingen omg
where upper(omg.db_omgeving)=upper('&&db')
and unl2.id=dep.uld_id
and dep.OGG_ID =OMG.ID)
order by 2,1
/
