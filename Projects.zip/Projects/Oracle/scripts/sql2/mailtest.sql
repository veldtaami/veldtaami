declare
      l_smtp_server      varchar2(50) :='otagrnms001.duo.ota';
      l_port             number(4) :=25;
      l_connection       utl_smtp.connection;
      l_addr_sender      varchar2(100) :='dba@duo.nl';
      l_from             varchar2(30) :='dba';

      l_ontvanger       varchar2(100) :='peter.rienstra@duo.nl';

      l_crlf             varchar2(2) := chr(13)||chr(10);
      l_header           varchar2(1000);
      l_mail_part        varchar2(32767);
      l_lengte           number(6);
      l_offset           number(6);

   begin

       -- Connect to your SMTP server over the designated port.
      l_connection := utl_smtp.open_connection(l_smtp_server, l_port);

      -- Perform initial handshaking with an SMTP server and then perform initial.
      -- transaction with this server.
      utl_smtp.helo(l_connection, l_smtp_server);
      utl_smtp.mail(l_connection, l_addr_sender);
      utl_smtp.rcpt(l_connection, l_ontvanger);
      utl_smtp.rcpt(l_connection, 'rhemy.lichtenberg@duo.nl');
dbms_output.put_line('hier 1');
      utl_smtp.open_data(l_connection);
dbms_output.put_line('hier 2');
      -- Header samenstellen
      l_header  := 'Date: '   ||'2014-07-08'||l_crlf
                 ||'From: '   ||l_from||' <'||l_addr_sender||'>'||l_crlf
                 ||'Subject: '||'TEST'||l_crlf
                 ||'To: '     ||l_ontvanger||l_crlf;
dbms_output.put_line('hier 3');
      utl_smtp.write_data(l_connection, 'MIME-Version: 1.0'||l_crlf||'Content-type: text'||l_crlf
                          ||l_header||l_crlf);
dbms_output.put_line('hier 4');
   
      utl_smtp.write_data(l_connection, 'Test als ONP vanaf VDE1A');
dbms_output.put_line('hier 5');        
      -- Close the connection.
      utl_smtp.close_data(l_connection);
dbms_output.put_line('hier 6');  
      utl_smtp.quit(l_connection);

   end;