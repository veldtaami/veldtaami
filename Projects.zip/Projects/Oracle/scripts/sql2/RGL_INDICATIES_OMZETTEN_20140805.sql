-- ZIJN ER VESTIGINGEN DIE 2012-INDICATIES HEBBEN en GEFUSEERD ZIJN NA 1/3/2014 en BIJ EEN EXPERIMENT HOREN? 
-- NEEN, ALLEEN 24TR00 EN DAT IS EEN REGISTRATIEFOUT.
SELECT * FROM OWI.OWI_V_BO_ORGANISATIES ORG
WHERE ORG.CODE_RELATIE IN
(SELECT IND.CODE_RELATIE_VEST_INSCHRIJVING FROM OWD.OWD_RGL_INDICATIES IND 
WHERE IND.TELDATUM = TO_DATE('01-10-2012','DD-MM-YYYY')
AND IND.CODE_RELATIE_VEST_INSCHRIJVING IN
(SELECT OVG.CODE_RELATIE_VAN FROM REL.REL_V_BO_ORG_OVERGANGEN OVG
WHERE OVG.DT_OVERGANG >= TO_DATE('01-03-2014','DD-MM-YYYY')
AND OVG.CODE_ROL_VAN = 'VST'))
AND ORG.CODE_RELATIE IN
(SELECT KOP.CODE_RELATIE_VOLG FROM REL.REL_V_BO_ORG_KOPPELINGEN KOP
WHERE KOP.CODE_ROL_LEID IN ('SVPO','SVVO')
AND KOP.CODE_ROL_VOLG = 'VST'
AND KOP.CODE_RELATIE_LEID IN (10416474, 10417637, 10417239)
AND KOP.DT_BEGIN_RELATIE <= TO_DATE('01-08-2014','DD-MM-YYYY')
AND (KOP.DT_EINDE_RELATIE IS NULL OR KOP.DT_EINDE_RELATIE > TO_DATE('01-08-2014','DD-MM-YYYY')))
; 

--INDICATIE 1/10/2013 waarvan de VEST_INSCHRIJVING een fusie heeft gehad na 01/03/2014;  63 rows, 51 verschillende REG_VEST
SELECT IND.ADMINNR_VEST_INSCHRIJVING FROM OWD.OWD_RGL_INDICATIES IND 
WHERE IND.TELDATUM = TO_DATE('01-10-2013','DD-MM-YYYY')
AND IND.CODE_RELATIE_VEST_INSCHRIJVING IN
(SELECT OVG.CODE_RELATIE_VAN FROM REL.REL_V_BO_ORG_OVERGANGEN OVG
WHERE OVG.DT_OVERGANG >= TO_DATE('01-03-2014','DD-MM-YYYY')
AND OVG.CODE_ROL_VAN = 'VST')
order by IND.ADMINNR_VEST_INSCHRIJVING
;

-- 51x nieuwe code_relatie/adminr en oude code_relatie/adminr; selecteren indicaties met vest_inschr die een overgang heeft
-- zelfde uitkomst als onderstaande select met indicaties met vest_inschr die uit_bedrijf zijn 
select distinct OVG.CODE_RELATIE_NAAR, ORG.NR_ADMINISTRATIE, IND.CODE_RELATIE_VEST_INSCHRIJVING, IND.ADMINNR_VEST_INSCHRIJVING
from owi.owi_v_bo_organisaties org, rel.rel_v_bo_org_overgangen ovg, OWD.OWD_RGL_INDICATIES IND
where ORG.DT_BEGIN_RECORD <= to_date('01-08-2014','dd-mm-yyyy')
and (ORG.DT_EINDE_RECORD is null or ORG.DT_EINDE_RECORD > to_date('01-08-2014','dd-mm-yyyy'))
and OVG.CODE_RELATIE_NAAR = ORG.CODE_RELATIE
and OVG.CODE_RELATIE_VAN = IND.CODE_RELATIE_VEST_INSCHRIJVING  
and IND.TELDATUM = TO_DATE('01-10-2013','DD-MM-YYYY')
AND IND.CODE_RELATIE_VEST_INSCHRIJVING IN
(SELECT OVG.CODE_RELATIE_VAN FROM REL.REL_V_BO_ORG_OVERGANGEN OVG
WHERE OVG.DT_OVERGANG >= TO_DATE('01-03-2014','DD-MM-YYYY')
AND OVG.CODE_ROL_VAN = 'VST')
order by IND.CODE_RELATIE_VEST_INSCHRIJVING
;

-- 51x nieuwe code_relatie/adminr en oude code_relatie/adminr; selecteren indicaties met vest_inschr die een datum_uit_bedrijf heeft, niet kijken naar koppelingen vest-SWV PassOnd
-- zelfde uitkomst als bovenstaande select met indicaties met vest_inschr die een fusie hebben 
select distinct OVG.CODE_RELATIE_NAAR, ORG.NR_ADMINISTRATIE, IND.CODE_RELATIE_VEST_INSCHRIJVING, IND.ADMINNR_VEST_INSCHRIJVING
from owi.owi_v_bo_organisaties org, rel.rel_v_bo_org_overgangen ovg, OWD.OWD_RGL_INDICATIES IND
where ORG.DT_BEGIN_RECORD <= to_date('01-08-2014','dd-mm-yyyy')
and (ORG.DT_EINDE_RECORD is null or ORG.DT_EINDE_RECORD > to_date('01-08-2014','dd-mm-yyyy'))
and OVG.CODE_RELATIE_NAAR = ORG.CODE_RELATIE
and OVG.CODE_RELATIE_VAN = IND.CODE_RELATIE_VEST_INSCHRIJVING  
and IND.TELDATUM = TO_DATE('01-10-2013','DD-MM-YYYY')
AND IND.CODE_RELATIE_VEST_INSCHRIJVING IN
(SELECT ORG2.CODE_RELATIE FROM OWI.OWI_V_BO_ORGANISATIES ORG2
WHERE ORG2.DT_UIT_BEDRIJF >= TO_DATE('01-03-2014','DD-MM-YYYY') and ORG2.DT_UIT_BEDRIJF <= TO_DATE('01-08-2014','DD-MM-YYYY')  
AND ORG2.CODE_ROL = 'VST')
order by IND.CODE_RELATIE_VEST_INSCHRIJVING;

-- zelfde lijst als bovenstaande select met uitsluiting van de reguliere vestigingen die nog WEL onder een PassOnd SWV vallen per 1/8/2014
-- 46x nieuwe code_relatie/adminr en oude code_relatie/adminr; selecteren indicaties met vest_inschr die een datum_uit_bedrijf heeft en die uit het SWV PassOnd zijn gezet;
-- wordt 49x na binnenkomen nieuwe BRIN om 12:15 6/8/2014
select distinct OVG.CODE_RELATIE_NAAR, ORG.NR_ADMINISTRATIE, IND.CODE_RELATIE_VEST_INSCHRIJVING, IND.ADMINNR_VEST_INSCHRIJVING
from owi.owi_v_bo_organisaties org, rel.rel_v_bo_org_overgangen ovg, OWD.OWD_RGL_INDICATIES IND
where ORG.DT_BEGIN_RECORD <= to_date('01-08-2014','dd-mm-yyyy')
and (ORG.DT_EINDE_RECORD is null or ORG.DT_EINDE_RECORD > to_date('01-08-2014','dd-mm-yyyy'))
and OVG.CODE_RELATIE_NAAR = ORG.CODE_RELATIE
and OVG.CODE_RELATIE_VAN = IND.CODE_RELATIE_VEST_INSCHRIJVING  
and IND.TELDATUM = TO_DATE('01-10-2013','DD-MM-YYYY')
AND IND.CODE_RELATIE_VEST_INSCHRIJVING IN
(SELECT ORG2.CODE_RELATIE FROM OWI.OWI_V_BO_ORGANISATIES ORG2
WHERE ORG2.DT_UIT_BEDRIJF >= TO_DATE('01-03-2014','DD-MM-YYYY') and ORG2.DT_UIT_BEDRIJF <= TO_DATE('01-08-2014','DD-MM-YYYY')  
AND ORG2.CODE_ROL = 'VST')
and IND.CODE_RELATIE_VEST_INSCHRIJVING IN
(SELECT KOP.CODE_RELATIE_VOLG FROM REL.REL_V_BO_ORG_KOPPELINGEN KOP
WHERE KOP.DT_EINDE_RELATIE >= TO_DATE('01-03-2014','DD-MM-YYYY') and KOP.DT_EINDE_RELATIE <= TO_DATE('01-08-2014','DD-MM-YYYY')
AND KOP.CODE_ROL_VOLG = 'VST' AND KOP.CODE_ROL_LEID IN ('SVPO','SVVO')  
)
order by IND.CODE_RELATIE_VEST_INSCHRIJVING;

-- zelfde lijst als bovenstaande select nu ook met soort_indicatie en aantal
select distinct OVG.CODE_RELATIE_NAAR, ORG.NR_ADMINISTRATIE, IND.CODE_RELATIE_VEST_INSCHRIJVING, IND.ADMINNR_VEST_INSCHRIJVING, IND.SOORT_INDICATIE, IND.AANTAL_INDICATIES
from owi.owi_v_bo_organisaties org, rel.rel_v_bo_org_overgangen ovg, OWD.OWD_RGL_INDICATIES IND
where ORG.DT_BEGIN_RECORD <= to_date('01-08-2014','dd-mm-yyyy')
and (ORG.DT_EINDE_RECORD is null or ORG.DT_EINDE_RECORD > to_date('01-08-2014','dd-mm-yyyy'))
and OVG.CODE_RELATIE_NAAR = ORG.CODE_RELATIE
and OVG.CODE_RELATIE_VAN = IND.CODE_RELATIE_VEST_INSCHRIJVING  
and IND.TELDATUM = TO_DATE('01-10-2013','DD-MM-YYYY')
AND IND.CODE_RELATIE_VEST_INSCHRIJVING IN
(SELECT ORG2.CODE_RELATIE FROM OWI.OWI_V_BO_ORGANISATIES ORG2
WHERE ORG2.DT_UIT_BEDRIJF >= TO_DATE('01-03-2014','DD-MM-YYYY') and ORG2.DT_UIT_BEDRIJF <= TO_DATE('01-08-2014','DD-MM-YYYY')  
AND ORG2.CODE_ROL = 'VST')
and IND.CODE_RELATIE_VEST_INSCHRIJVING IN
(SELECT KOP.CODE_RELATIE_VOLG FROM REL.REL_V_BO_ORG_KOPPELINGEN KOP
WHERE KOP.DT_EINDE_RELATIE >= TO_DATE('01-03-2014','DD-MM-YYYY') and KOP.DT_EINDE_RELATIE <= TO_DATE('01-08-2014','DD-MM-YYYY')
AND KOP.CODE_ROL_VOLG = 'VST' AND KOP.CODE_ROL_LEID IN ('SVPO','SVVO')  
)
order by IND.CODE_RELATIE_VEST_INSCHRIJVING;

--select * from rgl_indicaties and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy'); 
--van de gevonden 49 reg_vest die een compleet geregistreerde fusie (incl.beeindiging koppeling reg_vest - PassOnd SWV) hebben worden de indicaties omgezet. 
--dit zijn er 61(2 minder dan in de 2e select gevonden zijn doordat van 2 reg_vests de indicaties niet worden omgezet omdat de fusie niet compleet geregistreerd is).
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10122744 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10295199 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10133172 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10161690 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10134368 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10398922 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10133138 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10224790 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10131789 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
--select * from owd.owd_rgl_indicaties where ind.code_relatie_vest_inschrijving = 10223708 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10269699 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
--select * from owd.owd_rgl_indicaties where ind.code_relatie_vest_inschrijving = 10270298 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10155029 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10124706 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10130593 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10298041 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10280134 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10159703 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10146200 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10146244 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10185009 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10140586 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10275679 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10151209 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10150819 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10150820 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10223253 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10151447 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10274427 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10132953 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10140075 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10276412 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10218561 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10297117 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10180322 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10155052 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10297526 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10149992 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10132011 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10277277 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10157398 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10168022 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10125823 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10277040 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10279160 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10220094 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10172277 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10127089 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10170602 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10144419 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10191647 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');

--28 update van bovenstaande rgl_indicaties, code_relatie_vest_inschrijving en adminnr_vest_inschr worden vervangen door de resulterende fusie_vestiging
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10125469 , ind.adminnr_vest_inschrijving = '03XX00' where ind.code_relatie_vest_inschrijving = 10134368 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10424154 , ind.adminnr_vest_inschrijving = '04ON01' where ind.code_relatie_vest_inschrijving = 10398922 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10128140 , ind.adminnr_vest_inschrijving = '04TK00' where ind.code_relatie_vest_inschrijving = 10133138 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10131325 , ind.adminnr_vest_inschrijving = '05QF00' where ind.code_relatie_vest_inschrijving = 10224790 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
--update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10301323 , ind.adminnr_vest_inschrijving = '06AN00' where ind.code_relatie_vest_inschrijving = 10223708 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10422909 , ind.adminnr_vest_inschrijving = '06KO02' where ind.code_relatie_vest_inschrijving = 10269699 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
--update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10272103 , ind.adminnr_vest_inschrijving = '06YR00' where ind.code_relatie_vest_inschrijving = 10270298 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10137254 , ind.adminnr_vest_inschrijving = '07KQ00' where ind.code_relatie_vest_inschrijving = 10155029 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10137914 , ind.adminnr_vest_inschrijving = '07OY00' where ind.code_relatie_vest_inschrijving = 10130593 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10139329 , ind.adminnr_vest_inschrijving = '08AO00' where ind.code_relatie_vest_inschrijving = 10298041 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10141772 , ind.adminnr_vest_inschrijving = '08VQ00' where ind.code_relatie_vest_inschrijving = 10159703 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10423048 , ind.adminnr_vest_inschrijving = '09NN01' where ind.code_relatie_vest_inschrijving = 10146244 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10423059 , ind.adminnr_vest_inschrijving = '09ZG01' where ind.code_relatie_vest_inschrijving = 10185009 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10423957 , ind.adminnr_vest_inschrijving = '11MZ01' where ind.code_relatie_vest_inschrijving = 10150820 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10150502 , ind.adminnr_vest_inschrijving = '11VA00' where ind.code_relatie_vest_inschrijving = 10151447 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10151265 , ind.adminnr_vest_inschrijving = '12CO00' where ind.code_relatie_vest_inschrijving = 10274427 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10276025 , ind.adminnr_vest_inschrijving = '12GQ00' where ind.code_relatie_vest_inschrijving = 10132953 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10423231 , ind.adminnr_vest_inschrijving = '12TT01' where ind.code_relatie_vest_inschrijving = 10297117 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10423004 , ind.adminnr_vest_inschrijving = '13ES01' where ind.code_relatie_vest_inschrijving = 10155052 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10276832 , ind.adminnr_vest_inschrijving = '13JJ00' where ind.code_relatie_vest_inschrijving = 10297526 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10277404 , ind.adminnr_vest_inschrijving = '14EL00' where ind.code_relatie_vest_inschrijving = 10132011 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10157683 , ind.adminnr_vest_inschrijving = '14FJ00' where ind.code_relatie_vest_inschrijving = 10277277 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10157796 , ind.adminnr_vest_inschrijving = '14FY00' where ind.code_relatie_vest_inschrijving = 10157398 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10157956 , ind.adminnr_vest_inschrijving = '14HO00' where ind.code_relatie_vest_inschrijving = 10168022 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10424030 , ind.adminnr_vest_inschrijving = '15DI01' where ind.code_relatie_vest_inschrijving = 10125823 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10162911 , ind.adminnr_vest_inschrijving = '15YX00' where ind.code_relatie_vest_inschrijving = 10277040 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10167994 , ind.adminnr_vest_inschrijving = '17PK00' where ind.code_relatie_vest_inschrijving = 10220094 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10423037 , ind.adminnr_vest_inschrijving = '22LM02' where ind.code_relatie_vest_inschrijving = 10127089 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10283166 , ind.adminnr_vest_inschrijving = '24MK00' where ind.code_relatie_vest_inschrijving = 10170602 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10283564 , ind.adminnr_vest_inschrijving = '25LW00' where ind.code_relatie_vest_inschrijving = 10191647 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');

--27 rgl_indicatie rows 
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10122744 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10295199 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10133172 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10161690 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10131789 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10124706 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10280134 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10146200 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10140586 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10275679 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10151209 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10150819 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10223253 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10140075 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10276412 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10218561 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10180322 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10149992 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10279160 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10172277 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10144419 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy')
order by 1;

select * from owd.owd_rgl_indicaties ind1, owd.owd_rgl_indicaties ind2
where IND1.TELDATUM = to_date('01-10-2013','dd-mm-yyyy') 
and IND1.CODE_RELATIE_VEST_INSCHRIJVING in (10122744, 10295199, 10133172, 10161690, 10131789, 10124706, 10280134, 10146200, 10140586, 10275679, 10151209, 
              10150819, 10223253, 10140075, 10276412, 10218561, 10180322, 10149992, 10279160, 10172277, 10144419)
and IND2.TELDATUM = to_date('01-10-2013','dd-mm-yyyy')
and IND2.CODE_RELATIE_AB_SCHOOL = IND1.CODE_RELATIE_AB_SCHOOL
and IND2.SOORT_INDICATIE = IND1.SOORT_INDICATIE
and IND2.CODE_RELATIE_VEST_INSCHRIJVING in 
(select OVG.CODE_RELATIE_NAAR from rel.rel_v_bo_org_overgangen ovg
where OVG.CODE_RELATIE_VAN = IND1.CODE_RELATIE_VEST_INSCHRIJVING
and OVG.DT_OVERGANG = to_date('01-08-2014','dd-mm-yyyy'));

-- 22 vest waarbij de rgl_indicatie van de resterende reguliere vestiging moet worden geupdate; ophogen met het aantal_indicaties van de verdwijnende vestiging
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10114804 and ind.code_relatie_ab_school = 10084363 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'ZMLK-BB' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10118522 and ind.code_relatie_ab_school = 10290592 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10216258 and ind.code_relatie_ab_school = 10055660 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10269406 and ind.code_relatie_ab_school = 10264069 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10271213 and ind.code_relatie_ab_school = 10213840 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10137629 and ind.code_relatie_ab_school = 10262541 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10141523 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10203142 and ind.code_relatie_ab_school = 10050563 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10147383 and ind.code_relatie_ab_school = 10052445 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10145967 and ind.code_relatie_ab_school = 10404101 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'MG' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10297253 and ind.code_relatie_ab_school = 10262643 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10297253 and ind.code_relatie_ab_school = 10213840 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10149685 and ind.code_relatie_ab_school = 10052456 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10218538 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10154117 and ind.code_relatie_ab_school = 10074007 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10152257 and ind.code_relatie_ab_school = 10290570 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10152291 and ind.code_relatie_ab_school = 10262643 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10152440 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10155369 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10165614 and ind.code_relatie_ab_school = 10262289 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10224847 and ind.code_relatie_ab_school = 10060794 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from  owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10283188 and ind.code_relatie_ab_school = 10048212 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' ;

-- update van bovenstaande 22 records
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10114804 and ind.code_relatie_ab_school = 10084363 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'ZMLK-BB';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 7 where ind.code_relatie_vest_inschrijving = 10118522 and ind.code_relatie_ab_school = 10290592 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 4 where ind.code_relatie_vest_inschrijving = 10216258 and ind.code_relatie_ab_school = 10055660 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 3 where ind.code_relatie_vest_inschrijving = 10269406 and ind.code_relatie_ab_school = 10264069 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10271213 and ind.code_relatie_ab_school = 10213840 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10137629 and ind.code_relatie_ab_school = 10262541 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10141523 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10203142 and ind.code_relatie_ab_school = 10050563 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10147383 and ind.code_relatie_ab_school = 10052445 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10145967 and ind.code_relatie_ab_school = 10404101 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'MG';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 3 where ind.code_relatie_vest_inschrijving = 10297253 and ind.code_relatie_ab_school = 10262643 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10297253 and ind.code_relatie_ab_school = 10213840 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 3 where ind.code_relatie_vest_inschrijving = 10149685 and ind.code_relatie_ab_school = 10052456 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 6 where ind.code_relatie_vest_inschrijving = 10218538 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 5 where ind.code_relatie_vest_inschrijving = 10154117 and ind.code_relatie_ab_school = 10074007 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 7 where ind.code_relatie_vest_inschrijving = 10152257 and ind.code_relatie_ab_school = 10290570 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 3 where ind.code_relatie_vest_inschrijving = 10152291 and ind.code_relatie_ab_school = 10262643 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10152440 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 2 where ind.code_relatie_vest_inschrijving = 10155369 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 6 where ind.code_relatie_vest_inschrijving = 10165614 and ind.code_relatie_ab_school = 10262289 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 3 where ind.code_relatie_vest_inschrijving = 10224847 and ind.code_relatie_ab_school = 10060794 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
update owd.owd_rgl_indicaties ind set ind.aantal_indicaties = 3 where ind.code_relatie_vest_inschrijving = 10283188 and ind.code_relatie_ab_school = 10048212 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';

--select vd 22 rows rgl_indicaties die verwijderd moeten worden omdat de indicaties zijn opgeteld bij de resterende vestiging
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10122744 and ind.code_relatie_ab_school = 10084363 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'ZMLK-BB' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10295199 and ind.code_relatie_ab_school = 10290592 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10133172 and ind.code_relatie_ab_school = 10055660 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10161690 and ind.code_relatie_ab_school = 10264069 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10131789 and ind.code_relatie_ab_school = 10213840 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10124706 and ind.code_relatie_ab_school = 10262541 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10280134 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10146200 and ind.code_relatie_ab_school = 10050563 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10275679 and ind.code_relatie_ab_school = 10052445 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10140586 and ind.code_relatie_ab_school = 10404101 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'MG' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10223253 and ind.code_relatie_ab_school = 10262643 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10223253 and ind.code_relatie_ab_school = 10213840 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10150819 and ind.code_relatie_ab_school = 10052456 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10151209 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10180322 and ind.code_relatie_ab_school = 10074007 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10140075 and ind.code_relatie_ab_school = 10290570 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10276412 and ind.code_relatie_ab_school = 10262643 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10218561 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10149992 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10279160 and ind.code_relatie_ab_school = 10262289 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10172277 and ind.code_relatie_ab_school = 10060794 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4' union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10144419 and ind.code_relatie_ab_school = 10048212 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';

-- delete van bovenstaande 22 rgl_indicaties
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10122744 and ind.code_relatie_ab_school = 10084363 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'ZMLK-BB';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10295199 and ind.code_relatie_ab_school = 10290592 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10133172 and ind.code_relatie_ab_school = 10055660 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10161690 and ind.code_relatie_ab_school = 10264069 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10131789 and ind.code_relatie_ab_school = 10213840 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10124706 and ind.code_relatie_ab_school = 10262541 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10280134 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10146200 and ind.code_relatie_ab_school = 10050563 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10275679 and ind.code_relatie_ab_school = 10052445 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10140586 and ind.code_relatie_ab_school = 10404101 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'MG';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10223253 and ind.code_relatie_ab_school = 10262643 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10223253 and ind.code_relatie_ab_school = 10213840 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10150819 and ind.code_relatie_ab_school = 10052456 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'LG';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10151209 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10180322 and ind.code_relatie_ab_school = 10074007 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10140075 and ind.code_relatie_ab_school = 10290570 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10276412 and ind.code_relatie_ab_school = 10262643 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10218561 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10149992 and ind.code_relatie_ab_school = 10262392 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10279160 and ind.code_relatie_ab_school = 10262289 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10172277 and ind.code_relatie_ab_school = 10060794 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';
delete from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10144419 and ind.code_relatie_ab_school = 10048212 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') and ind.soort_indicatie = 'CLUSTER 4';

-- na de delete zijn er nog 5 vest die rgl_indicaties had met EN zonder dat deze ook bij de resterende reg_vest voorkwamen;
-- degenenen die ook bij de resterende regvest voorkwamen zijn gedelete dus er kan gewoon geupdate worden.
select * from owd.owd_rgl_indicaties ind1
where IND1.TELDATUM = to_date('01-10-2013','dd-mm-yyyy') 
and IND1.CODE_RELATIE_VEST_INSCHRIJVING in (10122744, 10295199, 10133172, 10161690, 10131789, 10124706, 10280134, 10146200, 10140586, 10275679, 10151209, 
              10150819, 10223253, 10140075, 10276412, 10218561, 10180322, 10149992, 10279160, 10172277, 10144419)
and not exists
(select * from owd.owd_rgl_indicaties ind2  
where IND2.TELDATUM = to_date('01-10-2013','dd-mm-yyyy')
and IND2.CODE_RELATIE_AB_SCHOOL = IND1.CODE_RELATIE_AB_SCHOOL
and IND2.SOORT_INDICATIE = IND1.SOORT_INDICATIE
and IND2.CODE_RELATIE_VEST_INSCHRIJVING in 
(select OVG.CODE_RELATIE_NAAR from rel.rel_v_bo_org_overgangen ovg
where OVG.CODE_RELATIE_VAN = IND1.CODE_RELATIE_VEST_INSCHRIJVING
and OVG.DT_OVERGANG = to_date('01-08-2014','dd-mm-yyyy')));

--nog 5 vd 10 records over
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10146200 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10276412 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10131789 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10140075 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy') union
select * from owd.owd_rgl_indicaties ind where ind.code_relatie_vest_inschrijving = 10172277 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');

-- update vd 5 resterende records
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10203142 , ind.adminnr_vest_inschrijving = '09NH00' where ind.code_relatie_vest_inschrijving = 10146200 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10152291 , ind.adminnr_vest_inschrijving = '12ME00' where ind.code_relatie_vest_inschrijving = 10276412 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10271213 , ind.adminnr_vest_inschrijving = '05XC00' where ind.code_relatie_vest_inschrijving = 10131789 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10152257 , ind.adminnr_vest_inschrijving = '12LQ00' where ind.code_relatie_vest_inschrijving = 10140075 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');
update owd.owd_rgl_indicaties ind set ind.code_relatie_vest_inschrijving = 10224847 , ind.adminnr_vest_inschrijving = '18WY00' where ind.code_relatie_vest_inschrijving = 10172277 and ind.teldatum = to_date('01-10-2013','dd-mm-yyyy');