select te_code
,      component
,      datum_changes_vanaf
,      datum_changes_tot
,      max(acct1.datum_deploy) acct1
,      max(validatie.datum_deploy) validatie
,      max(acct2.datum_deploy) acct2
,      max(schaduw.datum_deploy) schaduw
,      max(productie.datum_deploy) prod
,      ul.afhankelijkheid
,      ul.impact
,      ul.omschrijving 
from   meta_load.mge_unloads ul,
       (select * 
        from meta_load.mge_deployments dp, meta_load.mge_omgevingen og
        where DP.OGG_ID=OG.ID
          and OG.NAAM_OMGEVING='ACCT1') acct1,
       (select * 
          from meta_load.mge_deployments dp, meta_load.mge_omgevingen og
         where DP.OGG_ID=OG.ID
           and OG.NAAM_OMGEVING='VALIDATIE') validatie,
       (select * 
          from meta_load.mge_deployments dp, meta_load.mge_omgevingen og
         where DP.OGG_ID=OG.ID
           and OG.NAAM_OMGEVING='ACCT2') acct2,
       (select * 
          from meta_load.mge_deployments dp, meta_load.mge_omgevingen og
         where DP.OGG_ID=OG.ID
           and OG.NAAM_OMGEVING='SCHADUW') schaduw,
       (select * 
          from meta_load.mge_deployments dp, meta_load.mge_omgevingen og
         where DP.OGG_ID=OG.ID
           and OG.NAAM_OMGEVING='PROD') productie
where ul.status='R'
  and ul.id=acct1.ULD_ID (+)
  and ul.id=validatie.ULD_ID (+)
  and ul.id=acct2.ULD_ID (+)
  and ul.id=schaduw.ULD_ID (+)
  and ul.id=productie.ULD_ID (+)
group by te_code,component
,        datum_changes_vanaf
,        datum_changes_tot
,        ul.afhankelijkheid
,        ul.impact
,        ul.omschrijving 
order by ul.te_code desc
,        ul.component