select ctime "Date",
       decode(backup_type, 'L', 'Archive Log', 'I', 'Incremental','D', decode(controlfile_included,'NO', 'Full', 'Controlfile')) backup_type,
        bsize "Size MB"
 from (select trunc(bp.completion_time) ctime
              , backup_type
              , controlfile_included
              , round(sum(bp.bytes/1024/1024),2) bsize
       from v$backup_set bs, v$backup_piece bp
       where bs.set_stamp = bp.set_stamp
       and bs.set_count  = bp.set_count
       and bp.status = 'A'
       group by trunc(bp.completion_time), backup_type, controlfile_included)
order by 1, 2;