select v.sql_id,
       v.SQL_TEXT,
       v.sql_fulltext,
           v.PARSING_SCHEMA_NAME,
           v.FIRST_LOAD_TIME,
           v.DISK_READS,
           v.ROWS_PROCESSED,
           v.ELAPSED_TIME,
           v.service
   from v$sql v
where sql_id in (
select
a.SQL_ID
from
DBA_HIST_SQLSTAT a, dba_hist_snapshot s, v$sql v
where
s.snap_id = a.snap_id
and a.sql_id=v.sql_id
and v.sql_text like '%PROFILE%'
group by
a.SQL_ID,
v.SQL_TEXT)
order by ELAPSED_TIME

order by
sum(DISK_READS_DELTA) desc