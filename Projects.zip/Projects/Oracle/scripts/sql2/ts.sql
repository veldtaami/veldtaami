select t.tablespace_name TSNAME
,      t.mb TSSIZE
,      t.max MAXSIZE 
,      t.mb - nvl(f.mb,0) USED
,      nvl(f.mb,0) FREE
,      lpad( ceil(((t.mb - nvl(f.mb,0))/t.max)*100)||'%', 6) PUSED
,      '|'||rpad(lpad('#',ceil(((t.mb - nvl(f.mb,0))/t.max)*20),'#'),20,' ')||'|' "Used"
from (
  select tablespace_name, trunc(sum(bytes)/1048576) MB
  from dba_free_space
  group by tablespace_name
 union all
  select tablespace_name, trunc(sum(bytes_free)/1048576) MB
  from v$temp_space_header
  group by tablespace_name
) f, (
  select tablespace_name, trunc(sum(bytes)/1048576) MB, trunc(sum(decode(maxbytes,0,bytes,maxbytes))/1048576) max
  from dba_data_files
  group by tablespace_name
 union all
  select tablespace_name, trunc(sum(bytes)/1048576) MB, trunc(sum(decode(maxbytes,0,bytes,maxbytes))/1048576) max
  from dba_temp_files
  group by tablespace_name
) t
where t.tablespace_name = f.tablespace_name (+)
and   t.tablespace_name like upper('%'||nvl('&name','%')||'%')
and   ceil(((t.mb - nvl(f.mb,0))/t.max)*100) >= nvl(&procent,0)
order by t.tablespace_name
/