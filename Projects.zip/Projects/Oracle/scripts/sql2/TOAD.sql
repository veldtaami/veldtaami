-- "Set define off" turns off substitution variables. 
Set define off; 

--
-- TOAD  (User) 
--
CREATE USER TOAD
  IDENTIFIED BY LkC43U6fVtVE8VyuzHXc
  DEFAULT TABLESPACE TOOLS
  TEMPORARY TABLESPACE TEMP
  PROFILE DEFAULT
  ACCOUNT UNLOCK;
  -- 1 Role for TOAD 
  GRANT APPL_OBJ_EIGENAAR TO TOAD;
  ALTER USER TOAD DEFAULT ROLE ALL;
  -- 1 Tablespace Quota for TOAD 
  ALTER USER TOAD QUOTA UNLIMITED ON TOOLS;

ALTER USER TOAD GRANT CONNECT THROUGH SYSTEM;

--
-- TOAD_EXCEPTIONS  (Table) 
--
CREATE TABLE TOAD.TOAD_EXCEPTIONS
(
  USER_NAME  VARCHAR2(32 CHAR), 
  CONSTRAINT TOAD_EXCEPTIONS_PK
  PRIMARY KEY
  (USER_NAME)
  ENABLE VALIDATE
)
ORGANIZATION INDEX
PCTTHRESHOLD 50
TABLESPACE TOOLS
RESULT_CACHE (MODE DEFAULT)
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           );


--
-- TOAD_RESTRICTIONS  (Table) 
--
CREATE TABLE TOAD.TOAD_RESTRICTIONS
(
  USER_NAME  VARCHAR2(32 CHAR)                  NOT NULL,
  FEATURE    VARCHAR2(20 CHAR)                  NOT NULL
)
TABLESPACE TOOLS
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
NOCOMPRESS ;


-- Index TOAD_EXCEPTIONS_PK is created automatically by Oracle with index organized table TOAD_EXCEPTIONS.


--
-- TOAD_RES_PK  (Index) 
--
CREATE UNIQUE INDEX TOAD.TOAD_RES_PK ON TOAD.TOAD_RESTRICTIONS
(FEATURE, USER_NAME)
TABLESPACE TOOLS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           );


--
-- TOAD_RESTRICTIONS  (Synonym) 
--
CREATE PUBLIC SYNONYM TOAD_RESTRICTIONS FOR TOAD.TOAD_RESTRICTIONS;


-- 
-- Non Foreign Key Constraints for Table TOAD_EXCEPTIONS 
-- 
ALTER TABLE TOAD.TOAD_EXCEPTIONS ADD (
  CONSTRAINT TOAD_EXCEPTIONS_UPPER
  CHECK (USER_NAME=upper(USER_NAME))
  ENABLE VALIDATE);


-- 
-- Non Foreign Key Constraints for Table TOAD_RESTRICTIONS 
-- 
ALTER TABLE TOAD.TOAD_RESTRICTIONS ADD (
  CONSTRAINT TOAD_RES_PK
  PRIMARY KEY
  (FEATURE, USER_NAME)
  USING INDEX TOAD.TOAD_RES_PK
  ENABLE VALIDATE);


GRANT SELECT ON TOAD.TOAD_RESTRICTIONS TO PUBLIC;

GRANT DELETE, INSERT, SELECT, UPDATE ON TOAD.TOAD_RESTRICTIONS TO SYSTEM;

GRANT SELECT dba_role_privs TO SYSTEM;

CREATE OR REPLACE PROCEDURE SYSTEM.duo_restrict_toad is
BEGIN
  DECLARE
      CURSOR c_role_wel
      IS
         SELECT   distinct grantee
           FROM   sys.dba_role_privs
          WHERE   (REGEXP_LIKE (granted_role, '(^[A-Z][A-Z][A-Z]_.*)') or granted_role like ('RGLD%'))
                   AND granted_role NOT IN ('EXP_FULL_DATABASE', 'IMP_FULL_DATABASE')
                   AND grantee not in ('SYS','SYSTEM','DBA')
                   AND grantee not in (select user_name from toad.toad_exceptions)
         MINUS
         SELECT   user_name FROM toad.toad_restrictions;

      CURSOR c_role_niet
      IS
         SELECT   user_name FROM toad.toad_restrictions
         MINUS
         SELECT   distinct grantee
           FROM   sys.dba_role_privs
          WHERE   (REGEXP_LIKE (granted_role, '(^[A-Z][A-Z][A-Z]_.*)') or granted_role like ('RGLD%'))
                   AND granted_role NOT IN ('EXP_FULL_DATABASE', 'IMP_FULL_DATABASE')
                   AND grantee not in ('SYS','SYSTEM','DBA')
                   AND grantee not in (select user_name from toad.toad_exceptions);

      r_role_wel   c_role_wel%ROWTYPE;
      r_role_niet  c_role_niet%ROWTYPE;
   BEGIN
      FOR r_role_wel IN c_role_wel
      LOOP
         INSERT INTO toad.toad_restrictions
           VALUES   (r_role_wel.grantee, 'Read only override');
      END LOOP;

      COMMIT;
      FOR r_role_niet IN c_role_niet
      LOOP
         DELETE FROM toad.toad_restrictions
         WHERE  user_name = r_role_niet.user_name;
      END LOOP;
      COMMIT;
   END;
END;
/

BEGIN
  SYS.DBMS_SCHEDULER.CREATE_JOB
    (
       job_name        => 'SYSTEM.DUORESTRICTTOAD'
      ,start_date      => TO_TIMESTAMP_TZ('2014/06/14 10:12:13.384677 +01:00','yyyy/mm/dd hh24:mi:ss.ff tzr')
      ,repeat_interval => 'freq=daily; byday=MON,TUE,WED,THU,FRI; byhour=20; byminute=5;bysecond=0'
      ,end_date        => NULL
      ,job_class       => 'DEFAULT_JOB_CLASS'
      ,job_type        => 'STORED_PROCEDURE'
      ,job_action      => 'SYSTEM.DUO_RESTRICT_TOAD'
      ,comments        => NULL
    );
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYSTEM.DUORESTRICTTOAD'
     ,attribute => 'RESTARTABLE'
     ,value     => TRUE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYSTEM.DUORESTRICTTOAD'
     ,attribute => 'LOGGING_LEVEL'
     ,value     => SYS.DBMS_SCHEDULER.LOGGING_RUNS);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( name      => 'SYSTEM.DUORESTRICTTOAD'
     ,attribute => 'MAX_FAILURES');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( name      => 'SYSTEM.DUORESTRICTTOAD'
     ,attribute => 'MAX_RUNS');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYSTEM.DUORESTRICTTOAD'
     ,attribute => 'STOP_ON_WINDOW_CLOSE'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYSTEM.DUORESTRICTTOAD'
     ,attribute => 'JOB_PRIORITY'
     ,value     => 3);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( name      => 'SYSTEM.DUORESTRICTTOAD'
     ,attribute => 'SCHEDULE_LIMIT');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYSTEM.DUORESTRICTTOAD'
     ,attribute => 'AUTO_DROP'
     ,value     => FALSE);

  SYS.DBMS_SCHEDULER.ENABLE
    (name                  => 'SYSTEM.DUORESTRICTTOAD');
END;
/

