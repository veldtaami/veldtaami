select v.sql_id,
       v.SQL_TEXT,
       v.sql_fulltext,
           v.PARSING_SCHEMA_NAME,
           v.FIRST_LOAD_TIME,
           v.DISK_READS,
           v.ROWS_PROCESSED,
           v.ELAPSED_TIME,
           v.service
      from v$sql v
where v.sql_text like '%PROFILE%' and disk_reads > 10000
and parsing_schema_name='DOCSUSER'

desc v$sql