declare
  l_bericht    clob;
  l_response   clob;
  l_melding    varchar2(256);
  datumtijd    date := sysdate;
  total       number :=0;
begin
-- AVH
l_bericht:='<?xml version="1.0" encoding="utf-8"?><message xmlns="urn:cfi-envelop-2005-01">
<header><type>avh-opvragenuwv</type>
<destination>AVH</destination>
<sender>TBT_TEST</sender><requestid>CD6F1426E58837D3E044002481D1C3F5</requestid>
<userid>o399pel</userid>
<password></password>
<correlationid>6001a1e5-561e-4ded-91a8-b48879644452</correlationid>
<direction>request</direction></header>
<body>
<OpvragenUWV xmlns="urn:cfi-avh-opvragen-uwv-2005-01">
  <Relatie>10059560</Relatie>
  <Rol>OIPO</Rol>
  <DatumSelectie>2011-12-01</DatumSelectie>
</OpvragenUWV>
</body>
</message>';

GCO.GCO_SOAP_UTIL.VERSTUUR_SOAP_BERICHT
 (P_BERICHT_NAAM => 'avh-opvragenuwv'
 ,P_BERICHT => l_bericht
 ,P_RESPONSE => l_response
 ,P_MELDING => l_melding
 );
dbms_output.put_line('AVH: '||l_melding);
-- DAV
l_bericht:='<?xml version="1.0" encoding="utf-8"?><message xmlns="urn:cfi-envelop-2005-01">
<header><type>avh-opvragenuwv</type>
<destination>AVH</destination>
<sender>TBT_TEST</sender><requestid>CD6F1426E58837D3E044002481D1C3F5</requestid>
<userid>o399pel</userid>
<password></password>
<correlationid>6001a1e5-561e-4ded-91a8-b48879644452</correlationid>
<direction>request</direction></header>
<body>
<OpvragenUWV xmlns="urn:cfi-avh-opvragen-uwv-2005-01">
  <Relatie>10059560</Relatie>
  <Rol>OIPO</Rol>
  <DatumSelectie>2011-12-01</DatumSelectie>
</OpvragenUWV>
</body>
</message>';

GCO.GCO_SOAP_UTIL.VERSTUUR_SOAP_BERICHT
 (P_BERICHT_NAAM => 'avh-opvragenuwv'
 ,P_BERICHT => l_bericht
 ,P_RESPONSE => l_response
 ,P_MELDING => l_melding
 );
dbms_output.put_line('DAV: '||l_melding);
-- GEG
l_bericht:='<?xml version="1.0" encoding="utf-8"?>
<message xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:cfi-envelop-2005-01">
  <header>
    <type>dav-opvragengeadresseerden</type>
    <sender>TBT_TEST</sender>
    <requestid>4e6bb2a2-87ce-484e-9358-6671111e01fa</requestid>
    <userid>o399pel</userid>
    <password>SmFudWFyaTIwMTQ=</password>
    <direction>request</direction>
  </header>
  <sequence>
    <sequencenumber>1</sequencenumber>
    <totalinsequence>1</totalinsequence>
  </sequence>
  <body>
    <OpvragenGeadresseerden xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:cfi-dav-opvragen-geadresseerden-2005-01">
      <CodeGebeurtenis>VZBPER</CodeGebeurtenis>
    </OpvragenGeadresseerden>
  </body>
</message>';

GCO.GCO_SOAP_UTIL.VERSTUUR_SOAP_BERICHT
 (P_BERICHT_NAAM => 'owi-opvragenvasteonderwijsinstellingsgegevensrelatie'
 ,P_BERICHT => l_bericht
 ,P_RESPONSE => l_response
 ,P_MELDING => l_melding
 );
dbms_output.put_line('GEG: '||l_melding);
-- OWI
l_bericht:='<?xml version="1.0" encoding="utf-8"?><message xmlns="urn:cfi-envelop-2005-01"><header><type>owi-opvragenvasteonderwijsinstellingsgegevensrelatie</type><destination>OWI</destination>
<sender>TBT_TEST</sender><requestid>C23227FEB591543FE04400226403A0BB</requestid><userid>SC_EMR</userid><password></password><correlationid>C23101343E31175CE04400226403A0BB</correlationid><direction>request</direction></header><body><OpvragenVasteOnderwijsinstellingsGegevensRelatie xmlns="urn:cfi-owi-opvragen-vaste-onderwijsinstellings-gegevens-relatie-2005-01">
  <Relatie>10231386</Relatie>
  <Rol>BG</Rol>
</OpvragenVasteOnderwijsinstellingsGegevensRelatie>
</body></message>';

GCO.GCO_SOAP_UTIL.VERSTUUR_SOAP_BERICHT
 (P_BERICHT_NAAM => 'owi-opvragenvasteonderwijsinstellingsgegevensrelatie'
 ,P_BERICHT => l_bericht
 ,P_RESPONSE => l_response
 ,P_MELDING => l_melding
 );
dbms_output.put_line('OWI: '||l_melding);
-- OWT
l_bericht:='<?xml version="1.0" encoding="utf-8"?><message xmlns="urn:cfi-envelop-2005-01">
<header><type>owt-opvragenwecspecifiekegegevensonderwijs</type><destination>OWT</destination><sender>TBT_TEST</sender><requestid>0BFD7F63B643A497E05337F71EACF93C</requestid><userid></userid><password></password><correlationid></correlationid><direction>request</direction></header>
<body><OpvragenWecSpecifiekeGegevensOnderwijs xmlns="urn:cfi-owt-opvragen-wec-specifieke-gegevens-onderwijs-2005-01">
  <Onderwijs>1000197</Onderwijs>
  <DatumSelectie>2012-08-01</DatumSelectie>
</OpvragenWecSpecifiekeGegevensOnderwijs>
</body></message>';

GCO.GCO_SOAP_UTIL.VERSTUUR_SOAP_BERICHT
 (P_BERICHT_NAAM => 'owt-opvragenwecspecifiekegegevensonderwijs'
 ,P_BERICHT => l_bericht
 ,P_RESPONSE => l_response
 ,P_MELDING => l_melding
 );
dbms_output.put_line('OWT: '||l_melding);
-- OWD
l_bericht:='<?xml version="1.0" encoding="utf-8"?>
<message xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:cfi-envelop-2005-01">
  <header>
    <type>owd-opvragenaantalrglindicaties</type>
    <sender>TBT_TEST</sender>
    <requestid>a2234066-2c58-46ab-92c1-8eb92efa1414</requestid>
    <userid>o399dut</userid>
    <password />
    <direction>request</direction>
  </header>
  <sequence>
    <sequencenumber>1</sequencenumber>
    <totalinsequence>1</totalinsequence>
  </sequence>
  <body>
    <Request xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:cfi-owd-opvragen-aantal-r-g-l-indicaties-2005-01">
      <VestigingInschrijvingNummer>1</VestigingInschrijvingNummer>
      <VestigingInschrijvingRol>2</VestigingInschrijvingRol>
      <ABSchoolNummer>3</ABSchoolNummer>
      <ABSchoolRol>4</ABSchoolRol>
      <SoortIndicatie>6</SoortIndicatie>
      <Teldatum>1982-01-01</Teldatum>
    </Request>
  </body>
</message>';

GCO.GCO_SOAP_UTIL.VERSTUUR_SOAP_BERICHT
 (P_BERICHT_NAAM => 'owd-opvragenaantalrglindicaties'
 ,P_BERICHT => l_bericht
 ,P_RESPONSE => l_response
 ,P_MELDING => l_melding
 );
dbms_output.put_line('OWD: '||l_melding);
-- RFG
l_bericht:='<?xml version="1.0" encoding="utf-8"?><message xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:cfi-envelop-2005-01">
<header><type>rfg-opvragenwaardereferentiegegeven</type><sender>TBT_TEST</sender><requestid>240c4fb5-d1d6-45c6-aa22-332493426bc8</requestid><correlationid /><userid>SC_EMR</userid><password /><direction>request</direction></header><sequence><sequencenumber>1</sequencenumber><totalinsequence>1</totalinsequence></sequence><body><OpvragenWaardeReferentiegegeven xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:cfi-rfg-opvragen-waarde-referentiegegeven-2005-01"><IdentificatieReferentiegegeven>DGNINVOER</IdentificatieReferentiegegeven><DatumSelectie>2010-06-17</DatumSelectie></OpvragenWaardeReferentiegegeven></body></message>';

GCO.GCO_SOAP_UTIL.VERSTUUR_SOAP_BERICHT
 (P_BERICHT_NAAM => 'rfg-opvragenwaardereferentiegegeven'
 ,P_BERICHT => l_bericht
 ,P_RESPONSE => l_response
 ,P_MELDING => l_melding
 );
dbms_output.put_line('RFG: '||l_melding);
-- WER
l_bericht:='<?xml version="1.0" encoding="utf-8"?>
<message xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:cfi-envelop-2005-01">
  <header>
    <type>wer-opvragensegmentgroepen</type>
    <sender>TBT_TEST</sender>
    <requestid>52802f25-c357-4430-a6fa-92d526eabdef</requestid>
    <userid>o399ebb</userid>
    <password>RHVvWjExMTE=</password>
    <direction>request</direction>
  </header>
  <sequence>
    <sequencenumber>1</sequencenumber>
    <totalinsequence>1</totalinsequence>
  </sequence>
  <body>
    <OpvragenSegmentgroepenRequest xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:cfi-wer-opvragen-segmentgroepen-2005-01">
      <DatumSelectie>2009-11-11</DatumSelectie>
      <Code />
      <Code>ATEST06</Code>
    </OpvragenSegmentgroepenRequest>
  </body>
</message>';
GCO.GCO_SOAP_UTIL.VERSTUUR_SOAP_BERICHT
 (P_BERICHT_NAAM => 'wer-opvragensegmentgroepen'
 ,P_BERICHT => l_bericht
 ,P_RESPONSE => l_response
 ,P_MELDING => l_melding
 );
dbms_output.put_line('WER: '||l_melding);
-- ZMT
l_bericht:='<message xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:cfi-envelop-2005-01">
  <header>
    <type>zmt-opvragenzaakgegevens</type>
    <sender>TBT_TEST</sender>
    <requestid>3c38f24b-0f39-4b8a-a3f2-97c8d81068df</requestid>
    <userid>o388rui</userid>
    <direction>request</direction>
  </header>
  <sequence>
    <sequencenumber>1</sequencenumber>
    <totalinsequence>1</totalinsequence>
  </sequence>
  <body>
    <Request xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" ZaakType="STB" ZaakDatumVanaf="2011-08-01" Bekostigingsonderwerp="PERSBEKREG" Doelgroep="RSBASIS" ProductieRonde="201210" xmlns="urn:cfi-zmt-opvragen-zaak-gegevens-2005-01">
      <Bekostigingsperiode DatumIngang="2011-08-01" DatumEinde="2012-08-01" />
      <WaardeExtraIdentificerendGegeven Code="" Waarde="" />
    </Request>
  </body>
</message>';
GCO.GCO_SOAP_UTIL.VERSTUUR_SOAP_BERICHT
 (P_BERICHT_NAAM => 'zmt-opvragenzaakgegevens'
 ,P_BERICHT => l_bericht
 ,P_RESPONSE => l_response
 ,P_MELDING => l_melding
 );
dbms_output.put_line('ZMT: '||l_melding);
end;
/