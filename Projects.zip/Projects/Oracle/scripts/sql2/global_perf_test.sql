rem Global Wait Time (DB time - CPU time)
rem Memory Advice
rem Physical and logical read
rem buffer cache - buffer busy
rem logfile and log space
rem shared pool
rem sort
rem SQL
rem Chained / Migration
rem Histograms?
rem Do we use sql plan baselines?
rem Locked table statistics

col statistic_name for a25
pause look at global wait time (DB CPU - DB TIME = WAIT)

col stat_name for a38
rem time in microseconds
select stat_name, value from v$sys_time_model
where stat_name in ('DB time', 'DB CPU')
union
select 'Global Wait Time (DB time - CPU Time)',
   (select value from v$sys_time_model
       where stat_name  = 'DB time') -
   (select value from v$sys_time_model
       where stat_name  = 'DB CPU')
  from dual
/

pause do we have enough memory?

col MEMORY_SIZE_FACTOR  for 999.99 hea MEMORY_SIZE|FACTOR
col ESTD_DB_TIME_FACTOR for 999.99 hea  ESTD_DB_TIME|FACTOR
col MEMORY_SIZE         for 9999999 hea MEMORY|SIZE
col ESTD_DB_TIME        for 9999999 hea ESTD_DB|TIME

select * from v$memory_target_advice;

pause check logical and physical reads
select name, value from v$sysstat
   where name in ('physical reads', 
                  'session logical reads');

pause calculate ratio based on physical reads and gets
rem ratio = percentage of physical reads versus logical reads

col ratio for 999.99 hea HIT_RATIO
rem ratio s hit ratio, is percent (0.39 = 0.39 %)

col db_gets    for 999,999,999
col cons_gets  for 9,999,999,999
col phys_reads for 999,999,999
select db_gets, cons_gets, phys_reads,
     (1 - (phys_reads / (db_gets + cons_gets))) * 100 Ratio
   from (select value db_gets from v$sysstat
            WHERE name  = 'db block gets from cache'),
        (select value cons_gets from v$sysstat
            WHERE name  = 'consistent gets from cache'),
        (select value phys_reads from v$sysstat
            WHERE name  = 'physical reads cache');

rem check I/O wait time per function
rem wait_time in milliseconds

pause check I/O waits per function (are disks slow?)

select FUNCTION_NAME , NUMBER_OF_WAITS, WAIT_TIME 
    from v$iostat_function
    order by wait_time desc;

pause which functions are doing the most I/O
col SMALL_READ_MEGABYTES  for 999999999 hea SMALL_READ|MEGABYTES
col SMALL_WRITE_MEGABYTES for 999999999 hea SMALL_WRITE|MEGABYTES
col LARGE_READ_MEGABYTES  for 99999999 hea LARGE_READ|MEGABYTES
col LARGE_WRITE_MEGABYTES for 99999999 hea LARGE_WRITE|MEGABYTES

select FUNCTION_NAME, SMALL_READ_MEGABYTES, SMALL_WRITE_MEGABYTES,
                      LARGE_READ_MEGABYTES, LARGE_WRITE_MEGABYTES
  from v$iostat_function;

pause check I/O events
col event for a35

select event, TOTAL_WAITS_FG, TOTAL_WAITS_FG, 
              TIME_WAITED_FG, TIME_WAITED_MICRO_FG
  from v$system_event
  where event like 'db file%';

rem   which tables and/or indexes are read a lot
pause show top 10 segments for logical reads

select * from
      ( select object_name,  STATISTIC_NAME , value
            from v$segment_statistics
            where statistic_name = 'logical reads'
            order by value desc)
     where rownum < 11;

pause show top 19 segments for physical reads

select * from
      ( select object_name,  STATISTIC_NAME , value
            from v$segment_statistics
            where statistic_name = 'physical reads'
            order by value desc)
     where rownum < 11;

pause show top 10 segments for changes

select * from
      ( select object_name,  STATISTIC_NAME , value
            from v$segment_statistics
            where statistic_name = 'db block changes'
            order by value desc)
     where rownum < 11;

pause show top 10 segments for physical writes

select * from
      ( select object_name,  STATISTIC_NAME , value
            from v$segment_statistics
            where statistic_name = 'physical writes'
            order by value desc)
     where rownum < 11;

rem waits for buffer
col TOTAL_WAITS_FG       for 9999999   hea TOTAL|WAITS_FG
col TIME_WAITED_FG       for 9999999   hea TIME|WAITED_FG
col AVERAGE_WAIT_FG      for 99999.99  hea AVERAGE|WAIT_FG
col TIME_WAITED_MICRO_FG for 999999999 hea TIME_WAITED|MICRO_FG

pause buffer busy waits: redistribute records, partition

select event, total_waits_fg,  TIME_WAITED_FG, AVERAGE_WAIT_FG,
       TIME_WAITED_MICRO_FG
      from v$system_event
      where event in ('buffer busy waits');

pause which segments

select * from
      ( select object_name,  STATISTIC_NAME , value
            from v$segment_statistics
            where statistic_name = 'buffer busy waits'
            order by value desc)
     where rownum < 11;

pause free buffer waits: dbwr too slow, not enough memory

col event for a25
select event, total_waits_fg,  TIME_WAITED_FG, AVERAGE_WAIT_FG, 
       TIME_WAITED_MICRO_FG
      from v$system_event
      where event in ('free buffer waits');

pause show dbwr_processes

show parameter db_writer

pause log space problems?

select event, total_waits_fg,  TIME_WAITED_FG, AVERAGE_WAIT_FG,
       TIME_WAITED_MICRO_FG
     from v$system_event
     where event in ('log buffer space');

pause log file switch problems?

select event, total_waits_fg,  TIME_WAITED_FG, AVERAGE_WAIT_FG,
       TIME_WAITED_MICRO_FG
      from v$system_event
      where event like 'log file switch%';

pause slow lgwr, slow writes?

select event, total_waits_fg,  TIME_WAITED_FG, AVERAGE_WAIT_FG,
       TIME_WAITED_MICRO_FG
      from v$system_event
      where event in ('log file single write', 
                      'log file parallel write');

pause slow lgwr, commit is waiting (log file sync)

select event, total_waits_fg,  TIME_WAITED_FG, AVERAGE_WAIT_FG,
       TIME_WAITED_MICRO_FG
      from v$system_event
      where event in ('log file sync');

pause logfile waits (sysstat: redo log space%)

select name, value from v$sysstat where name like 'redo log space%';

rem parsing (shared pool)

pause soft versus hard parses

select name, value from v$sysstat 
    where name in ('parse time cpu', 
                   'parse time elapsed',
                   'parse count (total)', 
                   'parse count (hard)');

pause check for potential shared SQL (duplicated)

with plan_hash as
   (SELECT plan_hash_value, count(*) cnt_hash
       FROM V$SQL
       WHERE Parsing_SCHEMA_NAME not in ('SYS','DBSNMP','SYSMAN')
         AND plan_hash_value <> 0
       GROUP BY plan_hash_value ORDER BY 2)
select sql_text, plan_hash_value, executions, cnt_hash
   from v$sqlarea join plan_hash using (plan_hash_value)
   where cnt_hash > 1
     and sql_text like '%scott.emp%'
   order by plan_hash_value
/

pause SQL AREA: gets / misses
rem reload should be less than 1% of pins

col gets          for 999,999,999
col gethits       for 999,999,999
col get_misses    for 999,999,999
col pins          for 999,999,999
col pinhits       for 999,999,999
col pin_misses    for 999,999,999
col reloads       for 999,999,999
col invalidations for 999,999,999
col pct_get_miss  for 9999,999.99 hea pct_get|miss
col pct_pin_miss  for 9999,999.99 hea pct_pin|miss
col pct_reloads   for 9999,999.99

set lines 66
set hea off
col namespace for a66
select ' --------------               ' || namespace || '              -------------- ',
       '          Gets : ', gets,    '               Pins : ', pins,
       '       Gethits : ', gethits, '            Pinhits : ', pinhits,
       '        Misses : ', gets - gethits get_misses,
                      '         Pin_Misses : ', pins - pinhits pin_misses,
       '    Pct_Misses : ', (gets - gethits) / gets  * 100 pct_get_miss,
                      '     Pct_Pin_Misses : ', (pins - pinhits) / pins * 100 pct_pin_miss,
       '                                                    ',
       '       Reloads : ', reloads, '   Pct_Reloads_Pins : ',
                                     reloads / pins * 100 pct_reloads,
       ' Invalidations :',invalidations
   from v$librarycache
   where namespace = 'SQL AREA'
/

pause check shared pool latch
set hea on
set lines 100

select name, gets, misses from v$latch
  where name in ('shared pool', 'row cache objects');

pause do we have disk sorts or not enough memory for PGA?

col name for a35
select name, value from v$sysstat where name like 'workarea exec%';

pause check pga_target_advice
col PGA_TARGET_FOR_ESTIMATE for 9,999,999,999 hea PGA_TARGET|FOR_ESTIMATE
col PGA_TARGET_FACTOR       for 999.99        hea PGA_TARGET|FACTOR
col ESTD_PGA_CACHE_HIT_PERCENTAGE for 999.99 hea ESTD_PGA_CACHE|HIT_PERCENTAGE

select PGA_TARGET_FOR_ESTIMATE, 
       PGA_TARGET_FACTOR, 
       ESTD_PGA_CACHE_HIT_PERCENTAGE
    from v$pga_target_advice;

pause are many records sorted?

select name, value from v$sysstat where name like 'sort%';

pause reads and writes from temp tablespace

select name, value from v$sysstat 
   where name like 'physical reads direct temp%'
      or name like 'physical writes direct temp%';

pause SQL Activity: most executed SQL (cpu_time in microseconds)

col sql_text          for a50
col executions        for 999999   hea EXE|CUTIONS
col cpu_time_per_exec for 99999.99 hea CPU_TIME|PER_EXEC
select * from
  (select substr(sql_text, 1, 200) sql_text,
          executions,
          cpu_time, cpu_time / executions cpu_time_per_exec
     from v$sqlarea
     where executions > 0
     order by executions desc)
  where rownum < 11
/

pause SQL highest cpu time per execution (cpu_time_per_exec shown in sec)

rem parsing_user_id <= 30 seem to be SYS, DBSNMP, ... please check

col cpu_time_per_exec for 99999.99 hea CPU_TIME|PER_EXEC

select * from
  (select substr(sql_text, 1, 200) sql_text,
          executions,
          cpu_time, cpu_time / executions / 1000000 cpu_time_per_exec
     from v$sqlarea
     where executions > 0
       and parsing_user_id > 30
     order by cpu_time / executions desc)
  where rownum < 11;

pause SQL highest elapsed time per execution (cpu_time_per_exec shown in sec)
rem elapsed time in microseconds

col elapsed_time for 999999999 hea ELAPSED|TIME
col elapsed_time_per_exec for 99999.99 hea ELAPSED_TIME|PER_EXEC(SEC)

select * from
  (select substr(sql_text, 1, 200) sql_text,
          executions,
          elapsed_time, elapsed_time / executions / 1000000 elapsed_time_per_exec
     from v$sqlarea
     where executions > 0
       and parsing_user_id > 30
     order by elapsed_time / executions desc)
  where rownum < 11;

pause which statements have highest wait (microseconds) (no cluster_wait)
col APPLICATION_WAIT_TIME for 99999999 hea APPLICATION|WAIT_TIME
col CONCURRENCY_WAIT_TIME for 99999999 hea CONCURRENCY|WAIT_TIME
col USER_IO_WAIT_TIME     for 99999999 hea USER_IO|WAIT_TIME

select * from
  (select substr(sql_text, 1, 200) sql_text,
          APPLICATION_WAIT_TIME,
          CONCURRENCY_WAIT_TIME,
          USER_IO_WAIT_TIME,
          APPLICATION_WAIT_TIME + CONCURRENCY_WAIT_TIME 
                                + USER_IO_WAIT_TIME TOTAL_WAIT
     from v$sqlarea
     where executions > 0
       and parsing_user_id > 30
     order by APPLICATION_WAIT_TIME + CONCURRENCY_WAIT_TIME 
                                + USER_IO_WAIT_TIME desc)
  where rownum < 11;

pause top statement doing most disk reads per execution
col disk_reads_per_exec for 9999999.99 hea disk_reads|per_exec

select * from
  (select substr(sql_text, 1, 200) sql_text,
          disk_reads,
          executions,
          disk_reads / executions disk_reads_per_exec
     from v$sqlarea
     where executions > 0
       and parsing_user_id > 30
     order by disk_reads / executions desc)
  where rownum < 11;

pause top statement doing most disk reads for all executions
col disk_reads_per_exec for 9999999.99 hea disk_reads|per_exec

select * from
  (select substr(sql_text, 1, 200) sql_text,
          disk_reads,
          executions,
          disk_reads / executions disk_reads_per_exec
     from v$sqlarea
     where executions > 0
       and parsing_user_id > 30
     order by disk_reads desc)
  where rownum < 11;

pause top statement doing most block gets per executions
col buffer_gets_per_exec for 9999999.99 hea buffer_gets|per_exec

select * from
  (select substr(sql_text, 1, 200) sql_text,
          buffer_gets,
          executions,
          buffer_gets / executions buffer_gets_per_exec
     from v$sqlarea
     where executions > 0
       and parsing_user_id > 30
     order by buffer_gets / executions desc)
  where rownum < 11;

pause top statement doing most block gets for all executions

select * from
  (select substr(sql_text, 1, 200) sql_text,
          buffer_gets,
          executions,
          buffer_gets / executions buffer_gets_per_exec
     from v$sqlarea
     where executions > 0
       and parsing_user_id > 30
     order by buffer_gets desc)
  where rownum < 11;

rem select name, value from v$sysstat
rem     where name = 'table fetch continued row'

pause any trace of block chaining / migration

select name, value from v$sysstat
     where name = 'table fetch continued row';

pause show columns having histogram

col owner       for a10
col table_named for a20
col column_name for a25

select owner, table_name, column_name, histogram
  from dba_tab_columns
  where histogram <> 'NONE'
   and owner not in ('SYS', 'SYSTEM', 'DBSNMP', 'SYSMAN',
                     'APEX_030200', 'MDSYS', 'OLAPSYS',
                     'CTXSYS', 'WMSYS')
/

pause do we capture and/or use baselines

show parameter baseline

pause do we have baselines

col sql_text for a44 wrap
select sql_text, enabled, accepted from dba_sql_plan_baselines;

pause do we have locked statistics (STATTYPE_LOCKED = ALL)

select owner, STATTYPE_LOCKED, count(*) 
    from dba_tab_statistics 
    where STATTYPE_LOCKED = 'ALL'
    group by owner, STATTYPE_LOCKED;
