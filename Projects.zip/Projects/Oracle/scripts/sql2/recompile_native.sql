select 'alter '||type||' '||owner||'.'||name||' compile;' from DBA_PLSQL_OBJECT_SETTINGS
where owner not in ('SYS','SYSTEM','OUTLN','WMSYS','DBSNMP','ORACLE_OCM','EXFSYS','XDB')
and PLSQL_CODE_TYPE<>'NATIVE'
order by decode (type, 'TYPE',1,'VIEW', 2, 'FUNCTION',3,'PROCEDURE',4,'PACKAGE', 5,6)
