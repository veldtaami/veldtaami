explain plan for (
 select * from owner_sm1.CM3RA5 where "NUMBER"='C000302428'
);



select plan_table_output from table(dbms_xplan.display('plan_table',null,'basic'));


select plan_table_output  from table(dbms_xplan.display_cursor(null,null,'basic'));
 
 
select plan_table_output from table(dbms_xplan.display_cursor('fnrtqw9c233tt',null,'basic'));




select plan_table_output from v$sql s,
 table(dbms_xplan.display_cursor(s.sql_id,
                                 s.child_number, 'basic')) t
 where s.sql_text like 'select PROD_CATEGORY%';
 
 
