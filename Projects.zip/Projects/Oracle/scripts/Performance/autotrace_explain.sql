spool bindsql_probsummary_output.txt
 
set autotrace on explain
 
var Y varchar2(60)

 exec :Y := 'IM007293697';
 
SELECT m1."NUMBER" FROM PROBSUMMARYM1 m1 WHERE ((m1."PARENT_INCIDENT"=:Y)) ORDER BY m1."NUMBER" ASC;
 
spool off;
