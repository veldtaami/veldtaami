exec DBMS_UTILITY.ANALYZE_SCHEMA('OWNER_OOX','ESTIMATE', estimate_percent => 1);

exec DBMS_UTILITY.ANALYZE_TABLE('TBT_TOOLS','ESTIMATE', estimate_percent => 5);

EXEC DBMS_STATS.gather_table_stats('owner_sm1', 'PROBSUMMARYM1');

ANALYZE table scott estimate statistics sample 25 percent;


owner_sm1.PROBSUMMARYM1

begin
dbms_stats.gather_table_stats
(ownname => 'OWNER_SM1', 
tabname => 'PROBSUMMARYM1' , 
estimate_percent => dbms_stats.auto_sample_size, 
method_opt => 'for all indexed columns size auto',
degree => 4 ,
cascade => TRUE);
end;
/




