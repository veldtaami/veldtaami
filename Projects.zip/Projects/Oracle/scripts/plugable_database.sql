ALTER PLUGGABLE DATABASE BDAPEXO2 close;
drop  PLUGGABLE DATABASE BDAPEXO2 ;
drop  PLUGGABLE DATABASE BDAPEXO2 including datafiles;
CREATE PLUGGABLE DATABASE BDAPEXO2 ADMIN USER pdbadmin  IDENTIFIED BY pw_12345 ROLES = (dba)
  DEFAULT TABLESPACE users DATAFILE '+DG_DUO_DATA' SIZE 100M AUTOEXTEND ON maxsize 1G ; 


ALTER PLUGGABLE DATABASE BDAPEXO2 OPEN;

Warning: PDB altered with errors.

sys@cdb1212a>
select message,time from pdb_plug_in_violations;
select name,open_mode,restricted from v$pdbs;

alter session set container=BDAPEXO2;


ALTER PLUGGABLE DATABASE BDAPEXO2 close;
alter pluggable database BDAPEXO2 open read write instances =all;



CREATE PLUGGABLE DATABASE BDAPEXO2 FROM BDAPEXO;
ALTER PLUGGABLE DATABASE BDAPEXO2 OPEN;

 select name, inst_id, open_mode from gv$containers;
 
 