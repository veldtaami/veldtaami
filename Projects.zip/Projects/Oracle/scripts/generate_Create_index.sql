
set heading on;
set echo on;
set heading off;
set echo off;
 
SET LONG 20000 LONGCHUNKSIZE 20000 PAGESIZE 0 LINESIZE 1000 FEEDBACK OFF VERIFY OFF TRIMSPOOL ON




exec sys.DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'SQLTERMINATOR', true);
exec sys.DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'PRETTY', true);
   -- Uncomment the following lines if you need them.
exec sys.DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'SEGMENT_ATTRIBUTES', false);
exec sys.DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'STORAGE', false);

 

select index_name from dba_indexes where owner='OWNER_SM1' and table_name = 'PROBSUMMARYA1' order by 1

select 'select dbms_metadata.get_ddl(''INDEX'','''|| index_name|| ''',''' || owner || ''') from dual;' from dba_indexes 
where owner='OWNER_OOX' and table_name = 'OO_STEP_LOG_BINDINGS';


select dbms_metadata.get_ddl('TABLE','OO_DEBUGGER_EVENTS','OWNER_OOX') from dual;