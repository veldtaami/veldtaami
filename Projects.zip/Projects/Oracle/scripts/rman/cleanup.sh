cleanup() {
rman target / << EOF
allocate channel for maintenance device type disk;

RUN
{
# Cleaning actions
delete noprompt obsolete device type disk;
delete noprompt expired backup;
delete noprompt expired copy;
delete noprompt backup of spfile completed before 'sysdate-14';
}
EOF
}


export ORAENV_ASK=NO

DBS=`cat /etc/oratab|grep -v '^#'|awk -F : '{ print $1 }'|grep '[0-9]$'|grep -v '^+ASM'`
for ORACLE_SID in $DBS
do
. /usr/local/bin/oraenv >/dev/null 2>&1
cleanup
echo $ORACLE_SID
done


