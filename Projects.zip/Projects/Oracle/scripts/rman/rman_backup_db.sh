#!/bin/ksh
#
# Dit script maakt een online backup van een database. Het kan worden aangeroepen vanuit het script rman_backup_db_all.sh. 
#
# Invoerparameter:
#
# 1 : Database naam
# 2 : F = Full backup, I = Incremental (default), A = Archivelog backup
#
# Afhankelijkheden:
#
# /etc/oratab: De instance van de database moet hierin staan, bv BCM1O1
# /home/oracle/rman/scripts/rman_disk_db_onl_full.rcv: Rman script voor Full backup
# /home/oracle/rman/scripts/rman_disk_db_onl_incr.rcv: Rman script voor incremental backup
# /home/oracle/rman/scripts/rman_disk_archlogs.rcv: Rman script voor incremental backup
#
# Versie Datum      Wie              Wat
# 1.0    27-06-2013 Peter Rienstra   Script gemaakt
# 1.1    21-09-2015 Peter Rienstra   NLS_DATE_FORMAT toegevoegd.
#
set -x 

################################
# Set environment
################################

#. ${0%/*}/setuporaenv.sh                        # Set environment voor draaien vanuit cron

export PATH=$PATH:/usr/local/bin
export ORACLE_BASE=/u01/oracle

DATE_FORMAT="+%Y-%m-%d %H:%M:%S"                 # Datum format voor logging
NODENAME=`hostname|cut -d. -f1`                  # Server naam van de node

export NLS_DATE_FORMAT='yyyy-mm-dd hh24:mi:ss'   # Voor duidelijkere RMAN logging

SCRIPT_DIR=${0%/*}
cd ${SCRIPT_DIR}                                 # Ga naar directory, relatief vanaf plek script
SCRIPT_DIR=`pwd`                                     # Pak absoluut pad voor log directory
cd - > /dev/null

cd ${SCRIPT_DIR}/../log                          # Ga naar logdirectory, relatief vanaf plek script
LOGDIR=`pwd`                                     # Pak absoluut pad voor log directory
cd - > /dev/null

cd ${SCRIPT_DIR}/../cfg                          # Ga naar logdirectory, relatief vanaf plek script
CFGDIR=`pwd`                                     # Pak absoluut pad voor log directory
cd - > /dev/null
CONFIGFILE=${CFGDIR}/rman_backup.cfg

LOGFILE=${LOGDIR}/${0##*/}_${NODENAME}_`date +%Y%m%d`.log    # Logfile wisselt per dag
LOG_HIST=62                                      # Aantal dagen dat logfiles van het script bewaard blijven

#. ${HOME}/scripts/setenv

################################
# Clean logfiles
################################
clean_up ()
{
# Remove old logfiles

find ${LOGDIR} -name "${1##*/}_*" -mtime +${LOG_HIST} -exec rm -f {} \;
FILEFILTER=${RMANLOG%%${DB}*}$DB
FILEFILTER=${FILEFILTER##*/}_
find ${LOGDIR} -name "${FILEFILTER}*" -mtime +${LOG_HIST} -exec rm -f {} \;
}
################################
# MAIN PROGRAM 
################################
 
{
# Begin logfile
echo "###########"
echo `date "${DATE_FORMAT}"`" Start van $0 $@"

# Test input parameters

DB=$1
if [ -z "${DB}" ];then
   echo
   echo `date "${DATE_FORMAT}"` "ERROR: Geen database opgegeven."
   echo "Voorbeeld van aanroep: $0 BCM1O F"
   echo
   exit 1
fi

PREFIX=`grep ^${DB} ${CONFIGFILE}|cut -d: -f4`
SCRIPT_LEVEL0="${SCRIPT_DIR}/${PREFIX}rman_disk_db_onl_full.rcv"
SCRIPT_LEVEL1="${SCRIPT_DIR}/${PREFIX}rman_disk_db_onl_incr.rcv"
SCRIPT_ALOGS="${SCRIPT_DIR}/${PREFIX}rman_disk_archlogs.rcv"

FULL=${2:-I}
if [ $FULL = F ];then
   echo `date "${DATE_FORMAT}"`": Er wordt een FULL backup gemaakt"
   SCRIPT=${SCRIPT_LEVEL0}
   RMANLOG=${LOGDIR}/rman_disk_onl_db_f_${DB}_`date +%Y%m%d_%H%M%S`.log
   TAG=FULL_`date +%Y%m%dT%H%M%S`
elif [ $FULL = A ]; then
   echo `date "${DATE_FORMAT}"`": Er wordt een backup van de archivelogs gemaakt"
   SCRIPT=${SCRIPT_ALOGS}
   RMANLOG=${LOGDIR}/rman_disk_al_${DB}_`date +%Y%m%d_%H%M%S`.log
   TAG=ALOG_`date +%Y%m%dT%H%M%S`
else
   echo `date "${DATE_FORMAT}"`": Er wordt een INCREMENTAL backup gemaakt"
   SCRIPT=${SCRIPT_LEVEL1}
   RMANLOG=${LOGDIR}/rman_disk_onl_db_i_${DB}_`date +%Y%m%d_%H%M%S`.log
   TAG=INCR_`date +%Y%m%dT%H%M%S`
fi

# Get instance name
 
cnt=`ps -ef|grep pmon|grep ${DB}|wc -l`
if [ ${cnt} -ne 1 ];then
   echo
   echo `date "${DATE_FORMAT}"` "ERROR: Geen draaiende instance gevonden op deze server."
   echo
   exit 1
fi

proc=`ps -ef|grep pmon|grep ${DB}`
INSTANCE=$DB${proc: -1:1}

# Backup database

export ORACLE_SID=$INSTANCE
export ORAENV_ASK=NO
. oraenv  > /dev/null

echo `date "${DATE_FORMAT}"` "Backup database ${ORACLE_SID} met ${SCRIPT} en tag=${TAG}..."
${ORACLE_HOME}/bin/rman cmdfile=${SCRIPT} using ${TAG} log=${RMANLOG}


# Remove logfiles + old processed files
clean_up $0

# Einde logfile
echo
echo `date "${DATE_FORMAT}"`" Einde van $0"
echo "###########"
echo
} |tee -a  ${LOGFILE}
