CREATE RESTORE POINT pre_install_28012021;


SELECT name, scn, time, database_incarnation#, guarantee_flashback_database, storage_size 
FROM gv$restore_point;
 
DROP RESTORE POINT good_data;

in sql TABLE
FLASHBACK TABLE employees TO RESTORE POINT good_data;

Database: 
shutdown immediate;
 startup mount;
 flashback database to restore point 'before_damage';
 alter database open resetlogs;


RAC:
op 1 node: 

srvctl stop database -d <database name> -o immediate
sqlplus '/ as sysdba'
startup mount;
flashback database to restore point <restore point name>;
alter database open resetlogs;
shutdown immediate;
quit

srvctl start database -d <database name>
Run crs_stat -t to confirm that the database is backup okay.

