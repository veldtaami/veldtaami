#!/bin/ksh
#
# Dit script maakt een backup van alle databases. Hiervoor wordt gebruik gemaakt van het configuratiebestand rman_backup.cfg.
#
# Afhankelijkheden:
#
# rman_backup.cfg   : configuratie file met de databases waarvan een backup moet worden gemaakt.
# rman_backup_db.sh : script waarmee de backup per database wordt gemaakt.
#
# Versie Datum      Wie              Wat
# 1.0    27-06-2013 Peter Rienstra   Script gemaakt
# 1.1    22-06-2014 Peter Rienstra   Logfiles verwijderen alleen op node 1 i.v.m. OCFS locking probleem
# 1.2    19-03-2015 Peter Rienstra   Extra veld toegevoegd aan de configfile voo Ordina databases
#set -x 

################################
# Set environment
################################

#. ${0%/*}/setuporaenv.sh                        # Set environment voor draaien vanuit cron

DAYOFWEEK="`date +%u`"                           # Dag van de week waarop het script wordt gestart
SCRIPT_DIR=${0%/*}

cd ${SCRIPT_DIR}/../log                          # Ga naar logdirectory, relatief vanaf plek script
LOGDIR=`pwd`                                     # Pak absoluut pad voor log directory
cd - > /dev/null

cd ${SCRIPT_DIR}/../cfg                          # Ga naar logdirectory, relatief vanaf plek script
CFGDIR=`pwd`                                     # Pak absoluut pad voor log directory
cd - > /dev/null

SERVERNAME=`hostname|cut -d. -f1`                # Server naam van de node
RUNNODE=${SERVERNAME: -2:2}                      # Nummer van de node, bv 01, 02
LOGFILE=${LOGDIR}/${0##*/}_${SERVERNAME}_`date +%Y%m%d`.log    # Logfile wisselt per dag
CONFIGFILE=${CFGDIR}/rman_backup.cfg             # Configuratie file voor applicaties
BCK_SCRIPT=${SCRIPT_DIR}/rman_backup_db.sh       # Configuratie file voor applicaties
LOG_HIST=62                                      # Aantal dagen dat logfiles van het script bewaard blijven
DATE_FORMAT="+%Y-%m-%d %H:%M:%S"                 # Datum format voor logging

export PATH=$PATH:/usr/local/bin
export ORACLE_BASE=/u01/oracle


#. ${HOME}/scripts/setenv

################################
# Start logfile 
################################
start_logfile ()
{
echo "####################################"
echo `date "${DATE_FORMAT}"`" Start van $1"
}
################################
# End logfile 
################################
end_logfile ()
{
echo `date "${DATE_FORMAT}"`" Einde van $1"
echo "####################################"
}
################################
# Clean logfiles
################################
clean_up ()
{
# Remove old logfiles
echo
echo `date "${DATE_FORMAT}"`"Start Cleanup logfiles"

find ${LOGDIR} -name "*.log" -mtime +${LOG_HIST} -exec rm -f {} \;

echo `date "${DATE_FORMAT}"`"Einde Cleanup logfiles"
echo
}
################################
# MAIN PROGRAM 
################################
 
{
start_logfile $0

# Look for databases in config file

grep -v ^# ${CONFIGFILE}| while read LINE
do
  DB=`echo "$LINE"|cut -d: -f1`             # Database
  NODE=`echo "$LINE"|cut -d: -f2`           # Node
  DAY_FULL_BCK=`echo "$LINE"|cut -d: -f3`   # Dag wanneer er een full backup moet worden gemaakt
  BACKUP_DB=`echo "$LINE"|cut -d: -f5`      # Moet hiervan een backup worden gemaakt (J/N)
  
  if [ -n ${DB} -a -n ${NODE} -a -n ${DAY_FULL_BCK} -a -n ${BACKUP_DB} ]
  then
     if [ ${NODE} != ${RUNNODE} ];
     then
        echo `date "${DATE_FORMAT}"`" ${DB}: Geen backup, niet de juiste node"
     elif [ ${BACKUP_DB} != J ];
     then
        echo `date "${DATE_FORMAT}"`" ${DB}: Geen backup, staat niet aan (${BACKUP_DB})"
     else
        case "${DAYOFWEEK}" in
	   ${DAY_FULL_BCK})
                echo `date "${DATE_FORMAT}"` "${DB}: Full backup van ${DB}"
                $BCK_SCRIPT $DB F 
                echo `date "${DATE_FORMAT}"` "${DB}: Archivelog backup van ${DB}"
                $BCK_SCRIPT $DB A 
		;;
	   *)
                echo `date "${DATE_FORMAT}"` "${DB}: Full backup van ${DB}"
                $BCK_SCRIPT $DB F 
                echo `date "${DATE_FORMAT}"` "${DB}: Archivelog backup van ${DB}"
                $BCK_SCRIPT $DB A 
		;;
        esac
     fi
  fi
done

# Remove logfiles + old processed files only on node 1 to prevent deadlocks on OCFS
if [ ${RUNNODE} = "01" ];
then
   clean_up
fi

end_logfile $0
} >> ${LOGFILE}
