Handmatig de backup aftrappen:

alter system switch logfile;   (Gebeurt automatische door rman, bij een backup archivelogs)
rman_backup_db.sh BISP A 



restoren: 

rman
connect target /
show all


RUN
{
  set until time= "to_date('15/06/2017 17:00:00','dd/mm/yyyy hh24:mi:ss')";
  RESTORE DATABASE;
  RECOVER DATABASE;
}





handmatig oude backups verwijderen:



crosscheck archivelog all
crosscheck backup
RMAN> SHOW ALL;

CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 7 DAYS;
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 2 DAYS;
LIST BACKUP SUMMARY;



delete expired backup;
delete noprompt expired copy;
delete noprompt backup of spfile completed before 'sysdate-14';

DELETE OBSOLETE;