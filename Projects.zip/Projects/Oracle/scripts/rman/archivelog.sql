archive log list


srvctl stop database -d  RKG1E
sqlplus / as sysdba

STARTUP MOUNT;
ALTER DATABASE ARCHIVELOG;
shutdown immediate

srvctl start database -d  RKG1E


srvctl stop database -d  RKG1E
sqlplus / as sysdba

STARTUP MOUNT;
ALTER DATABASE NOARCHIVELOG;
shutdown immediate

srvctl start database -d  RKG1E



