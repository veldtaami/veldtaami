
XDB invalid

set lines 200
col comp_name for a40
col version for a30
col owner for a20
col schema_url for a60
col status for a30 

select comp_name, version, status from dba_registry;
 

testen:
select owner, schema_url  from dba_xml_schemas order by 1,2;
select any_path from resource_view;
 


alter system set cluster_database=true scope=spfile;

SOLUTION

To validate XDB execute:

connect / as sysdba
execute dbms_regxdb.validatexdb;


CONNECT / AS SYSDBA
GRANT EXECUTE ON DBMS_LOB TO XDB;
GRANT EXECUTE ON UTL_FILE TO XDB;
GRANT EXECUTE ON DBMS_SQL TO XDB;
GRANT EXECUTE ON DBMS_LOB TO PUBLIC;
GRANT EXECUTE ON UTL_FILE TO PUBLIC;
GRANT EXECUTE ON DBMS_SQL TO PUBLIC;
GRANT EXECUTE ON DBMS_JOB TO PUBLIC;
GRANT EXECUTE ON UTL_RAW TO PUBLIC;


@?/rdbms/admin/utlrp.sql


Reload the XDB Component (using xdbrelod.sql).

spool xdbreload_PSIB1.log
connect / as sysdba
set echo on;
shutdown immediate;
startup upgrade;
@?/rdbms/admin/xdbrelod.sql
shutdown immediate;
startup;


@?/rdbms/admin/prvtxdb.plb
@?/rdbms/admin/utlrp.sql

spool off



SYS@PSIB11 SQL> execute dbms_regxdb.validatexdb;
BEGIN dbms_regxdb.validatexdb; END;

*
ERROR at line 1:
ORA-31000: Resource 'http://xmlns.oracle.com/xdb/acl.xsd' is not an XDB schema document
ORA-06512: at "SYS.DBMS_REGXDB", line 111
ORA-06512: at "SYS.DBMS_REGXDB", line 98
ORA-06512: at line 1


SYS@PSIB11 SQL>
SYS@PSIB11 SQL>
SYS@PSIB11 SQL>  
set lines 200
col owner for a30
col schema_url for a70
SYS@PSIB11 SQL>
SYS@PSIB11 SQL> select owner, schema_url  from dba_xml_schemas order by 1,2;

OWNER                          SCHEMA_URL
------------------------------ ----------------------------------------------------------------------
SYS                            http://xmlns.oracle.com/sdm/sensitivedata_12_1.xsd
SYS                            http://xmlns.oracle.com/sdm/sensitivetypes_12_1.xsd
SYS                            http://xmlns.oracle.com/streams/schemas/lcr/streamslcr.xsd
XDB                            http://www.w3.org/1999/csx.xlink.xsd
XDB                            http://www.w3.org/1999/xlink.xsd
XDB                            http://www.w3.org/2001/csx.XInclude.xsd
XDB                            http://www.w3.org/2001/csx.xml.xsd
XDB                            http://www.w3.org/2001/xml.xsd
XDB                            http://xmlns.oracle.com/xdb/XDBFolderListing.xsd
XDB                            http://xmlns.oracle.com/xdb/XDBResConfig.xsd
XDB                            http://xmlns.oracle.com/xdb/XDBResource.xsd
XDB                            http://xmlns.oracle.com/xdb/XDBSchema.xsd
XDB                            http://xmlns.oracle.com/xdb/XDBStandard.xsd
XDB                            http://xmlns.oracle.com/xdb/acl.xsd
XDB                            http://xmlns.oracle.com/xdb/csx.xmltr.xsd
XDB                            http://xmlns.oracle.com/xdb/dav.xsd
XDB                            http://xmlns.oracle.com/xdb/stats.xsd
XDB                            http://xmlns.oracle.com/xdb/xdbconfig.xsd
XDB                            http://xmlns.oracle.com/xdb/xmltr.xsd

19 rows selected.

SYS@PSIB11 SQL>



SYS@PSIB11 SQL> select any_path from resource_view;
select any_path from resource_view
*
ERROR at line 1:
ORA-31000: Resource 'http://xmlns.oracle.com/xdb/acl.xsd' is not an XDB schema document





_________________________________________________________________________________________________


Doc ID 2466862.1

Rebuild the XDB repository hierarchical index.

IMPORTANT: Take a full backup of the database just in case.

connect / as sysdba
truncate table xdb.xdb$h_index;
exec dbms_xdb_admin.rebuildhierarchicalindex();
@?/rdbms/admin/utlrp.sql


