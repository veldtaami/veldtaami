-- if ARCHIVE DEST is FULL

1. temporary increase FRA from 115GB to 200GB to clear incident : 
2. backup all archivelogs : 
3. Delete archievlogs: 


alter system set db_recovery_file_dest_size=200G scope=both sid='*'; 

backup archivelog all ;

delete archivelog all BACKED UP 1 TIMES TO DISK;




