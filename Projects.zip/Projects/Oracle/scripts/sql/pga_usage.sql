select name,value from v$pgastat 
where name in 
('aggregate PGA target parameter', 'aggregate PGA auto target', 'total PGA inuse', 'total PGA allocated', 'over allocation count', 'extra bytes read/written', 'cache hit percentage')
;

set lines 200

select prc.inst_id, ses.sid, ses.serial#, prc.pid, prc.spid, 
round(prc.pga_used_mem/1024/1024) used_mb, 
round(prc.pga_alloc_mem/1024/1024) alloc_mb, 
round((prc.pga_alloc_mem - prc.pga_used_mem)/1024/1024, 0) unused_mb, 
round(prc.pga_freeable_mem/1024/1024) freeable_mb, 
round(prc.pga_max_mem/1024/1024) max_mb,
status
from gv$process prc
  left outer join gv$session ses on (ses.inst_id = prc.inst_id and ses.paddr = prc.addr and ses.type = 'USER')
order by used_mb desc
fetch first 20 rows only;


SELECT ROUND(SUM(pga_used_mem)/(1024*1024),2) PGA_USED_MB FROM v$process;

select sum(pga_used_mem)/1024/1024 mb_used_inactive_Sess
from gv$process prc
  left outer join gv$session ses on (ses.inst_id = prc.inst_id and ses.paddr = prc.addr and ses.type = 'USER')
where status='INACTIVE';

show parameter sga
show parameter pga


select pga_target_for_estimate, pga_target_factor, estd_time
from v$pga_target_advice;

