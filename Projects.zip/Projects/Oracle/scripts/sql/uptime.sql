set lines 200

select INSTANCE_NAME, INSTANCE_NUMBER , to_char(STARTUP_TIME,'DD:MM:YYYY HH24:MI') from gv$instance;
