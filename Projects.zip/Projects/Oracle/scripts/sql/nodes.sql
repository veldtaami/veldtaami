col description form a79
col host form a16
col pn form a5
col backend form a15
col sessions form 999
col username form a14
set linesize 180
set pagesize 249
set escape off
select
  distinct
  ses.sessions,
  round(wrk.logio) "exec/s",
  round(10*wrk.logio/ses.sessions)/10 "exec/ses/s",
  nod.pn,
  substr(nod.hostname,1,15) host,
  nod.description description
from
  (select /*+ ordered */
    a.pn,
    count(*) sessions
  from
    ibm_nodes a,
    v$session b
  where
    substr(a.hostname,1,64)=b.machine
    and
    b.username!='SYS'
    and
    b.type!='BACKGROUND'
  group by a.pn) ses,
  (select /*+ ordered */
     c.pn,
     sum(a.value/(24*3600)) logio 
   from 
     ibm_nodes c,
     v$session b, 
     v$sesstat a,
     v$statname d
   where 
     substr(c.hostname,1,64)=b.machine
     and
     a.statistic#=d.statistic#
     and
     d.name='execute count'
     and 
     a.sid=b.sid 
     and
     b.username!='SYS'
     and
     b.type!='BACKGROUND'
   group by c.pn) wrk,
  ibm_nodes nod
where 
  ses.pn=wrk.pn
  and
  nod.pn=wrk.pn
order by 2,3
/
@sqlplusdefaults
