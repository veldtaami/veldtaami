set feedback off
set pagesize 1000
set linesize 200
col latch# form 999999
col level# form 999999
col name form a50
select * from (
select latch#,
       level#,
       name,
       decode(gets,0,0,round(misses/gets*10000)/100) "miss%",
       decode(immediate_gets,0,0,round(immediate_misses/immediate_gets*10000)/100) "imm miss%",
       decode(gets,0,0,round(spin_gets/gets*10000)/100) "spinget%",
       decode(gets,0,0,round(sleeps/gets*10000)/100) "sleep%",
       round(wait_time/1000000) "sec waited"
from	v$latch
where	gets > 0
order by wait_time desc ) where rownum <40
/
@sqlplusdefaults
