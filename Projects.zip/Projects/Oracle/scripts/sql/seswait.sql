set feedback off
set pagesize 1000
select
  a.event event,
  count(1) sessions
from 
  v$session_wait a
where
event not in (select event from stats$idle_event)  
group by a.event
order by sessions desc
/
@sqlplusdefaults
