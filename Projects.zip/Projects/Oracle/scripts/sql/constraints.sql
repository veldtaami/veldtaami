

set lines 200
col CONSTRAINT_NAME for a40
col R_CONSTRAINT_NAME for a40
select table_name, constraint_name from dba_constraints where r_constraint_name in ( 
select CONSTRAINT_NAME 
from dba_constraints 
where table_name in ('OWD_HO_TELL_HOST','OWD_HO_TELL_HOST_MOD','OWD_HO_TELL_HOST_UNI_LIMBRG','OWD_HO_TELL_HOST_VF','OWD_HO_TELL_HOST_PRMONT_CRT','OWD_HO_TELL_HOST_JOINT_DOCT'))