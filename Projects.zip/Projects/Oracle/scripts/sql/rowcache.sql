set feedback off
select
  round(bytes/1024/1024) "Size (MB)" from v$sgastat where pool='shared pool' and name='row cache'
/
SELECT (SUM(GETS-GETMISSES))/SUM(GETS) "Dictionary Cache Hit Ratio" FROM V$ROWCACHE
/
@sqlplusdefaults
