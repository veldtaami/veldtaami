col owner form a12
col object_name form a32
col last_ddl_time form a19
set verify off
set linesize 200
set pagesize 1000

SELECT owner, object_name, object_type
FROM   all_objects
WHERE  upper(owner) like upper('&owner') 
AND    object_type IN ('PACKAGE', 'PACKAGE BODY')
ORDER BY object_name, object_type;

@sqlplusdefaults
