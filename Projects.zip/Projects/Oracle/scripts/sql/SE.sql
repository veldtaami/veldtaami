--create table t( id number, seq number, msg varchar2(4000) );
--
--create sequence s;
--
--create or replace trigger failed_to_extend_temp
--  after servererror on database
--  declare
--      l_sql_text ora_name_list_t;
--      l_n        number;
--  begin
--      if ( is_servererror(942) )       #### ONLY 942  !!!
--      then
--          insert into t values ( s.nextval, 1, 'ora_sysevent = ' || ora_sysevent );
--          insert into t values ( s.currval, 2, 'ora_login_user = ' || ora_login_user );
--          insert into t values ( s.currval, 3, 'ora_server_error = ' || ora_server_error(1) );
--          l_n := ora_sql_txt( l_sql_text );
--          for i in 1 .. l_n
--          loop
--             insert into t values ( s.currval, 3+i, 'l_sql_text(' || i || ') = ' || l_sql_text(i) );
--          end loop;
--      end if;
--  end;
--  /
--  
  
  create table server_errors (
   error_time        timestamp,               
   username  varchar2(30), 
   error_message   varchar2(4000),
   sql_statement      varchar2(4000)
);

alter table server_errors modify error_message   varchar2(4000)
alter table server_errors modify sql_statement      varchar2(4000);
-- Catch All error
create or replace trigger catch_servererrors
    after servererror on database
 declare
    sql_text ora_name_list_t;
    message varchar2(4000) := null;
    statement varchar2(4000) := null;
 begin
   for depth in 1 .. ora_server_error_depth loop
     message:= message|| ora_server_error_msg(depth);
   end loop;

   for i in 1 .. ora_sql_txt(sql_text) loop
      statement := statement || sql_text(i);
   end loop;

   insert into server_errors (error_time,username,error_message,sql_statement) values (sysdate, ora_login_user,message,statement);
 end;
/

-- select * from sys.server_error order by  2 desc; 


Internal Exception: java.sql.SQLException: ORA-13831: Opgegeven SQL-profielnaam of -patchnaam is ongeldig. 

create table t_13831( id number, seq number, msg varchar2(4000) );

create sequence s_13831;

create or replace trigger catch_13831
  after servererror on database
  declare
      l_sql_text ora_name_list_t;
      l_n        number;
  begin
      if ( is_servererror(13831) ) 
      then
          insert into t_13831 values ( s_13831.nextval, 1, 'ora_sysevent = ' || ora_sysevent );
          insert into t_13831 values ( s_13831.currval, 2, 'ora_login_user = ' || ora_login_user );
          insert into t_13831 values ( s_13831.currval, 3, 'ora_server_error = ' || ora_server_error(1) );
          l_n := ora_sql_txt( l_sql_text );
          for i in 1 .. l_n
          loop
             insert into t_13831 values ( s_13831.currval, 3+i, 'l_sql_text(' || i || ') = ' || l_sql_text(i) );
          end loop;
      end if;
  end;
  /
  
  
  
  
  
  
  
  
CREATE TABLE servererror_log (
    error_datetime  TIMESTAMP,
    error_user      VARCHAR2(30),
    db_name         VARCHAR2(9),
        l_server_error  number,
    error_stack     VARCHAR2(2000),
    captured_sql    VARCHAR2(1000))
/


CREATE OR REPLACE TRIGGER log_server_errors
AFTER SERVERERROR
ON DATABASE
DECLARE
sql_text ora_name_list_t;
stmt clob;
n number;
l_server_error number;
BEGIN
  n := ora_sql_txt(sql_text);
  if n > 1000 then n:= 1000; end if ;
  FOR i IN 1..n LOOP
    stmt := stmt || sql_text(i);
  END LOOP;

  l_server_error := server_error(1);

  INSERT INTO servererror_log
  (error_datetime, error_user, db_name,l_server_error,
   error_stack, captured_sql)
  VALUES
  (systimestamp, sys.login_user, sys.database_name,l_server_error,
  dbms_utility.format_error_stack, stmt);
  commit;
END log_server_errors;
/


  