alter session set nls_date_format='YYYY-MM-DD HH24:MI:SS';
select begin_time, end_time, undoblks, nospaceerrcnt from v$undostat order by begin_time;
