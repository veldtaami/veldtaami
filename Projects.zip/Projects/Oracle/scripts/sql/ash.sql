accept sid char prompt 'session id: '

col sample_time form a26
col object form a24
col event form a36
set linesize 200
set verify off
set pagesize 1000
select 
  a.SAMPLE_TIME, 
  b.hash_value, 
  a.SQL_PLAN_HASH_VALUE plan_hash, 
  c.object_type||' '||c.object_name object,
  a.EVENT,
  a.TIME_WAITED 
from 
  v$active_session_history a,
  v$sqlarea b,
  dba_objects c
where 
  a.session_id='&&sid' 
  and
  a.sql_id=b.sql_id
  and
  c.object_id=a.current_obj#
order by sample_time
/
@sqlplusdefaults
