@defaults

select table_name, owner, last_analyzed, NUM_ROWS ,blocks,  blocks*8192/1024/1024/1024 Gb, 
degree, chain_cnt, tablespace_name as chained_blocks  
from dba_Tables where owner = upper('&schema_naam')
order by 5,6 ;





select table_name, owner, last_analyzed, NUM_ROWS ,blocks,  blocks*8192/1024/1024/1024 Gb, 
degree, chain_cnt, tablespace_name as chained_blocks  
from dba_Tables where tablespace_name = upper('&tablespace_naam')
order by 5,6 ;
