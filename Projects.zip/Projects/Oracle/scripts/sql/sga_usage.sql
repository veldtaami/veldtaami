
show sga

show parameter sga_max_size


select sum(bytes)/1024/1024 " SGA size used in MB" from v$sgastat where name!='free memory';

SELECT sga_size, sga_size_factor, estd_db_time_factor
FROM v$sga_target_advice
ORDER BY sga_size ASC;