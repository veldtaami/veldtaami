SET LINESIZE 500 VERIFY OFF
col ORIGINAL_NAME for a40
col object_name for a40

SELECT owner,
       original_name,
       object_name,
       operation,
       type,
       space AS space_blks,
       ROUND((space*8)/1024,2) space_mb
FROM   dba_recyclebin
ORDER BY 1, 2;

SET VERIFY ON

echo "PURGE RECYCLEBIN;"
echo "PURGE DBA_RECYCLEBIN;" 