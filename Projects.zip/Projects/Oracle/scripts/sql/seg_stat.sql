set verify off
set pagesize 10000
set feedback off
col segment form a44
set linesize 120
accept keuze prompt '1=logical reads, 2=physical reads, 3=physical writes, 4=row lock waits, 5=ITL waits : '
select
*
from
(select
  a.owner||'.'||a.object_name segment,
  a.object_type,
  a.value value
from
  v$segment_statistics a
where
  a.statistic_name=decode( &keuze, 1, 'logical reads', 2, 'physical reads', 3, 'physical writes', 4, 'row lock waits', 5, 'ITL waits' )
  and value>0
order by a.value desc) where rownum<=20
/

@sqlplusdefaults
