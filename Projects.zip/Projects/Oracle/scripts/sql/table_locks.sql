set lines 200
set pages 99
col object_name for a40
col object_type for a30

prompt   "TABLE LOCKS"
select d.object_name, d.object_type, d.object_id , v.SESSION_ID, s.SERIAL# , s.USERNAME
from gv$locked_object v, dba_objects d, gv$session s
where v.object_id = d.object_id 
and v.SESSION_ID=s.sid;

-- select d.object_name, d.object_id 
-- from gv$locked_object v, dba_objects d
-- where v.object_id = d.object_id 
-- and d.object_type='TABLE';



select 'alter system kill session ''' || sid || ',' || serial# || ',@'||  s.inst_id || ''';' 
from gv$locked_object v, dba_objects d, gv$session s
where v.object_id = d.object_id
and v.SESSION_ID=s.sid;