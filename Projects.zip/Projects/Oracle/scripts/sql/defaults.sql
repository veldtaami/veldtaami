set in de sqlplus_home/sqlplus/admin/glogin.ora 
set sqlprompt "_connect_identifier > "
set sqlprompt "_user '@'_connect_identifier > "

set lines 200
set pages 100
set feedback on
set serveroutput on 

col AUTOEXTENSIBLE  for a5
col FILE_NAME       for a60
col owner       	for a30
col OBJECT_NAME 	for a30
col object_type 	for a30
col tablespace_name for a40
col DEFAULT_TABLESPACE for a50
col table_name 		for a40

col trigger_name	for a32
col trigger_type	for a20 
col username 		for a30