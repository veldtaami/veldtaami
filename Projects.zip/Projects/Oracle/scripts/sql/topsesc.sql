set verify off
set linesize 220
set feedback off
col username form a14
col program form a32
set pagesize 0
select decode( &1, 1, 'CPU used by this session', 2 , 'session logical reads', 3, 'physical reads', 4, 'physical writes', 5, 'redo size', 6, 'execute count' ) from dual;
set pagesize 10000
select * from 
(select
  a.sid,
  a.username,
  substr(a.program,1,20) program,
  round(100*b.value/((sysdate-a.logon_time)*24*60*60))/100 rate,
  a.sql_hash_value,
  d.xevent
from
  v$session a,
  v$sesstat b,
  v$statname c,
  (select
     a.event event,
     decode( b.event,  null, '> '||a.event, 'Idle - '||b.event) xevent
   from v$system_event a, stats$idle_event b 
   where  
     a.event=b.event (+)) d
where
  a.sid=b.sid
  and
  b.statistic#=c.statistic#
  and
  a.event=d.event
  and
  b.value!=0
  and
  sysdate-a.logon_time>0
  and
  c.name = decode( &1, 1, 'CPU used by this session', 2 , 'session logical reads', 3, 'physical reads', 4, 'physical writes', 5, 'redo size', 6, 'execute count' )  
order by rate desc  
) where rownum<=22
/
  
