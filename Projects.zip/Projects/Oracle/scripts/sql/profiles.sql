set lines 200
set pages 99
col limit for a30
 col profile for a30

select * from dba_profiles order by 1,2;