set linesize 200
set pagesize 40
col object_name form a30
col executions form 9999999999999999
select
  b.hash_value,
  parsing_schema_name,
  a.object_name,
  b.executions,
  b.buffer_gets,
  b.disk_reads,
  b.elapsed_time/1000000 elapsed,
  round((b.elapsed_time/executions)/1000000) avg_rsp_time
from
  (select distinct a.sql_id, a.object_name from v$sql_plan a where a.operation='TABLE ACCESS' and a.options='FULL'  ) a,
  v$sql b
where
  a.sql_id = b.sql_id
  and 
  b.executions>0
  and parsing_schema_name!='SYS'
order by 6
/
@sqlplusdefaults
