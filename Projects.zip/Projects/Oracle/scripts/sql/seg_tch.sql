set verify off
set linesize 100
set pagesize 30
set verify off
accept obj prompt 'owner.segment: '
accept bucket prompt 'bucket size: '
select
  round(x.tch/&bucket)*&bucket tch_lo,
  round(x.tch/&bucket+1)*&bucket tch_hi,
  count(*) cnt
from
  dba_objects o,
  x$bh x
where
  x.obj=o.data_object_id
  and
  upper(o.owner)||'.'||upper(o.object_name)=upper('&obj')
group by round(x.tch/&bucket)*&bucket, round(x.tch/&bucket+1)*&bucket
order by 1
/
