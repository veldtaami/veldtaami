 col grantee for a40
 col granted_role for a40
 set lines 200
 
 select GRANTEE , granted_role  from dba_role_privs where GRANTED_ROLE = 'DBA' and grantee not in ('SYS','SYSTEM');
 
 select 'revoke dba from ' || GRANTEE  || ';' from dba_role_privs where GRANTED_ROLE = 'DBA' and grantee not in ('SYS','SYSTEM', 'TBTDBA', 'TBT_TOOLS');