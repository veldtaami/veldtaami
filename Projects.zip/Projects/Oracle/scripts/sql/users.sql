@defaults
set lines 200
col username for a40
col profile for a30
select username , account_status , profile , default_tablespace, temporary_tablespace from dba_users order by 1;
