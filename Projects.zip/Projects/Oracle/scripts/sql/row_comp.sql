col table_name for a30
col "'SELECTCOUNT(1)'||TABLE_NAME||'FROM'||OWNER||'.'||TABLE_NAME||';'"  for a130
set lines 180
select table_name , num_rows, 'select count(1) '|| table_name || ' from ' || owner || '.' || table_name || ';' from dba_tables where owner = upper('&OWNER') and table_name like upper('%&deel_tabel_naam%');