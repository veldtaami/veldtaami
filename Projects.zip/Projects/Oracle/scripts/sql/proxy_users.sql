set lines 150
col PROXY for a30
col CLIENT for a40
select PROXY, CLIENT from proxy_users;

select 'alter user ' || client || ' grant connect through '|| PROXY from proxy_users;




--alter user owner_S12 grant connect through rabo_user;
--
--connect veldtaami[owner_s12]/"Coraisia_05>"@srv0gsib101
--
--show user
--
--