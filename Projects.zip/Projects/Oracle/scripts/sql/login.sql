set termout off
define sql_prompt='idle'
column id new_value sql_prompt
select lower(user)||'@'||lower(global_name) id from global_name;
set sqlprompt '&sql_prompt> '
set termout on
