col owner form a12
col object_name form a32
col last_ddl_time form a19
set verify off
set linesize 200
set pagesize 1000
select owner, object_type, object_name, status, to_char(last_ddl_time,'YYYY-MM-DD HH24:MI:SS') last_ddl_time from dba_objects 
where upper(object_name) like upper('%&1%')
order by owner, object_type, object_name;
@sqlplusdefaults
