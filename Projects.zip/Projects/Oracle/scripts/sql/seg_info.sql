set linesize 120
set verify off
set feedback off
col statistic_name form a30
accept segname prompt 'owner.segment: '
select
  owner,
  tablespace_name,
  extents,
  blocks,
  round(bytes/1024/1024) "Size (MB)"
from
dba_segments
where
upper(owner)||'.'||upper(segment_name)=upper('&segname')
/
set pagesize 0
prompt
select STATISTIC_NAME, VALUE from v$segment_statistics where upper(owner)||'.'||upper(OBJECT_NAME)=upper('&segname')
/
@sqlplusdefaults

