set serveroutput on
Declare
cursor REF_INDEXES IS
Select table_owner, INDEX_NAME
From dba_INDEXES
Where TABLE_OWNER = 'OWNER_SM1' and index_name not like 'SYS_%' and table_name = 'PROBSUMMARYM1'
Order By INDEX_NAME;
ind_query varchar2(200);

Begin
DBMS_OUTPUT.PUT_LINE('Reindex Tables: ');
For IDX In REF_INDEXES
Loop
Begin
ind_query := 'Alter Index  ' || IDX.table_owner || '.' || IDX.INDEX_NAME || ' Rebuild online parallel 4 ';
dbms_output.put_line (ind_query);
--EXECUTE IMMEDIATE ind_query ;
ind_query := 'Alter Index  ' || IDX.table_owner || '.' || IDX.INDEX_NAME || ' noparallel  ';
--EXECUTE IMMEDIATE ind_query ;
dbms_output.put_line (ind_query);
EXCEPTION
When OTHERS Then
         CONTINUE;
End;
End Loop;
--COMMIT;
End;
/



--set serveroutput on
--Declare
--cursor REF_INDEXES IS
--Select table_owner, INDEX_NAME
--From dba_INDEXES
--Where TABLE_OWNER = 'OWNER_SM1' and index_name not like 'SYS_%'
--Order By INDEX_NAME;
--ind_query varchar2(200);
--
--Begin
--DBMS_OUTPUT.PUT_LINE('Reindex Tables: ');
--For IDX In REF_INDEXES
--Loop
--Begin
----ind_query := 'Alter Index  ' || IDX.table_owner || '.' || IDX.INDEX_NAME || ' Rebuild online parallel 4 ';
----dbms_output.put_line (ind_query);
----EXECUTE IMMEDIATE ind_query ;
--ind_query := 'Alter Index  ' || IDX.table_owner || '.' || IDX.INDEX_NAME || ' noparallel  ';
----EXECUTE IMMEDIATE ind_query ;
--dbms_output.put_line (ind_query);
--EXCEPTION
--When OTHERS Then
--         CONTINUE;
--End;
--End Loop;
----COMMIT;
--End;
--/