. oraenv
RKG1P1

select * from dba_hist_wr_control;

exec dbms_workload_repository.create_snapshot;

-- 15 dagen: 21600
exec dbms_workload_repository.modify_snapshot_settings(retention => 21600)

PL/SQL procedure successfully completed.

select * from dba_hist_wr_control;





for i in CSC1P1 CSC1V1 BKR1P1 BKR1V1 RKG1V1 RKG1P1
#for i in CSC1P2 CSC1V2 BKR1P2 BKR1V2 RKG1V2 RKG1P2

for i in BCM1P1 BCM1R1 BCM1S1 BCM2S1 BBR1P1 BBR1S1 VDE1P1 VDE1S1 BBR1S1 BBR1P1
for i in BCM1P2 BCM1R2 BCM1S2 BCM2S2 BBR1P2 BBR1S2 VDE1P2  VDE1S2 BBR1S2 BBR1P2
for i in BCM1P3 BCM1S3 BCM2S3
do
ORACLE_SID=$i
ORAENV_ASK=NO
. oraenv > /dev/null 2>&1
sqlplus / as sysdba  <<EOF
 exec dbms_workload_repository.modify_snapshot_settings(retention => 21600)
EOF
done



for i in BCM1P1 BCM1R1 BCM1S1 BCM2S1 BBR1P1 BBR1S1 VDE1P1 VDE1S1 BBR1S1 BBR1P1

for i in BCM1P2 BCM1R2 BCM1S2 BCM2S2 BBR1P2 BBR1S2 VDE1P2  VDE1S2 BBR1S2 BBR1P2

for i in BCM1P3 BCM1S3 BCM2S3

