select sum(bytes)/1024/1024/1024 Gb_totaal_datafiles from dba_data_files;
select sum(bytes)/1024/1024/1024 Gb_totaal_segments from dba_segments;

select tablespace_name, sum(bytes)/1024/1024 mb_totaal ,sum(MAXBYTES)/1024/1024 max from dba_data_files
group by tablespace_name
order by tablespace_name;


select tablespace_name, sum(bytes)/1024/1024 mb_totaal_segmenten from dba_segments 
group by tablespace_name
order by tablespace_name;
