col table_name for a40
col constraint_name for a40
set lines 200
set pages 200

select owner, TABLE_NAME , CONSTRAINT_NAME , status , constraint_type
from dba_constraints where owner = 'ONP' and constraint_type = 'R'


select 'alter table onp.' || table_name || ' disable constraint '|| constraint_name || ';'
from dba_constraints where owner = 'ONP' and constraint_type = 'R'


select 'truncate table onp.' || table_name || ';'  from dba_Tables where owner = 'ONP';


select 'alter table onp.' || table_name || ' enable constraint '|| constraint_name || ';'
from dba_constraints where owner = 'ONP' and constraint_type = 'R'
