CREATE DATABASE LINK anwar_ff 
   CONNECT TO system IDENTIFIED BY dba00sarr00
   USING 'avh1s';
