set heading off
set linesize 200
@?/rdbms/admin/utlxplp
@sqlplusdefaults
