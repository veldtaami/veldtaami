-- FILE sqltxt.sql
-- PURPOSE shows the SQL statement for the prompted hash value, in a format suited for an explain plan
accept hash prompt 'sql hash value: '
SET SERVEROUTPUT ON FORMAT WORD_WRAPPED
SET LINESIZE 220
set pagesize 0
set feedback off
set verify off
declare
  s varchar2(32767);
  cursor c_sql is select sql_text from v$sqltext where hash_value=&hash order by piece;
  line number;
begin
  dbms_output.enable(20000);
  s:='';
  for r_sql in c_sql loop
    s := s || r_sql.sql_text;
  end loop;
  s := replace( s, ',', ', ' );  
  while instr( s, '  ' ) > 0 loop
    s := replace( s, '  ', ' ' );
  end loop;
  line:=1;
  for i in 1 .. length(s) loop
    line:=line+1;
    dbms_output.put(substr(s,i,1));
    if ( substr(s,i,1) = ' ' and mod(line,80) > 62 ) then
      dbms_output.new_line;
      line:=1;
    end if;
  end loop;
  dbms_output.new_line;
end;
/
@sqlplusdefaults
