
-- EXECUTE DBMS_STATS.GATHER_SCHEMA_STATS(ownname => 'BER', estimate_percent => 5);

--exec dbms_stats.gather_schema_stats(ownname => 'BER', options => 'GATHER AUTO', estimate_percent => dbms_stats.auto_sample_size, method_opt => 'for all columns size repeat', degree => 16 )
--/

exec dbms_stats.gather_schema_stats(ownname => 'BER', estimate_percent => 5 , method_opt => 'for all columns size repeat', degree => 16 )
/