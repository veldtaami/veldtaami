declare
  cur sys_refcursor;
  task_name varchar2(30);
  sqlset_name varchar2(30);
  l_minsnap number;
  l_maxsnap number;
BEGIN
  task_name := 'sql_tuning';
  sqlset_name := 'db workload';

  --drop task if it exists
  begin
    dbms_sqltune.drop_tuning_task( task_name => task_name );
  exception
    when others then
      null;
  end;

  -- drop sqlset if it exists
  begin
    dbms_sqltune.drop_sqlset( sqlset_name => sqlset_name );
  exception
    when others then
      null;
  end;

  -- create empty sqlset
  dbms_sqltune.create_sqlset( sqlset_name => sqlset_name, description => sqlset_name );

  -- load SQL from sqlarea / 99% of buffergets
  open cur for
    select value(p)
    from table(dbms_sqltune.select_cursor_cache('parsing_schema_name<>''SYS'' and parsing_schema_name<>''NOMAD'' and parsing_schema_name<>''SYSMONITOR''', NULL, 'BUFFER_GETS', NULL, NULL, .99 )) p;
  dbms_sqltune.load_sqlset(  sqlset_name => sqlset_name, populate_cursor => cur );
  close cur;
  -- load SQL from sqlarea / 99% of disk reads
  open cur for
    select value(p)
    from table(dbms_sqltune.select_cursor_cache('parsing_schema_name<>''SYS'' and parsing_schema_name<>''NOMAD'' and parsing_schema_name<>''SYSMONITOR''', NULL, 'DISK_READS', NULL, NULL, .99 )) p;
  dbms_sqltune.load_sqlset(  sqlset_name => sqlset_name, populate_cursor => cur, load_option=>'MERGE' );
  close cur;
  -- load SQL from sqlarea / 99% of cpu
  open cur for
    select value(p)
    from table(dbms_sqltune.select_cursor_cache('parsing_schema_name<>''SYS'' and parsing_schema_name<>''NOMAD'' and parsing_schema_name<>''SYSMONITOR''', NULL, 'CPU_TIME', NULL, NULL, .99 )) p;
  dbms_sqltune.load_sqlset(  sqlset_name => sqlset_name, populate_cursor => cur, load_option=>'MERGE' );
  close cur;
  
  -- selet min and max snapshots from AWR
  select min(snap_id), max(snap_id) into l_minsnap, l_maxsnap from dba_hist_snapshot;
  -- load SQL from AWR
  open cur for
    select value(p)
    from table(dbms_sqltune.select_workload_repository(l_minsnap,l_maxsnap,'parsing_schema_name<>''SYS'' and parsing_schema_name<>''NOMAD'' and parsing_schema_name<>''SYSMONITOR''', NULL, 'BUFFER_GETS', NULL, NULL, .99 )) p;
    dbms_sqltune.load_sqlset(  sqlset_name => sqlset_name, populate_cursor => cur, load_option=>'MERGE' );
    close cur;
  -- load SQL from AWR
  open cur for
    select value(p)
    from table(dbms_sqltune.select_workload_repository(l_minsnap,l_maxsnap,'parsing_schema_name<>''SYS'' and parsing_schema_name<>''NOMAD'' and parsing_schema_name<>''SYSMONITOR''', NULL, 'DISK_READS', NULL, NULL, .99 )) p;
    dbms_sqltune.load_sqlset(  sqlset_name => sqlset_name, populate_cursor => cur, load_option=>'MERGE' );
    close cur;
  -- load SQL from AWR
  open cur for
    select value(p)
    from table(dbms_sqltune.select_workload_repository(l_minsnap,l_maxsnap,'parsing_schema_name<>''SYS'' and parsing_schema_name<>''NOMAD'' and parsing_schema_name<>''SYSMONITOR''', NULL, 'CPU_TIME', NULL, NULL, .99 )) p;
    dbms_sqltune.load_sqlset(  sqlset_name => sqlset_name, populate_cursor => cur, load_option=>'MERGE' );
    close cur;

  -- create the tuning task from the sqlset
  task_name := dbms_sqltune.create_tuning_task(
    task_name => task_name,
    sqlset_name => sqlset_name,
    time_limit => null );

  -- run it
  dbms_sqltune.execute_tuning_task( task_name => task_name );

END;
/
SET LONG 10000000
SET LONGCHUNKSIZE 10000000
SET LINESIZE 200
SET PAGESIZE 0
SET TRIMSPOOL ON
spool sql_tune_advice.delete_me
select dbms_sqltune.report_tuning_task( 'sql_tuning') from dual;
exec dbms_sqltune.drop_tuning_task( task_name => 'sql_tuning' );
spool off
@sqlplusdefaults

