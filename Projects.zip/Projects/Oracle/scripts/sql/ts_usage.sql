set feedback off
set pagesize 1000
col "%USE" form 999
col tablespace_name form a22
col pct form a10
set linesize 100
select name from v$database;

select
  al.tablespace_name,
  round((nvl(used.bytes,0)+nvl(free.bytes,0))/(1024*1024)) sizemb,
  round(nvl(free.bytes,0)/(1024*1024)) freemb,
  round(nvl(used.bytes,0)/(1024*1024)) usedmb,
  round(nvl(used.bytes,0)/(nvl(used.bytes,0)+nvl(free.bytes,0))*100) "%USE",
  decode( round(nvl(used.bytes,0)/(nvl(used.bytes,0)+nvl(free.bytes,0))*10), 0, '----------', 1, '#---------', 2, '##--------', 3, '###-------', 4 , '####------', 5, '#####-----', 6, '######----', 7, '#######---', 8, '########--', 9, '#########-', 10, '##########', 'duh!' ) pct,
  round(auto.bytes/1204/1204) auto,
  decode( round(nvl(used.bytes,0)/(nvl(used.bytes,0)+nvl(auto.bytes,0)+nvl(free.bytes,0))*10), 0, '----------', 1, '#---------', 2, '##--------', 3, '###-------', 4 , '####------', 5, '#####-----', 6, '######----', 7, '#######---', 8, '########--', 9, '#########-', 10, '##########', 'duh!' ) "%AUTO"
from
  dba_tablespaces al,
  (select tablespace_name, sum(bytes) bytes from dba_segments group by tablespace_name) used,
  (select tablespace_name, sum(bytes) bytes from dba_free_space group by tablespace_name) free,
  (select tablespace_name, sum(decode(maxbytes,0,0,maxbytes-bytes)) bytes from dba_data_files group by tablespace_name) auto
where
  al.tablespace_name=free.tablespace_name(+)
  and
  al.tablespace_name=used.tablespace_name(+)
  and
  al.tablespace_name=auto.tablespace_name(+)
  and 
  al.contents!='TEMPORARY'
order by round(nvl(used.bytes,0)/(nvl(used.bytes,0)+nvl(free.bytes,0))*100) desc
/
@sqlplusdefaults
