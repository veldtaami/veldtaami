set serveroutput on
set long 99999

Declare
  f UTL_FILE.FILE_TYPE;
  s VARCHAR2(200);
begin
  f:= UTL_FILE.FOPEN('TEST_DATA_DIR', 'ttl_BER.log', 'R');
  loop
  UTL_FILE.GET_LINE(f,s);
  dbms_output.put_line(s);
  end loop;
  EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      UTL_FILE.FCLOSE (f);
end;
/

ttl_BER.log  ttl_BES.log  ttl_DOCSADM.log  ttl_OWD.log  ttl_OWI.log  ttl_OWT.log  ttl_PNC.log  ttl_REL.log
e

