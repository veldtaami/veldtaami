
-- select oracle_username, OBJECT_NAME , OS_USER_NAME from v$locked_object v, dba_objects d
--  where v.OBJECT_ID=d.object_id
--   and object_name like '%AVH%';
-- 
accept kill_user prompt "Enter username to KILL: "

select username,  sid, serial#, inst_id  from gv$session where username=upper('&&kill_user'); 
select 'alter system kill session ''' || sid || ',' || serial# || ',@'||  inst_id || ''';' from gv$session where username=upper('&&kill_user'); 