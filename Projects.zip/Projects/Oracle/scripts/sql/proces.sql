set lines 200
set pages 99
select  PID ,  USERNAME , PROGRAM , pname from v$process 
order by 2, 1 ;
