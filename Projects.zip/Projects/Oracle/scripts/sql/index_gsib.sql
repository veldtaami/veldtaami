RABO_USER @ srv0gsib101 > EXECUTE DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'PRETTY',false);

PL/SQL procedure successfully completed.

RABO_USER @ srv0gsib101 > execute DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'SQLTERMINATOR',true);

PL/SQL procedure successfully completed.

RABO_USER @ srv0gsib101 > exec DBMS_METADATA.SET_TRANSFORM_PARAM (DBMS_METADATA.SESSION_TRANSFORM, 'STORAGE',false);

PL/SQL procedure successfully completed.

RABO_USER @ srv0gsib101 > exec DBMS_METADATA.SET_TRANSFORM_PARAM (DBMS_METADATA.SESSION_TRANSFORM, 'SEGMENT_ATTRIBUTES',false);

PL/SQL procedure successfully completed.

RABO_USER @ srv0gsib101 > 
RABO_USER @ srv0gsib101 > 
RABO_USER @ srv0gsib101 > 
RABO_USER @ srv0gsib101 >  Set long 9999
RABO_USER @ srv0gsib101 >  set lines 200
RABO_USER @ srv0gsib101 >  set pages 99
RABO_USER @ srv0gsib101 > 
RABO_USER @ srv0gsib101 >  col  query  for a180
RABO_USER @ srv0gsib101 >  select dbms_metadata.get_ddl('INDEX', index_name , 'OWNER_SMR' ) as query
  2    from dba_indexes   where owner = 'OWNER_SM1' and
  3    table_name in ('CM3RM1','CM3RA1','CM3RA2','CM3RA3','CM3RA4','CM3RA5','CM3RA6','CM3RA7',
  4  'INCIDENTSM1','INCIDENTSA1','INCIDENTSA2','REQUESTA1','CM3TM1',
  5  'CM3TA1','CM3TA2','CM3TA3','CONTCTSM1','CONTCTSA1') and index_name not like 'SYS%';

QUERY                                                                                                                                                                                                   
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------                    
                                                                                                                                                                                                        
  CREATE UNIQUE INDEX "OWNER_SMR"."INCIDENTSA18173A73D_FBI" ON "OWNER_SMR"."INCIDENTSA1" (NLSSORT("INCIDENT_ID",'nls_sort=''BINARY_CI'''), "RECORD_NUMBER") ;                                           
                                                                                                                                                                                                        
                                                                                                                                                                                                        
  CREATE INDEX "OWNER_SMR"."MVLTST5_FBI" ON "OWNER_SMR"."INCIDENTSA1" (NLSSORT("ASSIGNMENT",'nls_sort=''BINARY_CI'''), NLSSORT("INCIDENT_ID",'nls_sort=''BINARY_CI''')) ;                               
                                                                                                                                                                                                        
                                                                                                                                                                                                        
  CREATE INDEX "OWNER_SMR"."MVLTST8_FBI" ON "OWNER_SMR"."CM3RM1" (NLSSORT("NUMBER",'nls_sort=''BINARY_CI'''), NLSSORT("ASSIGN_DEPT",'nls_sort=''BINARY_CI'''), NLSSORT("REQUESTED_BY                    
",'nls_sort=''BINARY_CI'''), NLSSORT("OPEN",'nls_sort=''BINARY_CI''')) ;                                                                                                                                
                                                                                                                                                                                                        
ERROR:
ORA-31603: object "INCIDENTSM1_FAT_IDX_FBI" of type INDEX not found in schema "OWNER_SMR" 
ORA-06512: at "SYS.DBMS_METADATA", line 6478 
ORA-06512: at "SYS.DBMS_SYS_ERROR", line 105 
ORA-06512: at "SYS.DBMS_METADATA", line 6465 
ORA-06512: at "SYS.DBMS_METADATA", line 9202 
ORA-06512: at line 1 



3 rows selected.

RABO_USER @ srv0gsib101 > spool off
