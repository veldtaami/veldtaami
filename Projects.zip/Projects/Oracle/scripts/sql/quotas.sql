set pages 50
set lines 200
col USERNAME         for a15
col TABLESPACE_NAME  for a30
col BYTES            for 999999999999
col MAX_BYTES        for 999999999999
select USERNAME, TABLESPACE_NAME , BYTES , MAX_BYTES 
from dba_ts_quotas
order by 1;


