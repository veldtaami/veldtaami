set lines 200
set pages 99
col SNAP_ID      for a20                
col SAMPLE_TIME  for a30               
col SQL_ID       for a30               
col PROGRAM      for a70               
col username format a20
col machine format a50

select  username, machine, program , INST_ID from gv$session where username not in ('SYS') order by 1;

select username, count(username) from gv$session where username not in ('SYS') group by username order by 1;

select machine, count(machine) from gv$session where username not in ('SYS') group by machine order by 1;

select inst_id, count(inst_id) from gv$session where username not in ('SYS') group by inst_id order by 1;


--prompt "from DBA_HIST_ACTIVE_SESS_HISTORY !!! "
--select 
-- SNAP_ID                     
--, SAMPLE_TIME                 
--, SQL_ID                      
-- user_id, PROGRAM    
--, machine                 
--, count(MACHINE)
-- from DBA_HIST_ACTIVE_SESS_HISTORY where sample_time > sysdate-(1/24) and user_id <> 0
-- group by machine, program , user_id
-- order by machine;

 
--  
-- select 
--  SNAP_ID                     
-- , SAMPLE_TIME                 
-- , SESSION_ID                  
-- , SESSION_SERIAL#             
-- , SQL_ID                      
-- , PROGRAM                     
-- , MODULE                      
-- , ACTION                      
-- , CLIENT_ID                   
-- , MACHINE                     
-- , PORT                        
-- , DELTA_TIME                  
-- , PGA_ALLOCATED               
-- , TEMP_SPACE_ALLOCATED        
--  from DBA_HIST_ACTIVE_SESS_HISTORY
-- order by  snap_id;
-- 
-- 
-- 
-- 
-- select 
--  SNAP_ID                     
-- , SAMPLE_TIME                 
-- , SQL_ID                      
-- , PROGRAM                     
-- , ACTION                      
-- , CLIENT_ID                   
-- , MACHINE                     
-- , PORT                        
-- , DELTA_TIME                  
--  from DBA_HIST_ACTIVE_SESS_HISTORY where sample_time > sysdate-(1/24);
-- order by  snap_id;
-- 


 
