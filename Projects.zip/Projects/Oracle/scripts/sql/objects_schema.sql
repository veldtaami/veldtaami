@defaults.sql

select owner, object_type , object_name from dba_objects where owner = upper('&schema_naam')
order by 1,2,3;

