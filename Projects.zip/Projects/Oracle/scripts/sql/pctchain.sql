select
  round(cont.value/(fts.value+indx.value)*10000)/100 pct_chained
from
  (select value from v$sysstat where name like '%table scan rows gotten%') fts,
  (select value from v$sysstat where name like '%table fetch by rowid%') indx,
  (select value from v$sysstat where name like '%table fetch continued row%') cont
/
