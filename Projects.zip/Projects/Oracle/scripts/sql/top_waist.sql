set lines 200
set pages 99
col table_name for a30

select * from (
SELECT TABLE_NAME,
         ROUND((BLOCKS * 8 /1024 ),2) "SIZE (MB)",
         ROUND((NUM_ROWS * AVG_ROW_LEN / 1024 /1024 ), 2) "ACTUAL DATA (MB)",
         (ROUND((BLOCKS * 8 /1024 ),2) - ROUND((NUM_ROWS * AVG_ROW_LEN / 1024 / 1024 ), 2)) "WASTED (MB)"
    FROM DBA_TABLES
   WHERE (ROUND((BLOCKS * 8 / 1024 ),2) > ROUND((NUM_ROWS * AVG_ROW_LEN / 1024 / 1024 ), 2))  
       ORDER BY 4 DESC ) 
where rownum < 10;
