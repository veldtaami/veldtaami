set linesize 120
col name form a40
col rio form 9999999
col wio form 9999999
col bprio form 999.9
col bpwio form 999.9
col ariot form 999.9
col awiot form 999.9
set pagesize 1000
select
  b.name,
  a.phyblkrd BRIO,                         -- blocks read
  a.phyblkwrt BWIO,                        -- blocks written
  round(10*a.phyblkrd/a.phyrds)/10 BPRIO,  -- blocks per read IO
  round(10*a.phyblkwrt/a.phywrts)/10 BPWIO,-- blocks per write IO
  round(100*a.readtim/a.phyrds)/10 ARIOT,   -- average read time per block
  round(100*a.writetim/a.phywrts)/10 AWIOT  -- average write time per block
from
  v$filestat a,
  v$datafile b
where
  a.file#=b.file#
  and
  a.phywrts>0 and a.phyrds>0
order by
  b.name
/
@sqlplusdefaults
