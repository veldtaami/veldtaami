set linesize 120
set pagesize 30
col segment form a44
select * from (
select
  owner||'.'||segment_name segment,
  segment_type,
  tablespace_name,
  blocks,
  round(bytes/1024/1024) "Size (MB)"
from
  dba_segments
order by bytes desc
) where rownum<41
/
@sqlplusdefaults
