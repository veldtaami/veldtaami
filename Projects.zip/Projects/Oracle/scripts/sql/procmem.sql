set linesize 200
set pagesize 1000
select
  p.spid,
  s.sid,
  s.username,
  substr(s.program,1,20) program,
  round(p.pga_alloc_mem/(1024)) allockb,
  round(p.pga_used_mem/(1024)) usedkb
from
v$process p,
v$session s
where
p.addr=s.paddr
order by allockb desc
/
