set lines 200
set pages 0
set feedback off
set verify off
accept deet prompt 'date: (yyyy-mm-dd): '
prompt #oracle IO wait event timings
prompt #columns: date time lgfs_totwps lgfs_avgw dbfpw_totwps dbfpw_avgw dbfsqr_totwps dbfsqr_avgw dbfscr_totwps dbfscr_avgw
select
  to_char(snap.begin_interval_time,'YYYY-MM-DD HH24:MI:SS')||' '||
--  round((cast(snap.end_interval_time as date)-cast(snap.begin_interval_time as date))*24*60*60)||' '||
  round(nvl(lgfs.totw,0)/(cast(snap.end_interval_time as date)-cast(snap.begin_interval_time as date))/24/60/6)/10||' '||
  round(nvl(lgfs.avgw,0)*10)/10||' '||
  round(nvl(dbfpw.totw,0)/(cast(snap.end_interval_time as date)-cast(snap.begin_interval_time as date))/24/60/6)/10||' '||
  round(nvl(dbfpw.avgw,0)*10)/10||' '||
  round(nvl(dbfsqr.totw,0)/(cast(snap.end_interval_time as date)-cast(snap.begin_interval_time as date))/24/60/6)/10||' '||
  round(nvl(dbfsqr.avgw,0)*10)/10||' '||
  round(nvl(dbfscr.totw,0)/(cast(snap.end_interval_time as date)-cast(snap.begin_interval_time as date))/24/60/6)/10||' '||
  round(nvl(dbfscr.avgw,0)*10)/10
from
  (select  a.snap_id, (a.total_waits-b.total_waits) totw, (a.time_waited_micro-b.time_waited_micro)/(a.total_waits-b.total_waits)/1E3 avgw
    from DBA_HIST_SYSTEM_EVENT a, DBA_HIST_SYSTEM_EVENT b, DBA_HIST_SNAPSHOT c
    where a.snap_id=b.snap_id+1 and a.event_name='log file sync' and a.event_name=b.event_name and a.snap_id=c.snap_id
    and a.total_waits>b.total_waits) lgfs,
  (select  a.snap_id, (a.total_waits-b.total_waits) totw, (a.time_waited_micro-b.time_waited_micro)/(a.total_waits-b.total_waits)/1E3 avgw
    from DBA_HIST_SYSTEM_EVENT a, DBA_HIST_SYSTEM_EVENT b, DBA_HIST_SNAPSHOT c
    where a.snap_id=b.snap_id+1 and a.event_name='db file parallel write' and a.event_name=b.event_name and a.snap_id=c.snap_id
    and a.total_waits>b.total_waits) dbfpw,
  (select  a.snap_id, (a.total_waits-b.total_waits) totw,(a.time_waited_micro-b.time_waited_micro)/(a.total_waits-b.total_waits)/1E3 avgw
    from DBA_HIST_SYSTEM_EVENT a, DBA_HIST_SYSTEM_EVENT b, DBA_HIST_SNAPSHOT c
    where a.snap_id=b.snap_id+1 and a.event_name='db file sequential read' and a.event_name=b.event_name and a.snap_id=c.snap_id
    and a.total_waits>b.total_waits) dbfsqr,
  (select  a.snap_id, (a.total_waits-b.total_waits) totw, (a.time_waited_micro-b.time_waited_micro)/(a.total_waits-b.total_waits)/1E3 avgw
    from DBA_HIST_SYSTEM_EVENT a, DBA_HIST_SYSTEM_EVENT b, DBA_HIST_SNAPSHOT c
    where a.snap_id=b.snap_id+1 and a.event_name='db file scattered read' and a.event_name=b.event_name and a.snap_id=c.snap_id
    and a.total_waits>b.total_waits) dbfscr,
  dba_hist_snapshot snap
where
  snap.snap_id=lgfs.snap_id(+)
  and
  snap.snap_id=dbfpw.snap_id(+)
  and
  snap.snap_id=dbfsqr.snap_id(+)
  and
  snap.snap_id=dbfscr.snap_id(+)
  and
  to_char(snap.begin_interval_time,'YYYY-MM-DD')='&deet'
  and
  snap.startup_time not between snap.begin_interval_time and snap.end_interval_time
order by snap.snap_id
/

