set pagesize 0
col tablespace form a20
col object form a40
col logical_reads form 999999999999
select
  d.name||'.'||c.name object,
  e.object_type,
  a.name tablespace ,
  b.value logical_reads
from
  ts$ a,
  v$segstat b,
  obj$ c,
  user$ d,
  dba_objects e
where
  a.ts#=b.ts#
  and
  b.obj#=c.obj#
  and
  c.owner#=d.user#
  and 
  c.name=e.object_name
  and 
  d.name=e.owner
  and
  b.statistic_name='logical reads'
order by b.value
/
