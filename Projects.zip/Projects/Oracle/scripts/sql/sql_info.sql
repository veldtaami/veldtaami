-- PURPOSE shows details and statistics of a parsed sql statement
set verify off
set linesize 120
set feedback off
accept hash prompt 'hash value: '
col executions form 9999999999
col elapsed_time form 99999999990.99
col cpu_time form 99999999990.99
select
  executions,
  disk_reads,
  buffer_gets,
  rows_processed "ROWS",
  elapsed_time/1000000 elapsed_time,
  cpu_time/10000000 cpu_time
from
  v$sqlarea where hash_value=&hash
/
col executions form a10
select
  'per exec' executions,
  round(10*disk_reads/executions)/10 disk_reads,
  round(10*buffer_gets/executions)/10 buffer_gets,
  round(10*rows_processed/executions)/10 "ROWS",
  round(100*elapsed_time/executions/1000000)/100 elapsed_time,
  round(100*cpu_time/executions/1000000)/1000 cpu_time
from
  v$sqlarea where hash_value=&hash
and executions>0
/
@sqlplusdefaults
