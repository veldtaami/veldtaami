set linesize 200
set pagesize 100
col group# form 99
col member for a60

select
  group#,
  thread#,
  sequence#,
  members,
  archived,
  status,
  first_change#,
  first_time
from v$log
  order by first_change#
/

select group#, members, bytes/1024/1024 mb from v$log;

select GROUP#,TYPE,MEMBER from v$logfile;

@sqlplusdefaults
