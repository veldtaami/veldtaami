create restore point ANW_30052017;	--moet met een letter beginnen.

select NAME , TIME from v$restore_point;

drop restore point ANW_30052017;