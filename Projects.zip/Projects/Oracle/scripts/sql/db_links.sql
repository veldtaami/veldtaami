set lines 200 
col OWNER    for a15
col DB_LINK  for a30
col USERNAME for a20
col HOST     for a50

select OWNER   , DB_LINK  , USERNAME , HOST    from dba_db_links;
