set feedback off
SELECT SUM(PINS-RELOADS)/SUM(PINS)*100 "Library Cache Hit Ratio"
FROM V$LIBRARYCACHE
/
SELECT SUM(PINS) "EXECUTIONS", SUM(RELOADS) "MISSES", SUM(RELOADS)/SUM(PINS)
"RELOAD RATIO"
FROM V$LIBRARYCACHE
/

select
  namespace,
  gets  locks,
  gets - gethits  loads,
  pins,
  reloads,
  invalidations
from
  sys.v_$librarycache
where
  gets > 0
order by
  2 desc
/
@sqlplusdefaults
