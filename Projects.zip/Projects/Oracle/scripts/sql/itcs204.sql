CREATE OR REPLACE  FUNCTION "SYS"."VERIFY_FUNCTION"
   ( UserName     VARCHAR2,
     PassWord     VARCHAR2,
     Old_PassWord VARCHAR2 )
  RETURN BOOLEAN
  IS
     N            BOOLEAN;
     M            INTEGER;
     PunctCnt     INTEGER;
     Differ       INTEGER;
     IsDigit      BOOLEAN;
     IsChar       BOOLEAN;
     IsPunct      BOOLEAN;
     DigitArray   VARCHAR2 (20);
     PunctArray   VARCHAR2 (25);
     CharArray    VARCHAR2 (52);
 
BEGIN
   DigitArray := '0123456789';
   CharArray  := 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
   PunctArray := '!"#$%&()``*+,-/:;<=>?_|';
 
   -- Check if the password is same as the username
   IF NLS_LOWER(Password) LIKE '%'|| NLS_LOWER(UserName) ||'%' THEN
      RAISE_APPLICATION_ERROR (-20001, 'Password same as or similar to user');
   END IF;
 
   -- Check for the minimum length of the password
   IF LENGTH (PassWord) < 8 THEN
      RAISE_APPLICATION_ERROR (-20002, 'Password length less than 8');
   END IF;
 
   -- Check if the password is too simple. A dictionary of words may be
   -- maintained and a check may be made so as not to allow the words
   -- that are too simple for the password.
   IF NLS_LOWER (PassWord) LIKE '%welcome%'   OR
      NLS_LOWER (PassWord) LIKE '%database%'  OR
      NLS_LOWER (PassWord) LIKE '%account%'   OR
      NLS_LOWER (PassWord) LIKE '%user%'      OR
      NLS_LOWER (PassWord) LIKE '%password%'  OR
      NLS_LOWER (PassWord) LIKE '%oracle%'    OR
      NLS_LOWER (PassWord) LIKE '%computer%'  OR
      NLS_LOWER (PassWord) LIKE '%abcd%'      OR
      NLS_LOWER (PassWord) LIKE '%ibm%'       OR
      SOUNDEX (PassWord) = SOUNDEX (UserName) OR
      SOUNDEX (PassWord) = SOUNDEX ('password')
   THEN
      RAISE_APPLICATION_ERROR (-20002, 'Password too simple');
   END IF;
 
   -- Check if the password contains at least one letter, one digit and one
   -- punctuation mark.
   -- 1. Check for the digit
   IsDigit := FALSE;
   M := LENGTH (PassWord);
   FOR I IN 1..10 LOOP
      FOR J IN 1..M LOOP
         IF SUBSTR (PassWord,J,1) = SUBSTR (DigitArray,I,1) THEN
            IsDigit:=TRUE;
            GOTO FindChar;
         END IF;
      END LOOP;
   END LOOP;
 
   IF IsDigit = FALSE THEN
      RAISE_APPLICATION_ERROR (-20003, 'Password should contain at least one digit, one character and one punctuation');
   END IF;
 
   -- 2. Check for the character
   <<FindChar>>
   IsChar := FALSE;
   FOR I IN 1..LENGTH (chararray) LOOP
      FOR J IN 1..M LOOP
         IF SUBSTR(PassWord,J,1) = SUBSTR(CharArray,I,1) THEN
            IsChar := TRUE;
            GOTO FindPunct;
         END IF;
      END LOOP;
   END LOOP;
 
   IF IsChar = FALSE THEN
      RAISE_APPLICATION_ERROR (-20003, 'Password should contain at least one digit, one character and one punctuation');
   END IF;
   -- 3. Check for the punctuation
   <<FindPunct>>
   IsPunct := FALSE;
 
   FOR I IN 1..LENGTH(PunctArray) LOOP
      FOR j IN 1..M LOOP
         IF SUBSTR (PassWord,J,1) = SUBSTR(PunctArray,i,1) THEN
            IsPunct := TRUE;
            GOTO EndSearch;
         END IF;
      END LOOP;
   END LOOP;
 
   IF IsPunct = FALSE THEN
      RAISE_APPLICATION_ERROR (-20003, 'Password should contain at least one digit, one character and one punctuation');
   END IF;
 
   <<EndSearch>>
   -- Check if the password differs from the previous password by at least
   -- 3 letters
   IF Old_PassWord IS NOT NULL THEN
     Differ := LENGTH(Old_PassWord) - LENGTH(PassWord);
 
     IF ABS (Differ) < 3 THEN
       IF LENGTH (PassWord) < LENGTH (Old_PassWord) THEN
         M := LENGTH (PassWord);
       ELSE
         M := LENGTH (Old_PassWord);
       END IF;
 
       Differ := ABS (Differ);
       FOR i IN 1..M LOOP
         IF SUBSTR (PassWord,I,1) != SUBSTR(Old_PassWord,I,1) THEN
           Differ := Differ + 1;
         END IF;
       END LOOP;
 
       IF Differ < 3 THEN
         RAISE_APPLICATION_ERROR (-20004, 'Password should differ by at least 3 characters');
       END IF;
     END IF;
   END IF;
 
   -- Check if the password doen't sound like the previous password
   IF SOUNDEX (Old_PassWord) = SOUNDEX (PassWord) THEN
      RAISE_APPLICATION_ERROR (-20004, 'Password sounds the same');
   END IF;
 
   -- Everything is fine; return TRUE ;
   RETURN(TRUE);
END;
/
