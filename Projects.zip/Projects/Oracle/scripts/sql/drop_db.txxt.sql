-- voor het droppen van een db: 
startup mount exclusive restrict
-- drop database;



and for RAC

srvctl status  database -d SCHD3
sqlplus / as sysdba
startup nomount;
alter system set cluster_database=FALSE scope=spfile sid='*';
alter system set cluster_database=FALSE scope=spfile sid='schd31';
alter system set cluster_database=FALSE scope=spfile sid='schd31';
alter system set cluster_database=FALSE scope=spfile sid='SCHD31';
alter system set cluster_database=FALSE scope=spfile sid='SCHD31';
shutdown abort;
startup mount exclusive restrict
select name from v$database;
drop database;

srvctl remove database -d SCHD3

haal uit de oratab.
ruim dbs-dir op. 
ruim trace dirs op
ruim oude backupbestanden op.

Verwijder database uit OEM



1.	srvctl add database -d RKG1T -o /u01/oracle/rdbms/12102EE_LRK_2
2.	srvctl config database -d RKG1T
3.	srvctl add instance -d RKG1T -i RKG1T1 -n otagrndb013n01
4.	srvctl add instance -d RKG1T -i RKG1T2 -n otagrndb013n02
5.	op instance 2:   mkdir -p /u01/oracle/admin/RKG1T/adump
6.	op instance 2: voeg toe in de oratab en een init.ora in de OH/dbs



