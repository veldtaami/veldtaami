set verify off
col data_type form a12
accept tab prompt 'owner.table: '
accept col prompt 'column: '
set linesize 120
set feedback off
select num_rows, blocks from dba_tables where upper(owner||'.'||table_name)=upper('&tab')
/
select
  data_type,
  data_length,
  avg_col_len,
  num_distinct,
  density,
  num_nulls,
  histogram
from
  dba_tab_columns
where
  upper(owner||'.'||table_name||'.'||column_name)=upper('&tab'||'.'||'&col')
/
select
  last_analyzed,
  sample_size,
  num_buckets
from
  dba_tab_columns
where
  upper(owner||'.'||table_name||'.'||column_name)=upper('&tab'||'.'||'&col')
/
@sqlplusdefaults
