--Script om elke ochtend te draaien, controle op db's. 
--
--  
--  1: hoe groot is mijn db en is het extra groot geworden:
--  in een tabel wordt middels een job elke dag de grootte van de database in bijgehouden. 
-- @host.sql


select INSTANCE_NAME, host_name, status, name , DB_UNIQUE_NAME from  v$instance, v$database;

@db_growth.sql
select sum(bytes)/1024/1024/1024 Gb_totaal_segments from dba_segments;
-- ts_usage geeft aan hoegroot de tablespaces zijn:
-- vervangen door een script die misschien de volle tbs terug geeft. 

-- @ts_usage 

prompt "Tablespaces > 80 % vol " 
select  tablespace_name, used_percent from dba_tablespace_usage_metrics where  used_percent > 80;


--  controle op de dba_outstanding_alerts. kijken of er fouten in de db zitten. 
Promp "Alerts  "
@alerts.sql
--@invalid.sql
-- zijn de statistieken goed. kijken naar staal objecten. 
--prompt "Stale objecten " 
-- @stale

-- een goede maat van hoe druk de db was zijn de logswitches. 
-- @switches




