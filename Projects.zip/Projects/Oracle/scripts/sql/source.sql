set lines 200
set long 9999
set pages 99

select distinct owner, name , type from dba_source where owner = upper('&&owner') and name = upper('&&name');
select text from dba_source where owner = upper('&owner') and name = upper('&name');
