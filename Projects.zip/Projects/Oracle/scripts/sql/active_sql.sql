

set line 200;
set pages 200;
col SPID format a10;
col USERNAME format a15;
col ID format a10;
col STATUS format a10;
col "Last Activity" format 9999999999;
col sql_text format a70;
select p.SPID, s.username, b.sql_id, a.hash_value, s.sid || ',' || s.serial# "ID", s.status, s.last_call_et "Last Activity", b.sql_text 
from gv$session s, gv$sqlarea b, gv$process p , gv$sql a
where s.username is not null and p.addr = s.paddr and s.sql_address=b.address and b.sql_id=a.sql_id
and s.username <> 'SYSTEM';

