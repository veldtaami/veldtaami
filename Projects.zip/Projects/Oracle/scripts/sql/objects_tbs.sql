@defaults.sql

set lines 200
col owner for a25
col SEGMENT_NAME for a40
col TABLESPACE_NAME for a30
select owner, SEGMENT_NAME , SEGMENT_TYPE, TABLESPACE_NAME from dba_segments
where tablespace_name = upper('&tablespacename')
order by owner, SEGMENT_NAME;

