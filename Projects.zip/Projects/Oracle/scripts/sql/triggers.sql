@defaults
select trigger_name, trigger_type, table_name , status
from dba_triggers where table_owner = upper('&schema_naam')
order by 3,1;