set feedback off
set pagesize 0
set linesize 400
prompt current memory layout
prompt ================================================================
select 'Total SGA     : '||round(sum(value)/(1024*1024))||'Mb' from v$sga;
select 'Total process : '||round(sum(pga_alloc_mem)/(1024*1024))||'Mb' from v$process;

prompt
prompt SGA management
prompt ================================================================
col name form a32
select name, round(value/(1024*1024))||'Mb' from v$parameter where name like 'sga_%';
select name, round(value/(1024*1024))||'Mb' from v$parameter where name like '%pga%';
select name, round(value/(1024*1024))||'Mb' from v$parameter where name like '%block_buffer%';
select name, round(value/(1024*1024))||'Mb' from v$parameter where name like '%pool%';

prompt
prompt SGA global breakdown
prompt ================================================================
select name, round(value/(1024*1024))||'Mb' mb from v$sga order by mb desc;

prompt
prompt SGA detail (>=1Mb)
prompt ================================================================
select pool, name, round(bytes/(1024*1024))||'Mb' mb from v$sgastat where bytes>1024*1024 order by pool desc, bytes desc;

prompt
prompt SGA advice
prompt ================================================================
set pagesize 1000
col Mb form 999999999999999
select sga_size Mb, sga_size_factor size_factor, estd_db_time_factor time_factor, estd_physical_reads phyrds from v$sga_target_advice order by sga_size_factor;


prompt
prompt buffer cache advice
prompt ================================================================
SELECT 
  size_for_estimate mb, 
  size_factor,  
  estd_physical_read_factor read_factor, 
  estd_physical_reads phyreads
FROM V$DB_CACHE_ADVICE
WHERE name='DEFAULT'
AND block_size = (SELECT value FROM V$PARAMETER WHERE name = 'db_block_size')
AND advice_status = 'ON'
order by size_factor;

prompt
prompt PGA Layout
prompt ================================================================
col name form a40
select name, value, unit from v$pgastat order by 3 desc, 2 desc;

prompt
prompt PGA advice
prompt ================================================================
select round(pga_target_for_estimate/(1024*1024)) Mb, pga_target_factor size_factor, estd_extra_bytes_rw extra_io, estd_pga_cache_hit_percentage cache, estd_overalloc_count overalloc from v$pga_target_advice;
set pagesize 0
@sqlplusdefaults
