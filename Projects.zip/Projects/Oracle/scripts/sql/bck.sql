set linesize 200
col "age_in_days" form 99.99
col "latest" form a25
col "type" form a10
select * from (
select sysdate-min(completion_time) "age_in_days", to_char(min(completion_time),'YYYY-MM-DD HH24:MI') "latest", 'FULL' "type" from
(select
 max(b.completion_time) completion_time,
 b.file#
 from
 v$datafile a,
 v$backup_datafile b,
 v$backup_set c,
 v$backup_piece d
 where
 a.file#=b.file#
 and
 b.set_stamp=c.set_stamp
 and
 b.set_count=c.set_count
 and
 c.backup_type='D'
 and
 (c.incremental_level=0 or c.incremental_level is NULL)
 and
 c.set_stamp=d.set_stamp and c.set_count=d.set_count
 and
 d.status='A'
 group by b.file#)
union
select sysdate-min(completion_time), to_char(min(completion_time),'YYYY-MM-DD HH24:MI'), 'INCR' from
(select
 max(b.completion_time) completion_time,
 b.file#
 from
 v$datafile a,
 v$backup_datafile b,
 v$backup_set c,
 v$backup_piece d
 where
 a.file#=b.file#
 and
 b.set_stamp=c.set_stamp
 and
 b.set_count=c.set_count
 and
 c.backup_type='I'
 and
 c.incremental_level>0
 and
 c.set_stamp=d.set_stamp and c.set_count=d.set_count
 and
 d.status='A'
 group by b.file#)
union
select
sysdate-max(a.completion_time), to_char(max(a.completion_time),'YYYY-MM-DD HH24:MI'), 'ARCH'
from
v$backup_set a,
v$backup_piece b
where
a.set_stamp=b.set_stamp and a.set_count=b.set_count and b.status='A' and
a.backup_type='L'
union
select sysdate-max(s.completion_time), to_char(max(s.completion_time),'YYYY-MM-DD HH24:MI'), 'COLD' from
v$Backup_Set S, v$Backup_Piece P
WHERE s.set_stamp=p.set_stamp and s.set_count=p.set_count and p.status='A'
AND P.Tag = 'COLD'
)
order by 1
/
