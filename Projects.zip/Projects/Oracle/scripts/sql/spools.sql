https://oracle-base.com/articles/misc/sqlcl-format-query-results-with-the-set-sqlformat-command



SET MARKUP HTML ON 

SET MARKUP CSV ON quote off
set markup csv on


spool ...
set termout off  ( in combinatie met een spool, komt de output alleen in het spoolbestand. niet op het scherm)




set colsep ,     -- separate columns with a comma
set pagesize 0   -- No header rows
set trimspool on -- remove trailing blanks
set headsep off  -- this may or may not be useful...depends on your headings.
set linesize X   -- X should be the sum of the column widths
set numw X       -- X should be the length you want for numbers (avoid scientific notation on IDs)

spool myfile.csv

select table_name, tablespace_name 
  from all_tables
 where owner = 'SYS'
   and tablespace_name is not null;
   
   
   
   set sqlprompt " _connect_identifier > "