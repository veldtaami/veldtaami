CRSCTL: in de GRID_Home/bin dir. 
export PATH=$PATH:/u01/grid/12102

crsctl stop crs

Voorgedefinieerde commands: 

crs_stat
crs_register
crs_unregister
crs_start
crs_stop
crs_getperm
crs_profile
crs_relocate
crs_setperm
crsctl check crsd
crsctl check cssd
crsctl check evmd
crsctl debug log
crsctl set css votedisk
crsctl start resources
crsctl stop resources



crsctl start/stop/status resource

Use the crsctl check css command to check the status of Cluster Synchronization Services



### omgeving zetten: 
export CRS_HOME=/u01/grid/12102/
export PATH=$PATH:$CRS_HOME/bin


### STARTEN 
./crsctl stop cluster
crsctl start crs
crsctl check crs
crsctl start cluster

Om CRS op te zetten: draai de root.sh script uit de bin dir. 
[root@ontgrndb023n04 12102]# pwd
/u01/grid/12102


CRS:
Status:  crs_stat -t
	crsctl start crs
	crsctl stop crs
	crsctl enable crs
	crsctl disable crs

crsctl check crs

srvctl status nodeapps
crsctl status resource -t
srvctl stop asm




###   RE-CONFIGURE CRS. 


/u01/grid/12102/root.sh
/u01/grid/12102/crs/install/rootcrs.pl -deconfig -force -verbose

Once de-configuration for Oracle clusterware completes successful reboot the server once de-config of clusterware is done as above and re-try executing root.sh again.

[root@RAC1 grid]# ./root.sh




### LOG-LOCATIONS:
$ORA_CRS_HOME//log 
$ORA_CRS_HOME/crs/log

$ORA_CRS_HOME/crs/init
$ORA_CRS_HOME/css/log
$ORA_CRS_HOME/evm/log

