

-- V10.00.172.1__Event_Oracle_SchemaCreation.sql

create table AGENT_STATE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 AGENT_ID varchar2(128 char) not null, LAST_STATE varchar2(255 char) not null, primary key (ID));
create table ALL_EVENTS (ID varchar2(255 char) not null, VERSION number(10,0) not null, TITLE clob, DESCRIPTION clob,
 SOLUTION clob, STATE varchar2(255 char), SEVERITY varchar2(255 char), PRIORITY varchar2(255 char),
 CATEGORY varchar2(255 char), SUBCATEGORY varchar2(255 char), TYPE varchar2(255 char), RELATED_CI_HINT clob,
 OM_SERVICE_ID clob, RELATED_CI_ID varchar2(255 char), RELATED_CI_TYPE varchar2(255 char), NODE_ID varchar2(255 char),
 NODE_TYPE varchar2(255 char), SEQUENCE_NUMBER number(19,0), NODEHINTS_HINT varchar2(4000 char),
 NODEHINTS_DNSNAME varchar2(255 char), NODEHINTS_IPADDRESS varchar2(255 char), NODEHINTS_COREID varchar2(255 char),
 SOURCECIHINTS_HINT clob, SOURCECIHINTS_DNSNAME varchar2(255 char), SOURCECIHINTS_IPADDRESS varchar2(255 char),
 SOURCECIHINTS_COREID varchar2(255 char), ORIGINATING_DNSNAME varchar2(255 char),
 ORIGINATING_IPADDRESS varchar2(255 char), ORIGINATING_COREID varchar2(255 char), SENDING_DNSNAME varchar2(255 char),
 SENDING_IPADDRESS varchar2(255 char), SENDING_COREID varchar2(255 char), OM_USER varchar2(255 char),
 ASSIGNED_USER_UUID varchar2(255 char), ASSIGNED_GROUP_UUID varchar2(255 char), CAUSE_ID varchar2(255 char),
 TIME_CREATED timestamp, TIME_CHANGED timestamp, TIME_STATE_CHANGED timestamp, TIME_RECEIVED timestamp,
 DUPLICATE_COUNT number(10,0), ETI_HINT varchar2(255 char), ETI_SUBCOMPONENT_ID varchar2(255 char),
 UA_HOST_DNSNAME varchar2(255 char), UA_HOST_IPADDRESS varchar2(255 char), UA_HOST_COREID varchar2(255 char),
 UA_CALL clob, UA_STATUS varchar2(255 char), UA_ADD_ANNO number(1,0), UA_WILL_RESOLVE number(1,0),
 AA_HOST_DNSNAME varchar2(255 char), AA_HOST_IPADDRESS varchar2(255 char), AA_HOST_COREID varchar2(255 char),
 AA_CALL clob, AA_STATUS varchar2(255 char), AA_ADD_ANNO number(1,0), AA_WILL_RESOLVE number(1,0),
 APPLICATION varchar2(255 char), OBJECT varchar2(255 char), EVENT_KEY clob, CLOSE_KEY_PATTERN clob, ORIGINAL_DATA clob,
 LOG_ONLY number(1,0), NO_DEDUP number(1,0), RECEIVED_ON_CI_DOWNTIME number(1,0), INSTRUCTION_AVAILABLE number(1,0),
 SOURCE_CI_ID varchar2(255 char), SOURCE_CI_TYPE varchar2(255 char), POLICY_TYPE varchar2(255 char),
 POLICY_NAME varchar2(255 char), CONDITION_ID varchar2(255 char), CONDITION_NAME varchar2(255 char),
 INSTRUCTION_ID varchar2(255 char), INTERFACE_NAME varchar2(255 char), PARAMETER_STRING varchar2(255 char),
 ORIGINAL_ID varchar2(255 char), CORRELATION_TYPE varchar2(255 char), CORRELATION_RULE_ID varchar2(255 char),
 CORRELATION_WEIGHT varchar2(255 char), ETI_INDICATOR_ID varchar2(255 char), ETI_VALUE_ID varchar2(255 char),
 ETI_RESET_VALUE_ID varchar2(255 char), ETI_NUMERIC_VALUE double precision, CONTROL_DNSNAME varchar2(255 char),
 CONTROL_SERVER_PORT number(10,0), CONTROL_SERVER_ID varchar2(255 char), CONTROL_EXTERNAL_ID varchar2(255 char),
 CONTROL_EXTERNAL_URL varchar2(255 char), RULE_NAME varchar2(255 char), TRANSFER_STATE varchar2(255 char),
 INITIATED_BY_UUID varchar2(255 char), SOURCE_DNSNAME varchar2(255 char), SOURCE_IA_MANAGEMENT_PORT number(10,0),
 SOURCE_IA_MANAGEMENT_PROTOCOL varchar2(255 char), SOURCE_SERVER_ID varchar2(255 char),
 SOURCE_EXTERNAL_ID varchar2(255 char), SOURCE_EXTERNAL_URL varchar2(255 char), CIRES_HINT_COUNT number(10,0),
 CIRES_MATCHED_HINT_COUNT number(10,0), CIRES_QUALITY_METRIC number(10,0), CIRES_STATUS clob,
 RECEIVED_AS_NOTIFY number(1,0), primary key (ID));
create table BASELINE_CONTENT_PACKS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CONTENT_PACK_ID varchar2(255 char) not null, CONTENT_PACK_VERSION varchar2(255 char) not null,
 NAME varchar2(255 char) not null, CONTENT_PACK clob, primary key (ID), unique (CONTENT_PACK_ID, CONTENT_PACK_VERSION));
create table BROWSER_SETTINGS (ID varchar2(255 char) not null, NAME varchar2(255 char), BS_INDEX number(10,0),
 ACTIVE_BROWSER number(1,0), FILTER_NAME varchar2(255 char), ORDER_INDEX number(10,0) not null,
 UI_SETTING_ID varchar2(255 char) not null, primary key (ID));
create table BS_VISIBLE_COLUMNS (BROWSER_SETTING_ID varchar2(255 char) not null, COLUMN_ID varchar2(255 char),
 WIDTH number(10,0), SORT_COLUMN number(10,0), SORTED_ASCENDING number(1,0), ORDER_INDEX number(10,0) not null,
 primary key (BROWSER_SETTING_ID, ORDER_INDEX));
create table CERTIFICATE_REQUESTS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CN varchar2(255 char) not null, CONTEXT varchar2(255 char), DPS varchar2(255 char) not null, INSTALLATION number(10,0),
 IP_ADDRESS varchar2(255 char) not null, NODE_NAME varchar2(255 char), PEER_ADDRESS varchar2(255 char),
 TIME_RECEIVED timestamp, EVENT_TYPE number(10,0), INFO varchar2(255 char), PLATFORM_CPU_TYPE number(10,0),
 PLATFORM_MAJOR number(10,0), PLATFORM_MINOR number(10,0), PLATFORM_SUB_MINOR number(10,0),
 PLATFORM_OS_TYPE number(10,0), CHANGED_BY_UUID varchar2(255 char), primary key (ID));
create table CI_EVENT_COUNTERS (ID varchar2(255 char) not null, VERSION number(10,0) not null, CI_ID varchar2(255 char),
 SUBCATEGORY varchar2(255 char), IS_INCONSISTENT number(1,0), UNRESOLVED_UNKNOWN_COUNTER number(10,0),
 UNRESOLVED_NORMAL_COUNTER number(10,0), UNRESOLVED_WARNING_COUNTER number(10,0), UNRESOLVED_MINOR_COUNTER number(10,0),
 UNRESOLVED_MAJOR_COUNTER number(10,0), UNRESOLVED_CRITICAL_COUNTER number(10,0),
 UNASSIGNED_UNKNOWN_COUNTER number(10,0), UNASSIGNED_NORMAL_COUNTER number(10,0),
 UNASSIGNED_WARNING_COUNTER number(10,0), UNASSIGNED_MINOR_COUNTER number(10,0), UNASSIGNED_MAJOR_COUNTER number(10,0),
 UNASSIGNED_CRITICAL_COUNTER number(10,0), primary key (ID), unique (CI_ID, SUBCATEGORY));
create table CONTENT_PACKS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, CONTENT_PACK_VERSION varchar2(255 char), CUSTOMER_ID number(10,0) not null,
 LABEL varchar2(255 char), DESCRIPTION clob, primary key (ID), unique (NAME, CONTENT_PACK_VERSION, CUSTOMER_ID));
create table CONTENT_PACK_LOCKS (ID varchar2(255 char) not null, VERSION number(10,0) not null, OWNER varchar2(255 char),
 FULL_USER varchar2(255 char), LOCK_TIME number(19,0), primary key (ID));
create table CP_SELECTED_ITEMS (CP_ID varchar2(255 char) not null, SELECTED_ITEM_KEY varchar2(255 char) not null,
 SELECTED_ITEM_LABEL varchar2(255 char), TYPE varchar2(255 char) not null, CONTENT_PACK_VERSION varchar2(255 char),
 CONTENT_PACK_ID varchar2(255 char), CONTENT_PACK_NAME varchar2(255 char), CONTENT_PACK_LABEL varchar2(255 char),
 primary key (CP_ID, SELECTED_ITEM_KEY, TYPE));
create table CSA_CERT_REQUEST_ADDL_INFO (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ADDL_INFO varchar2(255 char) not null, TIME_ADDED timestamp not null, HOST varchar2(255 char) not null,
 primary key (ID));
create table CSA_SERVERS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 HOST varchar2(255 char) not null, SERVER_TYPE number(10,0) not null, primary key (ID));
create table DB_SCHEMA_VERSION (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCHEMA_VERSION varchar2(255 char), BUILD varchar2(255 char), STATUS varchar2(255 char), MODIFIED timestamp,
 nextStep number(10,0), MIGRATED_FROM_VERSION varchar2(255 char), primary key (ID));
create table EVENT_ANNOTATIONS (ID varchar2(255 char) not null, VERSION number(10,0) not null, TEXT clob not null,
 EVENT_ID varchar2(255 char) not null, AUTHOR clob not null, TIME_CREATED timestamp not null, primary key (ID));
create table EVENT_AUTOMATION_STATES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 EVENT_REF varchar2(255 char), RULE_UUID varchar2(255 char) not null, MATCH_STATE number(1,0),
 EXECUTION_COUNT number(10,0), SCHEDULED_FOR timestamp, primary key (ID));
create table EVENT_CATEGORY (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CATEGORY varchar2(255 char) not null, primary key (ID), unique (CATEGORY));
create table EVENT_CUSTOM_ATTRIBUTES (EVENT_ID varchar2(255 char) not null, idx varchar2(255 char) not null, elt clob,
 primary key (EVENT_ID, idx));
create table EVENT_FORWARDING_INFO (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 EVENT_ID varchar2(255 char) not null, DNSNAME varchar2(255 char), IPADDRESS varchar2(255 char),
 COREID varchar2(255 char), CONNECTED_SERVER_ID varchar2(255 char), FORWARDING_TYPE varchar2(255 char),
 FORWARDING_STATE varchar2(255 char), EXTERNAL_ID varchar2(255 char), EXTERNAL_URL_PATH varchar2(255 char),
 TIME_LAST_CHANGE_SENT timestamp, RULE_NAME varchar2(255 char), IDENTIFIER varchar2(255 char), primary key (ID),
 unique (EVENT_ID, DNSNAME, IPADDRESS, COREID, CONNECTED_SERVER_ID));
create table EVENT_KPI_DELTAS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 AGGR_IN_PROGRESS number(1,0), CI_ID varchar2(255 char) not null, SUBCATEGORY varchar2(255 char),
 UNRESOLVED_UNKNOWN_COUNTER number(10,0), UNRESOLVED_NORMAL_COUNTER number(10,0),
 UNRESOLVED_WARNING_COUNTER number(10,0), UNRESOLVED_MINOR_COUNTER number(10,0), UNRESOLVED_MAJOR_COUNTER number(10,0),
 UNRESOLVED_CRITICAL_COUNTER number(10,0), UNASSIGNED_UNKNOWN_COUNTER number(10,0),
 UNASSIGNED_NORMAL_COUNTER number(10,0), UNASSIGNED_WARNING_COUNTER number(10,0), UNASSIGNED_MINOR_COUNTER number(10,0),
 UNASSIGNED_MAJOR_COUNTER number(10,0), UNASSIGNED_CRITICAL_COUNTER number(10,0), primary key (ID));
create table EVENT_PROPERTY_CHANGE (ID varchar2(255 char) not null, TYPE varchar2(255 char) not null,
 VERSION number(10,0) not null, PROP_NAME varchar2(255 char) not null, HISTORY_LINE varchar2(255 char) not null,
 STRING_CURRENT_VALUE clob, STRING_PREV_VALUE clob, DATE_CURRENT_VALUE timestamp, DATE_PREV_VALUE timestamp,
 CMA_KEY_OR_CMD varchar2(255 char), NUMBER_CURRENT_VALUE number(10,0), NUMBER_PREV_VALUE number(10,0),
 UUID_CURRENT_VALUE varchar2(255 char), UUID_PREV_VALUE varchar2(255 char), FK_UUID varchar2(255 char),
 primary key (ID));
create table EVENT_STATISTICS (START_DATE timestamp not null, METRIC_NAME varchar2(255 char) not null,
 SERVER_NAME varchar2(255 char) not null, INTERVAL number(19,0) not null, METRIC_VALUE number(19,0),
 primary key (START_DATE, METRIC_NAME, SERVER_NAME));
create table EVENT_SYNC_BUFFER (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 IDENTIFIER varchar2(255 char) not null, SEQ_NUMBER number(19,0) not null unique, TIME_CREATED timestamp not null,
 CORE_ID varchar2(255 char), FORWARDING_TYPE varchar2(255 char), DNS_NAME varchar2(255 char),
 IP_ADDRESS varchar2(255 char), CONNECTED_SERVER_ID varchar2(255 char), OM_SYNC_OBJECT blob, primary key (ID));
create table EVENT_SYNC_LOAD_BALANCE_LOCK (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 TARGET_IDENTIFIER varchar2(255 char) not null unique, EVENT_SYNC_PROCESSOR varchar2(255 char),
 TIME_LAST_UPDATED timestamp not null, primary key (ID));
create table EXC_NOTIFICATION (ID varchar2(255 char) not null, VERSION number(10,0) not null, CREATED number(19,0),
 MESSAGE varchar2(255 char), primary key (ID));
create table HEALTHCHECK_CONFIG (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CONFIG_MODE varchar2(255 char) not null, HEALTHCHECK_MODE varchar2(255 char) not null, AGENT_ID varchar2(128 char),
 AGENT_CI_ID varchar2(128 char), NODE_ID varchar2(128 char) not null, AGENT_SEND_INTERVAL number(19,0) not null,
 AGENT_ERROR_INTERVAL number(19,0) not null, LAST_DEPLOYED_SEND_INTERVAL number(19,0) not null,
 LAST_SUCCESSFUL_DEPLOYMENT number(19,0) not null, MANAGED_BY_OMI number(1,0) not null, primary key (ID));
create table HISTORY_LINE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 USER_UUID varchar2(255 char) not null, TIME_CHANGED timestamp not null, EVENT_REF varchar2(255 char),
 HEADLINE_MSG_KEY varchar2(255 char), COMP_ID varchar2(255 char), COMPONENT_TYPE varchar2(255 char), primary key (ID));
create table HI_CHANGE (ID number(10,0) not null, CI_ID varchar2(36 char) not null, HI_VALUE_ID varchar2(36 char),
 TIMESTAMP number(19,0) not null, HI_TYPE_ID varchar2(36 char), HI_SEVERITY varchar2(64 char), primary key (ID));
create table KPI_CHANGE (ID number(10,0) not null, KPI_TYPE number(10,0) not null, KPI_STATUS number(10,0) not null,
 CI_ID varchar2(36 char) not null, TIMESTAMP number(19,0) not null, primary key (ID));
create table LIC_PRODUCT_COUNT (DNSNAME varchar2(255 char) not null, PRODUCT_NAME varchar2(255 char) not null,
 VERSION number(10,0) not null, COUNT_TIMESTAMP timestamp not null, INSTANCE_COUNT number(10,0) not null,
 LIC_MANAGER varchar2(255 char) not null, primary key (DNSNAME, PRODUCT_NAME));
create table OAS_LDAP_GROUP_TO_USER_GROUP (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 USERGROUP_ID varchar2(255 char) not null, NAME varchar2(128 char) not null, LDAP_DOMAIN varchar2(64 char) not null,
 DESCRIPTION varchar2(128 char), LDAP_SERVER varchar2(255 char) not null, primary key (ID), unique (USERGROUP_ID, NAME,
 LDAP_DOMAIN));
create table OAS_LDAP_SETTINGS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 AUTO_CREATE_USER number(1,0) not null, AUTO_ADD_USERS_TO_GROUPS number(1,0) not null,
 SYNCHRONIZE_GROUPS number(1,0) not null, primary key (ID));
create table OAS_PERMISSION_TO_ROLE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ROLE_ID varchar2(255 char) not null, RESOURCE_KEY varchar2(1024 char) not null,
 OPERATION_KEY varchar2(64 char) not null, primary key (ID), unique (ROLE_ID, RESOURCE_KEY, OPERATION_KEY));
create table OAS_ROLE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(128 char) not null unique, DESCRIPTION varchar2(1024 char), primary key (ID));
create table OAS_TENANT (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(128 char) not null unique, DESCRIPTION varchar2(1024 char), primary key (ID));
create table OAS_USER (ID varchar2(255 char) not null, VERSION number(10,0) not null, NAME varchar2(128 char) not null,
 LOGIN varchar2(64 char) not null, LDAP_DOMAIN varchar2(64 char), PASSWORD_HASH varchar2(1024 char) not null,
 DESCRIPTION varchar2(1024 char), EMAIL_ADDRESS varchar2(256 char), TIME_ZONE varchar2(255 char),
 LAST_LOGIN_DATE timestamp, LDAP_USER number(1,0) not null, LOGIN_USER number(1,0) not null,
 SUPER_ADMINISTRATOR number(1,0) not null, DISABLED number(1,0) not null, EVENT_ASSIGNMENT_GROUP_ID varchar2(255 char),
 primary key (ID), unique (LOGIN, LDAP_DOMAIN));
create table OAS_USER_GROUP (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(128 char) not null unique, DESCRIPTION varchar2(1024 char), EVENT_ASSIGNMENT number(1,0) not null,
 LDAP_AUTO_ASSIGNMENT number(1,0), primary key (ID));
create table OAS_USER_GROUP_TO_ROLE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 USERGROUP_ID varchar2(255 char) not null, ROLE_ID varchar2(255 char) not null, TENANT_ID varchar2(255 char) not null,
 primary key (ID), unique (USERGROUP_ID, ROLE_ID, TENANT_ID));
create table OAS_USER_GROUP_TO_USER_GROUP (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CHILD_USER_GROUP_ID varchar2(255 char) not null, PARENT_USER_GROUP_ID varchar2(255 char) not null, primary key (ID),
 unique (CHILD_USER_GROUP_ID, PARENT_USER_GROUP_ID));
create table OAS_USER_TO_ROLE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 USER_ID varchar2(255 char) not null, ROLE_ID varchar2(255 char) not null, TENANT_ID varchar2(255 char) not null,
 primary key (ID), unique (USER_ID, ROLE_ID, TENANT_ID));
create table OAS_USER_TO_USER_GROUP (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 USER_ID varchar2(255 char) not null, USERGROUP_ID varchar2(255 char) not null, AUTO_ASSIGNMENT number(1,0),
 primary key (ID), unique (USER_ID, USERGROUP_ID));
create table OMCID_CMDB_MAPPINGS (OMC_ID varchar2(2048 char) not null, UCMDB_CIID varchar2(32 char),
 UCMDB_CITYPE varchar2(255 char), UCMDB_HOSTCIID varchar2(32 char), IS_ALIAS number(1,0), OM_HOSTNAME varchar2(255 char),
 IS_DECOMMISSIONED number(1,0) not null, primary key (OMC_ID));
create table OMSVCTYPEDEFS (GUID varchar2(255 char) not null, CAPTIONFORMAT varchar2(255 char),
 DESCRIPTIONFORMAT varchar2(255 char), KEYFORMAT varchar2(255 char), CAPTION varchar2(255 char),
 DESCRIPTION varchar2(255 char), MMODULE varchar2(255 char), primary key (GUID));
create table PARTITION_CONTROLLER (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 LAST_SPLIT number(19,0), PARTITION_IDENTIFIER varchar2(255 char), primary key (ID));
create table PMI_TEMPLATE_DETAILS (TEMPLATE_PATH varchar2(255 char) not null, LAST_UPDATED_TIME number(19,0),
 READ_ONLY number(1,0), TEMPLATE_CONTENTS blob, CUSTOMERID number(10,0), primary key (TEMPLATE_PATH));
create table PMI_TEMPLATE_UUID_MAP (GRAPH_UUID varchar2(255 char) not null, FAMILY_NAME varchar2(255 char),
 CATEGORY_NAME varchar2(255 char), TEMPLATE_PATH varchar2(255 char), CUSTOMERID number(10,0), primary key (GRAPH_UUID));
create table PMI_UISTATE_DETAILS (TEMPLATE_PATH varchar2(255 char) not null, LAST_UPDATED_TIME number(19,0),
 READ_ONLY number(1,0), TEMPLATE_CONTENTS blob, CUSTOMERID number(10,0), primary key (TEMPLATE_PATH));
create table POTENTIAL_CORRELATIONS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CAUSE_ID varchar2(255 char) not null, SYMPTOM_ID varchar2(255 char) not null, CORRELATOR_ID varchar2(255 char),
 CORRELATION_TYPE varchar2(255 char), CORRELATION_WEIGHT varchar2(255 char), TIME_CREATED timestamp, primary key (ID),
 unique (CAUSE_ID, SYMPTOM_ID, CORRELATOR_ID));
create table PREMIGRATION_BACKUP_FILES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 PATH varchar2(255 char) not null unique, FILE_TYPE varchar2(255 char) not null, BIN_DATA blob not null,
 TIME_ADDED timestamp, ADDITIONAL_INFO clob, PASS_PHRASE varchar2(255 char), primary key (ID));
create table PREVSYNCDATA (FILENAME varchar2(2048 char) not null, FILECONTENT blob, primary key (FILENAME));
create table RECONCILIATION_STATE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CUSTOMER_ID number(10,0) not null unique, LAST_POLL_TIMESTAMP varchar2(255 char), primary key (ID));
create table SERVER_KEY_STORE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CORE_ID varchar2(255 char) not null, BIN_DATA blob not null, PASS_PHRASE varchar2(255 char) not null,
 CERTIFICATE_TYPE varchar2(255 char), DATE_MODIFIED timestamp, DIGEST varchar2(255 char), primary key (ID));
create table SIMPLE_BLOB (ID varchar2(255 char) not null, VERSION number(10,0) not null, contentKey varchar2(255 char),
 contentType varchar2(255 char), contentHashCode number(10,0), ownerCreatorFeature varchar2(255 char), bytes blob,
 primary key (ID));
create table SIS_PROFILEINFO (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 profileId number(10,0) not null, bytes blob not null, connectedServerId varchar2(255 char) not null unique,
 primary key (ID));
create table SYNCPACKAGES (SYNCPACKAGE varchar2(255 char) not null, FILENAME varchar2(100 char) not null,
 FILECONTENT blob, primary key (SYNCPACKAGE, FILENAME));
create table TGT_COUNT (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 COUNT_TIMESTAMP timestamp not null, NUM_OF_TGT_CONNECTORS number(10,0) not null, primary key (ID));
create table UI_SETTINGS (ID varchar2(255 char) not null, VERSION number(10,0) not null, USER_UUID varchar2(255 char),
 CONTEXT varchar2(255 char), VIEW_NAME varchar2(255 char), CI_IDS varchar2(255 char),
 DETAILS_PERCENTAGE double precision, DETAILS_VISIBLE number(1,0), CI_VIEW_FILTER_STATE number(10,0),
 CI_FILTER_RECURSIVE number(1,0) not null, SOUNDS_ENABLED number(1,0) not null, FILTER_FAVORITES varchar2(255 char),
 VIEW_FAVORITES varchar2(255 char), ROW_COLORING_ENABLED number(1,0) not null, ROW_COLORING_ENUM varchar2(255 char),
 primary key (ID));
create index indexOverAgentId on AGENT_STATE (AGENT_ID);
create index indexOverSequenceNumber on ALL_EVENTS (SEQUENCE_NUMBER);
create index indexOverRelatedCiId on ALL_EVENTS (RELATED_CI_ID);
create index indexOverTimeReveiced on ALL_EVENTS (TIME_RECEIVED);
create index indexOverNodeId on ALL_EVENTS (NODE_ID);
create index indexOverCause on ALL_EVENTS (CAUSE_ID);
create index indexOverSourceCiId on ALL_EVENTS (SOURCE_CI_ID);
create index indexOverState on ALL_EVENTS (STATE);
alter table BROWSER_SETTINGS add constraint FK1B2C8F7A6959FD08 foreign key (UI_SETTING_ID) references UI_SETTINGS;
alter table BS_VISIBLE_COLUMNS add constraint FK771470E2DCF61145 foreign key (BROWSER_SETTING_ID) references
 BROWSER_SETTINGS;
create index inconsistentCounterIdx on CI_EVENT_COUNTERS (IS_INCONSISTENT);
alter table CP_SELECTED_ITEMS add constraint SELECTED_ITEM_TO_CPD foreign key (CP_ID) references CONTENT_PACKS;
create index annoToEventRefIdx on EVENT_ANNOTATIONS (EVENT_ID);
create index indexOverEventRef on EVENT_AUTOMATION_STATES (EVENT_REF);
create index INDEX_ON_CMA_INDEXCOL on EVENT_CUSTOM_ATTRIBUTES (idx);
create index cmaEventRefIndex on EVENT_CUSTOM_ATTRIBUTES (EVENT_ID);
create index fwInfoToEventId on EVENT_FORWARDING_INFO (EVENT_ID);
create index indexOverAggrInProgress on EVENT_KPI_DELTAS (AGGR_IN_PROGRESS);
create index eventPropChangeHistLineIdx on EVENT_PROPERTY_CHANGE (HISTORY_LINE);
create index indexOverIdentifier on EVENT_SYNC_BUFFER (IDENTIFIER);
create index indexOverConfigMode on HEALTHCHECK_CONFIG (CONFIG_MODE);
create index indexOverNodeIdHealthCheck on HEALTHCHECK_CONFIG (NODE_ID);
create index histLineTimeChangedIndex on HISTORY_LINE (ID, TIME_CHANGED);
create index histLineEventRefIndex on HISTORY_LINE (EVENT_REF);
create index indexOverCompT on HISTORY_LINE (COMPONENT_TYPE);
create index idxHiOvTime on HI_CHANGE (TIMESTAMP);
create index idxHiOvTimeCiId on HI_CHANGE (CI_ID);
create index idxKpiOvTimeCiId on KPI_CHANGE (CI_ID);
create index idxKpiOvTime on KPI_CHANGE (TIMESTAMP);
alter table OAS_LDAP_GROUP_TO_USER_GROUP add constraint FK727D14752002CC52 foreign key (USERGROUP_ID) references
 OAS_USER_GROUP;
alter table OAS_PERMISSION_TO_ROLE add constraint PERMISSION_TO_ROLE foreign key (ROLE_ID) references OAS_ROLE;
alter table OAS_USER add constraint DEFAULT_USER_GROUP foreign key (EVENT_ASSIGNMENT_GROUP_ID) references OAS_USER_GROUP;
alter table OAS_USER_GROUP_TO_ROLE add constraint USER_GROUP_TO_ROLE foreign key (USERGROUP_ID) references
 OAS_USER_GROUP;
alter table OAS_USER_GROUP_TO_ROLE add constraint ROLE_TO_USER_GROUP foreign key (ROLE_ID) references OAS_ROLE;
alter table OAS_USER_GROUP_TO_ROLE add constraint USER_GROUP_TO_ROLE_FOR_TENANT foreign key (TENANT_ID) references
 OAS_TENANT;
alter table OAS_USER_GROUP_TO_USER_GROUP add constraint CHILD_UG_TO_PARENT_UG foreign key (CHILD_USER_GROUP_ID)
 references OAS_USER_GROUP;
alter table OAS_USER_GROUP_TO_USER_GROUP add constraint PARENT_UG_TO_CHILD_UG foreign key (PARENT_USER_GROUP_ID)
 references OAS_USER_GROUP;
alter table OAS_USER_TO_ROLE add constraint ROLE_TO_USER foreign key (ROLE_ID) references OAS_ROLE;
alter table OAS_USER_TO_ROLE add constraint USER_TO_ROLE foreign key (USER_ID) references OAS_USER;
alter table OAS_USER_TO_ROLE add constraint USER_TO_ROLE_FOR_TENANT foreign key (TENANT_ID) references OAS_TENANT;
alter table OAS_USER_TO_USER_GROUP add constraint USER_GROUP_TO_USER foreign key (USERGROUP_ID) references
 OAS_USER_GROUP;
alter table OAS_USER_TO_USER_GROUP add constraint USER_TO_USER_GROUP foreign key (USER_ID) references OAS_USER;
create index correlationsBySymptomId on POTENTIAL_CORRELATIONS (SYMPTOM_ID);
create table C000_AR_ACTION_NTF_RECIPIENTS (ACTION_ID varchar2(255 char) not null, RECIPIENT_ID number(10,0));
create table C000_AR_ACTION_NTF_TMPLS (ACTION_ID varchar2(255 char) not null, TEMPLATE_ID varchar2(255 char) not null,
 primary key (ACTION_ID, TEMPLATE_ID));
create table C000_AR_ACTION_RBK_MAPPINGS (ACTION_ID varchar2(255 char) not null, CI_TYPE varchar2(255 char) not null,
 RUNBOOK_ID varchar2(255 char) not null, LIST_IDX number(10,0) not null, primary key (ACTION_ID, LIST_IDX));
create table C000_AUTOMATION_RULES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CREATOR varchar2(255 char), PURPOSE varchar2(255 char) not null, ENABLED number(1,0) not null,
 LABEL varchar2(255 char) not null, DESCRIPTION clob, DURATION number(10,0), MAX_EXECUTIONS number(10,0),
 ARTIFACT_ORIGIN varchar2(255 char), FILTER varchar2(255 char), primary key (ID));
create table C000_AUTOMATION_RULE_ACTIONS (ID varchar2(255 char) not null, ACTION_TYPE varchar2(255 char) not null,
 VERSION number(10,0) not null, LIST_IDX number(10,0) not null, ENABLED number(1,0),
 AUTOMATION_RULE_ID varchar2(255 char), FORWARDING_TARGET varchar2(255 char), FORWARDING_TYPE varchar2(255 char),
 RBK_NAME varchar2(255 char), RBK_DESCRIPTION clob, MODIFY_XML_DEF clob, ASSIGN_GRP_ID varchar2(255 char),
 ASSIGN_USR_ID varchar2(255 char), SCRIPT_ID varchar2(255 char), primary key (ID));
create table C000_AUTO_GRANT_CONFIG (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ARTIFACT_ORIGIN varchar2(255 char), SCRIPT_DEFINITION varchar2(255 char) unique, primary key (ID));
create table C000_AUTO_GRANT_IP_RANGES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ENABLED number(1,0) not null, IP_START_ADDRESS varchar2(255 char) not null, IP_END_ADDRESS varchar2(255 char) not null,
 AUTO_GRANT_CONFIG varchar2(255 char), primary key (ID));
create table C000_A_TO_SRPT_D (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char), primary key (ID));
create table C000_CIT_GRAPH_FAM_MAPPINGS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CITYPE varchar2(30 char) not null, CI_ATTRIBUTE varchar2(255 char), PATTERN varchar2(255 char),
 REPLACEMENT varchar2(255 char), ARTIFACT_ORIGIN varchar2(255 char), primary key (ID), unique (CITYPE));
create table C000_CI_TQL_MAPPINGS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CI_TYPE varchar2(30 char) not null, VIEW_NAME varchar2(76 char) not null, PATTERN varchar2(255 char), DESCRIPTION clob,
 PRIORITY number(10,0), ARTIFACT_ORIGIN varchar2(255 char), primary key (ID), unique (CI_TYPE, VIEW_NAME, PATTERN));
create table C000_CONSRV (ID varchar2(255 char) not null, VERSION number(10,0) not null, LABEL varchar2(255 char),
 ACTIVE number(1,0), NAME varchar2(255 char) not null, DESCRIPTION clob, TYPE varchar2(255 char) not null,
 ARTIFACT_ORIGIN varchar2(255 char), DNS varchar2(255 char) not null, FWD_DYN_TOPO number(1,0), CI_ID varchar2(255 char),
 CI_TYPE varchar2(255 char), primary key (ID));
create table C000_CONSRV_ACTION (ID varchar2(255 char) not null, DISCRIMINATOR varchar2(255 char) not null,
 VERSION number(10,0) not null, TYPE varchar2(255 char), STATE varchar2(255 char), APM_SETUP_TOPOSYNC number(1,0),
 APM_SERVER_INTEGR number(1,0), APM_DO_SYNC number(1,0), CONSRV_ID varchar2(255 char), ACTION_KEY varchar2(255 char),
 primary key (ID));
create table C000_CONSRV_ACTION_MSGKEYS (ACTION_ID varchar2(255 char) not null, MSG_KEY varchar2(255 char));
create table C000_CONSRV_ALIAS (ID varchar2(255 char) not null, VERSION number(10,0) not null, LABEL varchar2(255 char),
 ACTIVE number(1,0), NAME varchar2(255 char) not null, DESCRIPTION clob, TYPE varchar2(255 char) not null,
 ARTIFACT_ORIGIN varchar2(255 char), CONSRV varchar2(255 char), primary key (ID));
create table C000_CONSRV_CERTIFICATES (ID varchar2(255 char) not null, VERSION number(10,0) not null, BIN_DATA blob,
 primary key (ID));
create table C000_CONSRV_DEFAULT_SERVER (ID varchar2(255 char) not null, SERVER_ID varchar2(255 char), primary key (ID));
create table C000_CONSRV_FEATURE (ID varchar2(255 char) not null, DISCRIMINATOR varchar2(255 char) not null,
 VERSION number(10,0) not null, PATH varchar2(255 char), PORT number(10,0), HTTPS number(1,0),
 USERNAME varchar2(255 char), PW varchar2(255 char), CONSRV_CERTIFICATE varchar2(255 char), ES_DM varchar2(255 char),
 ES_PDC number(10,0), ES_COREID varchar2(255 char), ES_SCRIPT varchar2(255 char), ES_USESCRIPT number(1,0),
 ES_MTT number(10,0), ES_TC number(1,0), ES_BULK_TRANS number(1,0), ES_BACKSYNC number(1,0),
 ES_BS_USER varchar2(255 char), ES_BS_PW varchar2(255 char), ES_KIND varchar2(255 char), ES_UP_KIND varchar2(255 char),
 ES_DOWNTIMESYNC number(1,0), ES_DATAFLOWPROBE varchar2(255 char), CD_VERSION varchar2(255 char),
 CD_OS varchar2(255 char), UI_TYPE varchar2(255 char), UI_DNSNAME varchar2(255 char), UI_QUERY varchar2(255 char),
 UI_USE_OTHER number(1,0), UI_OTHER varchar2(255 char), PF_PROXY_DNSNAME varchar2(255 char),
 FO_DNSNAME varchar2(255 char), TF_DEFAULT_ROUTING_DOMAIN varchar2(255 char), TF_RESYNC_TIME_INTERVAL number(10,0),
 CONSRV_ID varchar2(255 char), FEATURE_KEY varchar2(255 char), primary key (ID));
create table C000_CORRELATION_RULES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char),
 LABEL varchar2(255 char), DESCRIPTION clob, IS_ENABLED number(1,0), DURATION number(10,0), WEIGHT varchar2(255 char),
 primary key (ID), unique (NAME));
create table C000_CR_PATH_CONSTRAINTS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 LINK_TYPE varchar2(30 char) not null, START_VAR_ID varchar2(255 char) not null, END_VAR_ID varchar2(255 char) not null,
 primary key (ID), unique (LINK_TYPE, START_VAR_ID, END_VAR_ID));
create table C000_CR_SYMPTOMS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CORRELATION_RULE_ID varchar2(255 char) not null, ETI_INDICATOR varchar2(255 char), ETI_VALUE varchar2(255 char),
 VARIABLE varchar2(255 char), IS_CAUSE number(1,0), primary key (ID));
create table C000_CR_VARIABLES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CORRELATION_RULE_ID varchar2(255 char) not null, CI_TYPE varchar2(30 char) not null, primary key (ID));
create table C000_CTGFM_GRAPH_FAMILIES (CTGFM_ID varchar2(255 char) not null, GRAPH_FAMILY varchar2(255 char),
 ORDER_INDEX number(10,0) not null, primary key (CTGFM_ID, ORDER_INDEX));
create table C000_CUSTOMACTION_DEF (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C000_DASHBOARD_CONFIG (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, DESCRIPTION clob, XML_DEFINITION clob, XML_VERSION number(5,0),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C000_DOWNTIME_CONFIG (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ARTIFACT_ORIGIN varchar2(255 char), DT_CATEGORY_ID number(10,0) unique, SHOW_CONFIRM_DIALOG number(1,0),
 DT_LIFECYCLE_STATE varchar2(255 char), primary key (ID));
create table C000_DT_ACTIVE_STEPS (DT_CONFIG_ID varchar2(255 char) not null, STEP_NAME varchar2(255 char) not null,
 primary key (DT_CONFIG_ID, STEP_NAME));
create table C000_EA_SCRIPT_DEF (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C000_ESS_CONFIGS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ENABLED number(1,0) not null, UPPER_THRESHOLD number(10,0) not null, LOWER_THRESHOLD number(10,0) not null,
 TIME_INTERVAL_SEC number(10,0) not null, START_EVT_SEVERITY raw(255) not null, START_EVT_CATEGORY varchar2(255 char),
 START_EVT_SUBCATEGORY varchar2(255 char), START_CLOSES_END number(1,0) not null, END_EVT_SEVERITY raw(255) not null,
 END_EVT_CATEGORY varchar2(255 char), END_EVT_SUBCATEGORY varchar2(255 char), LOG_ONLY_END_EVT number(1,0) not null,
 ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char), primary key (ID));
create table C000_ESS_EXCEPTIONS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 APPLY_ORDER number(10,0), EXC_MODE varchar2(255 char) not null, ESS_ID varchar2(255 char),
 FILTER_ID varchar2(255 char) not null, primary key (ID));
create table C000_ESUP_RULE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CUSTOMER_ID number(10,0) not null, LABEL varchar2(255 char), DESCRIPTION clob, ACTIVE number(1,0) not null,
 filter varchar2(255 char) not null, ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char), primary key (ID));
create table C000_EVENT_NOTIFI_TEMPLATES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 LABEL varchar2(255 char) not null, BODY clob, SUBJECT varchar2(255 char), CHANNEL_TYPE number(10,0) not null,
 IS_DEFAULT_TEMPLATE number(1,0) not null, HTML_FORMAT number(1,0), ARTIFACT_ORIGIN varchar2(255 char),
 primary key (ID));
create table C000_EXT_INTF_SCRIPT_DEF (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C000_E_TO_SRPT_D (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 STEP_POS number(10,0) not null, ARTIFACT_ORIGIN varchar2(255 char), STEP_ID varchar2(255 char) not null,
 primary key (ID));
create table C000_FILTER_CONFIG (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, OWNERS_UUID varchar2(255 char) not null, SHARED number(1,0),
 PURPOSE varchar2(255 char), DESCRIPTION clob, XML_DEFINITION clob, XML_VERSION number(5,0),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C000_FILTER_CONFIG_ATTRS (FILTER_CONFIG_ID varchar2(255 char) not null, elt clob,
 idx varchar2(255 char) not null, primary key (FILTER_CONFIG_ID, idx));
create table C000_FORWARDING_SCRIPT_DEF (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C000_GROUP_FILTER_MAPPINGS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 FILTER_ID varchar2(255 char), GROUP_UUID varchar2(255 char) not null, MAPPING_ORDER number(10,0) not null,
 DESCRIPTION clob, VIEW_NAME varchar2(76 char), CREATOR varchar2(255 char), ARTIFACT_ORIGIN varchar2(255 char),
 primary key (ID));
create table C000_MAPPING_RULES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CREATOR_UUID varchar2(255 char), NAME varchar2(255 char), LABEL varchar2(255 char), DESCRIPTION clob,
 IS_ENABLED number(1,0), ALLOW_OVERRIDE number(1,0), RULE_ORDER number(10,0) not null,
 ARTIFACT_ORIGIN varchar2(255 char), ETI_INDICATOR varchar2(255 char), ETI_VALUE varchar2(255 char),
 FILTER_CONFIGURATIONS_ID varchar2(255 char), primary key (ID));
create table C000_RESOURCE_CONTAINER (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 RESOURCE_NAME varchar2(255 char) not null, CONTAINER_POS number(10,0) not null,
 DEFINITION_ID varchar2(255 char) not null, primary key (ID), unique (RESOURCE_NAME, DEFINITION_ID));
create table C000_RESOURCE_ENTRY (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ENTRY_NAME varchar2(255 char) not null, BIN_DATA blob not null, DATA_SIZE number(10,0) not null,
 RES_CONTAINER_ID varchar2(255 char) not null, primary key (ID));
create table C000_SBEC_EVTSET (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 APPLY_ORDER number(10,0) not null, NAME varchar2(255 char), RELATORS_AS_XML clob, RULE_ID varchar2(255 char),
 filter varchar2(255 char) not null, HOLD number(1,0), ACTION varchar2(255 char), DISCARD_CLOSED number(1,0),
 ATTRIBUTES_XML_DEF clob, WEIGHT varchar2(255 char), primary key (ID));
create table C000_SBEC_EVTSET_SYMPTOMS (EVTSET_ID varchar2(255 char) not null, SYMPTOMSET_ID varchar2(255 char) not null,
 primary key (EVTSET_ID, SYMPTOMSET_ID));
create table C000_SBEC_RULE (ID varchar2(255 char) not null, SCENARIO varchar2(255 char) not null,
 VERSION number(10,0) not null, APPLY_ORDER number(10,0) not null, LABEL varchar2(255 char), DESCRIPTION clob,
 ACTIVE number(1,0) not null, ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char),
 FILTERS_ORDERED number(1,0), TIME_INTERVAL number(10,0), CREATE_EVENT number(1,0), ATTRIBUTES_XML_DEF clob,
 WEIGHT varchar2(255 char), REPETITION_COUNT number(10,0), primary key (ID));
create table C000_SBEC_RULE_SYMPTOMSET_IDS (RULE_ID varchar2(255 char) not null,
 SYMPTOMSET_ID varchar2(255 char) not null, primary key (RULE_ID, SYMPTOMSET_ID));
create table C000_STEP_DEFINITION (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 stepName varchar2(255 char) not null, orderNumber number(10,0) not null, primary key (ID), unique (stepName));
create table C000_STORM_END_EVT_CAS (ESS_ID varchar2(255 char) not null, elt clob, idx varchar2(255 char) not null,
 primary key (ESS_ID, idx));
create table C000_STORM_START_EVT_CAS (ESS_ID varchar2(255 char) not null, elt clob, idx varchar2(255 char) not null,
 primary key (ESS_ID, idx));
create table C000_TOOL_CATEGORIES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, LABEL varchar2(255 char), DESCRIPTION varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID), unique (NAME));
create table C000_TOOL_DEFINITIONS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, LABEL varchar2(255 char), DESCRIPTION clob, CITYPE varchar2(30 char) not null,
 ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char), TOOL_CATEGORY_ID varchar2(255 char) not null,
 primary key (ID), unique (NAME));
create table C000_TOOL_DEF_CMDS (TOOL_DEF_ID varchar2(255 char) not null, NAME varchar2(255 char) not null,
 LABEL varchar2(255 char), DESCRIPTION clob, ACTIVE number(1,0), TYPE varchar2(255 char) not null, COMMAND clob,
 TARGET varchar2(255 char), USERNAME varchar2(255 char), PASSWORD varchar2(255 char), ARGUMENTS varchar2(255 char),
 ORDER_INDEX number(10,0) not null, primary key (TOOL_DEF_ID, ORDER_INDEX));
alter table C000_AR_ACTION_NTF_RECIPIENTS add constraint C000_RECIPIENTS_TO_ACTION foreign key (ACTION_ID) references
 C000_AUTOMATION_RULE_ACTIONS;
alter table C000_AR_ACTION_NTF_TMPLS add constraint C000_TEMPLATE_TO_ACTION foreign key (ACTION_ID) references
 C000_AUTOMATION_RULE_ACTIONS;
alter table C000_AR_ACTION_NTF_TMPLS add constraint C000_TEMPLATE_TO_RULE foreign key (TEMPLATE_ID) references
 C000_EVENT_NOTIFI_TEMPLATES;
alter table C000_AR_ACTION_RBK_MAPPINGS add constraint C000_RBK_MAP_TO_ACTION foreign key (ACTION_ID) references
 C000_AUTOMATION_RULE_ACTIONS;
alter table C000_AUTOMATION_RULES add constraint C000_FILTER_TO_AUTO_RULE foreign key (FILTER) references
 C000_FILTER_CONFIG;
alter table C000_AUTOMATION_RULE_ACTIONS add constraint C000_SCRIPT_REF_TO_ACTION foreign key (SCRIPT_ID) references
 C000_EA_SCRIPT_DEF;
alter table C000_AUTOMATION_RULE_ACTIONS add constraint C000_ACTIONS_TO_AUTO_RULE foreign key (AUTOMATION_RULE_ID)
 references C000_AUTOMATION_RULES;
alter table C000_AUTO_GRANT_CONFIG add constraint C000_SCRIPT_DEF_TO_CONFIG foreign key (SCRIPT_DEFINITION) references
 C000_A_TO_SRPT_D;
alter table C000_AUTO_GRANT_IP_RANGES add constraint C000_IP_RANGES_TO_CONFIG foreign key (AUTO_GRANT_CONFIG) references
 C000_AUTO_GRANT_CONFIG;
alter table C000_A_TO_SRPT_D add constraint C000_F_TO_SRPT_D1be66fbd foreign key (filterConfig) references
 C000_FILTER_CONFIG;
alter table C000_CONSRV_ACTION add constraint C000_CONSRV_ID_ACTION foreign key (CONSRV_ID) references C000_CONSRV;
alter table C000_CONSRV_ALIAS add constraint C000_CONSRV_ID foreign key (CONSRV) references C000_CONSRV;
alter table C000_CONSRV_FEATURE add constraint C000_CONSRV_ID_FEATURE foreign key (CONSRV_ID) references C000_CONSRV;
alter table C000_CONSRV_FEATURE add constraint C000_CONSRV_FEATURE_ID foreign key (CONSRV_CERTIFICATE) references
 C000_CONSRV_CERTIFICATES;
alter table C000_CR_PATH_CONSTRAINTS add constraint C000_PATH_CONST_TO_VAR_START foreign key (START_VAR_ID) references
 C000_CR_VARIABLES;
alter table C000_CR_PATH_CONSTRAINTS add constraint C000_PATH_CONST_TO_VAR_END foreign key (END_VAR_ID) references
 C000_CR_VARIABLES;
alter table C000_CR_SYMPTOMS add constraint C000_SYMPT_TO_VAR foreign key (VARIABLE) references C000_CR_VARIABLES;
alter table C000_CR_SYMPTOMS add constraint C000_SYMPT_TO_RULES foreign key (CORRELATION_RULE_ID) references
 C000_CORRELATION_RULES;
alter table C000_CR_VARIABLES add constraint C000_VARS_TO_RULES foreign key (CORRELATION_RULE_ID) references
 C000_CORRELATION_RULES;
alter table C000_CTGFM_GRAPH_FAMILIES add constraint C000_FAMILIES_TO_MAPPING foreign key (CTGFM_ID) references
 C000_CIT_GRAPH_FAM_MAPPINGS;
alter table C000_CUSTOMACTION_DEF add constraint C000_F_TO_SRPT_Dea30b59e foreign key (filterConfig) references
 C000_FILTER_CONFIG;
alter table C000_DT_ACTIVE_STEPS add constraint C000_STEPS_TO_DT_CONFIG foreign key (DT_CONFIG_ID) references
 C000_DOWNTIME_CONFIG;
alter table C000_EA_SCRIPT_DEF add constraint C000_F_TO_SRPT_D4ac84283 foreign key (filterConfig) references
 C000_FILTER_CONFIG;
alter table C000_ESS_EXCEPTIONS add constraint C000_EXCEPTIONS_TO_CONFIG foreign key (ESS_ID) references
 C000_ESS_CONFIGS;
alter table C000_ESS_EXCEPTIONS add constraint C000_FILTER_TO_CONFIG foreign key (FILTER_ID) references
 C000_FILTER_CONFIG;
alter table C000_ESUP_RULE add constraint C000_FILTER_TO_ESUP foreign key (filter) references C000_FILTER_CONFIG;
alter table C000_EXT_INTF_SCRIPT_DEF add constraint C000_F_TO_SRPT_D9d71f46a foreign key (filterConfig) references
 C000_FILTER_CONFIG;
alter table C000_E_TO_SRPT_D add constraint C000_F_TO_SRPT_D6f793ac1 foreign key (filterConfig) references
 C000_FILTER_CONFIG;
alter table C000_E_TO_SRPT_D add constraint C000_SCRIPT_DEFS_TO_STEP foreign key (STEP_ID) references
 C000_STEP_DEFINITION;
alter table C000_FILTER_CONFIG_ATTRS add constraint C000_ATTRS_TO_CONFIG foreign key (FILTER_CONFIG_ID) references
 C000_FILTER_CONFIG;
alter table C000_FORWARDING_SCRIPT_DEF add constraint C000_F_TO_SRPT_D3b83f682 foreign key (filterConfig) references
 C000_FILTER_CONFIG;
create index C000_indexOverOrder on C000_GROUP_FILTER_MAPPINGS (MAPPING_ORDER);
alter table C000_GROUP_FILTER_MAPPINGS add constraint C000_FILTER_TO_GROUP_MAPPING foreign key (FILTER_ID) references
 C000_FILTER_CONFIG;
alter table C000_MAPPING_RULES add constraint C000_FILTER_TO_MAPPING_RULE foreign key (FILTER_CONFIGURATIONS_ID)
 references C000_FILTER_CONFIG;
alter table C000_RESOURCE_ENTRY add constraint C000_ENTRIES_TO_CONTAINER foreign key (RES_CONTAINER_ID) references
 C000_RESOURCE_CONTAINER;
alter table C000_SBEC_EVTSET add constraint C000_FILTER_TO_EVTSETSPEC foreign key (filter) references C000_FILTER_CONFIG;
alter table C000_SBEC_EVTSET add constraint C000_SETS_TO_RULE foreign key (RULE_ID) references C000_SBEC_RULE;
alter table C000_SBEC_EVTSET_SYMPTOMS add constraint C000_SBEC_SYMPSET_TO_EVTSET foreign key (EVTSET_ID) references
 C000_SBEC_EVTSET;
alter table C000_SBEC_RULE_SYMPTOMSET_IDS add constraint C000_SBEC_SYMPSET_TO_RULE foreign key (RULE_ID) references
 C000_SBEC_RULE;
alter table C000_STORM_END_EVT_CAS add constraint C000_END_EVENT_TO_CONFIG foreign key (ESS_ID) references
 C000_ESS_CONFIGS;
alter table C000_STORM_START_EVT_CAS add constraint C000_START_EVENT_TO_CONFIG foreign key (ESS_ID) references
 C000_ESS_CONFIGS;
alter table C000_TOOL_DEFINITIONS add constraint C000_TOOL_CATEGORY_TO_TOOL_DEF foreign key (TOOL_CATEGORY_ID)
 references C000_TOOL_CATEGORIES;
alter table C000_TOOL_DEF_CMDS add constraint C000_TOOL_CMD_TO_TOOL_DEF foreign key (TOOL_DEF_ID) references
 C000_TOOL_DEFINITIONS;
create table C001_AR_ACTION_NTF_RECIPIENTS (ACTION_ID varchar2(255 char) not null, RECIPIENT_ID number(10,0));
create table C001_AR_ACTION_NTF_TMPLS (ACTION_ID varchar2(255 char) not null, TEMPLATE_ID varchar2(255 char) not null,
 primary key (ACTION_ID, TEMPLATE_ID));
create table C001_AR_ACTION_RBK_MAPPINGS (ACTION_ID varchar2(255 char) not null, CI_TYPE varchar2(255 char) not null,
 RUNBOOK_ID varchar2(255 char) not null, LIST_IDX number(10,0) not null, primary key (ACTION_ID, LIST_IDX));
create table C001_AUTOMATION_RULES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CREATOR varchar2(255 char), PURPOSE varchar2(255 char) not null, ENABLED number(1,0) not null,
 LABEL varchar2(255 char) not null, DESCRIPTION clob, DURATION number(10,0), MAX_EXECUTIONS number(10,0),
 ARTIFACT_ORIGIN varchar2(255 char), FILTER varchar2(255 char), primary key (ID));
create table C001_AUTOMATION_RULE_ACTIONS (ID varchar2(255 char) not null, ACTION_TYPE varchar2(255 char) not null,
 VERSION number(10,0) not null, LIST_IDX number(10,0) not null, ENABLED number(1,0),
 AUTOMATION_RULE_ID varchar2(255 char), FORWARDING_TARGET varchar2(255 char), FORWARDING_TYPE varchar2(255 char),
 RBK_NAME varchar2(255 char), RBK_DESCRIPTION clob, MODIFY_XML_DEF clob, ASSIGN_GRP_ID varchar2(255 char),
 ASSIGN_USR_ID varchar2(255 char), SCRIPT_ID varchar2(255 char), primary key (ID));
create table C001_AUTO_GRANT_CONFIG (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ARTIFACT_ORIGIN varchar2(255 char), SCRIPT_DEFINITION varchar2(255 char) unique, primary key (ID));
create table C001_AUTO_GRANT_IP_RANGES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ENABLED number(1,0) not null, IP_START_ADDRESS varchar2(255 char) not null, IP_END_ADDRESS varchar2(255 char) not null,
 AUTO_GRANT_CONFIG varchar2(255 char), primary key (ID));
create table C001_A_TO_SRPT_D (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char), primary key (ID));
create table C001_CIT_GRAPH_FAM_MAPPINGS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CITYPE varchar2(30 char) not null, CI_ATTRIBUTE varchar2(255 char), PATTERN varchar2(255 char),
 REPLACEMENT varchar2(255 char), ARTIFACT_ORIGIN varchar2(255 char), primary key (ID), unique (CITYPE));
create table C001_CI_TQL_MAPPINGS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CI_TYPE varchar2(30 char) not null, VIEW_NAME varchar2(76 char) not null, PATTERN varchar2(255 char), DESCRIPTION clob,
 PRIORITY number(10,0), ARTIFACT_ORIGIN varchar2(255 char), primary key (ID), unique (CI_TYPE, VIEW_NAME, PATTERN));
create table C001_CONSRV (ID varchar2(255 char) not null, VERSION number(10,0) not null, LABEL varchar2(255 char),
 ACTIVE number(1,0), NAME varchar2(255 char) not null, DESCRIPTION clob, TYPE varchar2(255 char) not null,
 ARTIFACT_ORIGIN varchar2(255 char), DNS varchar2(255 char) not null, FWD_DYN_TOPO number(1,0), CI_ID varchar2(255 char),
 CI_TYPE varchar2(255 char), primary key (ID));
create table C001_CONSRV_ACTION (ID varchar2(255 char) not null, DISCRIMINATOR varchar2(255 char) not null,
 VERSION number(10,0) not null, TYPE varchar2(255 char), STATE varchar2(255 char), APM_SETUP_TOPOSYNC number(1,0),
 APM_SERVER_INTEGR number(1,0), APM_DO_SYNC number(1,0), CONSRV_ID varchar2(255 char), ACTION_KEY varchar2(255 char),
 primary key (ID));
create table C001_CONSRV_ACTION_MSGKEYS (ACTION_ID varchar2(255 char) not null, MSG_KEY varchar2(255 char));
create table C001_CONSRV_ALIAS (ID varchar2(255 char) not null, VERSION number(10,0) not null, LABEL varchar2(255 char),
 ACTIVE number(1,0), NAME varchar2(255 char) not null, DESCRIPTION clob, TYPE varchar2(255 char) not null,
 ARTIFACT_ORIGIN varchar2(255 char), CONSRV varchar2(255 char), primary key (ID));
create table C001_CONSRV_CERTIFICATES (ID varchar2(255 char) not null, VERSION number(10,0) not null, BIN_DATA blob,
 primary key (ID));
create table C001_CONSRV_DEFAULT_SERVER (ID varchar2(255 char) not null, SERVER_ID varchar2(255 char), primary key (ID));
create table C001_CONSRV_FEATURE (ID varchar2(255 char) not null, DISCRIMINATOR varchar2(255 char) not null,
 VERSION number(10,0) not null, PATH varchar2(255 char), PORT number(10,0), HTTPS number(1,0),
 USERNAME varchar2(255 char), PW varchar2(255 char), CONSRV_CERTIFICATE varchar2(255 char), ES_DM varchar2(255 char),
 ES_PDC number(10,0), ES_COREID varchar2(255 char), ES_SCRIPT varchar2(255 char), ES_USESCRIPT number(1,0),
 ES_MTT number(10,0), ES_TC number(1,0), ES_BULK_TRANS number(1,0), ES_BACKSYNC number(1,0),
 ES_BS_USER varchar2(255 char), ES_BS_PW varchar2(255 char), ES_KIND varchar2(255 char), ES_UP_KIND varchar2(255 char),
 ES_DOWNTIMESYNC number(1,0), ES_DATAFLOWPROBE varchar2(255 char), CD_VERSION varchar2(255 char),
 CD_OS varchar2(255 char), UI_TYPE varchar2(255 char), UI_DNSNAME varchar2(255 char), UI_QUERY varchar2(255 char),
 UI_USE_OTHER number(1,0), UI_OTHER varchar2(255 char), PF_PROXY_DNSNAME varchar2(255 char),
 FO_DNSNAME varchar2(255 char), TF_DEFAULT_ROUTING_DOMAIN varchar2(255 char), TF_RESYNC_TIME_INTERVAL number(10,0),
 CONSRV_ID varchar2(255 char), FEATURE_KEY varchar2(255 char), primary key (ID));
create table C001_CORRELATION_RULES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char),
 LABEL varchar2(255 char), DESCRIPTION clob, IS_ENABLED number(1,0), DURATION number(10,0), WEIGHT varchar2(255 char),
 primary key (ID), unique (NAME));
create table C001_CR_PATH_CONSTRAINTS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 LINK_TYPE varchar2(30 char) not null, START_VAR_ID varchar2(255 char) not null, END_VAR_ID varchar2(255 char) not null,
 primary key (ID), unique (LINK_TYPE, START_VAR_ID, END_VAR_ID));
create table C001_CR_SYMPTOMS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CORRELATION_RULE_ID varchar2(255 char) not null, ETI_INDICATOR varchar2(255 char), ETI_VALUE varchar2(255 char),
 VARIABLE varchar2(255 char), IS_CAUSE number(1,0), primary key (ID));
create table C001_CR_VARIABLES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CORRELATION_RULE_ID varchar2(255 char) not null, CI_TYPE varchar2(30 char) not null, primary key (ID));
create table C001_CTGFM_GRAPH_FAMILIES (CTGFM_ID varchar2(255 char) not null, GRAPH_FAMILY varchar2(255 char),
 ORDER_INDEX number(10,0) not null, primary key (CTGFM_ID, ORDER_INDEX));
create table C001_CUSTOMACTION_DEF (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C001_DASHBOARD_CONFIG (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, DESCRIPTION clob, XML_DEFINITION clob, XML_VERSION number(5,0),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C001_DOWNTIME_CONFIG (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ARTIFACT_ORIGIN varchar2(255 char), DT_CATEGORY_ID number(10,0) unique, SHOW_CONFIRM_DIALOG number(1,0),
 DT_LIFECYCLE_STATE varchar2(255 char), primary key (ID));
create table C001_DT_ACTIVE_STEPS (DT_CONFIG_ID varchar2(255 char) not null, STEP_NAME varchar2(255 char) not null,
 primary key (DT_CONFIG_ID, STEP_NAME));
create table C001_EA_SCRIPT_DEF (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C001_ESS_CONFIGS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ENABLED number(1,0) not null, UPPER_THRESHOLD number(10,0) not null, LOWER_THRESHOLD number(10,0) not null,
 TIME_INTERVAL_SEC number(10,0) not null, START_EVT_SEVERITY raw(255) not null, START_EVT_CATEGORY varchar2(255 char),
 START_EVT_SUBCATEGORY varchar2(255 char), START_CLOSES_END number(1,0) not null, END_EVT_SEVERITY raw(255) not null,
 END_EVT_CATEGORY varchar2(255 char), END_EVT_SUBCATEGORY varchar2(255 char), LOG_ONLY_END_EVT number(1,0) not null,
 ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char), primary key (ID));
create table C001_ESS_EXCEPTIONS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 APPLY_ORDER number(10,0), EXC_MODE varchar2(255 char) not null, ESS_ID varchar2(255 char),
 FILTER_ID varchar2(255 char) not null, primary key (ID));
create table C001_ESUP_RULE (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CUSTOMER_ID number(10,0) not null, LABEL varchar2(255 char), DESCRIPTION clob, ACTIVE number(1,0) not null,
 filter varchar2(255 char) not null, ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char), primary key (ID));
create table C001_EVENT_NOTIFI_TEMPLATES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 LABEL varchar2(255 char) not null, BODY clob, SUBJECT varchar2(255 char), CHANNEL_TYPE number(10,0) not null,
 IS_DEFAULT_TEMPLATE number(1,0) not null, HTML_FORMAT number(1,0), ARTIFACT_ORIGIN varchar2(255 char),
 primary key (ID));
create table C001_EXT_INTF_SCRIPT_DEF (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C001_E_TO_SRPT_D (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 STEP_POS number(10,0) not null, ARTIFACT_ORIGIN varchar2(255 char), STEP_ID varchar2(255 char) not null,
 primary key (ID));
create table C001_FILTER_CONFIG (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, OWNERS_UUID varchar2(255 char) not null, SHARED number(1,0),
 PURPOSE varchar2(255 char), DESCRIPTION clob, XML_DEFINITION clob, XML_VERSION number(5,0),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C001_FILTER_CONFIG_ATTRS (FILTER_CONFIG_ID varchar2(255 char) not null, elt clob,
 idx varchar2(255 char) not null, primary key (FILTER_CONFIG_ID, idx));
create table C001_FORWARDING_SCRIPT_DEF (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 SCRIPT_NAME varchar2(255 char) not null, SCRIPT clob not null, enabled number(1,0), readOnly number(1,0),
 timeout number(10,0), description clob, CREATOR varchar2(255 char), filterConfig varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID));
create table C001_GROUP_FILTER_MAPPINGS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 FILTER_ID varchar2(255 char), GROUP_UUID varchar2(255 char) not null, MAPPING_ORDER number(10,0) not null,
 DESCRIPTION clob, VIEW_NAME varchar2(76 char), CREATOR varchar2(255 char), ARTIFACT_ORIGIN varchar2(255 char),
 primary key (ID));
create table C001_MAPPING_RULES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 CREATOR_UUID varchar2(255 char), NAME varchar2(255 char), LABEL varchar2(255 char), DESCRIPTION clob,
 IS_ENABLED number(1,0), ALLOW_OVERRIDE number(1,0), RULE_ORDER number(10,0) not null,
 ARTIFACT_ORIGIN varchar2(255 char), ETI_INDICATOR varchar2(255 char), ETI_VALUE varchar2(255 char),
 FILTER_CONFIGURATIONS_ID varchar2(255 char), primary key (ID));
create table C001_RESOURCE_CONTAINER (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 RESOURCE_NAME varchar2(255 char) not null, CONTAINER_POS number(10,0) not null,
 DEFINITION_ID varchar2(255 char) not null, primary key (ID), unique (RESOURCE_NAME, DEFINITION_ID));
create table C001_RESOURCE_ENTRY (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 ENTRY_NAME varchar2(255 char) not null, BIN_DATA blob not null, DATA_SIZE number(10,0) not null,
 RES_CONTAINER_ID varchar2(255 char) not null, primary key (ID));
create table C001_SBEC_EVTSET (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 APPLY_ORDER number(10,0) not null, NAME varchar2(255 char), RELATORS_AS_XML clob, RULE_ID varchar2(255 char),
 filter varchar2(255 char) not null, HOLD number(1,0), ACTION varchar2(255 char), DISCARD_CLOSED number(1,0),
 ATTRIBUTES_XML_DEF clob, WEIGHT varchar2(255 char), primary key (ID));
create table C001_SBEC_EVTSET_SYMPTOMS (EVTSET_ID varchar2(255 char) not null, SYMPTOMSET_ID varchar2(255 char) not null,
 primary key (EVTSET_ID, SYMPTOMSET_ID));
create table C001_SBEC_RULE (ID varchar2(255 char) not null, SCENARIO varchar2(255 char) not null,
 VERSION number(10,0) not null, APPLY_ORDER number(10,0) not null, LABEL varchar2(255 char), DESCRIPTION clob,
 ACTIVE number(1,0) not null, ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char),
 FILTERS_ORDERED number(1,0), TIME_INTERVAL number(10,0), CREATE_EVENT number(1,0), ATTRIBUTES_XML_DEF clob,
 WEIGHT varchar2(255 char), REPETITION_COUNT number(10,0), primary key (ID));
create table C001_SBEC_RULE_SYMPTOMSET_IDS (RULE_ID varchar2(255 char) not null,
 SYMPTOMSET_ID varchar2(255 char) not null, primary key (RULE_ID, SYMPTOMSET_ID));
create table C001_STEP_DEFINITION (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 stepName varchar2(255 char) not null, orderNumber number(10,0) not null, primary key (ID), unique (stepName));
create table C001_STORM_END_EVT_CAS (ESS_ID varchar2(255 char) not null, elt clob, idx varchar2(255 char) not null,
 primary key (ESS_ID, idx));
create table C001_STORM_START_EVT_CAS (ESS_ID varchar2(255 char) not null, elt clob, idx varchar2(255 char) not null,
 primary key (ESS_ID, idx));
create table C001_TOOL_CATEGORIES (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, LABEL varchar2(255 char), DESCRIPTION varchar2(255 char),
 ARTIFACT_ORIGIN varchar2(255 char), primary key (ID), unique (NAME));
create table C001_TOOL_DEFINITIONS (ID varchar2(255 char) not null, VERSION number(10,0) not null,
 NAME varchar2(255 char) not null, LABEL varchar2(255 char), DESCRIPTION clob, CITYPE varchar2(30 char) not null,
 ARTIFACT_ORIGIN varchar2(255 char), CREATOR varchar2(255 char), TOOL_CATEGORY_ID varchar2(255 char) not null,
 primary key (ID), unique (NAME));
create table C001_TOOL_DEF_CMDS (TOOL_DEF_ID varchar2(255 char) not null, NAME varchar2(255 char) not null,
 LABEL varchar2(255 char), DESCRIPTION clob, ACTIVE number(1,0), TYPE varchar2(255 char) not null, COMMAND clob,
 TARGET varchar2(255 char), USERNAME varchar2(255 char), PASSWORD varchar2(255 char), ARGUMENTS varchar2(255 char),
 ORDER_INDEX number(10,0) not null, primary key (TOOL_DEF_ID, ORDER_INDEX));
alter table C001_AR_ACTION_NTF_RECIPIENTS add constraint C001_RECIPIENTS_TO_ACTION foreign key (ACTION_ID) references
 C001_AUTOMATION_RULE_ACTIONS;
alter table C001_AR_ACTION_NTF_TMPLS add constraint C001_TEMPLATE_TO_ACTION foreign key (ACTION_ID) references
 C001_AUTOMATION_RULE_ACTIONS;
alter table C001_AR_ACTION_NTF_TMPLS add constraint C001_TEMPLATE_TO_RULE foreign key (TEMPLATE_ID) references
 C001_EVENT_NOTIFI_TEMPLATES;
alter table C001_AR_ACTION_RBK_MAPPINGS add constraint C001_RBK_MAP_TO_ACTION foreign key (ACTION_ID) references
 C001_AUTOMATION_RULE_ACTIONS;
alter table C001_AUTOMATION_RULES add constraint C001_FILTER_TO_AUTO_RULE foreign key (FILTER) references
 C001_FILTER_CONFIG;
alter table C001_AUTOMATION_RULE_ACTIONS add constraint C001_SCRIPT_REF_TO_ACTION foreign key (SCRIPT_ID) references
 C001_EA_SCRIPT_DEF;
alter table C001_AUTOMATION_RULE_ACTIONS add constraint C001_ACTIONS_TO_AUTO_RULE foreign key (AUTOMATION_RULE_ID)
 references C001_AUTOMATION_RULES;
alter table C001_AUTO_GRANT_CONFIG add constraint C001_SCRIPT_DEF_TO_CONFIG foreign key (SCRIPT_DEFINITION) references
 C001_A_TO_SRPT_D;
alter table C001_AUTO_GRANT_IP_RANGES add constraint C001_IP_RANGES_TO_CONFIG foreign key (AUTO_GRANT_CONFIG) references
 C001_AUTO_GRANT_CONFIG;
alter table C001_A_TO_SRPT_D add constraint C001_F_TO_SRPT_D1be66fbd foreign key (filterConfig) references
 C001_FILTER_CONFIG;
alter table C001_CONSRV_ACTION add constraint C001_CONSRV_ID_ACTION foreign key (CONSRV_ID) references C001_CONSRV;
alter table C001_CONSRV_ALIAS add constraint C001_CONSRV_ID foreign key (CONSRV) references C001_CONSRV;
alter table C001_CONSRV_FEATURE add constraint C001_CONSRV_ID_FEATURE foreign key (CONSRV_ID) references C001_CONSRV;
alter table C001_CONSRV_FEATURE add constraint C001_CONSRV_FEATURE_ID foreign key (CONSRV_CERTIFICATE) references
 C001_CONSRV_CERTIFICATES;
alter table C001_CR_PATH_CONSTRAINTS add constraint C001_PATH_CONST_TO_VAR_START foreign key (START_VAR_ID) references
 C001_CR_VARIABLES;
alter table C001_CR_PATH_CONSTRAINTS add constraint C001_PATH_CONST_TO_VAR_END foreign key (END_VAR_ID) references
 C001_CR_VARIABLES;
alter table C001_CR_SYMPTOMS add constraint C001_SYMPT_TO_VAR foreign key (VARIABLE) references C001_CR_VARIABLES;
alter table C001_CR_SYMPTOMS add constraint C001_SYMPT_TO_RULES foreign key (CORRELATION_RULE_ID) references
 C001_CORRELATION_RULES;
alter table C001_CR_VARIABLES add constraint C001_VARS_TO_RULES foreign key (CORRELATION_RULE_ID) references
 C001_CORRELATION_RULES;
alter table C001_CTGFM_GRAPH_FAMILIES add constraint C001_FAMILIES_TO_MAPPING foreign key (CTGFM_ID) references
 C001_CIT_GRAPH_FAM_MAPPINGS;
alter table C001_CUSTOMACTION_DEF add constraint C001_F_TO_SRPT_Dea30b59e foreign key (filterConfig) references
 C001_FILTER_CONFIG;
alter table C001_DT_ACTIVE_STEPS add constraint C001_STEPS_TO_DT_CONFIG foreign key (DT_CONFIG_ID) references
 C001_DOWNTIME_CONFIG;
alter table C001_EA_SCRIPT_DEF add constraint C001_F_TO_SRPT_D4ac84283 foreign key (filterConfig) references
 C001_FILTER_CONFIG;
alter table C001_ESS_EXCEPTIONS add constraint C001_EXCEPTIONS_TO_CONFIG foreign key (ESS_ID) references
 C001_ESS_CONFIGS;
alter table C001_ESS_EXCEPTIONS add constraint C001_FILTER_TO_CONFIG foreign key (FILTER_ID) references
 C001_FILTER_CONFIG;
alter table C001_ESUP_RULE add constraint C001_FILTER_TO_ESUP foreign key (filter) references C001_FILTER_CONFIG;
alter table C001_EXT_INTF_SCRIPT_DEF add constraint C001_F_TO_SRPT_D9d71f46a foreign key (filterConfig) references
 C001_FILTER_CONFIG;
alter table C001_E_TO_SRPT_D add constraint C001_F_TO_SRPT_D6f793ac1 foreign key (filterConfig) references
 C001_FILTER_CONFIG;
alter table C001_E_TO_SRPT_D add constraint C001_SCRIPT_DEFS_TO_STEP foreign key (STEP_ID) references
 C001_STEP_DEFINITION;
alter table C001_FILTER_CONFIG_ATTRS add constraint C001_ATTRS_TO_CONFIG foreign key (FILTER_CONFIG_ID) references
 C001_FILTER_CONFIG;
alter table C001_FORWARDING_SCRIPT_DEF add constraint C001_F_TO_SRPT_D3b83f682 foreign key (filterConfig) references
 C001_FILTER_CONFIG;
create index C001_indexOverOrder on C001_GROUP_FILTER_MAPPINGS (MAPPING_ORDER);
alter table C001_GROUP_FILTER_MAPPINGS add constraint C001_FILTER_TO_GROUP_MAPPING foreign key (FILTER_ID) references
 C001_FILTER_CONFIG;
alter table C001_MAPPING_RULES add constraint C001_FILTER_TO_MAPPING_RULE foreign key (FILTER_CONFIGURATIONS_ID)
 references C001_FILTER_CONFIG;
alter table C001_RESOURCE_ENTRY add constraint C001_ENTRIES_TO_CONTAINER foreign key (RES_CONTAINER_ID) references
 C001_RESOURCE_CONTAINER;
alter table C001_SBEC_EVTSET add constraint C001_FILTER_TO_EVTSETSPEC foreign key (filter) references C001_FILTER_CONFIG;
alter table C001_SBEC_EVTSET add constraint C001_SETS_TO_RULE foreign key (RULE_ID) references C001_SBEC_RULE;
alter table C001_SBEC_EVTSET_SYMPTOMS add constraint C001_SBEC_SYMPSET_TO_EVTSET foreign key (EVTSET_ID) references
 C001_SBEC_EVTSET;
alter table C001_SBEC_RULE_SYMPTOMSET_IDS add constraint C001_SBEC_SYMPSET_TO_RULE foreign key (RULE_ID) references
 C001_SBEC_RULE;
alter table C001_STORM_END_EVT_CAS add constraint C001_END_EVENT_TO_CONFIG foreign key (ESS_ID) references
 C001_ESS_CONFIGS;
alter table C001_STORM_START_EVT_CAS add constraint C001_START_EVENT_TO_CONFIG foreign key (ESS_ID) references
 C001_ESS_CONFIGS;
alter table C001_TOOL_DEFINITIONS add constraint C001_TOOL_CATEGORY_TO_TOOL_DEF foreign key (TOOL_CATEGORY_ID)
 references C001_TOOL_CATEGORIES;
alter table C001_TOOL_DEF_CMDS add constraint C001_TOOL_CMD_TO_TOOL_DEF foreign key (TOOL_DEF_ID) references
 C001_TOOL_DEFINITIONS;


-- V10.00.172.2__MA_Oracle_SchemaCreation.sql

CREATE TABLE DATABASECHANGELOGLOCK (ID INTEGER NOT NULL, LOCKED NUMBER(1) NOT NULL, LOCKGRANTED TIMESTAMP,
 LOCKEDBY VARCHAR2(255), CONSTRAINT PK_DATABASECHANGELOGLOCK PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOGLOCK (ID, LOCKED) VALUES (1, 0);
CREATE TABLE DATABASECHANGELOG (ID VARCHAR2(63) NOT NULL, AUTHOR VARCHAR2(63) NOT NULL, FILENAME VARCHAR2(200) NOT NULL,
 DATEEXECUTED TIMESTAMP NOT NULL, ORDEREXECUTED INTEGER NOT NULL, EXECTYPE VARCHAR2(10) NOT NULL, MD5SUM VARCHAR2(35),
 DESCRIPTION VARCHAR2(255), COMMENTS VARCHAR2(255), TAG VARCHAR2(255), LIQUIBASE VARCHAR2(20),
 CONSTRAINT PK_DATABASECHANGELOG PRIMARY KEY (ID, AUTHOR, FILENAME));
CREATE TABLE CFG_ASPECT (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, LABEL NVARCHAR2(255) NOT NULL,
 PARENTFOLDER_ID NVARCHAR2(255), IS_STUB NUMBER(1) NOT NULL, CONSTRAINT CONSTRAINT_5 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-1', '2.0.5', '3:eb2a6f31b9fd37634853dfd44efcf4f7', 1);
CREATE TABLE CFG_ASPECTVERSION (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, CREATEDBY NVARCHAR2(255) NOT NULL,
 DATECREATED TIMESTAMP NOT NULL, DESCRIPTION CLOB, VER_MAJOR NUMBER(38,0) NOT NULL, VER_MINOR NUMBER(38,0) NOT NULL,
 NODE_COMPATIBLE NUMBER(1), IS_STUB NUMBER(1) NOT NULL, VER_INFO CLOB, ASPECT_ID NVARCHAR2(255) NOT NULL,
 CONSTRAINT CONSTRAINT_1 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-2', '2.0.5', '3:df4d879d0c5d95c9dbd2ff30770b3aa5', 2);
CREATE TABLE CFG_ASSIGNMENT (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, ASSIGNED_BY NVARCHAR2(255),
 CI_REF NVARCHAR2(255) NOT NULL, DATE_CREATED TIMESTAMP NOT NULL, LAST_UPDATED TIMESTAMP NOT NULL,
 LAST_UPDATED_BY NVARCHAR2(255), STATE NUMBER(1) NOT NULL, CLASS NVARCHAR2(255) NOT NULL, MTVER_ID NVARCHAR2(255),
 INSTR_DEPL NVARCHAR2(255), IS_PROXY_ASSIGNMENT NUMBER(1), INSTR_ID NVARCHAR2(255), ASPECTVER_ID NVARCHAR2(255),
 TMPL_DEPL NVARCHAR2(255), TMPL_VER_ID NVARCHAR2(255), TUNED_ATTRS INTEGER, CONSTRAINT CONSTRAINT_12 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-3', '2.0.5', '3:92493856554ed6f442c3c668e632a1d1', 3);
CREATE TABLE CFG_ASSIGNMENTDEPENDENCY (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, CHILD_ID NVARCHAR2(255),
 PARENT_ID NVARCHAR2(255), TOPO_PATH NVARCHAR2(255), CONSTRAINT CONSTRAINT_E PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-4', '2.0.5', '3:2f6342b7d1004a5c30b5f05ceb67e724', 4);
CREATE TABLE CFG_AT_ASPAUTOASGN_VIEWS (ASPECTAUTO_ASSGN_ID NVARCHAR2(255) NOT NULL, VIEW_NAME NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-5', '2.0.5', '3:97131ed9730bd80044dfc45fd9daa9b8', 5);
CREATE TABLE CFG_AT_ASPVERS_ASPVERS (ASPECTVERSION_ID NVARCHAR2(255) NOT NULL, CHILDASPECTVERSION_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-6', '2.0.5', '3:94c0931383e7e4aaa1e40bf822253765', 6);
CREATE TABLE CFG_AT_ASPVERS_CITYPE (ASPECTVERSION_ID NVARCHAR2(255) NOT NULL, CI_TYPES_STRING NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-7', '2.0.5', '3:1dfad00b6d77e9b57dcab9ae4cbbfb2c', 7);
CREATE TABLE CFG_AT_ASPVERS_INSTR (ASPECTVERSION_ID NVARCHAR2(255) NOT NULL, INSTRUMENTATION_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-8', '2.0.5', '3:4fac85eafb65ca011658d543f29a6449', 8);
CREATE TABLE CFG_AT_ASPVERS_TMPLVERS (ASPECTVERSION_ID NVARCHAR2(255) NOT NULL, TMPLVERSION_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-9', '2.0.5', '3:7f7952f3022c00eb9abb457c079399e7', 9);
CREATE TABLE CFG_AT_CONDITION_OSTYPE (CONDITION_ID NVARCHAR2(255) NOT NULL, OSTYPE_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-10', '2.0.5', '3:0ca7b1f4ff7c4c4ad6f0e49c896ed806', 10);
CREATE TABLE CFG_AT_GRPPARAM_PARAM (GROUPPARAM_ID NVARCHAR2(255) NOT NULL, PARAM_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-11', '2.0.5', '3:e48e4fb2d9947604d52d1358af6e371d', 11);
CREATE TABLE CFG_AT_INSTRDEPL_ASGN (INSTRDEPLOYMENT_ID NVARCHAR2(255) NOT NULL, ASSIGNMENT_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-12', '2.0.5', '3:4a396153871564ed3811881075e3ece9', 12);
CREATE TABLE CFG_AT_MTAUTOASGN_VIEWS (MGMTTMPLAUTO_ASSGN_ID NVARCHAR2(255) NOT NULL, VIEW_NAME NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-13', '2.0.5', '3:0345eda5d9f2a77db10d0f30549df5de', 13);
CREATE TABLE CFG_AT_PARAM_ENUMVAL (PARAMETER_ID NVARCHAR2(255), ENUM_VALUES_STRING NVARCHAR2(255),
 ENUM_VALUES_IDX INTEGER);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-14', '2.0.5', '3:e05c4a23911dc3d1c67b0f77f1b2023f', 14);
CREATE TABLE CFG_AT_TGAUTOASGN_CICOLL (TMPLGRPAUTO_ASSGN_ID NVARCHAR2(255) NOT NULL, CI_COLLECTION NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-15', '2.0.5', '3:39476bce8f3fbee4e7628949e3b75d0d', 15);
CREATE TABLE CFG_AT_TMPL_TMPLDEPLOY (TEMPLATE_ID NVARCHAR2(255) NOT NULL, TMPL_DEPLOYMENT_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-16', '2.0.5', '3:ef07c7b7cb991f5ebb3fd0183d9c69ff', 16);
CREATE TABLE CFG_AT_TMPL_TMPLGRP_LATEST (TEMPLATE_ID NVARCHAR2(255) NOT NULL, TMPLGROUP_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-17', '2.0.5', '3:bbd509c8ac4876d101922bc71f305758', 17);
CREATE TABLE CFG_AT_TMPL_TMPLGRP_MINLATEST (TEMPLATE_ID NVARCHAR2(255) NOT NULL, TMPLGROUP_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-18', '2.0.5', '3:1d86bf08f4dc3577b7adeb802058a8c0', 18);
CREATE TABLE CFG_AT_TMPLDEPL_ASGN (TMPL_DEPLOYMENT_ID NVARCHAR2(255) NOT NULL, ASSIGNMENT_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-19', '2.0.5', '3:ab39ecb8919d5397892d84fa3a099716', 19);
CREATE TABLE CFG_AT_TMPLGRP_TMPLVER_CHILD (TMPLGROUP_ID NVARCHAR2(255) NOT NULL, TMPLVERSION_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-20', '2.0.5', '3:7517843e67a2e959039a93afc4210caa', 20);
CREATE TABLE CFG_AT_TMPLVER_INSTR (TMPLVERSION_ID NVARCHAR2(255) NOT NULL, INSTRUMENTATION_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-21', '2.0.5', '3:71f9268ce489f508b7471426d7fdae92', 21);
CREATE TABLE CFG_AT_TMPLVER_OSTYPE (TMPLVERSION_ID NVARCHAR2(255) NOT NULL, OSTYPE_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-22', '2.0.5', '3:b522c0d5152ed1dcc9f8de7372cba39b', 22);
CREATE TABLE CFG_AUTOASSIGNMENT (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, STATE NUMBER(1) NOT NULL,
 CLASS NVARCHAR2(255) NOT NULL, MGMTTEMPLATE_VER_ID NVARCHAR2(255), TMPLGRP_ID NVARCHAR2(255),
 ASPECT_VER_ID NVARCHAR2(255), CONSTRAINT CONSTRAINT_C PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-23', '2.0.5', '3:58847e08604e6230c8f03f98c06c1f56', 23);
CREATE TABLE CFG_CIREFERENCE (ID NVARCHAR2(255) NOT NULL, VERSION NUMBER(38,0) NOT NULL, CI_NAME CLOB,
 CI_TYPE NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_58 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-24', '2.0.5', '3:bb53610ddd57ccc8dbc92a3bf1d62ae5', 24);
CREATE TABLE CFG_CONDITION (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, CIATTRMATCHOPERATOR NVARCHAR2(255),
 CIATTRNAME NVARCHAR2(255), CIATTRVALUE NVARCHAR2(255), CITYPE NVARCHAR2(255), CITYPEMATCHOPERATOR NVARCHAR2(255),
 CLASS NVARCHAR2(255) NOT NULL, MODELPROPERTY NVARCHAR2(255), ORDER_NUM INTEGER, PARAMETER NVARCHAR2(255), VALUE CLOB,
 ASPECT_VERSION NVARCHAR2(255), TEMPLATE_VERSION NVARCHAR2(255), CONSTRAINT CONSTRAINT_EC PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-25', '2.0.5', '3:edc5f3d6c7f11feedc360eca016fe04a', 25);
CREATE TABLE CFG_CONFIGFOLDER (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, DESCRIPTION CLOB,
 LABEL NVARCHAR2(255) NOT NULL, PARENTFOLDER_ID NVARCHAR2(255), CONSTRAINT CONSTRAINT_7 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-26', '2.0.5', '3:582453079bc74742cba3a85cc4ea9189', 26);
CREATE TABLE CFG_DELETEDASSIGNMENTS (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL,
 DEL_ASSIGN_UUID NVARCHAR2(255) NOT NULL, TMPL_DEPL_ID NVARCHAR2(255) NOT NULL,
 CONSTRAINT CONSTRAINT_B PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-27', '2.0.5', '3:315fd75aacf2466917d3569783b028ae', 27);
CREATE TABLE CFG_DEPL_INSTPARAMVALUE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, INSTANCENAME CLOB,
 INSTANCE_VALUE_ORDER INTEGER NOT NULL, PARAMID NVARCHAR2(255) NOT NULL, TMPLDEPL_ID NVARCHAR2(255) NOT NULL,
 CONSTRAINT CONSTRAINT_6 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-28', '2.0.5', '3:88cbf5a1f0839f4274b62bc2c2930d2e', 28);
CREATE TABLE CFG_DEPL_PARAMVALUE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, PARAMID NVARCHAR2(255) NOT NULL,
 DEPLINSTPARAM_ID NVARCHAR2(255), TMPLDEPL_ID NVARCHAR2(255) NOT NULL, VALUE CLOB,
 CONSTRAINT CONSTRAINT_B2 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-29', '2.0.5', '3:4934fa586d806ebbc8a30cf5a65e96ea', 29);
CREATE TABLE CFG_INSTR_DEPLOYMENT (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, DEPLOY_TIME TIMESTAMP NOT NULL,
 INSTRUMENTATION NVARCHAR2(255) NOT NULL, IS_ASSIGNED NUMBER(1) NOT NULL, IS_DEPLOYED NUMBER(1) NOT NULL,
 IS_MONITORED_BY_PROXY NUMBER(1) NOT NULL, IS_UPDATED NUMBER(1) NOT NULL, NODE_ID NVARCHAR2(255) NOT NULL,
 NODE_NAME NVARCHAR2(255) NOT NULL, PENDING_DELETE NVARCHAR2(255), CONSTRAINT CONSTRAINT_C9 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-30', '2.0.5', '3:6d0dd6ee7429201636358df01ef5aa9a', 30);
CREATE TABLE CFG_INSTRUMENTATION (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, CONTENT BLOB NOT NULL,
 CHKSUM NVARCHAR2(255) NOT NULL, DATE_UPDATED TIMESTAMP NOT NULL, DESCRIPTION CLOB, DIRNAME NVARCHAR2(255) NOT NULL,
 LABEL NVARCHAR2(255) NOT NULL, IS_STUB NUMBER(1) NOT NULL, CONSTRAINT CONSTRAINT_A PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-31', '2.0.5', '3:e46d25f63127ad33de86c4e90e6ca949', 31);
CREATE TABLE CFG_JOB (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, ASSIGNMENT_ID NVARCHAR2(255),
 DATE_CREATED TIMESTAMP NOT NULL, DESCRIPTION CLOB, EXEC_ON NVARCHAR2(255), LAST_UPDATED TIMESTAMP NOT NULL,
 NODE_ID NVARCHAR2(255) NOT NULL, NODE_NAME NVARCHAR2(255) NOT NULL, OPTIONS NUMBER(38,0) NOT NULL,
 SCOPE NVARCHAR2(255) NOT NULL, STATE NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_53 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-32', '2.0.5', '3:d88b69f03ced8131d5dcc7f8100a9fd5', 32);
CREATE TABLE CFG_MGMT_TOPOPATH (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL,
 ASPECT_VERSION_ID NVARCHAR2(255) NOT NULL, LABEL NVARCHAR2(255), MGMTTEMPLATE_VER_ID NVARCHAR2(255) NOT NULL,
 PATH NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_536 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-33', '2.0.5', '3:e5dd0e94504b1497945f465c6d48c1b7', 33);
CREATE TABLE CFG_MGMTPARAM_GROUPING (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL,
 MGMTPARAM_ID NVARCHAR2(255) NOT NULL, PARAMETER_ID NVARCHAR2(255) NOT NULL, TOPOPATH_ID NVARCHAR2(255) NOT NULL,
 CONSTRAINT CONSTRAINT_4 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-34', '2.0.5', '3:3a6ed5410fbdc62b64bd54431b01c3c2', 34);
CREATE TABLE CFG_MGMTTEMPLATE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, LABEL NVARCHAR2(255) NOT NULL,
 PARENT_ID NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_5E PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-35', '2.0.5', '3:b2ebffc1e624b0e57b34526d4b5a888b', 35);
CREATE TABLE CFG_MGMTTEMPLATE_VER (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, CILABEL NVARCHAR2(255),
 CITYPE NVARCHAR2(255) NOT NULL, CREATEDBY NVARCHAR2(255) NOT NULL, DATECREATED TIMESTAMP NOT NULL, DESCRIPTION CLOB,
 VER_MAJOR NUMBER(38,0) NOT NULL, VER_MINOR NUMBER(38,0) NOT NULL, TOPOVIEW NVARCHAR2(255) NOT NULL, VER_INFO CLOB,
 MGMTTMPLVER_ID NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_9 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-36', '2.0.5', '3:92793c756b1b12a15aacddc75462747f', 36);
CREATE TABLE CFG_NODEFILTER (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, DESCRIPTION CLOB,
 FILTER_VIEW NVARCHAR2(255), LABEL NVARCHAR2(255) NOT NULL, READONLY NUMBER(1) NOT NULL,
 CONSTRAINT CONSTRAINT_3C PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-37', '2.0.5', '3:66cc127bad6aad2a7a420a96b947396d', 37);
CREATE TABLE CFG_NODEFILTER_CRITERIA (CRITERIA NVARCHAR2(255), CRITERIA_IDX NVARCHAR2(255),
 CRITERIA_ELT NVARCHAR2(255) NOT NULL);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-38', '2.0.5', '3:3e04a82bb520daae07ce5eae5e2b2415', 38);
CREATE TABLE CFG_OSTYPE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, LABEL NVARCHAR2(255) NOT NULL,
 NAME NVARCHAR2(255) NOT NULL, PATTERN NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_76 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-39', '2.0.5', '3:ff310b23248d04c51bceada541aad86d', 39);
CREATE TABLE CFG_PARAMETER (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, BASEPARAM NVARCHAR2(255) NOT NULL,
 DEFAULT_VALUE CLOB, DESCRIPTION CLOB, EXPERT NUMBER(1) NOT NULL, HASCONDITIONALVALUES NUMBER(1),
 ISINSTANCEPARAM NUMBER(1) NOT NULL, LABEL NVARCHAR2(255) NOT NULL, MANDATORY NUMBER(1) NOT NULL, MAX FLOAT, MIN FLOAT,
 MODELPROPERTY NVARCHAR2(255), READONLY NUMBER(1) NOT NULL, IS_STUB NUMBER(1) NOT NULL, TYPE NVARCHAR2(255) NOT NULL,
 UI_ORDER INTEGER NOT NULL, VISIBLE NUMBER(1) NOT NULL, CLASS NVARCHAR2(255) NOT NULL, SET_TO_GROUPED_DEFAULT NUMBER(1),
 MT_VERSION NVARCHAR2(255), PARENT_INST_PARAM_ID NVARCHAR2(255), ASPECT_VERSION NVARCHAR2(255),
 TEMPLATE_VERSION NVARCHAR2(255), VARNAME NVARCHAR2(255), CONSTRAINT CONSTRAINT_94 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-40', '2.0.5', '3:f30c292d40de6e463500c75119df618d', 40);
CREATE TABLE CFG_PARAMVALUE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, ASSIGNMENTID NVARCHAR2(255),
 AUTOASSIGNMENTID NVARCHAR2(255), INSTVALUEORDER INTEGER, ISDEFAULT NUMBER(1) NOT NULL, IS_DELETED NUMBER(1),
 IS_TUNED NUMBER(1) NOT NULL, MODEL_PROPERTY NVARCHAR2(255), ORGPARAMID NVARCHAR2(255), PARAMID NVARCHAR2(255),
 PARENTINSTPARAMVALID NVARCHAR2(255), TOPOPATH_ID NVARCHAR2(255), TUNED_ASPECT_ID NVARCHAR2(255),
 TUNED_BASE_PARAMETER NVARCHAR2(255), TUNED_PATH NVARCHAR2(255), UIINSTVALUEORDER INTEGER,
 USEGROUPEDDEFAULT NUMBER(1) NOT NULL, VALUE CLOB, CONSTRAINT CONSTRAINT_F PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-41', '2.0.5', '3:989778e25b5b18ae9148ffdfab6f1fb8', 41);
CREATE TABLE CFG_TEMPLATE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, LABEL NVARCHAR2(255) NOT NULL,
 IS_STUB NUMBER(1) NOT NULL, TEMPLATETYPE_ID NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_5F PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-42', '2.0.5', '3:5584c5e0024240573b2d202559f354c4', 42);
CREATE TABLE CFG_TEMPLATEDEPLOYMENT (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, DEPLSTATE NUMBER(1) NOT NULL,
 IS_ASSIGNED NUMBER(1) NOT NULL, IS_DEPLOYED NUMBER(1) NOT NULL, IS_MONITORED_BY_PROXY NUMBER(1) NOT NULL,
 IS_UPDATED NUMBER(1) NOT NULL, NODE_ID NVARCHAR2(255) NOT NULL, NODE_NAME NVARCHAR2(255) NOT NULL,
 PARAMETER_CHECKSUM NUMBER(38,0) NOT NULL, STATE NUMBER(1) NOT NULL, TMPL_VER_ID NVARCHAR2(255) NOT NULL,
 CONSTRAINT CONSTRAINT_37 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-43', '2.0.5', '3:773ec02c1659b7a2f83aa5cf3ff9f4d2', 43);
CREATE TABLE CFG_TEMPLATEFILE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, CONTENT BLOB NOT NULL,
 CHKSUM NVARCHAR2(255) NOT NULL, NAME NVARCHAR2(255) NOT NULL, TMPL_VER_ID NVARCHAR2(255) NOT NULL,
 CONSTRAINT CONSTRAINT_124 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-44', '2.0.5', '3:756959858829366695cce6e7a7bfb4a9', 44);
CREATE TABLE CFG_TEMPLATEGROUP (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, DESCRIPTION CLOB,
 LABEL NVARCHAR2(255) NOT NULL, PARENT_GROUP NVARCHAR2(255), IS_SPECIALGROUP NUMBER(1) NOT NULL,
 IS_TYPEGROUP NUMBER(1) NOT NULL, CONSTRAINT CONSTRAINT_36 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-45', '2.0.5', '3:23dfdacebc8fabcb5d40cee0a47f37cd', 45);
CREATE TABLE CFG_TEMPLATETYPE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL,
 AGT_PARAMTYPE NVARCHAR2(255) NOT NULL, AGT_TYPE NVARCHAR2(255) NOT NULL, ALLOWMULTIPLE NUMBER(1) NOT NULL,
 CONNECTEDSERVERTYPE NVARCHAR2(255), DESCRIPTION CLOB, EDITORURL NVARCHAR2(255), ISPROXYTYPE NUMBER(1) NOT NULL,
 LABEL NVARCHAR2(255) NOT NULL, POLICYID NVARCHAR2(255), PROCESSORCLASS NVARCHAR2(255),
 SUPPORTSINSTANCEPARAMETERS NUMBER(1) NOT NULL, CONSTRAINT CONSTRAINT_124F PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-46', '2.0.5', '3:aa5c3c9d7ea160a4138e90053a259374', 46);
CREATE TABLE CFG_TEMPLATEVERSION (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, ALLPARAXML CLOB,
 CREATEDBY NVARCHAR2(255) NOT NULL, DATECREATED TIMESTAMP NOT NULL, DEPLOY_TO CLOB, DESCRIPTION CLOB,
 VER_MAJOR NUMBER(38,0) NOT NULL, MGMT_PACK NVARCHAR2(255), MGMT_PACKTYPE NVARCHAR2(255),
 VER_MINOR NUMBER(38,0) NOT NULL, IS_STUB NUMBER(1) NOT NULL, VER_INFO CLOB, TEMPLATE_ID NVARCHAR2(255) NOT NULL,
 VISIBLEPARAXML CLOB, CONSTRAINT CONSTRAINT_49 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-47', '2.0.5', '3:e9b2eaf358d241a7d36a0923b566c49d', 47);
ALTER TABLE CFG_ASPECT ADD CONSTRAINT FK5E746CB3F39801A8 FOREIGN KEY (PARENTFOLDER_ID) REFERENCES CFG_CONFIGFOLDER (ID) 
 ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-48', '2.0.5', '3:6c86ce48c8e489fa10bd5f6e8687b0f3', 48);
ALTER TABLE CFG_ASPECTVERSION ADD CONSTRAINT FK182D1CA5F799D570 FOREIGN KEY (ASPECT_ID) REFERENCES CFG_ASPECT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-49', '2.0.5', '3:7cf2f4363fc48616090e0abd385a4c08', 49);
ALTER TABLE CFG_ASSIGNMENT ADD CONSTRAINT FK121831A821D72779 FOREIGN KEY (ASPECTVER_ID) REFERENCES CFG_ASPECTVERSION
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-50', '2.0.5', '3:479e52583f3b7b87bbedecb43f67ba67', 50);
ALTER TABLE CFG_ASSIGNMENT ADD CONSTRAINT FK121831A829D895C9 FOREIGN KEY (CI_REF) REFERENCES CFG_CIREFERENCE (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-51', '2.0.5', '3:3151a78932f61dd3c072be4ba07d4069', 51);
ALTER TABLE CFG_ASSIGNMENT ADD CONSTRAINT FK121831A88A41620D FOREIGN KEY (INSTR_DEPL) REFERENCES CFG_INSTR_DEPLOYMENT
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-52', '2.0.5', '3:0280f3db0861784c3cda561aa3e3c545', 52);
ALTER TABLE CFG_ASSIGNMENT ADD CONSTRAINT FK121831A8F5EF10C6 FOREIGN KEY (INSTR_ID) REFERENCES CFG_INSTRUMENTATION (ID) 
 ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-53', '2.0.5', '3:2e01e20d1c9643e2ffb5007391879d2d', 53);
ALTER TABLE CFG_ASSIGNMENT ADD CONSTRAINT FK121831A81FF8B963 FOREIGN KEY (MTVER_ID) REFERENCES CFG_MGMTTEMPLATE_VER (ID)
  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-54', '2.0.5', '3:9f8ebff70461ec54dd71a585509db5ae', 54);
ALTER TABLE CFG_ASSIGNMENT ADD CONSTRAINT FK121831A8E083829C FOREIGN KEY (TMPL_DEPL) REFERENCES CFG_TEMPLATEDEPLOYMENT
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-55', '2.0.5', '3:e4a85215a669c40d1b7a86968d6f20d8', 55);
ALTER TABLE CFG_ASSIGNMENT ADD CONSTRAINT FK121831A813869D89 FOREIGN KEY (TMPL_VER_ID) REFERENCES CFG_TEMPLATEVERSION
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-56', '2.0.5', '3:c1e32fb02f460c5123967481ec5468df', 56);
ALTER TABLE CFG_ASSIGNMENTDEPENDENCY ADD CONSTRAINT FKEBBCFEF39B9235A1 FOREIGN KEY (CHILD_ID) REFERENCES CFG_ASSIGNMENT
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-57', '2.0.5', '3:bbb14d89b9bb43edb24995d50d591fd5', 57);
ALTER TABLE CFG_ASSIGNMENTDEPENDENCY ADD CONSTRAINT FKEBBCFEF3B40ECF53 FOREIGN KEY (PARENT_ID) REFERENCES CFG_ASSIGNMENT
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-58', '2.0.5', '3:436b4228e4c6688a1cde04ec6faa01f7', 58);
ALTER TABLE CFG_AT_ASPAUTOASGN_VIEWS ADD CONSTRAINT FKDB0A98046BC15D54 FOREIGN KEY (ASPECTAUTO_ASSGN_ID) REFERENCES
 CFG_AUTOASSIGNMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-59', '2.0.5', '3:789d20baa753d783e6f1f30204230355', 59);
ALTER TABLE CFG_AT_ASPVERS_ASPVERS ADD CONSTRAINT FK77A70DACC0EDE24 FOREIGN KEY (ASPECTVERSION_ID) REFERENCES
 CFG_ASPECTVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-60', '2.0.5', '3:ba88480392303b02922a8b5cd56c2fb3', 60);
ALTER TABLE CFG_AT_ASPVERS_ASPVERS ADD CONSTRAINT FK77A70DACCFBD1B40 FOREIGN KEY (CHILDASPECTVERSION_ID) REFERENCES
 CFG_ASPECTVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-61', '2.0.5', '3:df6b75377a3c728db55bec778366da5b', 61);
ALTER TABLE CFG_AT_ASPVERS_CITYPE ADD CONSTRAINT FKABE407C2C0EDE24 FOREIGN KEY (ASPECTVERSION_ID) REFERENCES
 CFG_ASPECTVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-62', '2.0.5', '3:d101a24d5d600f670db559864a2871a6', 62);
ALTER TABLE CFG_AT_ASPVERS_INSTR ADD CONSTRAINT FK9245636AC0EDE24 FOREIGN KEY (ASPECTVERSION_ID) REFERENCES
 CFG_ASPECTVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-63', '2.0.5', '3:f302291419a0403622cd24a3d58457ee', 63);
ALTER TABLE CFG_AT_ASPVERS_INSTR ADD CONSTRAINT FK9245636AF9CCDD04 FOREIGN KEY (INSTRUMENTATION_ID) REFERENCES
 CFG_INSTRUMENTATION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-64', '2.0.5', '3:c5d1d20a71ea54de7e425fbd002b1b6e', 64);
ALTER TABLE CFG_AT_ASPVERS_TMPLVERS ADD CONSTRAINT FKF5063787C0EDE24 FOREIGN KEY (ASPECTVERSION_ID) REFERENCES
 CFG_ASPECTVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-65', '2.0.5', '3:f2b20c7f9cd56b69b22112c0dc03015c', 65);
ALTER TABLE CFG_AT_ASPVERS_TMPLVERS ADD CONSTRAINT FKF506378763A67EDF FOREIGN KEY (TMPLVERSION_ID) REFERENCES
 CFG_TEMPLATEVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-66', '2.0.5', '3:354ba9f8b6eecfeefb3fa0ea541e92d7', 66);
ALTER TABLE CFG_AT_CONDITION_OSTYPE ADD CONSTRAINT FK88CB2CF374513164 FOREIGN KEY (CONDITION_ID) REFERENCES
 CFG_CONDITION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-67', '2.0.5', '3:6b065ed9ac76d9bd7b2ad6b4728e4348', 67);
ALTER TABLE CFG_AT_CONDITION_OSTYPE ADD CONSTRAINT FK88CB2CF3B5720D3F FOREIGN KEY (OSTYPE_ID) REFERENCES CFG_OSTYPE (ID)
  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-68', '2.0.5', '3:2930cbc9a49f2e8524f2853a143b4549', 68);
ALTER TABLE CFG_AT_GRPPARAM_PARAM ADD CONSTRAINT FKE42E0A87878365C7 FOREIGN KEY (GROUPPARAM_ID) REFERENCES CFG_PARAMETER
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-69', '2.0.5', '3:70f08edb0a0a4033bd675ac7d15a489b', 69);
ALTER TABLE CFG_AT_GRPPARAM_PARAM ADD CONSTRAINT FKE42E0A87A9A7BF40 FOREIGN KEY (PARAM_ID) REFERENCES CFG_PARAMETER (ID)
  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-70', '2.0.5', '3:81c816cb8ad92dc8fbc406dfa23327f6', 70);
ALTER TABLE CFG_AT_INSTRDEPL_ASGN ADD CONSTRAINT FK94466660A4E57A50 FOREIGN KEY (ASSIGNMENT_ID) REFERENCES
 CFG_ASSIGNMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-71', '2.0.5', '3:3d4b03190d5aa0529a052f6f2eabb96f', 71);
ALTER TABLE CFG_AT_INSTRDEPL_ASGN ADD CONSTRAINT FK9446666024E5DBC6 FOREIGN KEY (INSTRDEPLOYMENT_ID) REFERENCES
 CFG_INSTR_DEPLOYMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-72', '2.0.5', '3:4176a4cbb44f10f59a1eb24c96493cba', 72);
ALTER TABLE CFG_AT_MTAUTOASGN_VIEWS ADD CONSTRAINT FK5428498FBE598FBB FOREIGN KEY (MGMTTMPLAUTO_ASSGN_ID) REFERENCES
 CFG_AUTOASSIGNMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-73', '2.0.5', '3:54bb11fc1e3d8a60048d9c7b1c232a35', 73);
ALTER TABLE CFG_AT_TGAUTOASGN_CICOLL ADD CONSTRAINT FKD0B09AE5BD4F1BFD FOREIGN KEY (TMPLGRPAUTO_ASSGN_ID) REFERENCES
 CFG_AUTOASSIGNMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-74', '2.0.5', '3:67abc6f2ca48e4b059ba0cf11628097c', 74);
ALTER TABLE CFG_AT_TMPL_TMPLDEPLOY ADD CONSTRAINT FK2E7BC7756CC074B0 FOREIGN KEY (TEMPLATE_ID) REFERENCES CFG_TEMPLATE
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-75', '2.0.5', '3:7f3832d2466c8ad7282fb64dd2d8c4ba', 75);
ALTER TABLE CFG_AT_TMPL_TMPLDEPLOY ADD CONSTRAINT FK2E7BC7756B5DCCE0 FOREIGN KEY (TMPL_DEPLOYMENT_ID) REFERENCES
 CFG_TEMPLATEDEPLOYMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-76', '2.0.5', '3:50138ccad070a7447b3ddb96b6ed9036', 76);
ALTER TABLE CFG_AT_TMPL_TMPLGRP_LATEST ADD CONSTRAINT FKBED3DFCF6CC074B0 FOREIGN KEY (TEMPLATE_ID) REFERENCES
 CFG_TEMPLATE (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-77', '2.0.5', '3:76f790b5736d8b534c1bc4629abfda49', 77);
ALTER TABLE CFG_AT_TMPL_TMPLGRP_LATEST ADD CONSTRAINT FKBED3DFCF28FA8EBF FOREIGN KEY (TMPLGROUP_ID) REFERENCES
 CFG_TEMPLATEGROUP (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-78', '2.0.5', '3:61725184a9aeca0ed8bbf907bbc18a38', 78);
ALTER TABLE CFG_AT_TMPL_TMPLGRP_MINLATEST ADD CONSTRAINT FK72E79EF16CC074B0 FOREIGN KEY (TEMPLATE_ID) REFERENCES
 CFG_TEMPLATE (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-79', '2.0.5', '3:26fdc624dd999dc4a664ce430664fb2d', 79);
ALTER TABLE CFG_AT_TMPL_TMPLGRP_MINLATEST ADD CONSTRAINT FK72E79EF128FA8EBF FOREIGN KEY (TMPLGROUP_ID) REFERENCES
 CFG_TEMPLATEGROUP (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-80', '2.0.5', '3:0df588859b036c1664e6aed0292a5b32', 80);
ALTER TABLE CFG_AT_TMPLDEPL_ASGN ADD CONSTRAINT FKF4543255A4E57A50 FOREIGN KEY (ASSIGNMENT_ID) REFERENCES CFG_ASSIGNMENT
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-81', '2.0.5', '3:3f94598dec244b19656974f6e33aa6c8', 81);
ALTER TABLE CFG_AT_TMPLDEPL_ASGN ADD CONSTRAINT FKF45432556B5DCCE0 FOREIGN KEY (TMPL_DEPLOYMENT_ID) REFERENCES
 CFG_TEMPLATEDEPLOYMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-82', '2.0.5', '3:d7f4a2be285a449f6ad76f3f781a8d61', 82);
ALTER TABLE CFG_AT_TMPLGRP_TMPLVER_CHILD ADD CONSTRAINT FK7F8C63AB28FA8EBF FOREIGN KEY (TMPLGROUP_ID) REFERENCES
 CFG_TEMPLATEGROUP (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-83', '2.0.5', '3:2fc406e5ae01437b6019407ce0a824ca', 83);
ALTER TABLE CFG_AT_TMPLGRP_TMPLVER_CHILD ADD CONSTRAINT FK7F8C63AB63A67EDF FOREIGN KEY (TMPLVERSION_ID) REFERENCES
 CFG_TEMPLATEVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-84', '2.0.5', '3:6a88cbf9feb85664f2b46eb47c517a68', 84);
ALTER TABLE CFG_AT_TMPLVER_INSTR ADD CONSTRAINT FKEA2C700AF9CCDD04 FOREIGN KEY (INSTRUMENTATION_ID) REFERENCES
 CFG_INSTRUMENTATION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-85', '2.0.5', '3:0b3370aa6387db5ab1eaeb6aa0b712d2', 85);
ALTER TABLE CFG_AT_TMPLVER_INSTR ADD CONSTRAINT FKEA2C700A63A67EDF FOREIGN KEY (TMPLVERSION_ID) REFERENCES
 CFG_TEMPLATEVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-86', '2.0.5', '3:9dfa3225242f5008431caa70d23ad363', 86);
ALTER TABLE CFG_AT_TMPLVER_OSTYPE ADD CONSTRAINT FK65E5A1A0B5720D3F FOREIGN KEY (OSTYPE_ID) REFERENCES CFG_OSTYPE (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-87', '2.0.5', '3:e77e0d6159bc708078cbcadabaaa05b1', 87);
ALTER TABLE CFG_AT_TMPLVER_OSTYPE ADD CONSTRAINT FK65E5A1A063A67EDF FOREIGN KEY (TMPLVERSION_ID) REFERENCES
 CFG_TEMPLATEVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-88', '2.0.5', '3:ba699b1a75018276dfd977588e4d64ba', 88);
ALTER TABLE CFG_AUTOASSIGNMENT ADD CONSTRAINT FKC646131734AC8AE8 FOREIGN KEY (ASPECT_VER_ID) REFERENCES
 CFG_ASPECTVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-89', '2.0.5', '3:300abbca4ced6801625c9851847bf092', 89);
ALTER TABLE CFG_AUTOASSIGNMENT ADD CONSTRAINT FKC6461317F768180 FOREIGN KEY (MGMTTEMPLATE_VER_ID) REFERENCES
 CFG_MGMTTEMPLATE_VER (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-90', '2.0.5', '3:983019300122366b9d2313a814755482', 90);
ALTER TABLE CFG_AUTOASSIGNMENT ADD CONSTRAINT FKC6461317839DBD9 FOREIGN KEY (TMPLGRP_ID) REFERENCES CFG_TEMPLATEGROUP
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-91', '2.0.5', '3:988bed7faa0a37727fb9655a40b6e521', 91);
ALTER TABLE CFG_CONDITION ADD CONSTRAINT FKEC4DF6C020E851DB FOREIGN KEY (ASPECT_VERSION) REFERENCES CFG_ASPECTVERSION
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-92', '2.0.5', '3:f8f7baf255cf3979582e46fb2d054aef', 92);
ALTER TABLE CFG_CONDITION ADD CONSTRAINT FKEC4DF6C0D85400DC FOREIGN KEY (PARAMETER) REFERENCES CFG_PARAMETER (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-93', '2.0.5', '3:511af4d82ab904f42e21b7b6d08dc950', 93);
ALTER TABLE CFG_CONDITION ADD CONSTRAINT FKEC4DF6C020F10B1B FOREIGN KEY (TEMPLATE_VERSION) REFERENCES
 CFG_TEMPLATEVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-94', '2.0.5', '3:e46584e7644217107f2ca07111107233', 94);
ALTER TABLE CFG_CONFIGFOLDER ADD CONSTRAINT FK7877024BF39801A8 FOREIGN KEY (PARENTFOLDER_ID) REFERENCES CFG_CONFIGFOLDER
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-95', '2.0.5', '3:5901f1bc0cb3e9c938b1b0ed1904d3d4', 95);
ALTER TABLE CFG_DELETEDASSIGNMENTS ADD CONSTRAINT FKB4C9D968CC4686E8 FOREIGN KEY (TMPL_DEPL_ID) REFERENCES
 CFG_TEMPLATEDEPLOYMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-96', '2.0.5', '3:dea3e630eebe9b008ff34661ed827a67', 96);
ALTER TABLE CFG_DEPL_INSTPARAMVALUE ADD CONSTRAINT FK6F60D191CA611641 FOREIGN KEY (PARAMID) REFERENCES CFG_PARAMETER
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-97', '2.0.5', '3:d6591964abe1e6e75384463471436c26', 97);
ALTER TABLE CFG_DEPL_INSTPARAMVALUE ADD CONSTRAINT FK6F60D1911CAD2B1D FOREIGN KEY (TMPLDEPL_ID) REFERENCES
 CFG_TEMPLATEDEPLOYMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-98', '2.0.5', '3:c22bf21198b9fe526844737918074b19', 98);
ALTER TABLE CFG_DEPL_PARAMVALUE ADD CONSTRAINT FKB27F0E4B3087BE08 FOREIGN KEY (DEPLINSTPARAM_ID) REFERENCES
 CFG_DEPL_INSTPARAMVALUE (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-99', '2.0.5', '3:ea3ad9346667bbbff554198a9e916d25', 99);
ALTER TABLE CFG_DEPL_PARAMVALUE ADD CONSTRAINT FKB27F0E4BCA611641 FOREIGN KEY (PARAMID) REFERENCES CFG_PARAMETER (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-100', '2.0.5', '3:f7984e9fbc2c5894b8dc3b44ed553d0c', 100);
ALTER TABLE CFG_DEPL_PARAMVALUE ADD CONSTRAINT FKB27F0E4B1CAD2B1D FOREIGN KEY (TMPLDEPL_ID) REFERENCES
 CFG_TEMPLATEDEPLOYMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-101', '2.0.5', '3:8921c542a29e93c8dc0e9641b8b323be', 101);
ALTER TABLE CFG_INSTR_DEPLOYMENT ADD CONSTRAINT FKC91408B3F54628E6 FOREIGN KEY (INSTRUMENTATION) REFERENCES
 CFG_INSTRUMENTATION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-102', '2.0.5', '3:5670f7362d832e22740666d6c746cff1', 102);
ALTER TABLE CFG_MGMT_TOPOPATH ADD CONSTRAINT FK536745E22596F213 FOREIGN KEY (ASPECT_VERSION_ID) REFERENCES
 CFG_ASPECTVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-103', '2.0.5', '3:be9956dff157ade078192c78edafe1c8', 103);
ALTER TABLE CFG_MGMT_TOPOPATH ADD CONSTRAINT FK536745E2F768180 FOREIGN KEY (MGMTTEMPLATE_VER_ID) REFERENCES
 CFG_MGMTTEMPLATE_VER (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-104', '2.0.5', '3:f710d59d15519b11daa7b84d0e733b2c', 104);
ALTER TABLE CFG_MGMTPARAM_GROUPING ADD CONSTRAINT FK40A8AB71B8F2AF24 FOREIGN KEY (MGMTPARAM_ID) REFERENCES CFG_PARAMETER
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-105', '2.0.5', '3:5c835cde5f8599b3c215ba2ec53b5193', 105);
ALTER TABLE CFG_MGMTPARAM_GROUPING ADD CONSTRAINT FK40A8AB71843FEA4 FOREIGN KEY (PARAMETER_ID) REFERENCES CFG_PARAMETER
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-106', '2.0.5', '3:49cfc3febf116ff242cf47d6cd9b1bed', 106);
ALTER TABLE CFG_MGMTPARAM_GROUPING ADD CONSTRAINT FK40A8AB71DA6FBDE5 FOREIGN KEY (TOPOPATH_ID) REFERENCES
 CFG_MGMT_TOPOPATH (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-107', '2.0.5', '3:359079a75525a9cc13c3e5e81c75629a', 107);
ALTER TABLE CFG_MGMTTEMPLATE ADD CONSTRAINT FK5E96F4567F8AC556 FOREIGN KEY (PARENT_ID) REFERENCES CFG_CONFIGFOLDER (ID) 
 ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-108', '2.0.5', '3:3953d0ba1edc513c1e438f86f8f117b4', 108);
ALTER TABLE CFG_MGMTTEMPLATE_VER ADD CONSTRAINT FK96E5541AE0F3A0C0 FOREIGN KEY (MGMTTMPLVER_ID) REFERENCES
 CFG_MGMTTEMPLATE (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-109', '2.0.5', '3:dd201a1e206051ae23d3a4c416b938d2', 109);
ALTER TABLE CFG_PARAMETER ADD CONSTRAINT FK94233D4E20E851DB FOREIGN KEY (ASPECT_VERSION) REFERENCES CFG_ASPECTVERSION
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-110', '2.0.5', '3:2086896002213b4a79dc544145a16952', 110);
ALTER TABLE CFG_PARAMETER ADD CONSTRAINT FK94233D4EF1719C05 FOREIGN KEY (MT_VERSION) REFERENCES CFG_MGMTTEMPLATE_VER
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-111', '2.0.5', '3:522b47bc244d3bb763a049b2aa6fb4ef', 111);
ALTER TABLE CFG_PARAMETER ADD CONSTRAINT FK94233D4E10BA34EA FOREIGN KEY (PARENT_INST_PARAM_ID) REFERENCES CFG_PARAMETER
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-112', '2.0.5', '3:b6139aacdff47b345e17e8b28d0bf14b', 112);
ALTER TABLE CFG_PARAMETER ADD CONSTRAINT FK94233D4E20F10B1B FOREIGN KEY (TEMPLATE_VERSION) REFERENCES
 CFG_TEMPLATEVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-113', '2.0.5', '3:78efde43c2e1ec956586ac246d97fb49', 113);
ALTER TABLE CFG_PARAMVALUE ADD CONSTRAINT FKF12B73DFD90D332B FOREIGN KEY (ASSIGNMENTID) REFERENCES CFG_ASSIGNMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-114', '2.0.5', '3:0b0456a171a3bd2013f34fa16087d000', 114);
ALTER TABLE CFG_PARAMVALUE ADD CONSTRAINT FKF12B73DF1083DC26 FOREIGN KEY (AUTOASSIGNMENTID) REFERENCES
 CFG_AUTOASSIGNMENT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-115', '2.0.5', '3:d55a12f7bee2a280c57ac20b351776b0', 115);
ALTER TABLE CFG_PARAMVALUE ADD CONSTRAINT FKF12B73DFF2740C37 FOREIGN KEY (ORGPARAMID) REFERENCES CFG_PARAMETER (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-116', '2.0.5', '3:34e8e61006b061f64027478054731ed8', 116);
ALTER TABLE CFG_PARAMVALUE ADD CONSTRAINT FKF12B73DF3489839B FOREIGN KEY (PARAMID) REFERENCES CFG_PARAMETER (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-117', '2.0.5', '3:b47ac8b607c447827e521d6d35e1b688', 117);
ALTER TABLE CFG_PARAMVALUE ADD CONSTRAINT FKF12B73DFE7C6C17D FOREIGN KEY (PARENTINSTPARAMVALID) REFERENCES
 CFG_PARAMVALUE (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-118', '2.0.5', '3:29f441f976d100c3cb7668fcc1b40a7d', 118);
ALTER TABLE CFG_PARAMVALUE ADD CONSTRAINT FKF12B73DFDA6FBDE5 FOREIGN KEY (TOPOPATH_ID) REFERENCES CFG_MGMT_TOPOPATH (ID)
  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-119', '2.0.5', '3:cded72cf3a8fa3178fa2e28551a9f8e8', 119);
ALTER TABLE CFG_PARAMVALUE ADD CONSTRAINT FKF12B73DF3F5CF85D FOREIGN KEY (TUNED_ASPECT_ID) REFERENCES CFG_ASPECT (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-120', '2.0.5', '3:cc882b4678b3188a5bf0893b1401a940', 120);
ALTER TABLE CFG_TEMPLATE ADD CONSTRAINT FK5FAB7615EC477B90 FOREIGN KEY (TEMPLATETYPE_ID) REFERENCES CFG_TEMPLATETYPE
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-121', '2.0.5', '3:0314932440e8d592ccd11ed25059c5ea', 121);
ALTER TABLE CFG_TEMPLATEDEPLOYMENT ADD CONSTRAINT FK3797469A13869D89 FOREIGN KEY (TMPL_VER_ID) REFERENCES
 CFG_TEMPLATEVERSION (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-122', '2.0.5', '3:c45a52a3de825025c3da56e11eac3373', 122);
ALTER TABLE CFG_TEMPLATEFILE ADD CONSTRAINT FK1249511113869D89 FOREIGN KEY (TMPL_VER_ID) REFERENCES CFG_TEMPLATEVERSION
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-123', '2.0.5', '3:924424c7a52a245605fabf90231d4ab9', 123);
ALTER TABLE CFG_TEMPLATEGROUP ADD CONSTRAINT FK36F30D6AF127559 FOREIGN KEY (PARENT_GROUP) REFERENCES CFG_TEMPLATEGROUP
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-124', '2.0.5', '3:e65822f4756c62ba5c7f9d65f198d897', 124);
ALTER TABLE CFG_TEMPLATEVERSION ADD CONSTRAINT FK49DD21036CC074B0 FOREIGN KEY (TEMPLATE_ID) REFERENCES CFG_TEMPLATE (ID)
  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-1.0.xml', '1366781048057-125', '2.0.5', '3:0f24bef8da044344d4c630b913400fae', 125);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_3 ON CFG_NODEFILTER(LABEL);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-1.0.xml',
 '1366781048057-126', '2.0.5', '3:16d4ddd636faedf0dac1040b7393ade1', 126);
CREATE TABLE CFG_ASS_VALS (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, ASSIGNEDSTATE NUMBER(1) NOT NULL,
 CI_ID NVARCHAR2(255) NOT NULL, OBJ_ID NVARCHAR2(255) NOT NULL, IS_ASSIGNED NUMBER(1) NOT NULL,
 REVISION INTEGER NOT NULL, CONSTRAINT CONSTRAINT_10 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-1', '2.0.5', '3:23fe9cefa5b1135d1beae1be2f2b93b0', 127);
CREATE TABLE CFG_AT_ASSIGNMENT_CI (ID NVARCHAR2(255) NOT NULL, CI_ID NVARCHAR2(255) NOT NULL,
 DIRECT_ASSIGNMENT_ID NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_8 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-2', '2.0.5', '3:f7f15a2d83d294f2548d0e72ae1c42b9', 128);
CREATE TABLE CFG_AT_PKG_DEPLGROUPS (DEPLPKG_VER_ID NVARCHAR2(255) NOT NULL, GROUP_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-3', '2.0.5', '3:bbcff2c74237a222c7025fe72dafe1b2', 129);
CREATE TABLE CFG_AT_PKG_OSVER (DEPLBIN_ID NVARCHAR2(255) NOT NULL, OSVERS_ID NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-4', '2.0.5', '3:55bbbf68822e250ec021d20d859c43ee', 130);
CREATE TABLE CFG_AT_PKG_SUB (DEPLBIN_ID NVARCHAR2(255) NOT NULL, SUB_PACKAGE NVARCHAR2(255));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-5', '2.0.5', '3:37099caca49d359c4d63027940f6800c', 131);
CREATE TABLE CFG_DEL_ASSGN_DEPL (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, ASSIGN_ID NVARCHAR2(255) NOT NULL,
 CI_ID NVARCHAR2(255) NOT NULL, CI_NAME NVARCHAR2(255) NOT NULL, INSTR_ID NVARCHAR2(255), TMPLVERS_ID NVARCHAR2(255),
 CONSTRAINT CONSTRAINT_3 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-6', '2.0.5', '3:9e01336f8b6c3eccbf316f7ffb35abff', 132);
CREATE TABLE CFG_DEPL_VALS (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, CI_ID NVARCHAR2(255) NOT NULL,
 OBJ_ID NVARCHAR2(255) NOT NULL, DEPLSTATE NUMBER(1) NOT NULL, IS_DEPLOYED NUMBER(1) NOT NULL,
 DEPLOYMENT_TIME NUMBER(38,0) NOT NULL, NODE_NAME NVARCHAR2(255) NOT NULL, REVISION NUMBER(38,0) NOT NULL,
 CONSTRAINT CONSTRAINT_EA PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-7', '2.0.5', '3:bfa38928a830fa10c41782d075c13a89', 133);
CREATE TABLE CFG_DIRECTASSIGNMENT (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL,
 ASSIGNED_BY NVARCHAR2(255) NOT NULL, ASSIGNED_CLASS NVARCHAR2(255) NOT NULL, CACHED_UCMDB_DATA CLOB NOT NULL,
 CI_ID NVARCHAR2(255) NOT NULL, DATE_CREATED TIMESTAMP NOT NULL, DELETED NUMBER(1) NOT NULL, IS_WEAK NUMBER(1) NOT NULL,
 LAST_UPDATED TIMESTAMP NOT NULL, LAST_UPDATED_BY NVARCHAR2(255) NOT NULL, STATE NUMBER(1) NOT NULL,
 VERSION_OBJECT_ID NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_D PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-8', '2.0.5', '3:7d9c611e0a297ac72faebf03d9495ac5', 134);
CREATE TABLE CFG_PKG_DEPLBIN (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, CONTENT BLOB,
 BDL_DESCRPTR_FILE NVARCHAR2(255), DEPLPKG_VERS_ID NVARCHAR2(255) NOT NULL, OS NVARCHAR2(255) NOT NULL,
 PATCH_ID NVARCHAR2(255), PROCESSOR_ARCH NVARCHAR2(255) NOT NULL, IS_STUB NUMBER(1) NOT NULL,
 CONSTRAINT CONSTRAINT_944 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-9', '2.0.5', '3:875799ad12d848aa701c27be39f7d6f5', 135);
CREATE TABLE CFG_PKG_DEPLBUNDLE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, DESCRIPTION CLOB,
 LABEL NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_BB7 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-10', '2.0.5', '3:ae07d01da4d416f5f061be4ad28474e0', 136);
CREATE TABLE CFG_PKG_DEPLPKG (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, NODE_ID NVARCHAR2(255) NOT NULL,
 DEPL_BIN_ID NVARCHAR2(255) NOT NULL, NODE_NAME NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_944CC PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-11', '2.0.5', '3:19988b7b69d53ad706343e9bc504bd08', 137);
CREATE TABLE CFG_PKG_DEPLVER (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, BUILD_VERSION NUMBER(38,0) NOT NULL,
 BUNDLE_ID NVARCHAR2(255) NOT NULL, MAJOR_VERSION NUMBER(38,0) NOT NULL, MINOR_VERSION NUMBER(38,0) NOT NULL,
 PKG_TYPE NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_944CD PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-12', '2.0.5', '3:18e4614037f6e0bc04483e12fa06422b', 138);
CREATE TABLE CFG_TUNEDASSIGNMENT (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL,
 ASSIGNED_BY NVARCHAR2(255) NOT NULL, ASSIGNED_CLASS NVARCHAR2(255) NOT NULL, CI_ID NVARCHAR2(255) NOT NULL,
 DATE_CREATED TIMESTAMP NOT NULL, LAST_UPDATED TIMESTAMP NOT NULL, LAST_UPDATED_BY NVARCHAR2(255) NOT NULL,
 PARAMETERS_CHANGED NUMBER(1) NOT NULL, STATE NUMBER(1) NOT NULL, STATE_CHANGED NUMBER(1) NOT NULL,
 VERSION_OBJECT_ID NVARCHAR2(255) NOT NULL, CONSTRAINT CONSTRAINT_C7 PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-13', '2.0.5', '3:317e0b1c0bd12687a11d213753defbf4', 139);
CREATE TABLE CFG_VALUESTORE (ID NVARCHAR2(255) NOT NULL, VERSION INTEGER NOT NULL, CATEGORY NVARCHAR2(255) NOT NULL,
 FKEY NVARCHAR2(255) NOT NULL, VALUE CLOB NOT NULL, CONSTRAINT CONSTRAINT_4F PRIMARY KEY (ID));
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-14', '2.0.5', '3:af6de8b06f8eafba09e6fe7c7fce49ae', 140);
ALTER TABLE CFG_JOB ADD DETAILS CLOB;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Column', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-15', '2.0.5', '3:04e3acdfd1b6fb26a3ee697c1ed403c3', 141);
ALTER TABLE CFG_ASSIGNMENT DROP CONSTRAINT FK121831A821D72779;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-16', '2.0.5', '3:08d1bfff7347262b316780b808e34884', 142);
ALTER TABLE CFG_ASSIGNMENT DROP CONSTRAINT FK121831A829D895C9;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-17', '2.0.5', '3:d8fa22da342ecd99c22015cba6170c51', 143);
ALTER TABLE CFG_ASSIGNMENT DROP CONSTRAINT FK121831A88A41620D;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-18', '2.0.5', '3:075ce2064c2bff794b87bd00e6513135', 144);
ALTER TABLE CFG_ASSIGNMENT DROP CONSTRAINT FK121831A8F5EF10C6;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-19', '2.0.5', '3:b1437b67edf5279bdeb1af6436e3e3c1', 145);
ALTER TABLE CFG_ASSIGNMENT DROP CONSTRAINT FK121831A81FF8B963;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-20', '2.0.5', '3:f37f6bb7d36169e5d0cf2c318baa771a', 146);
ALTER TABLE CFG_ASSIGNMENT DROP CONSTRAINT FK121831A8E083829C;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-21', '2.0.5', '3:d920a502dc3d76a984f8af52987eb27a', 147);
ALTER TABLE CFG_ASSIGNMENT DROP CONSTRAINT FK121831A813869D89;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-22', '2.0.5', '3:1a2edf521061e3e3d8d5dc5479cbdb20', 148);
ALTER TABLE CFG_ASSIGNMENTDEPENDENCY DROP CONSTRAINT FKEBBCFEF39B9235A1;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-23', '2.0.5', '3:de7f9594df078eaf85244afdaca3f037', 149);
ALTER TABLE CFG_ASSIGNMENTDEPENDENCY DROP CONSTRAINT FKEBBCFEF3B40ECF53;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-24', '2.0.5', '3:405ddd2b595b42857f929642f2d3ea4c', 150);
ALTER TABLE CFG_AT_INSTRDEPL_ASGN DROP CONSTRAINT FK94466660A4E57A50;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-25', '2.0.5', '3:046d6f625570bc520b4617a9ba72993f', 151);
ALTER TABLE CFG_AT_INSTRDEPL_ASGN DROP CONSTRAINT FK9446666024E5DBC6;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-26', '2.0.5', '3:50b25b46ba71811326c4e0517ed29588', 152);
ALTER TABLE CFG_AT_TMPL_TMPLDEPLOY DROP CONSTRAINT FK2E7BC7756CC074B0;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-27', '2.0.5', '3:2956da675baa24a7967eccc11c9d2531', 153);
ALTER TABLE CFG_AT_TMPL_TMPLDEPLOY DROP CONSTRAINT FK2E7BC7756B5DCCE0;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-28', '2.0.5', '3:2b2e5d9d0bd8c3dc6509a2063ca6c6b5', 154);
ALTER TABLE CFG_AT_TMPLDEPL_ASGN DROP CONSTRAINT FKF4543255A4E57A50;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-29', '2.0.5', '3:e29fbc37d84a02ebfa480db051862ede', 155);
ALTER TABLE CFG_AT_TMPLDEPL_ASGN DROP CONSTRAINT FKF45432556B5DCCE0;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-30', '2.0.5', '3:db934ff4ed27d8361e793d698d768268', 156);
ALTER TABLE CFG_DELETEDASSIGNMENTS DROP CONSTRAINT FKB4C9D968CC4686E8;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-31', '2.0.5', '3:8a96da8aa301e21c0cf062dfb7832f8c', 157);
ALTER TABLE CFG_DEPL_INSTPARAMVALUE DROP CONSTRAINT FK6F60D191CA611641;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-32', '2.0.5', '3:31da33fcee8b22d632e4d71b1941a9d5', 158);
ALTER TABLE CFG_DEPL_INSTPARAMVALUE DROP CONSTRAINT FK6F60D1911CAD2B1D;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-33', '2.0.5', '3:df066b147d4f4c2a1f866b5bdb0ac76a', 159);
ALTER TABLE CFG_DEPL_PARAMVALUE DROP CONSTRAINT FKB27F0E4B3087BE08;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-34', '2.0.5', '3:d20cf2e99a3605164c02b714a823cd22', 160);
ALTER TABLE CFG_DEPL_PARAMVALUE DROP CONSTRAINT FKB27F0E4BCA611641;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-35', '2.0.5', '3:280465ffa7ba0672df39391affecd3d8', 161);
ALTER TABLE CFG_DEPL_PARAMVALUE DROP CONSTRAINT FKB27F0E4B1CAD2B1D;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-36', '2.0.5', '3:41af9d49e09c1da43070e1c3cc801182', 162);
ALTER TABLE CFG_INSTR_DEPLOYMENT DROP CONSTRAINT FKC91408B3F54628E6;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-37', '2.0.5', '3:913d5ba2b51ba610e047da254a5a8c81', 163);
ALTER TABLE CFG_PARAMVALUE DROP CONSTRAINT FKF12B73DFD90D332B;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-38', '2.0.5', '3:c1eb58d9fa113f0b6b997af9e0bdf18a', 164);
ALTER TABLE CFG_TEMPLATEDEPLOYMENT DROP CONSTRAINT FK3797469A13869D89;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-39', '2.0.5', '3:d020b80b4fa13981b9ee70319e1facfc', 165);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_5 ON CFG_ASPECT(LABEL);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-46', '2.0.5', '3:64806c04c92b805a589fbc99ff582bd3', 166);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_A ON CFG_INSTRUMENTATION(DIRNAME);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-47', '2.0.5', '3:c5d328f6e6337349abee1defc593d568', 167);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_5E ON CFG_MGMTTEMPLATE(LABEL);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-48', '2.0.5', '3:c2cd6e9cbdaa1188fc60b2cd751e8396', 168);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_7 ON CFG_OSTYPE(NAME);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-49', '2.0.5', '3:680aa6905798b158c120d172a7974b6b', 169);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_9 ON CFG_PKG_DEPLBIN(DEPLPKG_VERS_ID, PROCESSOR_ARCH, OS);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-50', '2.0.5', '3:0dc71ad73bf9180bbdf1be865e164d8e', 170);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_B ON CFG_PKG_DEPLBUNDLE(LABEL);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-51', '2.0.5', '3:82946c050243373329606dd4ef3bd199', 171);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_94 ON CFG_PKG_DEPLVER(BUNDLE_ID, BUILD_VERSION, MAJOR_VERSION, MINOR_VERSION);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-52', '2.0.5', '3:e74c6698cbacd5ca8e0a3520fdbf3e7f', 172);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_5F ON CFG_TEMPLATE(LABEL);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-53', '2.0.5', '3:a3e6c46f86561ba2d741c62afcdfbe37', 173);
CREATE UNIQUE INDEX CONSTRAINT_INDEX_1 ON CFG_TEMPLATETYPE(LABEL);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-54', '2.0.5', '3:e7690b6da3a8909f45ebcf3d26acb053', 174);
CREATE INDEX VALUESTORE_KEY_IDX ON CFG_VALUESTORE(FKEY);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-55', '2.0.5', '3:23c750b062f63d46ba1864989e2832c4', 175);
ALTER TABLE CFG_PARAMVALUE DROP COLUMN ASSIGNMENTID;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Column', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-56', '2.0.5', '3:1d6795c27b4f9fc0f0125a754071c8b1', 176);
DROP TABLE CFG_ASSIGNMENT;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-57', '2.0.5', '3:f5d77d622510abb91caed5398892dd88', 177);
DROP TABLE CFG_ASSIGNMENTDEPENDENCY;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-58', '2.0.5', '3:067a4217fe7e78bf31d3b66da4038a3d', 178);
DROP TABLE CFG_AT_INSTRDEPL_ASGN;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-59', '2.0.5', '3:c5857f6300dc2cf073335489663fa16d', 179);
DROP TABLE CFG_AT_TMPL_TMPLDEPLOY;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-60', '2.0.5', '3:c537c921280c6642ac7daddaaa1f1c8b', 180);
DROP TABLE CFG_AT_TMPLDEPL_ASGN;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-61', '2.0.5', '3:3783d253f13a429488f042428a2b6543', 181);
DROP TABLE CFG_CIREFERENCE;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-62', '2.0.5', '3:9f79354e4146225734e8e7a59363693c', 182);
DROP TABLE CFG_DELETEDASSIGNMENTS;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-63', '2.0.5', '3:878c655d25445df5066a71cba6663898', 183);
DROP TABLE CFG_DEPL_INSTPARAMVALUE;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-64', '2.0.5', '3:07672f28b860bbe22300ef38500c02db', 184);
DROP TABLE CFG_DEPL_PARAMVALUE;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-65', '2.0.5', '3:63df282530b4ba559d7b6836d9734760', 185);
DROP TABLE CFG_INSTR_DEPLOYMENT;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-66', '2.0.5', '3:06acc3875c1c4058fa25a74d5426e24a', 186);
DROP TABLE CFG_TEMPLATEDEPLOYMENT;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Drop Table', 'EXECUTED', 'db.changelog-10.00.xml',
 '1416380563941-67', '2.0.5', '3:6bf97c0bfb2105dc7b8578ecd2d8403e', 187);
ALTER TABLE CFG_AT_PKG_DEPLGROUPS ADD CONSTRAINT FKD168FD152010060F FOREIGN KEY (DEPLPKG_VER_ID) REFERENCES
 CFG_PKG_DEPLVER (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-40', '2.0.5', '3:a0ff74d6fd55d09effdd35476031a0fd', 188);
ALTER TABLE CFG_AT_PKG_OSVER ADD CONSTRAINT FK4F8701DB8A35D36D FOREIGN KEY (DEPLBIN_ID) REFERENCES CFG_PKG_DEPLBIN (ID) 
 ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-41', '2.0.5', '3:0dcc581e0a59170f8e0719899e561a9c', 189);
ALTER TABLE CFG_AT_PKG_SUB ADD CONSTRAINT FKFDAF7BDC8A35D36D FOREIGN KEY (DEPLBIN_ID) REFERENCES CFG_PKG_DEPLBIN (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-42', '2.0.5', '3:a9df6f486f3468b36151d8e6b6180f2d', 190);
ALTER TABLE CFG_PKG_DEPLBIN ADD CONSTRAINT FK944C927CDEEB0BC2 FOREIGN KEY (DEPLPKG_VERS_ID) REFERENCES CFG_PKG_DEPLVER
 (ID)  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-43', '2.0.5', '3:f90dffaf0dc4eef561340d3269622700', 191);
ALTER TABLE CFG_PKG_DEPLPKG ADD CONSTRAINT FK944CC741B7902732 FOREIGN KEY (DEPL_BIN_ID) REFERENCES CFG_PKG_DEPLBIN (ID) 
 ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-44', '2.0.5', '3:8f562ada7107e96ead3cc091c7e128c6', 192);
ALTER TABLE CFG_PKG_DEPLVER ADD CONSTRAINT FK944CDD18D623B216 FOREIGN KEY (BUNDLE_ID) REFERENCES CFG_PKG_DEPLBUNDLE (ID)
  ;
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Add Foreign Key Constraint', 'EXECUTED',
 'db.changelog-10.00.xml', '1416380563941-45', '2.0.5', '3:dff3cea8ba691439d5de6ba471e22af2', 193);
CREATE INDEX ASPECTVERSION_IDX ON CFG_PARAMETER(ASPECT_VERSION);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-1', '2.0.5', '3:8f1ac90638fbda3d46ff1591e3eb2a11', 194);
CREATE INDEX MTVERSION_IDX ON CFG_PARAMETER(MT_VERSION);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-2', '2.0.5', '3:04010aabd7c1255b072de7fdcdf8a90f', 195);
CREATE INDEX PARENT_IDX ON CFG_PARAMETER(PARENT_INST_PARAM_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-3', '2.0.5', '3:8b9595e80e9a16121b3df93ff09cf00d', 196);
CREATE INDEX TEMPLATEVERSION_IDX ON CFG_PARAMETER(TEMPLATE_VERSION);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-4', '2.0.5', '3:59fbe90eec7a1e3b484c832ae8ee5d1f', 197);
CREATE INDEX PARAMETER_IDX1 ON CFG_AT_PARAM_ENUMVAL(PARAMETER_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-5', '2.0.5', '3:40a0c089fd31f4ace6c279f75e1bf7f9', 198);
CREATE INDEX PARAMETER_IDX2 ON CFG_CONDITION(PARAMETER);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-6', '2.0.5', '3:9b719af2e8714742eaa1506fa5370efa', 199);
CREATE INDEX TEMPLATEVER_IDX1 ON CFG_TEMPLATEFILE(TMPL_VER_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-7', '2.0.5', '3:577fc4eb8cce30248eeb91b3a2459a1c', 200);
CREATE INDEX TEMPLATEVER_IDX2 ON CFG_AT_TMPLVER_INSTR(TMPLVERSION_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-8', '2.0.5', '3:f4bc5db15cdb19967a895965767e105d', 201);
CREATE INDEX TEMPLATEVER_IDX3 ON CFG_AT_TMPLVER_OSTYPE(TMPLVERSION_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-9', '2.0.5', '3:5f206e701f5aa125495625a6c93db041', 202);
CREATE INDEX TEMPLATE_IDX ON CFG_TEMPLATEVERSION(TEMPLATE_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-10', '2.0.5', '3:ae874f728b13d7a308e9bac6aea33785', 203);
CREATE INDEX TEMPLATEVER_IDX4 ON CFG_CONDITION(TEMPLATE_VERSION);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-11', '2.0.5', '3:1c51b52900818bb0b5fd4d729fe0d490', 204);
CREATE INDEX ASPECTVER_IDX1 ON CFG_AT_ASPVERS_TMPLVERS(ASPECTVERSION_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-12', '2.0.5', '3:52481bce88c5c8ac5afb124df4580f51', 205);
CREATE INDEX ASPECTVER_IDX2 ON CFG_AT_ASPVERS_INSTR(ASPECTVERSION_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-13', '2.0.5', '3:2565ca5b4a3ec5ce6f010dec5d8b3db9', 206);
CREATE INDEX ASPECTVER_IDX3 ON CFG_AT_ASPVERS_CITYPE(ASPECTVERSION_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-14', '2.0.5', '3:9296652b5ae111c4389fc0b7bb480606', 207);
CREATE INDEX ASPECTVER_IDX4 ON CFG_AT_ASPVERS_ASPVERS(ASPECTVERSION_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-15', '2.0.5', '3:aceb4989b2bdc14efd595542758857fe', 208);
CREATE INDEX ASPECTVER_IDX5 ON CFG_CONDITION(ASPECT_VERSION);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-16', '2.0.5', '3:471c397301f5848581a60f99cfdbced1', 209);
CREATE INDEX GRPPARAM_IDX ON CFG_AT_GRPPARAM_PARAM(GROUPPARAM_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-17', '2.0.5', '3:76e24f6f1d3aa8e84ee6c8359fa2f171', 210);
CREATE INDEX MTVER_IDX ON CFG_MGMT_TOPOPATH(MGMTTEMPLATE_VER_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-18', '2.0.5', '3:36f6ec1f39711159f9e1d5fe4a2b81b0', 211);
CREATE INDEX MTGRPPARAM_IDX ON CFG_MGMTPARAM_GROUPING(MGMTPARAM_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-19', '2.0.5', '3:d958ec818cd1046da4d36d08bdcb7355', 212);
CREATE INDEX PARAMVALUEAUTOASSIGNMENTID ON CFG_PARAMVALUE(AUTOASSIGNMENTID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-41', '2.0.5', '3:5b90a811729b7648f53c5484a5bbd8b9', 213);
CREATE INDEX PARAMVALUEPARENTINSTPARAMVALID ON CFG_PARAMVALUE(PARENTINSTPARAMVALID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-42', '2.0.5', '3:114c0649ad4fa59abf1a130e26d0d651', 214);
CREATE INDEX PARAMVALUEPARAMID ON CFG_PARAMVALUE(PARAMID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-43', '2.0.5', '3:b32c0f5a4df5fcce0f6924b1a8371595', 215);
CREATE INDEX PARAMVALUEORGPARAMID ON CFG_PARAMVALUE(ORGPARAMID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-44', '2.0.5', '3:ca67798756e6aef3e48a4665750e97f1', 216);
CREATE INDEX PARAMVALUETOPOPATHID ON CFG_PARAMVALUE(TOPOPATH_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-45', '2.0.5', '3:130dca16f1dc58f10aa0a62957f54f42', 217);
CREATE INDEX PARAMVALUETUNEDASPECTID ON CFG_PARAMVALUE(TUNED_ASPECT_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-46', '2.0.5', '3:c5fc75eea11dbfc6b751c6200cbfb838', 218);
CREATE INDEX MGMTPARAMGROUPINGPARAMETERID ON CFG_MGMTPARAM_GROUPING(PARAMETER_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-50', '2.0.5', '3:f0ad99cf798d4c892754bfbda76a9647', 219);
CREATE INDEX ATGRPPARAMPARAMPARAMID ON CFG_AT_GRPPARAM_PARAM(PARAM_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-51', '2.0.5', '3:3917ef88a089456ec84499fed518eb4f', 220);
CREATE INDEX ATASPVERTMPLVERTMPLVERSIONID ON CFG_AT_ASPVERS_TMPLVERS(TMPLVERSION_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-52', '2.0.5', '3:bffe07d3e846e85df43be982332dfd84', 221);
CREATE INDEX ATTMPLVERINSTRINSTRID ON CFG_AT_TMPLVER_INSTR(INSTRUMENTATION_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-53', '2.0.5', '3:743050e057b0822a1a2b8ade38d07f72', 222);
CREATE INDEX ATASSIGNMENTCI1 ON CFG_AT_ASSIGNMENT_CI(CI_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-54', '2.0.5', '3:f2d0d7884ba5529a33e559d3ce536af2', 223);
CREATE INDEX ATASSIGNMENTCI2 ON CFG_AT_ASSIGNMENT_CI(DIRECT_ASSIGNMENT_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-55', '2.0.5', '3:4d88ddc0eb1d867a5c26ae2fdd71fd58', 224);
CREATE INDEX DIRECTASSIGNMENT1 ON CFG_DIRECTASSIGNMENT(VERSION_OBJECT_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-57', '2.0.5', '3:960680eabff2a1e707c0eb7bb2daac8c', 225);
CREATE INDEX DIRECTASSIGNMENT2 ON CFG_DIRECTASSIGNMENT(CI_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-58', '2.0.5', '3:6f9bc86cb11bfa78fd95cd6331ed2a41', 226);
CREATE INDEX DELASSGNDEPL ON CFG_DEL_ASSGN_DEPL(ASSIGN_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-59', '2.0.5', '3:4e11680e806b0af34c70d248a5bcda4b', 227);
CREATE INDEX DEPLVALS1 ON CFG_DEPL_VALS(OBJ_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-60', '2.0.5', '3:a61143b159a15af5a3e22bc18aa97617', 228);
CREATE INDEX DEPLVALS2 ON CFG_DEPL_VALS(CI_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-61', '2.0.5', '3:f6a97cb34586c4b794717ed6c103a04b', 229);
CREATE INDEX ASSVALS1 ON CFG_ASS_VALS(OBJ_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-62', '2.0.5', '3:728f4fbd7517cf16a571a619c50c6957', 230);
CREATE INDEX ASSVALS2 ON CFG_ASS_VALS(CI_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-63', '2.0.5', '3:0fb390a1bc48378231de711d0cfe9727', 231);
CREATE INDEX TUNEDASSIGNMENT ON CFG_TUNEDASSIGNMENT(CI_ID);
INSERT INTO DATABASECHANGELOG (AUTHOR, COMMENTS, DATEEXECUTED, DESCRIPTION, EXECTYPE, FILENAME, ID, LIQUIBASE, MD5SUM,
 ORDEREXECUTED) VALUES ('Hewlett-Packard', '', SYSTIMESTAMP, 'Create Index', 'EXECUTED', 'db.changelog-indices.xml',
 '1363189879379-64', '2.0.5', '3:75aac98b802265664d868095fb12e8ba', 232);


-- V10.01.041.1__Event_Oracle_SchemaUpgrade.sql

BEGIN
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'C000_AUTOMATION_RULES' AND COLUMN_NAME = 'RST_ON_DUPLICATE';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE C000_AUTOMATION_RULES ADD RST_ON_DUPLICATE NUMBER(1, 0)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'C001_AUTOMATION_RULES' AND COLUMN_NAME = 'RST_ON_DUPLICATE';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE C001_AUTOMATION_RULES ADD RST_ON_DUPLICATE NUMBER(1, 0)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'UI_SETTINGS' AND COLUMN_NAME = 'MULTI_SELECT';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE UI_SETTINGS ADD MULTI_SELECT NUMBER(1, 0)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'ALL_EVENTS' AND COLUMN_NAME = 'TIME_FIRST_RECEIVED';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE ALL_EVENTS ADD TIME_FIRST_RECEIVED TIMESTAMP(6)';
  END IF;
  END;
END;
/


-- V10.01.041.2__PD_Oracle_SchemaUpdate.sql

BEGIN
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'PMI_SERVICE_DASHBOARD';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE
    'create table PMI_SERVICE_DASHBOARD
     ( TEMPLATE_PATH varchar2(255) not null,
       LAST_UPDATED_TIME numeric(19,0) null,
       READ_ONLY number(1,0) null,
       TEMPLATE_CONTENTS blob null,
       CUSTOMERID int null,
       primary key (TEMPLATE_PATH)
     )';
    END IF;
  END;
END;
/


-- V10.10.028.1__Event_Oracle_SchemaUpgrade.sql

-- Create new tables
BEGIN
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'MARBLE_PERSIST_1';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE 'CREATE TABLE MARBLE_PERSIST_1 (ID VARCHAR2(255 CHAR) NOT NULL, PARTITION_ID NUMBER(10, 0) NOT NULL, CUSTOMER_ID NUMBER(10, 0) NOT NULL, MP_TIMESTAMP NUMBER(19, 0) NOT NULL, MP_ACTION NUMBER(10, 0) NOT NULL, SERIAL_NUMBER NUMBER(10, 0) NOT NULL, SERVER_NAME VARCHAR2(255 CHAR) NOT NULL, MP_VERSION VARCHAR2(255 CHAR) NOT NULL, MP_STATE BLOB NOT NULL, primary key (ID))';
    EXECUTE IMMEDIATE 'CREATE INDEX MARBLE_PERSIST_1_IX1 ON MARBLE_PERSIST_1(PARTITION_ID, CUSTOMER_ID)';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'MARBLE_PERSIST_2';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE 'CREATE TABLE MARBLE_PERSIST_2 (ID VARCHAR2(255 CHAR) NOT NULL, PARTITION_ID NUMBER(10, 0) NOT NULL, CUSTOMER_ID NUMBER(10, 0) NOT NULL, MP_TIMESTAMP NUMBER(19, 0) NOT NULL, MP_ACTION NUMBER(10, 0) NOT NULL, SERIAL_NUMBER NUMBER(10, 0) NOT NULL, SERVER_NAME VARCHAR2(255 CHAR) NOT NULL, MP_VERSION VARCHAR2(255 CHAR) NOT NULL, MP_STATE BLOB NOT NULL, primary key (ID))';
    EXECUTE IMMEDIATE 'CREATE INDEX MARBLE_PERSIST_2_IX1 ON MARBLE_PERSIST_2(PARTITION_ID, CUSTOMER_ID)';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'MARBLE_PERSIST_GARBAGE';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE 'CREATE TABLE MARBLE_PERSIST_GARBAGE (ID VARCHAR2(255 CHAR) NOT NULL, CUSTOMER_ID NUMBER(10, 0) NOT NULL, PARTITION_ID NUMBER(10, 0) NOT NULL, MP_TIMESTAMP NUMBER(19, 0) NOT NULL, MP_ACTION NUMBER(10, 0) NOT NULL, SERIAL_NUMBER NUMBER(10, 0) NOT NULL, SERVER_NAME VARCHAR2(255 CHAR) NOT NULL, MP_VERSION VARCHAR2(255 CHAR) NOT NULL, MP_STATE BLOB NOT NULL, primary key (ID))';
    EXECUTE IMMEDIATE 'CREATE INDEX MARBLE_PERSIST_GARBAGE_IX1 ON MARBLE_PERSIST_GARBAGE(CUSTOMER_ID, PARTITION_ID)';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'MARBLE_PERSIST_LAST_WRITE';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE 'CREATE TABLE MARBLE_PERSIST_LAST_WRITE (ID VARCHAR2(255 CHAR) NOT NULL, TABLE_NAME VARCHAR2(255 CHAR) NOT NULL, CUSTOMER_ID NUMBER(10, 0) NOT NULL, PARTITION_ID NUMBER(10, 0) NOT NULL, primary key (ID))';
    EXECUTE IMMEDIATE 'CREATE INDEX MARBLE_PERSIST_LAST_WRITE_IX2 ON MARBLE_PERSIST_LAST_WRITE(TABLE_NAME, CUSTOMER_ID, PARTITION_ID)';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'MARBLE_PERSIST_NEXT_WRITE';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE 'CREATE TABLE MARBLE_PERSIST_NEXT_WRITE (ID VARCHAR2(255 CHAR) NOT NULL, TABLE_NAME VARCHAR2(255 CHAR) NOT NULL, MP_TIMESTAMP NUMBER(19, 0) NOT NULL, primary key (ID))';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'USS_GROUPS';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE 'CREATE TABLE USS_GROUPS (ID VARCHAR2(255 CHAR) NOT NULL, VERSION NUMBER(10, 0) NOT NULL, NAME VARCHAR2(255 CHAR), primary key (ID), unique (NAME))';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'USS_KEYS';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE 'CREATE TABLE USS_KEYS (ID VARCHAR2(255 CHAR) NOT NULL, VERSION NUMBER(10, 0) NOT NULL, NAME VARCHAR2(255 CHAR), primary key (ID), unique (NAME))';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'USS_KEYS_GROUPS';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE 'CREATE TABLE USS_KEYS_GROUPS (KEYID VARCHAR2(255 CHAR) NOT NULL, GROUPID VARCHAR2(255 CHAR) NOT NULL, PRIMARY KEY (KEYID, GROUPID))';
	EXECUTE IMMEDIATE 'ALTER TABLE USS_KEYS_GROUPS ADD CONSTRAINT FK1002EAB5A0D86305 FOREIGN KEY (KEYID) REFERENCES USS_KEYS (ID)';
	EXECUTE IMMEDIATE 'ALTER TABLE USS_KEYS_GROUPS ADD CONSTRAINT FK1002EAB5E280045 FOREIGN KEY (GROUPID) REFERENCES USS_GROUPS (ID)';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'USS_USERVALUES';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE 'CREATE TABLE USS_USERVALUES (ID VARCHAR2(255 CHAR) NOT NULL, VERSION NUMBER(10, 0) NOT NULL, UVKEY VARCHAR2(255 CHAR) NOT NULL, UVUSER VARCHAR2(255 CHAR), UVINSTANCE VARCHAR2(255 CHAR), VALUE VARCHAR2(255 CHAR))';
	EXECUTE IMMEDIATE 'ALTER TABLE USS_USERVALUES ADD CONSTRAINT FKC91131B7A16CD369 FOREIGN KEY (UVKEY) REFERENCES USS_KEYS (ID)';
    END IF;
  END;
-- Create new columns
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'HISTORY_LINE' AND COLUMN_NAME = 'PREVIOUS_EVENT_STATE';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE HISTORY_LINE ADD PREVIOUS_EVENT_STATE VARCHAR2(255 CHAR)';
	EXECUTE IMMEDIATE 'CREATE INDEX INDEXOVERPREVSTATE ON HISTORY_LINE (PREVIOUS_EVENT_STATE)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'HISTORY_LINE' AND COLUMN_NAME = 'CURRENT_EVENT_STATE';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE HISTORY_LINE ADD CURRENT_EVENT_STATE VARCHAR2(255 CHAR)';
    EXECUTE IMMEDIATE 'CREATE INDEX INDEXOVERCURRENTSTATE ON HISTORY_LINE (CURRENT_EVENT_STATE)';	
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'HISTORY_LINE' AND COLUMN_NAME = 'PROP_CHANGE_XML';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE HISTORY_LINE ADD PROP_CHANGE_XML CLOB';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'C000_SBEC_RULE' AND COLUMN_NAME = 'BEHAVIOR';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE C000_SBEC_RULE ADD BEHAVIOR VARCHAR2(255 CHAR)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'C000_SBEC_RULE' AND COLUMN_NAME = 'USE_DUPLICATE_COUNTS';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE C000_SBEC_RULE ADD USE_DUPLICATE_COUNTS NUMBER(1, 0)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'C001_SBEC_RULE' AND COLUMN_NAME = 'BEHAVIOR';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE C001_SBEC_RULE ADD BEHAVIOR VARCHAR2(255 CHAR)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'C001_SBEC_RULE' AND COLUMN_NAME = 'USE_DUPLICATE_COUNTS';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE C001_SBEC_RULE ADD USE_DUPLICATE_COUNTS NUMBER(1, 0)';
  END IF;
  END;
-- Create additional indices
  DECLARE index_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(*) INTO index_exists FROM user_indexes WHERE index_name = 'INDEXOVERTIMESTATECHANGED';
    IF index_exists = 0 THEN
      EXECUTE IMMEDIATE 'CREATE INDEX INDEXOVERTIMESTATECHANGED ON ALL_EVENTS (TIME_STATE_CHANGED)';
    END IF;
  END;
END;
/


-- V10.10.028.2__MA_Oracle_SchemaUpgrade.sql

BEGIN
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'CFG_JOB' AND COLUMN_NAME = 'NEXT_RETRY';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE CFG_JOB ADD NEXT_RETRY TIMESTAMP(6)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'CFG_JOB' AND COLUMN_NAME = 'RETRY_COUNT';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE CFG_JOB ADD RETRY_COUNT NUMBER(*, 0) DEFAULT 0 NOT NULL';
  END IF;
  END;
END;
/


-- V10.10.028.3__PD_Oracle_SchemaUpgrade.sql

BEGIN
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'PMI_CITYPE_MAPPING';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE
    'CREATE TABLE PMI_CITYPE_MAPPING (CITYPE VARCHAR2(255 CHAR) NOT NULL, ID VARCHAR2(255 CHAR), CI_TYPE_LABEL VARCHAR2(255 CHAR), ATTRIBUTE VARCHAR2(255 CHAR), PATTERN VARCHAR2(255 CHAR), REPLACEMENT VARCHAR2(255 CHAR), ARTIFACT_ORIGIN VARCHAR2(255 CHAR), ASSIGNMENT_ORIGIN VARCHAR2(255 CHAR), VERSION VARCHAR2(255 CHAR), primary key (CITYPE))';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'PMI_CITYPE_MAPPING_PREDEFINED';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE
    'CREATE TABLE PMI_CITYPE_MAPPING_PREDEFINED (CITYPE VARCHAR2(255 CHAR) NOT NULL, ID VARCHAR2(255 CHAR), CI_TYPE_LABEL VARCHAR2(255 CHAR), ATTRIBUTE VARCHAR2(255 CHAR), PATTERN VARCHAR2(255 CHAR), REPLACEMENT VARCHAR2(255 CHAR), ARTIFACT_ORIGIN VARCHAR2(255 CHAR), ASSIGNMENT_ORIGIN VARCHAR2(255 CHAR), VERSION VARCHAR2(255 CHAR), primary key (CITYPE))';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'PMI_DASHBOARDS';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE
    'CREATE TABLE PMI_DASHBOARDS (ID VARCHAR2(255 CHAR) NOT NULL, TITLE VARCHAR2(255 CHAR), TAGS VARCHAR2(255 CHAR), DASHBOARD BLOB, LAST_UPDATED_TIME NUMBER(19, 0), IS_READ_ONLY NUMBER(1, 0), CUSTOMERID NUMBER(10, 0), IS_FAVORITE NUMBER(1, 0), USERID VARCHAR2(255 CHAR), GRAPH_FAMILY_ID VARCHAR2(255 CHAR), primary key (ID))';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM user_tables WHERE table_name = 'PMI_DASHBOARD_ASSIGNEMENT';
    IF cnt = 0 THEN
    EXECUTE IMMEDIATE
    'CREATE TABLE PMI_DASHBOARD_ASSIGNEMENT (ID VARCHAR2(255 CHAR) NOT NULL, DASHBOARD_UUID VARCHAR2(255 CHAR), CUSTOMERID NUMBER(10, 0), CI_TYPE VARCHAR2(255 CHAR), IS_DEFAULT NUMBER(1, 0), CI_PROPERTY VARCHAR2(255 CHAR), primary key (ID))';
    END IF;
  END;
END;
/


-- V10.11.016.1__Event_Oracle_BVD_Tables.sql

BEGIN
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*)
    INTO cnt
    FROM user_tables
    WHERE table_name = 'C000_BVD_FWD_RULES';
    IF cnt = 0
    THEN
      EXECUTE IMMEDIATE
      'create table C000_BVD_FWD_RULES
       ( ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         VERSION NUMBER(10,0) NOT NULL ENABLE,
         CREATOR VARCHAR2(255 CHAR),
         ENABLED NUMBER(1,0) NOT NULL ENABLE,
         LABEL VARCHAR2(255 CHAR) NOT NULL ENABLE,
         PREFIXES VARCHAR2(255 CHAR),
         DESCRIPTION CLOB,
         ARTIFACT_ORIGIN VARCHAR2(255 CHAR),
         PRIMARY KEY (ID)
        )';
    END IF;
  END;

  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*)
    INTO cnt
    FROM user_tables
    WHERE table_name = 'C001_BVD_FWD_RULES';
    IF cnt = 0
    THEN
      EXECUTE IMMEDIATE
      'create table C001_BVD_FWD_RULES
       ( ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         VERSION NUMBER(10,0) NOT NULL ENABLE,
         CREATOR VARCHAR2(255 CHAR),
         ENABLED NUMBER(1,0) NOT NULL ENABLE,
         LABEL VARCHAR2(255 CHAR) NOT NULL ENABLE,
         PREFIXES VARCHAR2(255 CHAR),
         DESCRIPTION CLOB,
         ARTIFACT_ORIGIN VARCHAR2(255 CHAR),
         PRIMARY KEY (ID)
        )';
    END IF;
  END;

  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*)
    INTO cnt
    FROM user_tables
    WHERE table_name = 'C000_BVD_DATA_FWD_RULE';
    IF cnt = 0
    THEN
      EXECUTE IMMEDIATE
      'create table C000_BVD_DATA_FWD_RULE
       ( ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         DATA_TYPE VARCHAR2(255 CHAR) NOT NULL ENABLE,
         VERSION NUMBER(10,0) NOT NULL ENABLE,
         EVT_DASHBOARD_ID VARCHAR2(255 CHAR),
         VIEW_NAME VARCHAR2(255 CHAR),
         KPIS CLOB,
         FAVORITE VARCHAR2(255 CHAR),
         DATA_ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         LIST_IDX NUMBER(10,0),
         PRIMARY KEY (ID),
         CONSTRAINT C000_DATA_TO_RULE FOREIGN KEY (DATA_ID)
         REFERENCES C000_BVD_FWD_RULES (ID) ENABLE
        )';
    END IF;
  END;

  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*)
    INTO cnt
    FROM user_tables
    WHERE table_name = 'C001_BVD_DATA_FWD_RULE';
    IF cnt = 0
    THEN
      EXECUTE IMMEDIATE
      'create table C001_BVD_DATA_FWD_RULE
       ( ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         DATA_TYPE VARCHAR2(255 CHAR) NOT NULL ENABLE,
         VERSION NUMBER(10,0) NOT NULL ENABLE,
         EVT_DASHBOARD_ID VARCHAR2(255 CHAR),
         VIEW_NAME VARCHAR2(255 CHAR),
         KPIS CLOB,
         FAVORITE VARCHAR2(255 CHAR),
         DATA_ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         LIST_IDX NUMBER(10,0),
         PRIMARY KEY (ID),
         CONSTRAINT C001_DATA_TO_RULE FOREIGN KEY (DATA_ID)
         REFERENCES C001_BVD_FWD_RULES (ID) ENABLE
        )';
    END IF;
  END;

  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*)
    INTO cnt
    FROM user_tables
    WHERE table_name = 'C000_BVD_TARGET';
    IF cnt = 0
    THEN
      EXECUTE IMMEDIATE
      'create table C000_BVD_TARGET
       ( RULE_ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         CONSRV_ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         PRIMARY KEY (RULE_ID, CONSRV_ID),
         CONSTRAINT C000_TARGET_TO_RULE FOREIGN KEY (RULE_ID)
         REFERENCES C000_BVD_FWD_RULES (ID) ENABLE
        )';
    END IF;
  END;

  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*)
    INTO cnt
    FROM user_tables
    WHERE table_name = 'C001_BVD_TARGET';
    IF cnt = 0
    THEN
      EXECUTE IMMEDIATE
      'create table C001_BVD_TARGET
       ( RULE_ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         CONSRV_ID VARCHAR2(255 CHAR) NOT NULL ENABLE,
         PRIMARY KEY (RULE_ID, CONSRV_ID),
         CONSTRAINT C001_TARGET_TO_RULE FOREIGN KEY (RULE_ID)
         REFERENCES C001_BVD_FWD_RULES (ID) ENABLE
        )';
    END IF;
  END;
END;
/


-- V10.50.006.1__Event_Oracle_FilterCategory.sql

BEGIN
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*)
    INTO cnt
    FROM user_tables
    WHERE table_name = 'C000_FILTER_CATEGORY';
    IF cnt = 0
    THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE C000_FILTER_CATEGORY (ID              VARCHAR2(255 CHAR) NOT NULL,
                                          VERSION         NUMBER(10, 0)      NOT NULL,
                                          CATEGORY_NAME   VARCHAR2(255 CHAR) NOT NULL,
                                          ARTIFACT_ORIGIN VARCHAR2(255 CHAR),
                                          PRIMARY KEY (ID, CATEGORY_NAME),
                                          UNIQUE (CATEGORY_NAME))';
    END IF;
  END;
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*)
    INTO cnt
    FROM user_tables
    WHERE table_name = 'C001_FILTER_CATEGORY';
    IF cnt = 0
    THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE C001_FILTER_CATEGORY (ID              VARCHAR2(255 CHAR) NOT NULL,
                                          VERSION         NUMBER(10, 0)      NOT NULL,
                                          CATEGORY_NAME   VARCHAR2(255 CHAR) NOT NULL,
                                          ARTIFACT_ORIGIN VARCHAR2(255 CHAR),
                                          PRIMARY KEY (ID, CATEGORY_NAME),
                                          UNIQUE (CATEGORY_NAME))';
    END IF;
  END;
END;
/


-- V10.60.001.1__Event_Oracle_SchemaUpgrade.sql

BEGIN
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'USS_USERVALUES' AND COLUMN_NAME = 'LARGEVALUE';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE USS_USERVALUES ADD LARGEVALUE clob';
  END IF;
  END;
END;
/


-- V10.60.001.2__Event_Oracle_SBEC.sql

BEGIN

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'HOLDSTORE_EVENT';
    IF (table_exists = 0) THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE HOLDSTORE_EVENT (
        ID VARCHAR2(255 CHAR) NOT NULL,
        VERSION NUMBER(10,0) NOT NULL,
        EVENTID VARCHAR2(255 CHAR) NOT NULL,
        EVENT BLOB NOT NULL,
        PRIMARY KEY (ID)
      )';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'HOLDSTORE_ONHOLD';
    IF (table_exists = 0) THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE HOLDSTORE_ONHOLD (
        ID VARCHAR2(255 CHAR) NOT NULL,
        VERSION NUMBER(10,0) NOT NULL,
        CONTAINER_UUID VARCHAR2(255 CHAR) NOT NULL,
        AUTORELEASEDATE TIMESTAMP NOT NULL,
        HELDEVENT VARCHAR2(255 CHAR) NOT NULL,
        PRIMARY KEY (ID)
      )';
      EXECUTE IMMEDIATE
      'ALTER TABLE HOLDSTORE_ONHOLD ADD CONSTRAINT HOLDSTORE_EVENT_TO_ONHOLD FOREIGN KEY (HELDEVENT) REFERENCES HOLDSTORE_EVENT';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'HOLDSTORE_RELEASED';
    IF (table_exists = 0) THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE HOLDSTORE_RELEASED (
        ID VARCHAR2(255 CHAR) NOT NULL,
        VERSION NUMBER(10, 0) NOT NULL,
        HELDEVENT VARCHAR2(255 CHAR) NOT NULL,
        ORDER_NUMBER NUMBER(10, 0) NOT NULL,
        PRIMARY KEY (ID),
        UNIQUE (ORDER_NUMBER)
      )';
      EXECUTE IMMEDIATE
      'ALTER TABLE HOLDSTORE_RELEASED ADD CONSTRAINT HOLDSTORE_EVENT_TO_RELEASED FOREIGN KEY (HELDEVENT) REFERENCES HOLDSTORE_EVENT';
    END IF;
  END;

  --

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'C000_ESC_HS_EOH';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE C000_ESC_HS_EOH';
    END IF;
  END;
  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'C000_ESC_HS_EVENT';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE C000_ESC_HS_EVENT';
    END IF;
  END;
  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'C001_ESC_HS_EOH';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE C001_ESC_HS_EOH';
    END IF;
  END;
  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'C001_ESC_HS_EVENT';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE C001_ESC_HS_EVENT';
    END IF;
  END;

END;
/


-- V10.60.001.3__UE_CleanupUE.sql

BEGIN
  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_CPACK_TO_ATEMPLATES';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_CPACK_TO_ATEMPLATES';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_CPACK_TO_EXPMAP';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_CPACK_TO_EXPMAP';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_CPACK_TO_WAYPOINTS';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_CPACK_TO_WAYPOINTS';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_CONTENTPACKAGE';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_CONTENTPACKAGE';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_AVATAR';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_AVATAR';
    END IF;
  END;
  
  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_WAYPOINT_CONDTEMPLATE';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_WAYPOINT_CONDTEMPLATE';
    END IF;
  END;  

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_CONDITION_TEMPLATE';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_CONDITION_TEMPLATE';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_LBCOUNTER';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_LBCOUNTER';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_USER_TO_USERGROUP';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_USER_TO_USERGROUP';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_USER_ROLE';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_USER_ROLE';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_TRIGGER';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_TRIGGER';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_PROGRESSINFO';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_PROGRESSINFO';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_ACHIEVEMENT';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_ACHIEVEMENT';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_CONDITION';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_CONDITION';
    END IF;
  END;
  
  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_ACHIEVEMENT_DEFINITION';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_ACHIEVEMENT_DEFINITION';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_CATEGORY_TO_ATEMPLATES';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_CATEGORY_TO_ATEMPLATES';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_ACHIEVEMENT_TEMPLATE';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_ACHIEVEMENT_TEMPLATE';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_CATEGORY_TO_USERGROUPS';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_CATEGORY_TO_USERGROUPS';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_CATEGORY';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_CATEGORY';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_Icon';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_Icon';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_LOC_ITEM';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_LOC_ITEM';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_MAP';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_MAP';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_OMIOWNER';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_OMIOWNER';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_ROLE';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_ROLE';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_RUNTIME_SERVER';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_RUNTIME_SERVER';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_SETTINGS';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_SETTINGS';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_TRIGGER_DEFINITION';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_TRIGGER_DEFINITION';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_USER';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_USER';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_USERGROUP';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_USERGROUP';
    END IF;
  END;

  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_WAYPOINT';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_WAYPOINT';
    END IF;
  END;
  
  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'EXC_NOTIFICATION';
    IF (table_exists = 1) THEN
      EXECUTE IMMEDIATE
      'DROP TABLE EXC_NOTIFICATION';
    END IF;
  END;
  
END;
/

-- V10.61.009.1__Event_Oracle_SchemaUpgrade.sql

BEGIN
-- Drop obsolete indices
  DECLARE index_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(*) INTO index_exists FROM user_indexes WHERE index_name = 'INDEX_ON_CMA_INDEXCOL';
    IF index_exists > 0 THEN
      EXECUTE IMMEDIATE 'DROP INDEX INDEX_ON_CMA_INDEXCOL';
    END IF;
  END;
-- Create additional indices
  DECLARE index_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(*) INTO index_exists FROM user_indexes WHERE index_name = 'INDEX_ON_CMA_UPPERIDX';
    IF index_exists = 0 THEN
      EXECUTE IMMEDIATE 'CREATE INDEX INDEX_ON_CMA_UPPERIDX ON EVENT_CUSTOM_ATTRIBUTES (upper(idx))';
    END IF;
  END;
END;
/


-- V10.62.001.1__Event_Oracle_SchemaUpgrade.sql

alter table ALL_EVENTS modify PARAMETER_STRING varchar2(4000 char);


-- V10.63.001.1__Event_Oracle_AgtCapabilityData.sql

BEGIN
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*)
    INTO cnt
    FROM user_tables
    WHERE table_name = 'AGT_CAPABILITY_DATA';
    IF cnt = 0
    THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE AGT_CAPABILITY_DATA (
        ID                     VARCHAR2(255 CHAR) NOT NULL,
        VERSION                NUMBER(10, 0)      NOT NULL,
        COMMUNICATION_MODE     VARCHAR2(255 CHAR) NOT NULL,
        SUPPORTED_POLICY_TYPES CLOB,
        PRIMARY KEY (ID)
      )';
    END IF;
  END;
END;
/


-- V10.63.001.2__Event_Oracle_AddIndexToOmCiMapping.sql
BEGIN
-- Create additional indices
  DECLARE index_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(*) INTO index_exists FROM user_indexes WHERE index_name = 'IDX_HOSTNAME_ALIAS_TYPE';
    IF index_exists = 0 THEN
      EXECUTE IMMEDIATE 'CREATE INDEX IDX_HOSTNAME_ALIAS_TYPE ON OMCID_CMDB_MAPPINGS (OM_HOSTNAME, UCMDB_CITYPE, IS_ALIAS)';
    END IF;
  END;
END;
/



-- V10.63.001.3__Event_Oracle_RemoveNotNullConstraint.sql

-- remove not null constraint
BEGIN
  DECLARE cnt NUMBER;
  BEGIN
    SELECT count(*) INTO cnt FROM all_tab_cols WHERE table_name = 'HISTORY_LINE' AND column_name = 'PROP_CHANGE_XML' AND nullable = 'Y';
    IF cnt = 0 THEN
      EXECUTE IMMEDIATE 'ALTER TABLE HISTORY_LINE modify PROP_CHANGE_XML NULL';
    END IF;
  END;
END;
/

-- V10.70.001.1__Event_Oracle_CiLicenseCount.sql

BEGIN
  DECLARE table_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO table_exists FROM user_tables WHERE table_name = 'CI_LICENSE_COUNT';
    IF (table_exists = 0) THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE CI_LICENSE_COUNT (
        ID VARCHAR2(255 CHAR) NOT NULL,
        VERSION NUMBER(10,0) NOT NULL,
        TENANT VARCHAR2(100 CHAR) NOT NULL,
        COUNT_TIMESTAMP TIMESTAMP NOT NULL,
        FULL_LICENSE_COUNT NUMBER(10,0) NOT NULL,
        REDUCED_LICENSE_COUNT NUMBER(10,0) NOT NULL,
        PRIMARY KEY (ID)
      )';
    END IF;
  END;
  -- Create additional indices
  DECLARE index_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(*) INTO index_exists FROM user_indexes WHERE index_name = 'INDEXOVERCICOUNTTIMESTAMP';
    IF index_exists = 0 THEN
      EXECUTE IMMEDIATE 'CREATE INDEX INDEXOVERCICOUNTTIMESTAMP ON CI_LICENSE_COUNT (COUNT_TIMESTAMP)';
    END IF;
  END;
END;
/


-- V10.71.001.1__Event_Oracle_AgentTenant.sql

BEGIN
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'LIC_PRODUCT_COUNT' AND COLUMN_NAME = 'TENANT';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE LIC_PRODUCT_COUNT ADD TENANT VARCHAR2(100 CHAR)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'LIC_PRODUCT_COUNT' AND COLUMN_NAME = 'CORE_ID';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE LIC_PRODUCT_COUNT ADD CORE_ID VARCHAR2(255 CHAR)';
  END IF;
  END;
END;
/


-- V10.71.001.2__Event_EventStorm.sql

BEGIN
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'C000_ESS_CONFIGS' AND COLUMN_NAME = 'PREFER_NODE_HINT';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE C000_ESS_CONFIGS ADD PREFER_NODE_HINT NUMBER(1,0)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'C001_ESS_CONFIGS' AND COLUMN_NAME = 'PREFER_NODE_HINT';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE C001_ESS_CONFIGS ADD PREFER_NODE_HINT NUMBER(1,0)';
  END IF;
  END;
END;
/


-- V10.72.001.0__ActionScoring_Oracle_Tables.sql

BEGIN
  DECLARE table_exists NUMBER;
  BEGIN
    SELECT COUNT(*) INTO table_exists FROM user_tables WHERE table_name = 'TSEVENTSOLUTION';
    IF table_exists = 0 THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE TSEVENTSOLUTION (
		IDTSEVENTSOLUTION 		VARCHAR(128) 	NOT NULL, 
		EVENTTYPE 				VARCHAR(128) 	NOT NULL, 
		CONSTRAINT PK_TSEVENTSOLUTION 
		PRIMARY KEY (IDTSEVENTSOLUTION)
		)';
    END IF;
  END;    
DECLARE table_exists NUMBER;
  BEGIN
    SELECT COUNT(*) INTO table_exists FROM user_tables WHERE table_name = 'TSEVENTTYPE';
    IF table_exists = 0 THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE TSEVENTTYPE (
		EVENTID 				VARCHAR(64) 	NOT NULL, 
		EVENTTITLE 			VARCHAR(1024), 
		EVENTTYPE 				VARCHAR(128),
		CONSTRAINT PK_TSEVENTTYPE 
		PRIMARY KEY (EVENTID)
		)';
    END IF;
  END;    
DECLARE table_exists NUMBER;
  BEGIN
    SELECT COUNT(*) INTO table_exists FROM user_tables WHERE table_name = 'TSSOLUTIONS';
    IF table_exists = 0 THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE TSSOLUTIONS (
		SOLUTIONID 				VARCHAR(128) 	NOT NULL, 
		EXECUTIONCOUNT 			VARCHAR(128),
		HELPFULCOUNT					VARCHAR(128),
		NOTHELPFULCOUNT				VARCHAR(128),
		DESCRIPTION				VARCHAR(1024),
		SOLUTIONSOURCE			VARCHAR(128),
		SOLUTIONTARGETID		VARCHAR(128),
		TITLE					VARCHAR(128),
		SUCCESSPCT				NUMERIC(10, 2),
		SUCCESSFULCOUNT 				VARCHAR(128),
		UNIQUEID				VARCHAR(128),
		IDTSEVENTSOLUTION		VARCHAR(128),
		CONSTRAINT PK_TSSOLUTIONS
		PRIMARY KEY (SOLUTIONID)
		)';
	   EXECUTE IMMEDIATE
	   'ALTER TABLE TSSOLUTIONS ADD CONSTRAINT TSSOLUTIONS_TO_TSEVENTSOLUTION FOREIGN KEY (IDTSEVENTSOLUTION)
		REFERENCES TSEVENTSOLUTION (IDTSEVENTSOLUTION)';	   
    END IF;
  END;
DECLARE table_exists NUMBER;
  BEGIN
    SELECT COUNT(*) INTO table_exists FROM user_tables WHERE table_name = 'TSEXECUTIONTOKEN';
    IF table_exists = 0 THEN
      EXECUTE IMMEDIATE
      'CREATE TABLE TSEXECUTIONTOKEN (
		HASHEDTOKEN				VARCHAR(64)		NOT NULL,
		TIMESTAMPOFTOKEN 		TIMESTAMP 		NOT NULL,
		CONSTRAINT PK_TSEXECUTIONTOKEN
		PRIMARY KEY (HASHEDTOKEN)
	)';	   
    END IF;
  END;
END;
/
-- V10.72.001.1__Event_Oracle_ServerKeyStore.sql

BEGIN
  DECLARE column_nullable USER_TAB_COLS.NULLABLE%TYPE;
  BEGIN
   SELECT NULLABLE INTO column_nullable
     FROM USER_TAB_COLS
     WHERE TABLE_NAME = 'SERVER_KEY_STORE' AND COLUMN_NAME = 'BIN_DATA';
   IF column_nullable = 'N' THEN
     EXECUTE IMMEDIATE 'ALTER TABLE SERVER_KEY_STORE MODIFY BIN_DATA NULL';
   END IF;
  END;

  DECLARE column_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
      WHERE TABLE_NAME = 'SERVER_KEY_STORE' AND COLUMN_NAME = 'BCFKS_DATA';
    IF (column_exists = 0) THEN
      EXECUTE IMMEDIATE 'ALTER TABLE SERVER_KEY_STORE ADD BCFKS_DATA blob';
    END IF;
  END;
END;
/


-- V10.82.001.0__ActionScoring_Oracle_TableModification_EventType.sql

-- CHANGING DATATYPE TO CLOB FOR TSEVENTTYPE.EVENTTITLE
BEGIN
	DECLARE eventType_dataType VARCHAR2(100) := 'no';
	BEGIN
		SELECT DATA_TYPE INTO eventType_dataType
		FROM all_tab_columns
		WHERE
			COLUMN_NAME = 'EVENTTITLE' AND TABLE_NAME = 'TSEVENTTYPE';

		IF (eventType_dataType = 'VARCHAR2') THEN
		BEGIN
			EXECUTE IMMEDIATE 'ALTER TABLE TSEVENTTYPE ADD EVENTTITLEBCK CLOB';
			EXECUTE IMMEDIATE 'UPDATE TSEVENTTYPE SET EVENTTITLEBCK = EVENTTITLE' ;
			EXECUTE IMMEDIATE 'ALTER TABLE TSEVENTTYPE DROP COLUMN EVENTTITLE';
			EXECUTE IMMEDIATE 'ALTER TABLE TSEVENTTYPE RENAME COLUMN EVENTTITLEBCK TO EVENTTITLE';
		END;
		END IF ;
	END;

	-- CHANGING DATATYPE LENGTH TO 255 FOR TSSOLUTION.TITLE

	DECLARE toolTitle_dataType INTEGER := 999;
	BEGIN
		SELECT DATA_LENGTH INTO toolTitle_dataType
		FROM all_tab_columns
		WHERE
			COLUMN_NAME = 'TITLE' AND TABLE_NAME = 'TSSOLUTIONS';

		IF (toolTitle_dataType < 255) THEN
		BEGIN
			EXECUTE IMMEDIATE 'ALTER TABLE TSSOLUTIONS ADD TITLEBCK VARCHAR(255)';
			EXECUTE IMMEDIATE 'UPDATE TSSOLUTIONS SET TITLEBCK = TITLE' ;
			EXECUTE IMMEDIATE 'ALTER TABLE TSSOLUTIONS DROP COLUMN TITLE';
			EXECUTE IMMEDIATE 'ALTER TABLE TSSOLUTIONS RENAME COLUMN TITLEBCK TO TITLE';
		END;
		END IF ;
	END;
END;
/
-- V10.82.003.1__Event_Oracle_SchemaUpgrade.sql

create index fwInfoToForwardingState on EVENT_FORWARDING_INFO (FORWARDING_STATE);
create index fwInfoToForwardingType on EVENT_FORWARDING_INFO (FORWARDING_TYPE);

-- V10.83.001.1__Event_Oracle_SchemaUpgrade.sql

BEGIN
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'AGENT_STATE' AND COLUMN_NAME = 'LAST_LIFE_SIGN';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE AGENT_STATE ADD LAST_LIFE_SIGN number(19,0)';
  END IF;
  END;
END;
/


-- V11.00.001.1__Event_Oracle_PatternEnhancements.sql

BEGIN
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'ALL_EVENTS' AND COLUMN_NAME = 'PATTERN_SEPS';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE ALL_EVENTS ADD PATTERN_SEPS varchar2(255 char)';
  END IF;
  END;
  DECLARE column_exists NUMBER := 0;
  BEGIN
  SELECT COUNT(1) INTO column_exists FROM USER_TAB_COLS
    WHERE TABLE_NAME = 'ALL_EVENTS' AND COLUMN_NAME = 'PATTERN_IGNORE_CASE';
  IF (column_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE ALL_EVENTS ADD PATTERN_IGNORE_CASE number(1,0)';
  END IF;
  END;
END;
/
