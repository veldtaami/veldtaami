/************************************************************************/
/*   FileName    : oracle_tablespace_create.sql                 	*/
/*   Description : create a new oracle tablespace with to given params  */	
/*                                                                     	*/
/*   Parameters  : 1) Tablespace name					*/
/*                 2) Full path tablespace file				*/
/*                 3) Tablespace file size in Kb			*/
/*                                                                     	*/
/*   Created by  : Topaz DB Team 18-Jan-04		               	*/
/*      	 							*/
/************************************************************************/

set echo on
set feedback on
set autoprint on
set serveroutput on size 20000

spool oracle_tablespace_create.log

prompt Creating tablespace &&1 into file: &&2 with size of &&3

CREATE TABLESPACE &&1
    LOGGING 
    DATAFILE 
    '&&2' SIZE &&3 REUSE
    EXTENT MANAGEMENT LOCAL 
    SEGMENT SPACE MANAGEMENT AUTO 
/

spool off

EXIT;
