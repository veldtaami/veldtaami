#!/bin/sh

usage()
{
   clear
   cat << __END__

   Used for: This batch creates Oracle tablespace for Topaz.

   Usage   : oracle_tablespace_create [admin_user] [admin_password] 
   		 [conn_str] [tableaspace_name] [file_name] [file_size] .

   PARAMETERS :
     1) [admin_user]            = Username, with Administrative DB Privilages.
     2) [admin_password]        = Password Of The Above user.
     3) [conn_str]              = DB Connection String As In Tnsnames.ora .
     4) [tablespace_name]       = Tablespace name to be created.
     5) [file_name]             = Full path file name to be created.
     6) [file_size]             = File size (use M for Mb, K for Kb).

   e.g. :  oracle_tablespace_create system manager topaz 
           h:\oracle\oradata\topaz01.ora 50M
           
           
__END__
   exit 0
}


if [ "$1" = "" -o "$2" = "" -o "$3" = "" -o "$4" = "" -o "$5" = "" -o "$6" = "" ]; then 
   usage
fi           

echo   BATCH START !!

sqlplus -s $1/$2@$3 @oracle_tablespace_create.sql $4 $5 $6

echo   BATCH ENDED !!

echo   Check The Log File oracle_tablespace_create.log In The Working Directory For Errors .

exit 0
