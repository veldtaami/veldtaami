#!/bin/sh

usage()
{
   clear
   cat << __END__

   Used for: This batch creates Oracle user for Topaz using SqlPlus,
 		 and then creates Topaz Management DB Objects.

   Usage   : management_ora_dbobjects_create [admin_user] [admin_password] 
   		 [topaz_user] [topaz_password] [conn_str] [default_tablespace]
   		 [temporary_tablespace] .

   PARAMETERS :
     1) [admin_user]            = Username, with Administrative DB Privilages.
     2) [admin_password]        = Password Of The Above user.
     3) [topaz_user]            = Username to be created for topaz DB objects.
     4) [topaz_password] 	    = Password Of The Above user.
     5) [conn_str]              = DB Connection String As In Tnsnames.ora .
     6) [default_tablespace]    = Default tablespace for the above user.
     7) [temporary_tablespace]  = Temporary tablespace for the above user.

   e.g. :  management_ora_dbobjects_create system manager topaz topaz topaz.world tbs tmp .


__END__
   exit 0
}

if [ "$1" = "" -o "$2" = "" -o "$3" = "" -o "$4" = "" -o "$5" = "" -o "$6" = "" -o "$7" = "" ]; then 
   usage
fi  


echo   BATCH START !!

sqlplus -s $1/$2@$5 @oracle_user_create.sql $3 $4 $6 $7
sqlplus -s $3/$4@$5 @management_ora_dbobjects_create.sql

echo   BATCH ENDED !!

echo   Check The Log File (management_ora_dbobjects_create.log) In The Working Directory For Errors .


exit 0
