/************************************************************************/
/*   FileName    : oracle_user_create		  .sql                 	*/
/*   Description : create a new DB user according to given params      	*/	
/*                                                                     	*/
/*   Parameters  : 1) username to be created.		               	*/
/*                 2) password for the above user.			*/
/*                 3) Default tablespace name.                          */
/*                 4) Temporary tablespace name .                       */
/*                                                                     	*/
/*   Created by  : Tal Olier 02/04/2001			               	*/
/*   Modified By : 							*/
/*      	 							*/
/************************************************************************/

set echo on
set feedback on
set autoprint on
set serveroutput on size 20000

spool oracle_user_create.log

prompt creating oracle user: &&1 with password: &&2


CREATE USER &&1 IDENTIFIED BY &&2
DEFAULT TABLESPACE &&3
TEMPORARY TABLESPACE &&4;

GRANT "CONNECT" TO &&1;
GRANT CREATE SEQUENCE TO &&1;
GRANT CREATE TABLE TO &&1;
GRANT CREATE TRIGGER TO &&1;
GRANT UNLIMITED TABLESPACE TO &&1;
GRANT CREATE VIEW TO &&1;
GRANT CREATE PROCEDURE TO &&1;
ALTER USER &&1 DEFAULT ROLE ALL;

spool off

EXIT;
