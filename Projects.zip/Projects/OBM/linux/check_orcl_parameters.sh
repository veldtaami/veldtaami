#!/bin/bash
# check_orcl_parameters.sh for Oracle

clear
if [ -z $ORACLE_HOME ]; then
echo -e '\nThis script must be run by a user who has the $ORACLE_HOME variable set
Please login with the username oracle (or user with equivalent environment settings)' >&2
echo -e '\n'
exit 1
fi

/bin/clear
echo -e "\nPlease provide a username (system or user with equivalent privileges)\n"
read -p "Enter The Username: " USER
read -p "Enter The Oracle SID: " DB

CHGPARM=$(pwd)

/bin/clear

if [ -z $USER ] || [ -z $DB ]
then
read -p "
----------------------------------------------------------------------------------------
Please enter the User Name (system or user with equivalent privileges) and the ORACLE SID
at the appropriate prompt
----------------------------------------------------------------------------------------

Press any key to continue  "
else
$ORACLE_HOME/bin/sqlplus $USER@$DB @check_orcl_parameters.sql
fi
