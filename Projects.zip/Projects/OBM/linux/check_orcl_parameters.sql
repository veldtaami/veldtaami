set pagesize 60;
set linesize 200;
set echo off;
set verify off;
set feedback off;
set wrap on 
set serveroutput on


Declare 

strParameterSQL varchar(200) := 'SELECT value FROM v$parameter WHERE name = :1';
strParameterDefaultSQL varchar(200) := 'SELECT isdefault FROM v$parameter WHERE name = :1';
strRecycleBinSQL varchar(200) := 'select sum(space*8)/1024 space_in_MB from dba_recyclebin';
v_param v$parameter.value%type;
v_default v$parameter.isdefault%type;
v_size dba_recyclebin.space%type;
  
procedure recycle_bin
  is
  begin    
        execute immediate strRecycleBinSQL INTO v_size;  
        dbms_output.put_line('recyclebin size: ' || v_size || 'MB');
  end;

procedure check_param_int(param_name VARCHAR, default_value int)
  is
  begin
      begin
        execute immediate strParameterSQL INTO v_param using param_name;
      end;

      if TO_NUMBER(v_param) < default_value then
	if param_name = 'sga_target' and TO_NUMBER(v_param) = 0 then
          return;
	end if;

	dbms_output.put_line(param_name || ': '|| v_param || '. recommended value: ' || default_value);

      end if;
  end;  
  
procedure check_param_str(param_name VARCHAR, default_value VARCHAR)
  is
  begin
      begin
        execute immediate strParameterSQL INTO v_param using param_name;
      end;

      if UPPER(v_param) != UPPER(default_value) then
        dbms_output.put_line(param_name || ': '|| v_param || '. recommended value: ' || default_value);
        if param_name = 'recyclebin' then
          recycle_bin();
        end if;
      end if;
  end; 

procedure check_param_default(param_name VARCHAR)
  is
  begin
      begin
        execute immediate strParameterDefaultSQL INTO v_default using param_name;
      end;

      if v_default != 'TRUE' then
        dbms_output.put_line(param_name || ': '|| v_default || '. recommended to be oracle default ');
      end if;
  end; 
 
begin

dbms_output.put_line(chr(10));

check_param_int('db_block_size', 8192); 
check_param_str('db_cache_advice', 'ON'); 
check_param_int('sga_target', 4294967296); 
check_param_int('memory_target', 5368709120);
check_param_int('log_buffer', 5242880);
check_param_default('db_file_multiblock_read_count');
check_param_int('processes', 1000);
check_param_int('sessions', 1110);
check_param_int('optimizer_index_cost_adj', 100);
check_param_str('timed_statistics', 'TRUE'); 
check_param_str('log_checkpoint_interval', '0'); 
check_param_int('log_checkpoint_timeout', 1800);
check_param_str('optimizer_mode', 'ALL_ROWS');
check_param_str('cursor_sharing', 'EXACT');
check_param_int('open_cursors', 2000);
check_param_str('sql_trace', 'FALSE');
check_param_str('undo_management', 'AUTO');
check_param_default('undo_retention');
check_param_str('recyclebin', 'off');
check_param_str('nls_length_semantics', 'BYTE');
check_param_str('nls_comp', 'BINARY');
check_param_str('nls_sort', 'BINARY');
check_param_str('workarea_size_policy', 'AUTO');
check_param_int('pga_aggregate_target', 1073741824);
check_param_str('statistics_level', 'TYPICAL');
check_param_str('optimizer_capture_sql_plan_baselines', 'FALSE');
check_param_str('audit_trail', 'NONE');
check_param_str('cursor_space_for_time', 'FALSE');
check_param_str('blank_trimming', 'FALSE');
check_param_str('deferred_segment_creation', 'TRUE');

dbms_output.put_line(chr(10));

end;
/
exit;


