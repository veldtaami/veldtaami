CREATE OR REPLACE FUNCTION unix_to_date(unix_sec NUMBER)
RETURN date
IS
ret_date DATE;
BEGIN
    ret_date:=TO_DATE('19700101','YYYYMMDD')+( 1/ 24/ 60/ 60)*unix_sec;
    RETURN ret_date;
END;
/

Het gaat om de table “OO_EXECUTION_SUMMARY” (DB: SRV0PHOO101) waarbij de column “START_TIME_LONG” vertaald moet worden van epoch naar date/time. 


select START_TIME_LONG from owner_oox.OO_EXECUTION_SUMMARY where rownum < 2;

select max(TO_DATE('19700101','YYYYMMDD')+( 1/ 24/ 60/ 60)*START_TIME_LONG) as start_time_lng from owner_oox.OO_EXECUTION_SUMMARY ; 




RABO_USER @ srv0phoo101 > desc owner_oox.OO_EXECUTION_SUMMARY
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 ID                                        NOT NULL NUMBER(38)
 EXECUTION_ID                              NOT NULL VARCHAR2(255 CHAR)
 BRANCH_ID                                 NOT NULL VARCHAR2(255 CHAR)
 STATUS                                    NOT NULL VARCHAR2(255 CHAR)
 START_TIME                                         TIMESTAMP(6)
 END_TIME                                           TIMESTAMP(6)
 FLOW_UUID                                 NOT NULL VARCHAR2(255 CHAR)
 FLOW_PATH                                          VARCHAR2(1024 CHAR)
 RESULT_STATUS_TYPE                                 VARCHAR2(255 CHAR)
 RESULT_STATUS_NAME                                 VARCHAR2(255 CHAR)
 PAUSE_REASON                                       VARCHAR2(255 CHAR)
 OWNER                                     NOT NULL VARCHAR2(255 CHAR)
 TRIGGERED_BY                              NOT NULL VARCHAR2(255 CHAR)
 EXECUTION_NAME                                     VARCHAR2(255 CHAR)
 ROI                                                FLOAT(126)
 DURATION                                           NUMBER(38)
 TRIGGER_SOURCE                                     VARCHAR2(20 CHAR)
 LOG_LEVEL                                          VARCHAR2(50 CHAR)
 RUNNING_CONF_VERSION                               NUMBER(38)
 TIMEOUT                                            NUMBER(10)
 CANCEL_REASON                                      VARCHAR2(40 CHAR)
 START_TIME_LONG                           NOT NULL NUMBER(38)
 END_TIME_LONG                                      NUMBER(38)
 RERUN_HIST                                         VARCHAR2(4000 CHAR)
 PATHS_HIST                                         VARCHAR2(4000 CHAR)
 AUTO_RESUME                                        NUMBER(1)

create view owner_oox.OO_EXECUTION_SUMMARY_vw as 
select * , TO_DATE('19700101','YYYYMMDD')+( 1/ 24/ 60/ 60)*START_TIME_LONG) as start_time_long_2 from owner_oox.OO_EXECUTION_SUMMARY;

create view owner_oox.OO_EXECUTION_SUMMARY_vw as 
select  a.*, TO_DATE('19700101','YYYYMMDD')+( 1/ 24/ 60/ 60/1000)*a.START_TIME_LONG  as start_time_long_2  from owner_oox.OO_EXECUTION_SUMMARY a;

 where rownum < 2;
 
 4
 select  start_time_long_2 , start_time_long from owner_oox.OO_EXECUTION_SUMMARY_vw where rownum < 5;
 
 
 
 create view owner_oox.OO_EXECUTION_SUMMARY_vw as 
select  a.*, TO_DATE('19700101','YYYYMMDD')+( 1/ 24/ 60/ 60/1000)*a.START_TIME_LONG  as start_time_long_2  from owner_oox.OO_EXECUTION_SUMMARY a;

create view owner_oox.OO_EXECUTION_SUMMARY_vw as 
SELECT    FLOW_UUID,
  EXECUTION_ID,
            RESULT_STATUS_TYPE,
            ROI,
            START_TIME_LONG,
            to_char(to_date('1970-01-01 00','yyyy-mm-dd hh24') + (START_TIME_LONG)/1000/60/60/24 , 'YYYY-MM-DD HH24:MI:SS') as START_DATE_TIME
  FROM 	OO_EXECUTION_SUMMARY 
  
  
 
 
 