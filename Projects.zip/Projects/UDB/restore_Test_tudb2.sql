restore test TUDB201

exdb1301-adm.oracle.rabobank.nl

drop table cdm_root_1


RABO_USER @srv0tudb201 > alter session set current_schema=owner_o02; 
Session altered.

RABO_USER @srv0tudb201 > alter table cdm_root_1 rename to cdm_root_bck;
Table altered.



set database in blackout

login als oracle op de 0301




PIT-recovery:
shutdown abort
startup nomount
start script: rma / rec.....

run {
    set until time "to_date('2021-07-06_10:00:00','YYYY-MM-DD_HH24:MI:SS')" ;
    startup force mount;
    sql 'alter database flashback off';
    restore database;
    recover database;
	}


	
 sqlplus:   
alter database open resetlogs;
alter database flashback on;
shutdown immediate
srvctl start database -d TUDB2_01





oracle@exdb1301-adm:TUDB21:/home/oracle
$ sqlplus / as sysdba

SQL*Plus: Release 12.2.0.1.0 Production on Tue Jul 6 10:56:49 2021

Copyright (c) 1982, 2016, Oracle.  All rights reserved.


Connected to:
Oracle Database 12c Enterprise Edition Release 12.2.0.1.0 - 64bit Production

SYS@TUDB21 SQL> shutdown abort;
ORACLE instance shut down.
SYS@TUDB21 SQL>
SYS@TUDB21 SQL>
SYS@TUDB21 SQL> startup nomount
ORACLE instance started.

Total System Global Area 1577058304 bytes
Fixed Size                  8621136 bytes
Variable Size             922411952 bytes
Database Buffers          369098752 bytes
Redo Buffers              276926464 bytes
SYS@TUDB21 SQL> exit
Disconnected from Oracle Database 12c Enterprise Edition Release 12.2.0.1.0 - 64bit Production
oracle@exdb1301-adm:TUDB21:/home/oracle
$ rma

Recovery Manager: Release 12.2.0.1.0 - Production on Tue Jul 6 10:57:38 2021

Copyright (c) 1982, 2017, Oracle and/or its affiliates.  All rights reserved.

connected to target database: TUDB2 (not mounted)
recovery catalog database Password:
connected to recovery catalog database
recovery catalog schema version 19.10.00.00. is newer than RMAN version

run {
    set until time "to_date('2021-07-06_10:00:00','YYYY-MM-DD_HH24:MI:SS')" ;
    startup force mount;
    sql 'alter database flashback off';
    restore database;
    recover database;
7> }

executing command: SET until clause

Oracle instance started
database mounted

Total System Global Area    1577058304 bytes

Fixed Size                     8621136 bytes
Variable Size                922411952 bytes
Database Buffers             369098752 bytes
Redo Buffers                 276926464 bytes

sql statement: alter database flashback off

Starting restore at 06-07-2021:10:59:25
allocated channel: ORA_DISK_1
channel ORA_DISK_1: SID=28 device type=DISK
allocated channel: ORA_DISK_2
channel ORA_DISK_2: SID=31 device type=DISK
allocated channel: ORA_DISK_3
channel ORA_DISK_3: SID=32 device type=DISK
allocated channel: ORA_DISK_4
channel ORA_DISK_4: SID=382 device type=DISK

channel ORA_DISK_1: starting datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
channel ORA_DISK_1: restoring datafile 00013 to +DATA/TUDB2_01/DATAFILE/o02d.9736.1051006921
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/02/TUDB2/vc0336r9_1_1
channel ORA_DISK_2: starting datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
channel ORA_DISK_2: restoring datafile 00024 to +DATA/TUDB2_01/DATAFILE/ldmx.9747.1051006999
channel ORA_DISK_2: restoring datafile 00026 to +DATA/TUDB2_01/DATAFILE/o22x.9749.1051007003
channel ORA_DISK_2: restoring datafile 00027 to +DATA/TUDB2_01/DATAFILE/o04d.9750.1051007007
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/02/TUDB2/ve0336r9_1_1
channel ORA_DISK_3: starting datafile backup set restore
channel ORA_DISK_3: specifying datafile(s) to restore from backup set
channel ORA_DISK_3: restoring datafile 00007 to +DATA/TUDB2_01/DATAFILE/cmdd.9730.1051006899
channel ORA_DISK_3: restoring datafile 00028 to +DATA/TUDB2_01/DATAFILE/o04x.9751.1051007009
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/01/TUDB2/vd0336r9_1_1
channel ORA_DISK_4: starting datafile backup set restore
channel ORA_DISK_4: specifying datafile(s) to restore from backup set
channel ORA_DISK_4: restoring datafile 00011 to +DATA/TUDB2_01/DATAFILE/o01d.9734.1051006919
channel ORA_DISK_4: restoring datafile 00020 to +DATA/TUDB2_01/DATAFILE/o03x.9743.1051006987
channel ORA_DISK_4: restoring datafile 00022 to +DATA/TUDB2_01/DATAFILE/b01x.9745.1051006991
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/02/TUDB2/vg0336vv_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/02/TUDB2/vc0336r9_1_1 tag=TAG20210704T044112
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:01:09
channel ORA_DISK_1: starting datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
channel ORA_DISK_1: restoring datafile 00002 to +DATA/TUDB2_01/DATAFILE/sysaux.9725.1051006887
channel ORA_DISK_1: restoring datafile 00012 to +DATA/TUDB2_01/DATAFILE/o01x.9735.1051006919
channel ORA_DISK_1: restoring datafile 00014 to +DATA/TUDB2_01/DATAFILE/o02x.9737.1051006977
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/02/TUDB2/vi03377g_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/02/TUDB2/ve0336r9_1_1 tag=TAG20210704T044112
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:01:11
channel ORA_DISK_2: starting datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
channel ORA_DISK_2: restoring datafile 00003 to +DATA/TUDB2_01/DATAFILE/undotbs1.9726.1051006887
channel ORA_DISK_2: restoring datafile 00008 to +DATA/TUDB2_01/DATAFILE/cmdx.9731.1051006915
channel ORA_DISK_2: restoring datafile 00010 to +DATA/TUDB2_01/DATAFILE/hisx.9733.1051006917
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/02/TUDB2/vj03379h_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/02/TUDB2/vj03379h_1_1 tag=TAG20210704T044112
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:07
channel ORA_DISK_2: starting datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
channel ORA_DISK_2: restoring datafile 00001 to +DATA/TUDB2_01/DATAFILE/system.9724.1051006885
channel ORA_DISK_2: restoring datafile 00006 to +DATA/TUDB2_01/DATAFILE/users.9729.1051006897
channel ORA_DISK_2: restoring datafile 00015 to +DATA/TUDB2_01/DATAFILE/ad1d.9738.1051006977
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/02/TUDB2/vk03379l_1_1
channel ORA_DISK_3: piece handle=/backup/local/otacl304/01/TUDB2/vd0336r9_1_1 tag=TAG20210704T044112
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:01:33
channel ORA_DISK_3: starting datafile backup set restore
channel ORA_DISK_3: specifying datafile(s) to restore from backup set
channel ORA_DISK_3: restoring datafile 00019 to +DATA/TUDB2_01/DATAFILE/o03d.9742.1051006987
channel ORA_DISK_3: restoring datafile 00025 to +DATA/TUDB2_01/DATAFILE/o22d.9748.1051007001
channel ORA_DISK_3: restoring datafile 00031 to +DATA/TUDB2_01/DATAFILE/a01x.9754.1051007031
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/02/TUDB2/vl0337a4_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/02/TUDB2/vk03379l_1_1 tag=TAG20210704T044112
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:31
channel ORA_DISK_2: starting datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
channel ORA_DISK_2: restoring datafile 00005 to +DATA/TUDB2_01/DATAFILE/a01d.9728.1051006897
channel ORA_DISK_2: restoring datafile 00017 to +DATA/TUDB2_01/DATAFILE/ad2d.9740.1051006983
channel ORA_DISK_2: restoring datafile 00030 to +DATA/TUDB2_01/DATAFILE/m01x.9753.1051007029
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/02/TUDB2/vm0337bh_1_1
channel ORA_DISK_4: piece handle=/backup/local/otacl304/02/TUDB2/vg0336vv_1_1 tag=TAG20210704T044112
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:01:47
channel ORA_DISK_4: starting datafile backup set restore
channel ORA_DISK_4: specifying datafile(s) to restore from backup set
channel ORA_DISK_4: restoring datafile 00004 to +DATA/TUDB2_01/DATAFILE/tools.9727.1051006895
channel ORA_DISK_4: restoring datafile 00009 to +DATA/TUDB2_01/DATAFILE/hisd.9732.1051006915
channel ORA_DISK_4: restoring datafile 00023 to +DATA/TUDB2_01/DATAFILE/ldmd.9746.1051006993
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/02/TUDB2/vn0337ca_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/02/TUDB2/vi03377g_1_1 tag=TAG20210704T044112
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:48
channel ORA_DISK_1: starting datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
channel ORA_DISK_1: restoring datafile 00016 to +DATA/TUDB2_01/DATAFILE/ad1x.9739.1051006979
channel ORA_DISK_1: restoring datafile 00018 to +DATA/TUDB2_01/DATAFILE/ad2x.9741.1051006985
channel ORA_DISK_1: restoring datafile 00021 to +DATA/TUDB2_01/DATAFILE/b01d.9744.1051006989
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/01/TUDB2/vh03376d_1_1
channel ORA_DISK_3: piece handle=/backup/local/otacl304/02/TUDB2/vl0337a4_1_1 tag=TAG20210704T044112
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:00:24
channel ORA_DISK_3: starting datafile backup set restore
channel ORA_DISK_3: specifying datafile(s) to restore from backup set
channel ORA_DISK_3: restoring datafile 00029 to +DATA/TUDB2_01/DATAFILE/m01d.9752.1051007013
channel ORA_DISK_3: restoring section 1 of 2
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/01/TUDB2/vb0336r9_1_1
channel ORA_DISK_4: piece handle=/backup/local/otacl304/02/TUDB2/vn0337ca_1_1 tag=TAG20210704T044112
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:00:10
channel ORA_DISK_4: starting datafile backup set restore
channel ORA_DISK_4: specifying datafile(s) to restore from backup set
channel ORA_DISK_4: restoring datafile 00029 to +DATA/TUDB2_01/DATAFILE/m01d.9752.1051007013
channel ORA_DISK_4: restoring section 2 of 2
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/02/TUDB2/vb0336r9_2_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/02/TUDB2/vm0337bh_1_1 tag=TAG20210704T044112
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:29
channel ORA_DISK_1: piece handle=/backup/local/otacl304/01/TUDB2/vh03376d_1_1 tag=TAG20210704T044112
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:52
channel ORA_DISK_4: piece handle=/backup/local/otacl304/02/TUDB2/vb0336r9_2_1 tag=TAG20210704T044112
channel ORA_DISK_4: restored backup piece 2
channel ORA_DISK_4: restore complete, elapsed time: 00:01:39
channel ORA_DISK_3: piece handle=/backup/local/otacl304/01/TUDB2/vb0336r9_1_1 tag=TAG20210704T044112
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:03:03
Finished restore at 06-07-2021:11:04:46

Starting recover at 06-07-2021:11:04:46
using channel ORA_DISK_1
using channel ORA_DISK_2
using channel ORA_DISK_3
using channel ORA_DISK_4
channel ORA_DISK_1: starting incremental datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
destination for restore of datafile 00013: +DATA/TUDB2_01/DATAFILE/o02d.9736.1051006921
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/02/TUDB2/0r0353pk_1_1
channel ORA_DISK_2: starting incremental datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
destination for restore of datafile 00029: +DATA/TUDB2_01/DATAFILE/m01d.9752.1051007013
channel ORA_DISK_2: restoring section 1 of 2
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/01/TUDB2/0q0353pk_1_1
channel ORA_DISK_3: starting incremental datafile backup set restore
channel ORA_DISK_3: specifying datafile(s) to restore from backup set
destination for restore of datafile 00007: +DATA/TUDB2_01/DATAFILE/cmdd.9730.1051006899
destination for restore of datafile 00028: +DATA/TUDB2_01/DATAFILE/o04x.9751.1051007009
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/01/TUDB2/0s0353pk_1_1
channel ORA_DISK_4: starting incremental datafile backup set restore
channel ORA_DISK_4: specifying datafile(s) to restore from backup set
destination for restore of datafile 00011: +DATA/TUDB2_01/DATAFILE/o01d.9734.1051006919
destination for restore of datafile 00020: +DATA/TUDB2_01/DATAFILE/o03x.9743.1051006987
destination for restore of datafile 00022: +DATA/TUDB2_01/DATAFILE/b01x.9745.1051006991
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/02/TUDB2/0v0353pm_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/02/TUDB2/0r0353pk_1_1 tag=TAG20210704T220124
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:00
channel ORA_DISK_1: starting incremental datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
destination for restore of datafile 00029: +DATA/TUDB2_01/DATAFILE/m01d.9752.1051007013
channel ORA_DISK_1: restoring section 2 of 2
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/01/TUDB2/0q0353pk_2_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/01/TUDB2/0q0353pk_1_1 tag=TAG20210704T220124
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:00
channel ORA_DISK_2: starting incremental datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
destination for restore of datafile 00024: +DATA/TUDB2_01/DATAFILE/ldmx.9747.1051006999
destination for restore of datafile 00026: +DATA/TUDB2_01/DATAFILE/o22x.9749.1051007003
destination for restore of datafile 00027: +DATA/TUDB2_01/DATAFILE/o04d.9750.1051007007
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/02/TUDB2/0t0353pk_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/01/TUDB2/0q0353pk_2_1 tag=TAG20210704T220124
channel ORA_DISK_1: restored backup piece 2
channel ORA_DISK_1: restore complete, elapsed time: 00:00:00
channel ORA_DISK_1: starting incremental datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
destination for restore of datafile 00016: +DATA/TUDB2_01/DATAFILE/ad1x.9739.1051006979
destination for restore of datafile 00018: +DATA/TUDB2_01/DATAFILE/ad2x.9741.1051006985
destination for restore of datafile 00021: +DATA/TUDB2_01/DATAFILE/b01d.9744.1051006989
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/01/TUDB2/100353pn_1_1
channel ORA_DISK_3: piece handle=/backup/local/otacl304/01/TUDB2/0s0353pk_1_1 tag=TAG20210704T220124
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:00:00
channel ORA_DISK_3: starting incremental datafile backup set restore
channel ORA_DISK_3: specifying datafile(s) to restore from backup set
destination for restore of datafile 00001: +DATA/TUDB2_01/DATAFILE/system.9724.1051006885
destination for restore of datafile 00006: +DATA/TUDB2_01/DATAFILE/users.9729.1051006897
destination for restore of datafile 00015: +DATA/TUDB2_01/DATAFILE/ad1d.9738.1051006977
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/02/TUDB2/130353po_1_1
channel ORA_DISK_4: piece handle=/backup/local/otacl304/02/TUDB2/0v0353pm_1_1 tag=TAG20210704T220124
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:00:01
channel ORA_DISK_4: starting incremental datafile backup set restore
channel ORA_DISK_4: specifying datafile(s) to restore from backup set
destination for restore of datafile 00002: +DATA/TUDB2_01/DATAFILE/sysaux.9725.1051006887
destination for restore of datafile 00012: +DATA/TUDB2_01/DATAFILE/o01x.9735.1051006919
destination for restore of datafile 00014: +DATA/TUDB2_01/DATAFILE/o02x.9737.1051006977
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/02/TUDB2/110353pn_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/01/TUDB2/100353pn_1_1 tag=TAG20210704T220124
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:01
channel ORA_DISK_1: starting incremental datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
destination for restore of datafile 00003: +DATA/TUDB2_01/DATAFILE/undotbs1.9726.1051006887
destination for restore of datafile 00008: +DATA/TUDB2_01/DATAFILE/cmdx.9731.1051006915
destination for restore of datafile 00010: +DATA/TUDB2_01/DATAFILE/hisx.9733.1051006917
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/01/TUDB2/120353pn_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/02/TUDB2/0t0353pk_1_1 tag=TAG20210704T220124
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:01
channel ORA_DISK_2: starting incremental datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
destination for restore of datafile 00004: +DATA/TUDB2_01/DATAFILE/tools.9727.1051006895
destination for restore of datafile 00009: +DATA/TUDB2_01/DATAFILE/hisd.9732.1051006915
destination for restore of datafile 00023: +DATA/TUDB2_01/DATAFILE/ldmd.9746.1051006993
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/01/TUDB2/160353pp_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/01/TUDB2/120353pn_1_1 tag=TAG20210704T220124
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:01
channel ORA_DISK_1: starting incremental datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
destination for restore of datafile 00005: +DATA/TUDB2_01/DATAFILE/a01d.9728.1051006897
destination for restore of datafile 00017: +DATA/TUDB2_01/DATAFILE/ad2d.9740.1051006983
destination for restore of datafile 00030: +DATA/TUDB2_01/DATAFILE/m01x.9753.1051007029
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/02/TUDB2/150353pp_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/01/TUDB2/160353pp_1_1 tag=TAG20210704T220124
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:01
channel ORA_DISK_2: starting incremental datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
destination for restore of datafile 00019: +DATA/TUDB2_01/DATAFILE/o03d.9742.1051006987
destination for restore of datafile 00025: +DATA/TUDB2_01/DATAFILE/o22d.9748.1051007001
destination for restore of datafile 00031: +DATA/TUDB2_01/DATAFILE/a01x.9754.1051007031
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/01/TUDB2/140353pp_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/01/TUDB2/140353pp_1_1 tag=TAG20210704T220124
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:01
channel ORA_DISK_2: starting incremental datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
destination for restore of datafile 00013: +DATA/TUDB2_01/DATAFILE/o02d.9736.1051006921
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/02/TUDB2/2o037p0j_1_1
channel ORA_DISK_3: piece handle=/backup/local/otacl304/02/TUDB2/130353po_1_1 tag=TAG20210704T220124
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:00:03
channel ORA_DISK_3: starting incremental datafile backup set restore
channel ORA_DISK_3: specifying datafile(s) to restore from backup set
destination for restore of datafile 00007: +DATA/TUDB2_01/DATAFILE/cmdd.9730.1051006899
destination for restore of datafile 00028: +DATA/TUDB2_01/DATAFILE/o04x.9751.1051007009
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/01/TUDB2/2p037p0j_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/02/TUDB2/2o037p0j_1_1 tag=TAG20210705T221545
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:01
channel ORA_DISK_2: starting incremental datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
destination for restore of datafile 00024: +DATA/TUDB2_01/DATAFILE/ldmx.9747.1051006999
destination for restore of datafile 00026: +DATA/TUDB2_01/DATAFILE/o22x.9749.1051007003
destination for restore of datafile 00027: +DATA/TUDB2_01/DATAFILE/o04d.9750.1051007007
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/02/TUDB2/2q037p0j_1_1
channel ORA_DISK_4: piece handle=/backup/local/otacl304/02/TUDB2/110353pn_1_1 tag=TAG20210704T220124
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:00:03
channel ORA_DISK_4: starting incremental datafile backup set restore
channel ORA_DISK_4: specifying datafile(s) to restore from backup set
destination for restore of datafile 00029: +DATA/TUDB2_01/DATAFILE/m01d.9752.1051007013
channel ORA_DISK_4: restoring section 1 of 2
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/01/TUDB2/2n037p0i_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/02/TUDB2/150353pp_1_1 tag=TAG20210704T220124
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:02
channel ORA_DISK_1: starting incremental datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
destination for restore of datafile 00029: +DATA/TUDB2_01/DATAFILE/m01d.9752.1051007013
channel ORA_DISK_1: restoring section 2 of 2
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/01/TUDB2/2n037p0i_2_1
channel ORA_DISK_3: piece handle=/backup/local/otacl304/01/TUDB2/2p037p0j_1_1 tag=TAG20210705T221545
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:00:01
channel ORA_DISK_3: starting incremental datafile backup set restore
channel ORA_DISK_3: specifying datafile(s) to restore from backup set
destination for restore of datafile 00011: +DATA/TUDB2_01/DATAFILE/o01d.9734.1051006919
destination for restore of datafile 00020: +DATA/TUDB2_01/DATAFILE/o03x.9743.1051006987
destination for restore of datafile 00022: +DATA/TUDB2_01/DATAFILE/b01x.9745.1051006991
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/02/TUDB2/2s037p0l_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/01/TUDB2/2n037p0i_2_1 tag=TAG20210705T221545
channel ORA_DISK_1: restored backup piece 2
channel ORA_DISK_1: restore complete, elapsed time: 00:00:00
channel ORA_DISK_1: starting incremental datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
destination for restore of datafile 00016: +DATA/TUDB2_01/DATAFILE/ad1x.9739.1051006979
destination for restore of datafile 00018: +DATA/TUDB2_01/DATAFILE/ad2x.9741.1051006985
destination for restore of datafile 00021: +DATA/TUDB2_01/DATAFILE/b01d.9744.1051006989
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/01/TUDB2/2t037p0n_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/02/TUDB2/2q037p0j_1_1 tag=TAG20210705T221545
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:00
channel ORA_DISK_2: starting incremental datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
destination for restore of datafile 00003: +DATA/TUDB2_01/DATAFILE/undotbs1.9726.1051006887
destination for restore of datafile 00008: +DATA/TUDB2_01/DATAFILE/cmdx.9731.1051006915
destination for restore of datafile 00010: +DATA/TUDB2_01/DATAFILE/hisx.9733.1051006917
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/02/TUDB2/2v037p0o_1_1
channel ORA_DISK_4: piece handle=/backup/local/otacl304/01/TUDB2/2n037p0i_1_1 tag=TAG20210705T221545
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:00:01
channel ORA_DISK_4: starting incremental datafile backup set restore
channel ORA_DISK_4: specifying datafile(s) to restore from backup set
destination for restore of datafile 00019: +DATA/TUDB2_01/DATAFILE/o03d.9742.1051006987
destination for restore of datafile 00025: +DATA/TUDB2_01/DATAFILE/o22d.9748.1051007001
destination for restore of datafile 00031: +DATA/TUDB2_01/DATAFILE/a01x.9754.1051007031
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/01/TUDB2/31037p0p_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/01/TUDB2/2t037p0n_1_1 tag=TAG20210705T221545
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:01
channel ORA_DISK_1: starting incremental datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
destination for restore of datafile 00001: +DATA/TUDB2_01/DATAFILE/system.9724.1051006885
destination for restore of datafile 00006: +DATA/TUDB2_01/DATAFILE/users.9729.1051006897
destination for restore of datafile 00015: +DATA/TUDB2_01/DATAFILE/ad1d.9738.1051006977
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/02/TUDB2/30037p0o_1_1
channel ORA_DISK_3: piece handle=/backup/local/otacl304/02/TUDB2/2s037p0l_1_1 tag=TAG20210705T221545
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:00:01
channel ORA_DISK_3: starting incremental datafile backup set restore
channel ORA_DISK_3: specifying datafile(s) to restore from backup set
destination for restore of datafile 00002: +DATA/TUDB2_01/DATAFILE/sysaux.9725.1051006887
destination for restore of datafile 00012: +DATA/TUDB2_01/DATAFILE/o01x.9735.1051006919
destination for restore of datafile 00014: +DATA/TUDB2_01/DATAFILE/o02x.9737.1051006977
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/01/TUDB2/2u037p0n_1_1
channel ORA_DISK_4: piece handle=/backup/local/otacl304/01/TUDB2/31037p0p_1_1 tag=TAG20210705T221545
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:00:00
channel ORA_DISK_4: starting incremental datafile backup set restore
channel ORA_DISK_4: specifying datafile(s) to restore from backup set
destination for restore of datafile 00004: +DATA/TUDB2_01/DATAFILE/tools.9727.1051006895
destination for restore of datafile 00009: +DATA/TUDB2_01/DATAFILE/hisd.9732.1051006915
destination for restore of datafile 00023: +DATA/TUDB2_01/DATAFILE/ldmd.9746.1051006993
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/02/TUDB2/33037p0t_1_1
channel ORA_DISK_4: piece handle=/backup/local/otacl304/02/TUDB2/33037p0t_1_1 tag=TAG20210705T221545
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:00:01
channel ORA_DISK_4: starting incremental datafile backup set restore
channel ORA_DISK_4: specifying datafile(s) to restore from backup set
destination for restore of datafile 00005: +DATA/TUDB2_01/DATAFILE/a01d.9728.1051006897
destination for restore of datafile 00017: +DATA/TUDB2_01/DATAFILE/ad2d.9740.1051006983
destination for restore of datafile 00030: +DATA/TUDB2_01/DATAFILE/m01x.9753.1051007029
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/01/TUDB2/32037p0t_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/02/TUDB2/30037p0o_1_1 tag=TAG20210705T221545
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:04
channel ORA_DISK_2: piece handle=/backup/local/otacl304/02/TUDB2/2v037p0o_1_1 tag=TAG20210705T221545
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:05
channel ORA_DISK_3: piece handle=/backup/local/otacl304/01/TUDB2/2u037p0n_1_1 tag=TAG20210705T221545
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:00:04
channel ORA_DISK_4: piece handle=/backup/local/otacl304/01/TUDB2/32037p0t_1_1 tag=TAG20210705T221545
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:00:07

starting media recovery

archived log for thread 1 with sequence 72971 is already on disk as file +RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72971.1008.1077181737
channel ORA_DISK_1: starting archived log restore to default destination
channel ORA_DISK_1: restoring archived log
archived log thread=1 sequence=72961
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/01/TUDB2/35037p17_1_1
channel ORA_DISK_2: starting archived log restore to default destination
channel ORA_DISK_2: restoring archived log
archived log thread=1 sequence=72962
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/01/TUDB2/37037qie_1_1
channel ORA_DISK_3: starting archived log restore to default destination
channel ORA_DISK_3: restoring archived log
archived log thread=1 sequence=72963
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/01/TUDB2/39037vtp_1_1
channel ORA_DISK_4: starting archived log restore to default destination
channel ORA_DISK_4: restoring archived log
archived log thread=1 sequence=72964
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/01/TUDB2/3b0383d8_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/01/TUDB2/35037p17_1_1 tag=TAG20210705T221607
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:01
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72961.25078.1077188709 thread=1 sequence=72961
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72961.25078.1077188709 RECID=10418 STAMP=1077188709
channel ORA_DISK_1: starting archived log restore to default destination
channel ORA_DISK_1: restoring archived log
archived log thread=1 sequence=72965
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/01/TUDB2/3d0387od_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/01/TUDB2/37037qie_1_1 tag=TAG20210705T224221
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:01
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72962.23353.1077188709 thread=1 sequence=72962
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72962.23353.1077188709 RECID=10419 STAMP=1077188709
channel ORA_DISK_2: starting archived log restore to default destination
channel ORA_DISK_2: restoring archived log
archived log thread=1 sequence=72966
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/01/TUDB2/3f038dco_1_1
channel ORA_DISK_3: piece handle=/backup/local/otacl304/01/TUDB2/39037vtp_1_1 tag=TAG20210706T001345
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:00:02
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72963.4178.1077188709 thread=1 sequence=72963
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72963.4178.1077188709 RECID=10421 STAMP=1077188709
channel ORA_DISK_3: starting archived log restore to default destination
channel ORA_DISK_3: restoring archived log
archived log thread=1 sequence=72967
channel ORA_DISK_3: reading from backup piece /backup/local/otacl304/01/TUDB2/3h038gs5_1_1
channel ORA_DISK_4: piece handle=/backup/local/otacl304/01/TUDB2/3b0383d8_1_1 tag=TAG20210706T011312
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:00:08
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72964.26079.1077188709 thread=1 sequence=72964
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72964.26079.1077188709 RECID=10420 STAMP=1077188709
channel ORA_DISK_4: starting archived log restore to default destination
channel ORA_DISK_4: restoring archived log
archived log thread=1 sequence=72968
channel ORA_DISK_4: reading from backup piece /backup/local/otacl304/01/TUDB2/3j038kj9_1_1
channel ORA_DISK_1: piece handle=/backup/local/otacl304/01/TUDB2/3d0387od_1_1 tag=TAG20210706T022725
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:09
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72965.25078.1077188711 thread=1 sequence=72965
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72965.25078.1077188711 RECID=10422 STAMP=1077188710
channel ORA_DISK_1: starting archived log restore to default destination
channel ORA_DISK_1: restoring archived log
archived log thread=1 sequence=72969
channel ORA_DISK_1: reading from backup piece /backup/local/otacl304/01/TUDB2/3l038o3k_1_1
channel ORA_DISK_2: piece handle=/backup/local/otacl304/01/TUDB2/3f038dco_1_1 tag=TAG20210706T040336
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:10
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72966.23353.1077188711 thread=1 sequence=72966
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72966.23353.1077188711 RECID=10423 STAMP=1077188712
channel ORA_DISK_2: starting archived log restore to default destination
channel ORA_DISK_2: restoring archived log
archived log thread=1 sequence=72970
channel ORA_DISK_2: reading from backup piece /backup/local/otacl304/01/TUDB2/3n038rqa_1_1
channel ORA_DISK_3: piece handle=/backup/local/otacl304/01/TUDB2/3h038gs5_1_1 tag=TAG20210706T050301
channel ORA_DISK_3: restored backup piece 1
channel ORA_DISK_3: restore complete, elapsed time: 00:00:07
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72967.4178.1077188717 thread=1 sequence=72967
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72967.4178.1077188717 RECID=10424 STAMP=1077188717
channel ORA_DISK_1: piece handle=/backup/local/otacl304/01/TUDB2/3l038o3k_1_1 tag=TAG20210706T070628
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:00:05
channel ORA_DISK_2: piece handle=/backup/local/otacl304/01/TUDB2/3n038rqa_1_1 tag=TAG20210706T080946
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:00:02
channel ORA_DISK_4: piece handle=/backup/local/otacl304/01/TUDB2/3j038kj9_1_1 tag=TAG20210706T060633
channel ORA_DISK_4: restored backup piece 1
channel ORA_DISK_4: restore complete, elapsed time: 00:00:08
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72968.26079.1077188719 thread=1 sequence=72968
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72968.26079.1077188719 RECID=10425 STAMP=1077188719
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72969.25078.1077188721 thread=1 sequence=72969
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72969.25078.1077188721 RECID=10426 STAMP=1077188721
channel default: deleting archived log(s)
archived log file name=+RECO/TUDB2_01/ARCHIVELOG/2021_07_06/thread_1_seq_72970.23353.1077188725 RECID=10427 STAMP=1077188724
media recovery complete, elapsed time: 00:00:07
Finished recover at 06-07-2021:11:05:33

RMAN> exit


Recovery Manager complete.
oracle@exdb1301-adm:TUDB21:/home/oracle
$ sqlplus / as sysdba

SQL*Plus: Release 12.2.0.1.0 Production on Tue Jul 6 11:05:55 2021

Copyright (c) 1982, 2016, Oracle.  All rights reserved.


Connected to:
Oracle Database 12c Enterprise Edition Release 12.2.0.1.0 - 64bit Production

SYS@TUDB21 SQL> alter database open resetlogs;

Database altered.

SYS@TUDB21 SQL> alter database flashback on;

Database altered.

SYS@TUDB21 SQL> shutdown immediate;
Database closed.
Database dismounted.
ORACLE instance shut down.
SYS@TUDB21 SQL> exit
Disconnected from Oracle Database 12c Enterprise Edition Release 12.2.0.1.0 - 64bit Production
oracle@exdb1301-adm:TUDB21:/home/oracle
$ srvctl start database -d TUDB2_01
oracle@exdb1301-adm:TUDB21:/home/oracle


