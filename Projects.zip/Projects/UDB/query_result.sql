rabo_user@pudb2> SELECT
  2  owner,
  3  table_name,
  4  TRUNC(sum(bytes)/1024/1024) Meg,
  5  ROUND( ratio_to_report( sum(bytes) ) over () * 100) Percent
  6  FROM
  7  (SELECT segment_name table_name, owner, bytes
  8  FROM dba_segments
  9  WHERE segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')
 10  UNION ALL
 11  SELECT i.table_name, i.owner, s.bytes
 12  FROM dba_indexes i, dba_segments s
 13  WHERE s.segment_name = i.index_name
 14  AND s.owner = i.owner
 15  AND s.segment_type IN ('INDEX', 'INDEX PARTITION', 'INDEX SUBPARTITION')
 16  UNION ALL
 17  SELECT l.table_name, l.owner, s.bytes
 18  FROM dba_lobs l, dba_segments s
 19  WHERE s.segment_name = l.segment_name
 20  AND s.owner = l.owner
 21  AND s.segment_type IN ('LOBSEGMENT', 'LOB PARTITION')
 22  UNION ALL
 23  SELECT l.table_name, l.owner, s.bytes
 24  FROM dba_lobs l, dba_segments s
 25  WHERE s.segment_name = l.index_name
 26  AND s.owner = l.owner
 27  AND s.segment_type = 'LOBINDEX')
 28  WHERE owner in UPPER('OWNER_M01')
 29  GROUP BY table_name, owner
 30  HAVING SUM(bytes)/1024/1024 > 10
 31  ORDER BY SUM(bytes) desc
 32  ;


OWNER                          TABLE_NAME                                      MEG    PERCENT
------------------------------ ---------------------------------------- ---------- ----------
OWNER_M01                      DDM_DISCOVERY_TOUCH_RESULTS_QUEUE             72162         77
OWNER_M01                      CMP3$888208                                    7836          8
OWNER_M01                      URM_RESOURCES_HISTORY                          5470          6
OWNER_M01                      URM_HYBRID_DETAILS                             1163          1
OWNER_M01                      CCM_SAI_FILE                                    815          1
OWNER_M01                      DDM_GW_TASK_RESULTS                             802          1
OWNER_M01                      CONTENT_PACKS                                   753          1
OWNER_M01                      DDM_MAP_OBJECTID                                383          0
OWNER_M01                      CCM_DISCOVERY_ERRORS                            369          0
OWNER_M01                      URM_HYBRID_DETAILS_HISTORY                      344          0
OWNER_M01                      SYNC_STATE_STATUS                               308          0
OWNER_M01                      SYNC_ID_MAP_1006                                235          0
OWNER_M01                      SYNC_ID_MAP_1037                                216          0
OWNER_M01                      NORMALIZATION_OUTPUT_ATTRIBUTE                  200          0
OWNER_M01                      SYNC_ID_MAP_1024                                196          0
OWNER_M01                      URM_RESOURCES                                   163          0
OWNER_M01                      CDM_LAST_CONCRETE_454592214                     129          0
OWNER_M01                      CCM_DISCOVERY_STATS                             128          0
OWNER_M01                      CCM_DISCOVERY_DESTS_RESULTS                     109          0
OWNER_M01                      CDM_ROOT_1                                      105          0
OWNER_M01                      CDM_ROOT_LINK_1                                  82          0
OWNER_M01                      SYNC_ID_MAP_1030                                 71          0
OWNER_M01                      DDM_GW_TASKS                                     64          0
OWNER_M01                      CDM_IP_ADDRESS_1                                 62          0
OWNER_M01                      SYNC_ID_MAP_1031                                 60          0
OWNER_M01                      CCM_SAI_RULE                                     56          0
OWNER_M01                      NORMALIZATION_INPUT_ATTRIBUTE                    55          0
OWNER_M01                      HDM_210910IP_ADDRESS_1                           48          0
OWNER_M01                      HDM_211010IP_ADDRESS_1                           46          0
OWNER_M01                      HDM_210710IP_ADDRESS_1                           45          0
OWNER_M01                      HDM_210810IP_ADDRESS_1                           45          0
OWNER_M01                      CDM_BUSINESS_APPLICATION_1                       41          0
OWNER_M01                      HDM_210910BUSINES_1930557736                     41          0
OWNER_M01                      HDM_210810BUSINES_146651607                      41          0
OWNER_M01                      HIST_MODEL_REVISION_MAPPING                      38          0
OWNER_M01                      HDM_210710BUSINES_2071106346                     37          0
OWNER_M01                      NORMALIZATION_RULE                               35          0
OWNER_M01                      CDM_LIST_ATTR_PRIMITIVE_1                        35          0
OWNER_M01                      HDM_211010BUSINES_384523026                      34          0
OWNER_M01                      HDM_210910NT_1                                   34          0
OWNER_M01                      HDM_ROOT_1                                       31          0
OWNER_M01                      HDM_210910UNIX_1                                 30          0
OWNER_M01                      HDM_210710USAGE_1                                30          0
OWNER_M01                      HDM_210910COMPOSITION_1                          29          0
OWNER_M01                      CDM_COMPOSITION_1                                29          0
OWNER_M01                      HDM_210710UNIX_1                                 28          0
OWNER_M01                      CDM_CONTAINMENT_1                                27          0
OWNER_M01                      HDM_210810USAGE_1                                27          0
OWNER_M01                      HDM_210910RUNNING_SOFTWARE_1                     26          0
OWNER_M01                      HDM_210810RUNNING_SOFTWARE_1                     26          0
OWNER_M01                      CDM_RUNNING_SOFTWARE_1                           26          0
OWNER_M01                      CDM_USAGE_1                                      26          0
OWNER_M01                      HDM_210710COMPOSITION_1                          24          0
OWNER_M01                      HDM_211010COMPOSITION_1                          24          0
OWNER_M01                      HDM_210910CONTAINMENT_1                          23          0
OWNER_M01                      HDM_210810COMPOSITION_1                          23          0
OWNER_M01                      CDM_NT_1                                         23          0
OWNER_M01                      HDM_ROOT_LINK_1                                  22          0
OWNER_M01                      HDM_210710CONTAINMENT_1                          21          0
OWNER_M01                      HDM_210810UNIX_1                                 21          0
OWNER_M01                      HDM_210810CONTAINMENT_1                          20          0
OWNER_M01                      HDM_211010CONTAINMENT_1                          20          0
OWNER_M01                      CCM_DISCOVERY_CI_ERRORS                          19          0
OWNER_M01                      LOA                                              19          0
OWNER_M01                      CDM_UNIX_1                                       17          0
OWNER_M01                      HDM_210910STORAGEARRAY_1                         17          0
OWNER_M01                      HDM_210910USAGE_1                                17          0
OWNER_M01                      CDM_IP_SERVICE_ENDPOINT_1                        16          0
OWNER_M01                      HDM_210710RUNNING_SOFTWARE_1                     15          0
OWNER_M01                      VIEW_ARCHIVE                                     15          0
OWNER_M01                      HDM_210810NT_1                                   15          0
OWNER_M01                      CDM_NODE_1                                       15          0
OWNER_M01                      HDM_210710NT_1                                   15          0
OWNER_M01                      HDM_211010USAGE_1                                15          0
OWNER_M01                      HDM_211010RUNNING_SOFTWARE_1                     14          0
OWNER_M01                      CDM_STORAGEARRAY_1                               13          0
OWNER_M01                      HDM_211010NT_1                                   12          0
OWNER_M01                      CDM_INTERFACE_1                                  12          0
OWNER_M01                      DDM_JOBS_EXECUTION                               12          0
OWNER_M01                      HDM_210810WEBSPHEREAS_1                          12          0
OWNER_M01                      DDM_JOBS_EXECUTION_HISTORY                       12          0
OWNER_M01                      CCM_SAI_VERSION                                  12          0
OWNER_M01                      HDM_211010UNIX_1                                 11          0

83 rows selected.

rabo_user@pudb2>

