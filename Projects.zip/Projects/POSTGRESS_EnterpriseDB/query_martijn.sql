De tabel namen e.d. zullen mogelijk anders zijn dit is van de vorige marketplace omgeving nog even wat queries waarbij je kan zien hoe je ze moet opbouwen, voor al dat JDOC kan lastig zijn.
En zo kan ik er nog wel een paar opzoeken als je het leuk vindt.

select guid , jdoc from catalog.category where jdoc->'summary'->'name'->>'en' = 'SERVICE MANAGEMENT';

select jdoc->'items'->'requestHumanReadableId' , jdoc->'items'->'summary'->'humanReadableId' , jdoc->'items'->'summary'->'state' , jdoc->'items'->'summary'->'sxRemoteRequestId' , jdoc->'items'->'summary'->'createdBy' from shopping.propel_order

SELECT * FROM policy.user_approval WHERE created <= cast(extract(epoch from timestamp '2019-08-07') as bigint)*1000 AND created >= cast(extract(epoch from timestamp '2019-08-05') as bigint)*1000 AND username = 'Harjan.J.Kuiper01@rabobank.com';

SELECT * FROM policy.request_approval WHERE jdoc->'requestApprovalProcess'->'steps' @> ANY (ARRAY ['[{"stepName":"181053_1"}]']::jsonb[])

SELECT jdoc , jdoc#>>'{summary,created}' , to_timestamp(NULLIF(left(jdoc#>>'{summary,created}',-3),'')::int) AT TIME ZONE 'UTC'
FROM shopping.propel_order
WHERE
TO_NUMBER(jdoc#>>'{summary,created}','9999999999999') > 1551657600000
AND
jdoc->>'summary' not like '%sxRemoteRequestId%';


Kind Regards, 

Martijn Steenhorst 
