select username from dba_users where account_status = 'LOCKED'
and username not in (select distinct(owner) from dba_objects );
order(username)


 select owner, object_type , count(object_name) from dba_objects  
 where object_Type = 'SYNONYM'
 group by owner, object_type
 order by owner, object_type
 
 
 
 
select 'drop user ' ||  username || ';' from dba_users where account_status = 'LOCKED'
and (username not in (select distinct(owner) from dba_objects ) 
or username in (
 select distinct owner from dba_objects where object_type = 'SYNONYM' 
minus 
  select distinct owner from dba_objects where object_type <> 'SYNONYM'
))



 select distinct object_type  from dba_objects 
 SYNONYM
 
 
-- de users die alleen synoniemen hebben: 
 select distinct owner from dba_objects where object_type = 'SYNONYM' 
minus 
  select distinct owner from dba_objects where object_type <> 'SYNONYM'

-- users die gelocked zijn en geen objecten hebben: 
select username from dba_users where account_status = 'LOCKED'
and username not in (select distinct(owner) from dba_objects );

-- users die gelocked zijn en alleen syn hebben of geen objecten hebben. 
 
select username from dba_users where account_status = 'LOCKED'
and (username not in (select distinct(owner) from dba_objects ) 
or username in (
 select distinct owner from dba_objects where object_type = 'SYNONYM' 
minus 
  select distinct owner from dba_objects where object_type <> 'SYNONYM'
))
and username not in 'ANONYMOUS';


select username from dba_users where 
 (username not in (select distinct(owner) from dba_objects ) 
or username in (
 select distinct owner from dba_objects where object_type = 'SYNONYM' 
minus 
  select distinct owner from dba_objects where object_type <> 'SYNONYM'
))
and username not in 'ANONYMOUS';
