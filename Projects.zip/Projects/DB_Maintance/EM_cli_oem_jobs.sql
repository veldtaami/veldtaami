   [Paths]
      SIBDIR = /appl/sib/prod
      SIBBIN = /appl/sib/prod/bin
      SIBLOG = /appl/sib/prod/logs
      SIBRUN = /appl/sib/prod/server/RUN



USER=$1                                 # De user die na de switch de controle uit gaat voeren
DATABASE=$2                             # De database welke geswitched moet worden
SWITCHTO=$3                             # Waar moet de database naar toe geswitched worden SNAPSHOT/PHYSICAL
EXTRA_SCRIPTS=$4                        # Moeten er na het switchen nog extra scripts gedraaid worden JA/NEE
LOGDIR=${SIBLOG}                        # Directory waar alle logging in moet komen
SCRIPTDIR=${SIBBIN}                     # Directory waar het emcli
EMCLIDIR=${SIBDIR}/emcli13              # De directory waar het emcli script staat
EXTRA_SCRIPTDIR=${SIBBIN}/snapshot      # De directory waar de ini-file en de scripts staan die na de switch uitgevoerd moeten worden
SLEEPTIME=600                           # Hoe lang moet er na het uitvoeren van het switch commando gewacht worden`
#SLEEPTIME=1                            # Hoe lang moet er na het uitvoeren van het switch commando gewacht worden
HOE_GESTART=$(ps -o comm= $PPID)        # Deze variabele wordt gebruikt om te kijken of het script vanuit TWS gestart is of handmatig vanaf commandline



### maintain sequence for EMjob

/appl/sib/prod/emcli13/emcli setup -url="https://poem13.oracle.rabobank.nl/em" -username=TEAM_CSS_ISA_DFA -password='@Team_ITSM_2019' -nocertvalidate -autologin -dir="/home/sibp" -localdirans="yes" -trustall
/appl/sib/prod/emcli13/emcli login -username="TEAM_CSS_ISA_DFA" -password='@Team_ITSM_2019'

SEQ1_SIB_SNAP=`cat ${EMCLIDIR}/SEQ1_SIB_SNAP.lis`
let SEQ1_SIB_SNAP=${SEQ1_SIB_SNAP}+1
echo ${SEQ1_SIB_SNAP} > ${EMCLIDIR}/SEQ1_SIB_SNAP.lis
SNJOBNAME="APP_PSIB_SWITCH_DB_ROLE_${SWITCHTO}.${SEQ1_SIB_SNAP}"

echo "name=${SNJOBNAME}" >${SIBBIN}/switchdatdabase.txt
echo "type=OSCommand" >>${SIBBIN}/switchdatdabase.txt
echo "description=Switching standby role of PSIB database to ${SWITCHTO} standby" >>${SIBBIN}/switchdatdabase.txt
echo "target_list=PSIB1_03:rac_database" >>${SIBBIN}/switchdatdabase.txt
echo "variable.default_shell_command=/orabackup1/PSIB1/scripts/Switch_Standby_Role/SwitchStandbyDbRole12C.sh -d PSIB1_03 -a ${SWITCHTO}" >>${SIBBIN}/switchdatdabase.txt
echo "schedule.frequency=IMMEDIATE" >>${SIBBIN}/switchdatdabase.txt
echo "cred.defaultHostCred.PSIB1_03:rac_database=NAMED:EMADMIN:NC_HOST_ORACLE" >>${SIBBIN}/switchdatdabase.txt

. ${EMCLIDIR}/setenv_emcli.sh
echo "We gaan nu switchen naar ${SWITCHTO}"
${EMCLIDIR}/emcli create_job -input_file=property_file:${SIBBIN}/switchdatdabase.txt


/appl/sib/prod/emcli13/emcli create_job -input_file=property_file:"/appl/sib/prod/bin/switchdatdabase.txt"

/appl/sib/prod/emcli13/emcli setup -url="https://poem13.oracle.rabobank.nl/em" -username=TEAM_CSS_ISA_DFA -password='@Team_ITSM_2019' -dir="/home/sibp/" -localdirans="yes" -trustall -nocertvalidate -autologin  -licans="no" -certans="no" -novalidate



./emcli setup -url="https://poem13.oracle.rabobank.nl/em" -username=TEAM_CSS_ISA_DFA -password='@Team_ITSM_2019' -nocertvalidate -autologin -dir="/home/sibp" -localdirans="yes" -trustall
./emcli login -username="TEAM_CSS_ISA_DFA" -password='@Team_ITSM_2019'
./emcli create_job -input_file=property_file:"/appl/sib/prod/bin/switchdatdabase.txt"



./emcli login -username="TEAM_CSS_ISA_DFA" -password='@Team_ITSM_2019'
./emcli create_job -input_file=property_file:"/home/VeldtAAMI/emcli/propertytest.txt"

name=AVE_TEST
type=OSCommand
description=Switching standby role of PSIB database to standby
target_list=PSIB1_03:rac_database
#variable.default_shell_command=/orabackup1/PSIB1/scripts/Switch_Standby_Role/SwitchStandbyDbRole12C.sh -d PSIB1_03 -a (SNAP of PHY) 
schedule.frequency=IMMEDIATE
cred.defaultHostCred.PSIB1_03:rac_database=NAMED:EMADMIN:NC_HOST_ORACLE




### maintain sequence for EMjob

${EMCLIDIR}/emcli setup -url="https://poem13.oracle.rabobank.nl/em" -username=TEAM_CSS_ISA_DFA -password='@Team_ITSM_2019' -nocertvalidate -autologin -dir="/home/sibp" -localdirans="yes" -trustall -novalidate
${EMCLIDIR}/emcli login -username="TEAM_CSS_ISA_DFA" -password='@Team_ITSM_2019'

SEQ1_SIB_SNAP=`cat ${EMCLIDIR}/SEQ1_SIB_SNAP.lis`
let SEQ1_SIB_SNAP=${SEQ1_SIB_SNAP}+1
echo ${SEQ1_SIB_SNAP} > ${EMCLIDIR}/SEQ1_SIB_SNAP.lis
SNJOBNAME="APP_PSIB_SWITCH_DB_ROLE_${SWITCHTO}.${SEQ1_SIB_SNAP}"

echo "name=${SNJOBNAME}" >${SIBBIN}/switchdatdabase.txt
echo "type=OSCommand" >>${SIBBIN}/switchdatdabase.txt
echo "description=Switching standby role of PSIB database to ${SWITCHTO} standby" >>${SIBBIN}/switchdatdabase.txt
echo "target_list=PSIB1_03:rac_database" >>${SIBBIN}/switchdatdabase.txt
echo "variable.default_shell_command=/orabackup1/PSIB1/scripts/Switch_Standby_Role/SwitchStandbyDbRole12C.sh -d PSIB1_03 -a ${SWITCHTO}" >>${SIBBIN}/switchdatdabase.txt
echo "schedule.frequency=IMMEDIATE" >>${SIBBIN}/switchdatdabase.txt
echo "cred.defaultHostCred.PSIB1_03:rac_database=NAMED:EMADMIN:NC_HOST_ORACLE" >>${SIBBIN}/switchdatdabase.txt

. ${EMCLIDIR}/setenv_emcli.sh
echo "We gaan nu switchen naar ${SWITCHTO}"
echo "de emclidir is:   ${EMCLIDIR}"
${EMCLIDIR}/emcli create_job -input_file=property_file:${SIBBIN}/switchdatdabase.txt

}

