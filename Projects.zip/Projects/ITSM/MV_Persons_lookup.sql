Users where to create: 
PROD :  owner_sm1
build:  owner_sm1
ACC  :  owner_s12


--- create the MV logs
CREATE MATERIALIZED VIEW LOG ON owner_sm1.OPERATORM1 WITH ROWID;
CREATE MATERIALIZED VIEW LOG ON owner_sm1.CONTCTSM1 WITH ROWID;

--- create the MV: 
CREATE MATERIALIZED VIEW "OWNER_SM1"."SMDM_PERSON_LOOKUP" ("LOOKUPVALUE", "PERSONID")
  TABLESPACE "SM1D" 
  BUILD IMMEDIATE
  REFRESH FORCE ON DEMAND
  ENABLE QUERY REWRITE
  AS SELECT 
LOOKUPVALUE,
PERSONID FROM (
SELECT 
T1.LOOKUPVALUE,
T1.PERSONID,
T1.SYSMODTIME,
row_number() OVER (PARTITION BY T1.LOOKUPVALUE ORDER BY T1."SYSMODTIME" DESC) AS "ROWNUM"
FROM (
   SELECT
RN_OPERATORQUERY AS LOOKUPVALUE,
CASE WHEN (lower(o1."NAME")= 'agent' OR lower(o1."NAME")= 'alert' OR lower(o1."NAME")= 'archiving' OR lower(o1."NAME")= 'assrename' OR lower(o1."NAME")= 'automationtaskupdate' OR lower(o1."NAME")= 'availability' OR lower(o1."NAME") LIKE 'bg_load%' OR lower(o1."NAME")= 'change' OR lower(o1."NAME")= 'contract' OR lower(o1."NAME")= 'event' OR lower(o1."NAME")= 'gie' OR lower(o1."NAME")= 'kafka' OR lower(o1."NAME")= 'kmattachment' OR lower(o1."NAME")= 'kmcheck' OR lower(o1."NAME")= 'kmreindex' OR lower(o1."NAME")= 'kmupdate' OR lower(o1."NAME")= 'lister' OR lower(o1."NAME")= 'marquee' OR lower(o1."NAME") LIKE 'massup%' OR lower(o1."NAME") LIKE 'message%' OR lower(o1."NAME")= 'ocm' OR lower(o1."NAME")= 'ppmfailover' OR lower(o1."NAME")= 'problem' OR lower(o1."NAME")= 'propel' OR lower(o1."NAME")= 'refcheck' OR lower(o1."NAME")= 'report'OR lower(o1."NAME")= 'rnemailso' OR lower(o1."NAME")= 'scheduledaction' OR lower(o1."NAME")= 'sla' OR lower(o1."NAME") LIKE 'smartemail%' OR lower(o1."NAME") LIKE 'smidol%' OR lower(o1."NAME")= 'smsurvey28' OR lower(o1."NAME")= 'survey_service_agent' OR lower(o1."NAME")= 'spool' OR lower(o1."NAME")= 'timedurationdata' OR lower(o1."NAME")= 'update_cms' OR lower(o1."NAME") LIKE 'linker%' OR lower(o1."NAME")= 'ocm') THEN 'System Account' 
WHEN (lower(o1."NAME") LIKE 'sys%') THEN 'Admin Account' 
WHEN (lower(o1."NAME") LIKE 'gam-%') THEN 'Global Admin Account' 
WHEN (lower(o1."NAME") LIKE 'fu_%') THEN 'Functional User Account'
WHEN (lower(o1."NAME") LIKE 'kpl-%' OR lower(o1."NAME") LIKE 'smomi%' OR lower(o1."NAME")= 'smoo14' OR lower(o1."NAME") LIKE '%csir_eu%') THEN 'Integration Account'
WHEN (lower(o1."NAME") LIKE '%@%') THEN o1."NAME" END AS PERSONID,
o1.SYSMODTIME
FROM OPERATORM1 o1
UNION
SELECT 
NAME AS LOOKUPVALUE,
o2."NAME" AS PERSONID,
o2.SYSMODTIME
FROM OPERATORM1 o2
WHERE (lower(o2."NAME") LIKE '%@%') 
UNION
SELECT 
CONTACT_NAME AS LOOKUPVALUE,
c1."OPERATOR_ID" AS PERSONID,
c1.SYSMODTIME
FROM CONTCTSM1 c1
WHERE (lower(c1."OPERATOR_ID") LIKE '%@%')
ORDER BY "PERSONID") T1
)
WHERE "ROWNUM" = 1;

COMMENT ON MATERIALIZED VIEW "OWNER_SM1"."SMDM_PERSON_LOOKUP"  IS 'snapshot table for snapshot OWNER_SM1.SMDM_PERSON_LOOKUP';


-- create the procedure to REFRESH
CREATE OR REPLACE PROCEDURE owner_sm1.refresh_mv_smdm_pers
 AS
 BEGIN
     DBMS_MVIEW.REFRESH('SMDM_PERSON_LOOKUP');
 END;
 /
 
 
-- create a job to refresh every hour. 
BEGIN
     DBMS_SCHEDULER.CREATE_JOB
     (
     job_name            => 'MY_MVIEW_REFRESH',
     job_type            => 'STORED_PROCEDURE',
     job_action          => 'owner_sm1.refresh_mv_smdm_pers',
     number_of_arguments => 0,
     start_date          => SYSTIMESTAMP,
     repeat_interval     => 'FREQ=HOURLY;BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN',
   end_date            => NULL,
   enabled             => TRUE,
   auto_drop           => FALSE,
   comments            => 'This job refresh MV_EMP every hour'
   );
END;
/
