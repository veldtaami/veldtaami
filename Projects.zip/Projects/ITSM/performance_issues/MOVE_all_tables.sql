RequestM1:  
REQUESTTASKM1

create tablespace SM1D_01 datafile '+DATA' size 1G autoextend on maxsize 100G;
alter user owner_S12 quota unlimited on SM1D_01;


-- Beide tabellen verplaatst naar nieuwe tablespace  (Prod + ACC, onder  )



move online: 

select  s.SEGMENT_NAME lobs_name,  sum(bytes)/1024/1024 MB  , s.TABLESPACE_NAME , d.table_name from dba_segments  s, dba_lobs d
 where s.segment_name = d.segment_name and
 s.segment_name in
 (select segment_name from dba_lobs where owner = upper('OWNER_SM1') and table_name = 'REQUESTTASKM1' )
 group by s.segment_name,  s.TABLESPACE_NAME,  d.table_name
 order by 2,1

ALTER SESSION ENABLE PARALLEL DML;
ALTER SESSION ENABLE PARALLEL DDL;
ALTER SESSION ENABLE PARALLEL query;
alter session force parallel dml parallel 8;
alter session force parallel ddl parallel 8;
alter session force parallel query parallel 8;

-- MOVE Tables  (groter dan 1G)
select 'alter table OWNER_SM1.' || table_name || ' move online tablespace SM1D_01 ;'  from dba_tables 
where TABLESPACE_NAME = 'SM1D'  and owner = 'OWNER_SM1' and (blocks*8192/1024/1024/1024) < 0.2 ;



 select table_name, owner, last_analyzed, NUM_ROWS ,blocks,  blocks*8192/1024/1024/1024 Gb,
  2* degree, chain_cnt, tablespace_name as chained_blocks
  
  
  
-- MOVE LOBS
select 'alter table  '||owner||'.'||table_name||' move lob ("'||column_name ||'") store as (tablespace SM1D_01) ONLINE;' 
from dba_lobs where table_name ='REQUESTTASKM1' and owner = 'OWNER_SM1' and tablespace_name = 'S12D'; 

-- MOVE INDEXES
select 'ALTER INDEX '||owner||'.'||index_name||' REBUILD TABLESPACE '||'SM1D_01 online parallel 8;' 
from dba_indexes where table_name ='REQUESTTASKM1' and owner = 'OWNER_SM1' and index_name not like 'SYS%';











--- ANALYSE

de query:
set autotrace on explain
...
set autotrace off


--- analyse:

begin
dbms_stats.gather_table_stats
(ownname => 'OWNER_SM1', 
tabname => 'REQUESTTASKM1' , 
estimate_percent => dbms_stats.auto_sample_size, 
method_opt => 'for all indexed columns size auto',
degree => 4 ,
cascade => TRUE);
end;
/

of


 EXEC DBMS_STATS.gather_table_stats('owner_sm1', 'REQUESTM1');



alter table OWNER_SM1.TIMEDURATION4INCIDENTSM1 move online tablespace SM1D_01 ;
alter table OWNER_SM1.TIMEDURATION4PROBSUMMARYM1 move online tablespace SM1D_01 ;
alter table OWNER_SM1.SMISTASKLOGM1 move online tablespace SM1D_01 ; 
alter table OWNER_SM1.CM3RM1 move online tablespace SM1D_01 ;                
alter table OWNER_SM1.ALERTM1 move online tablespace SM1D_01 ;               
alter table OWNER_SM1.ACTIVITYDEVICEM1 move online tablespace SM1D_01 ;      
alter table OWNER_SM1.REQUESTTASKM1 move online tablespace SM1D_01 ;         
alter table OWNER_SM1.ACTIVITYREQUESTTASKM1 move online tablespace SM1D_01 ; 
alter table OWNER_SM1.ACTIVITYCM3M1 move online tablespace SM1D_01 ;         
alter table OWNER_SM1.AUDITM1 move online tablespace SM1D_01 ;               
alter table OWNER_SM1.ACTIVITYREQUESTM1 move online tablespace SM1D_01 ;     
alter table OWNER_SM1.ACTSVCMGTM1 move online tablespace SM1D_01 ;           
alter table OWNER_SM1.ACTIVITYM1 move online tablespace SM1D_01 ;            
alter table OWNER_SM1.CIRELATIONBSGM1 move online tablespace SM1D_01 ;       
