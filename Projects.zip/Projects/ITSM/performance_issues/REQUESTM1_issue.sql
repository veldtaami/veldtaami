RequestM1:  
REQUESTTASKM1

create tablespace S12D_01 datafile '+DATA' size 1G autoextend on maxsize 32G;
alter user owner_S12 quota unlimited on S12D_01;


-- Beide tabellen verplaatst naar nieuwe tablespace  (Prod + ACC, onder S12 )



move online: 

select  s.SEGMENT_NAME lobs_name,  sum(bytes)/1024/1024 MB  , s.TABLESPACE_NAME , d.table_name from dba_segments  s, dba_lobs d
 where s.segment_name = d.segment_name and
 s.segment_name in
 (select segment_name from dba_lobs where owner = upper('OWNER_S12') and table_name = 'REQUESTTASKM1' )
 group by s.segment_name,  s.TABLESPACE_NAME,  d.table_name
 order by 2,1


ALTER SESSION ENABLE PARALLEL DML;
ALTER SESSION ENABLE PARALLEL DDL;
ALTER SESSION ENABLE PARALLEL query;
alter session force parallel dml parallel 8;
alter session force parallel ddl parallel 8;
alter session force parallel query parallel 8;


select 'alter table owner_S12.' || table_name || ' move online tablespace S12D_01 ;' from dba_tables 
where table_name = 'REQUESTTASKM1'  and owner = 'OWNER_S12';


@unusable

select 'alter table  '||owner||'.'||table_name||' move lob ("'||column_name ||'") store as (tablespace S12D_01) ONLINE;' 
from dba_lobs where table_name ='REQUESTTASKM1' and owner = 'OWNER_S12' and tablespace_name = 'S12D'; 

select 'ALTER INDEX '||owner||'.'||index_name||' REBUILD TABLESPACE '||'S12D_01 online parallel 8;' 
from dba_indexes where table_name ='REQUESTTASKM1' and owner = 'OWNER_S12' and index_name not like 'SYS%';











--- ANALYSE

de query:
set autotrace on explain
...
set autotrace off


--- analyse:

begin
dbms_stats.gather_table_stats
(ownname => 'OWNER_S12', 
tabname => 'REQUESTTASKM1' , 
estimate_percent => dbms_stats.auto_sample_size, 
method_opt => 'for all indexed columns size auto',
degree => 4 ,
cascade => TRUE);
end;
/

of


 EXEC DBMS_STATS.gather_table_stats('owner_sm1', 'REQUESTM1');



--- de Query: 
alter session set nls_sort=binary_ci;
alter session set nls_comp=linguistic;


SELECT "NUMBER" FROM 
(SELECT A.*, ROWNUM RN FROM 
(SELECT m1."NUMBER" FROM owner_sm1.REQUESTM1 m1 
WHERE (m1."SUBMIT_DATE"> to_date('2021/01/01 12:37:30','YYYY/MM/DD HH24:mi:ss') 
    and m1."SUBMIT_DATE"< to_date('2021/06/30 13:37:30','YYYY/MM/DD HH24:mi:ss')) ORDER BY m1."NUMBER" ASC) A WHERE ROWNUM<3) WHERE RN>=1
	
SELECT "NUMBER" FROM 
(SELECT A.*, ROWNUM RN FROM 
(SELECT m1."NUMBER" FROM owner_s12.REQUESTTASKM1 m1 
WHERE (m1."SUBMIT_DATE"> to_date('2021/01/01 12:37:30','YYYY/MM/DD HH24:mi:ss') 
    and m1."SUBMIT_DATE"< to_date('2021/06/30 13:37:30','YYYY/MM/DD HH24:mi:ss')) ORDER BY m1."NUMBER" ASC) A WHERE ROWNUM<3) WHERE RN>=1
	




Performance Analyser: 

SET linesize 200
SET LONG 999999999
SET pages 1000
SET longchunksize 20000

--- create task
DECLARE
 stmt_task VARCHAR2(64);
BEGIN
 stmt_task:=dbms_sqltune.create_tuning_task(sql_id => '37awfdksun2qx',  time_limit => 3600, task_name => 'Task1', description => 'task1');
END;
/

-- uitvoeren van de task:
EXECUTE dbms_sqltune.execute_tuning_task('Task1');

--- report result
SELECT dbms_sqltune.report_tuning_task('Task1', 'TEXT', 'ALL') FROM dual;
 
--- drop task
execute dbms_sqltune.drop_tuning_task('Task1');




de EXTRA Indexen: 


-- Op PROD

CREATE INDEX "OWNER_SM1"."REQUESTTSKM1_AVE_NR_SUBD_FBI" ON "OWNER_SM1"."REQUESTTASKM1" (NLSSORT("NUMBER",'nls_sort=''BINARY_CI'''),"SUBMIT_DATE")
ONLINE   TABLESPACE "SM1D_01"  PARALLEL 8;
 
CREATE INDEX "OWNER_SM1"."REQUESTM1_AVE_NR_UPDD_FBI" ON "OWNER_SM1"."REQUESTM1" (NLSSORT("NUMBER",'nls_sort=''BINARY_CI'''),"UPDATE_DATE")
ONLINE   TABLESPACE "SM1D_01"  PARALLEL 8;

CREATE INDEX "OWNER_SM1"."REQUESTM1_AVE_NR_SUBD_FBI" ON "OWNER_SM1"."REQUESTM1" (NLSSORT("NUMBER",'nls_sort=''BINARY_CI'''),"SUBMIT_DATE")
ONLINE   TABLESPACE "SM1D_01"  PARALLEL 8;


-- Op ACCeptatie

CREATE INDEX "OWNER_S12"."REQUESTTSKM1_AVE_NR_SUBD_FBI" ON "OWNER_S12"."REQUESTTASKM1" (NLSSORT("NUMBER",'nls_sort=''BINARY_CI'''),"SUBMIT_DATE")
ONLINE   TABLESPACE "S12D_01"  PARALLEL 8; 

CREATE INDEX "OWNER_S12"."REQUESTM1_AVE_NR_SUBD_FBI" ON "OWNER_S12"."REQUESTM1" (NLSSORT("NUMBER",'nls_sort=''BINARY_CI'''),"SUBMIT_DATE")
ONLINE   TABLESPACE "S12D_01"  PARALLEL 8;

CREATE INDEX "OWNER_S12"."REQUESTM1_AVE_NR_UPDD_FBI" ON "OWNER_S12"."REQUESTM1" (NLSSORT("NUMBER",'nls_sort=''BINARY_CI'''),"UPDATE_DATE")
ONLINE   TABLESPACE "S12D_01"  PARALLEL 8;

