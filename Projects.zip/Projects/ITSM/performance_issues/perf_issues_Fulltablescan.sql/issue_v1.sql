-- creeer de task
atvmrpzua7ysj



DECLARE
 stmt_task VARCHAR2(64);
BEGIN
 stmt_task:=dbms_sqltune.create_tuning_task(sql_id => 'atvmrpzua7ysj', time_limit => 3600, task_name => 'prob_sum2', description => 'select');
END;
/


-- uitvoeren van de task:
EXECUTE dbms_sqltune.execute_tuning_task('prob_sum2');


--voortgang bekijken

ALTER SESSION SET nls_date_format='dd-mon-yyyy hh24:mi:ss';

col description FOR a40
SELECT task_name, description, advisor_name, execution_start, execution_end, status
 FROM dba_advisor_tasks
 WHERE owner='YJAQUIER'
 ORDER BY task_id DESC;
 
-- resultaat bekijken 
SET linesize 200
SET LONG 999999999
SET pages 1000
SET longchunksize 20000
SELECT dbms_sqltune.report_tuning_task('prob_sum2', 'TEXT', 'ALL') FROM dual;
 
 
 EXECUTE dbms_sqltune.drop_tuning_task('prob_sum');
 
 
 
 
execute dbms_stats.gather_table_stats(ownname => 'OWNER_OOX', tabname =>'RM_EXEC_SUM_ID_SLS_TMP', estimate_percent =>  DBMS_STATS.AUTO_SAMPLE_SIZE, method_opt => 'FOR ALL COLUMNS SIZE AUTO');



 for this statement.
 execute dbms_sqltune.accept_sql_profile(task_name => 'prob_sum', task_owner => 'RABO_USER', replace => TRUE, profile_type => DBMS_SQLTUNE.PX_PROFILE);


