var old_ci_name = 'XSRV2371';
var im_m_query = 'logical.name="' + old_ci_name + '" or rn.caused.by="' + old_ci_name + '"'; //Incident
var m_record = new SCFile('probsummary')
var total = m_record.doCount(im_m_query);
print("Total count Incident module: " + total);




spool bindsql_probsummary_output.txt

 

set autotrace on explain

set timing on
var X varchar2(140)
var Y varchar2(140)
 

exec :X := 'xsrv2447';
exec :Y := 'xsrv2447';

SELECT m1."NUMBER" FROM owner_sm1.PROBSUMMARYM1 m1 WHERE ((m1."LOGICAL_NAME"=:Y or m1."RN_CAUSED_BY"=:Y)) ORDER BY m1."NUMBER" ASC;

set timing off



select SQL_ID, SQL_TEXT from v$sql  where  upper(sql_text) like '%PROBSUMMARYM1%LOGICAL_NAME%RN_CAUSED_BY%';

dt3z9y9xcgpa7
SELECT m1."NUMBER" FROM owner_sm1.PROBSUMMARYM1 m1 WHERE ((m1."LOGICAL_NAME"=:X or m1."RN_CAUSED_BY"=:Y)) ORDER BY m1."NUMBER" ASC

sql_id: dt3z9y9xcgpa7
plan hash value: 3699459919
-- creeer de task

DECLARE
 stmt_task VARCHAR2(64);
BEGIN
 stmt_task:=dbms_sqltune.create_tuning_task(sql_id => 'dt3z9y9xcgpa7', time_limit => 3600, task_name => 'prob_sum', description => 'task to delete');
END;
/


-- uitvoeren van de task:
EXECUTE dbms_sqltune.execute_tuning_task('prob_sum');


-- resultaat bekijken 
SET linesize 200
SET LONG 999999999
SET pages 1000
SET longchunksize 20000
SELECT dbms_sqltune.report_tuning_task('prob_sum', 'TEXT', 'ALL') FROM dual;
 
 
EXECUTE dbms_sqltune.drop_tuning_task('prob_sum');

 
 
 
 
 
 
execute dbms_stats.gather_table_stats(ownname => 'OWNER_OOX', tabname =>'RM_EXEC_SUM_ID_SLS_TMP', estimate_percent =>  DBMS_STATS.AUTO_SAMPLE_SIZE, method_opt => 'FOR ALL COLUMNS SIZE AUTO');