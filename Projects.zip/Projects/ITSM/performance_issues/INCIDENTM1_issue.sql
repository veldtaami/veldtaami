-- tabellen verplaatst naar nieuwe tablespace  
move online: 

create tablespace SM1D_02 datafile '+DATA' size 1G autoextend on maxsize 32G;
alter user owner_SM1 quota unlimited on SM1D_02;


Set timing on



-- de LOBS
select  s.SEGMENT_NAME lobs_name,  sum(bytes)/1024/1024 MB  , s.TABLESPACE_NAME , d.table_name from dba_segments  s, dba_lobs d
 where s.segment_name = d.segment_name and
 s.segment_name in
 (select segment_name from dba_lobs where owner = upper('OWNER_SM1') and table_name = 'INCIDENTSM1' )
 group by s.segment_name,  s.TABLESPACE_NAME,  d.table_name
 order by 2,1

-- de tabel grootte
select sum(bytes)/1024/1024 MB from dba_Segments 
where segment_name ='INCIDENTSM1'and owner = 'OWNER_SM1';

select blocks*8/1024 MB , owner from  dba_tables 
where table_name  ='INCIDENTSM1' and owner = 'OWNER_SM1';

exec dbms_stats. GATHER_TABLE_STATS('OWNER_SM1','INCIDENTSM1', ESTIMATE_PERCENT => 2);



ALTER SESSION ENABLE PARALLEL DML;
ALTER SESSION ENABLE PARALLEL DDL;
ALTER SESSION ENABLE PARALLEL query;
alter session force parallel dml parallel 8;
alter session force parallel ddl parallel 8;
alter session force parallel query parallel 8;



-- move table
select 'alter table OWNER_SM1.' || table_name || ' move online tablespace SM1D_02 ;' from dba_tables 
where table_name = 'INCIDENTSM1'  and owner = 'OWNER_SM1';

-- move lob
select 'alter table  '||owner||'.'||table_name||' move lob ("'||column_name ||'") store as (tablespace SM1D_02) ONLINE;' 
from dba_lobs where table_name ='INCIDENTSM1' and owner = 'OWNER_SM1' and tablespace_name = 'SM1D'; 

-- move indexes
select 'ALTER INDEX '||owner||'.'||index_name||' REBUILD TABLESPACE '||'SM1D_02 online parallel 8;' 
from dba_indexes where table_name ='INCIDENTSM1' and owner = 'OWNER_SM1' and index_name not like 'SYS%';

@unusable



begin
dbms_stats.gather_table_stats
(ownname => 'OWNER_SM1', 
tabname => 'INCIDENTSM1' , 
estimate_percent => dbms_stats.auto_sample_size, 
method_opt => 'for all indexed columns size auto',
degree => 4 ,
cascade => TRUE);
end;
/
