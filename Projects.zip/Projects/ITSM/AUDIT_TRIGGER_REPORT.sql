--drop table fotdba.logon_audit_tbl;
create table fotdba.logon_audit_tbl(
   db_user         varchar2(30),
   ses_id          varchar2(30),
   host_name       varchar2(60),
   term_name       varchar2(60),
   program_name    varchar2(90),
   instance_nm     varchar2(20),
   logon_date           date
 );
grant all on fotdba.logon_audit_tbl 



create or replace trigger
   sys.logon_audit_trigger
AFTER LOGON ON DATABASE
BEGIN
insert into fotdba.logon_audit_tbl (
select 
user,
sys_context('USERENV','SESSIONID'),
sys_context('USERENV','HOST'),
sys_context('USERENV','TERMINAL'),
sys_context('USERENV','CLIENT_PROGRAM_NAME'),
sys_context('USERENV','INSTANCE_NAME'),
sysdate from dual where user <> 'SYS');
END;
/



col program_name for a40
select db_user ,  ses_id  , host_name   , term_name   , program_name, to_char(logon_date,  'DD-MM-YYYY HH24:MI:SS') from fotdba.logon_audit_tbl ;

select db_user ,  ses_id  , host_name   , term_name   , program_name, to_char(logon_date,  'DD-MM-YYYY HH24:MI:SS') from fotdba.logon_audit_tbl ;



RApportages:

select count(db_user), db_user from fotdba.logon_audit_tbl group by db_user;


Aantal connecties van 1 dag:

select count(db_user), db_user from fotdba.logon_audit_tbl 
where db_user not in ('PUBLIC','AUDIT_USER_ADMIN', 'FOTDBA', 'SYSRAC', 'RABO_USER') 
and logon_date between to_date('04-10-2021 09:00','DD-MM-YYYY HH24:MI') 
and to_date('05-10-2021 09:00','DD-MM-YYYY HH24:MI') 
group by db_user order by 1 desc;


aantal connecties van 1 week.
select count(db_user), db_user from fotdba.logon_audit_tbl 
where db_user not in ('PUBLIC','AUDIT_USER_ADMIN', 'FOTDBA', 'SYSRAC', 'RABO_USER') 
and logon_date between to_date('27-09-2021 09:00','DD-MM-YYYY HH24:MI') 
and to_date('01-10-2021 18:00','DD-MM-YYYY HH24:MI') 
group by db_user order by 1 desc;


Waar komen de connecties vandaan:


select distinct db_user, host_name, program_name from fotdba.logon_audit_tbl
where db_user in ('SELECT_SMR_PDA','USER_LKT','USER_SCM','SELECT_SMR_RMW','SPLUNK_AUDIT',
'SELECT_SMR_SPL','SELECT_SMR_BLN','SELECT_SMR_ADM','USER_SM1','SELECT_SMR_SDT','SELECT_SM1','SELECT_SMR_CTR','SELECT_CIT')
order by 1;
			 
			 
			 
			 
			 select SQL_FULLTEXT , LAST_LOAD_TIME  FROM gv$sql where LAST_LOAD_TIME is not null order by LAST_LOAD_TIME ASC 
			 
SELECT distinct
   u.username,
   h.program,
   s.sql_id
FROM
   DBA_HIST_ACTIVE_SESS_HISTORY h,
   DBA_USERS u,
   DBA_HIST_SQLTEXT s
WHERE  sample_time >= SYSDATE - 30
   AND h.user_id=u.user_id
   AND h.sql_id = s.sql_iD
   AND u.username in ('SELECT_SMR_PDA','USER_LKT','USER_SCM','SELECT_SMR_RMW','SPLUNK_AUDIT',
'SELECT_SMR_SPL','SELECT_SMR_BLN','SELECT_SMR_ADM','USER_SM1','SELECT_SMR_SDT','SELECT_SM1','SELECT_SMR_CTR','SELECT_CIT')
order by 1
/
			 
set long 9990			 
select sql_id, sql_text from DBA_HIST_SQLTEXT where sql_id in
(SELECT distinct
   s.sql_id
FROM
   DBA_HIST_ACTIVE_SESS_HISTORY h,
   DBA_USERS u,
   DBA_HIST_SQLTEXT s
WHERE  sample_time >= SYSDATE - 30
   AND h.user_id=u.user_id
   AND h.sql_id = s.sql_iD
   AND u.username in ('SELECT_SMR_PDA','USER_LKT','USER_SCM','SELECT_SMR_RMW','SPLUNK_AUDIT',
'SELECT_SMR_SPL','SELECT_SMR_BLN','SELECT_SMR_ADM','USER_SM1','SELECT_SMR_SDT','SELECT_SM1','SELECT_SMR_CTR','SELECT_CIT')
)





CLIENT_INFO

select v.SQL_TEXT,
           v.PARSING_SCHEMA_NAME,
           v.FIRST_LOAD_TIME
      from v$sql v
where v.PARSING_SCHEMA_NAME = 'SELECT_SMR_PDA';

to_date(v.FIRST_LOAD_TIME,'YYYY-MM-DD hh24:mi:ss')>ADD_MONTHS(trunc(sysdate,'MM'),-2)


select v.SQL_TEXT,
           v.PARSING_SCHEMA_NAME,
           v.FIRST_LOAD_TIME,
           v.DISK_READS,
           v.ROWS_PROCESSED,
           v.ELAPSED_TIME,
           v.service
      from v$sql v
where to_date(v.FIRST_LOAD_TIME,'YYYY-MM-DD hh24:mi:ss')>ADD_MONTHS(trunc(sysdate,'MM'),-2)
