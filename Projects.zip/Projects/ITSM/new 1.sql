rawgrant execute on utl_http to owner_sm2;
grant execute on dbms_lock to owner_sm2;
SRV0TSIB101

grant execute on utl_http to owner_sm2
grant execute on dbms_lock to owner_sm2
 
BEGIN
  DBMS_NETWORK_ACL_ADMIN.create_acl (
    acl          => 'local_sx_acl_file.xml', 
    description  => 'A test of the ACL functionality',
    principal    => 'OWNER_SM2',
    is_grant     => TRUE, 
    privilege    => 'connect',
    start_date   => SYSTIMESTAMP,
    end_date     => NULL);
end;
 
begin
  DBMS_NETWORK_ACL_ADMIN.assign_acl (
    acl         => 'local_sx_acl_file.xml',
    host        => 'localhost', 
    lower_port  => 9002,
    upper_port  => NULL);    
end; 


 
create or replace procedure Call_To_SM9 ( username IN VARCHAR2 , password IN VARCHAR2 , url IN VARCHAR2 )
is
  req utl_http.req;
  res utl_http.resp;
  --url varchar2(4000) := 'http://lsrv5538.linux.rabobank.nl:12345/SM/9/rest/incidents';

  name varchar2(4000);
  buffer varchar2(4000); 
  content varchar2(4000) := '{"Incident": {"AffectedCI": "GXXU0010-L2-010I-APAC","Area": "failure",
  "AssignmentGroup": "ITN CI ICS MMS CR SM","Category": "incident","Description": ["Test description],
  "Impact": "3","OpenGroup": "ITN CI ICS CONTROL ROOM","Priority": "3", "Subarea": "error message",
  "Title": "Martijn Test arcsight via API","Urgency": "3"}}';

begin
  req := utl_http.begin_request(url, 'POST',' HTTP/1.1');

  utl_http.set_header(req, 'content-type', 'application/json'); 
  utl_http.set_header(req, 'Authorization','Basic ' || utl_raw.cast_to_varchar2(utl_encode.base64_encode(utl_i18n.string_to_raw(username || ':' || password, 'AL32UTF8'))));
  utl_http.write_text(req, content);
  res := utl_http.get_response(req);
  -- process the response from the HTTP call
  begin
    loop
      utl_http.read_line(res, buffer);
      dbms_output.put_line(buffer);
    end loop;
    utl_http.end_response(res);
  exception
    when utl_http.end_of_body 
    then
      utl_http.end_response(res);
  end;
end Call_To_SM9;
/


execute  Call_To_SM9('veldtaami','pietje','http://lsrv5538.linux.rabobank.nl:12345/SM/9/rest/incidents');


Uit ASK TOM:

declare
acl_nom varchar2(100) := '/sys/acls/domtest.xml';
begin
dbms_network_acl_admin.drop_acl (acl => acl_nom);
end;
/

declare
acl_nom varchar2(100) := '/sys/acls/domtest.xml';
begin
dbms_network_acl_admin.create_acl (
acl => acl_nom,
description => 'mytest acl',
principal => 'OWNER_SM2',
is_grant => true,
privilege => 'connect',
start_date => systimestamp,
end_date => null);
END;
/


declare
acl_nom varchar2(100) := '/sys/acls/domtest.xml';
Begin
dbms_network_acl_admin.assign_acl(acl => acl_nom,
host => '*',
lower_port => 443,
upper_port => 39000);

END;
/


