--drop table fotdba.logon_audit_tbl;
create table fotdba.logon_audit_tbl(
   db_user         varchar2(30),
   ses_id          varchar2(30),
   host_name       varchar2(60),
   term_name       varchar2(60),
   program_name    varchar2(90),
   instance_nm     varchar2(20),
   logon_date           date
 );
grant all on fotdba.logon_audit_tbl 



create or replace trigger
   sys.logon_audit_trigger
AFTER LOGON ON DATABASE
BEGIN
insert into fotdba.logon_audit_tbl (
select 
user,
sys_context('USERENV','SESSIONID'),
sys_context('USERENV','HOST'),
sys_context('USERENV','TERMINAL'),
sys_context('USERENV','CLIENT_PROGRAM_NAME'),
sys_context('USERENV','INSTANCE_NAME'),
sysdate from dual where user <> 'SYS');
END;
/



col program_name for a40
select db_user ,  ses_id  , host_name   , term_name   , program_name, to_char(logon_date,  'DD-MM-YYYY HH24:MI:SS') from fotdba.logon_audit_tbl ;


select 
user,
sys_context('USERENV','INSTANCE_NAME') from dual;


CLIENT_INFO