RABO_USER @ srv0psib101 > select name, value, ISSPECIFIED from v$spparameter where ISSPECIFIED = 'TRUE';

NAME                                               VALUE                                                        ISSPEC
-------------------------------------------------- ------------------------------------------------------------ ------
processes                                          5000                                                         TRUE
resource_limit                                     TRUE                                                         TRUE
cpu_count                                          8                                                            TRUE
sga_max_size                                       10737418240                                                  TRUE
use_large_pages                                    ONLY                                                         TRUE
shared_pool_size                                   524288000                                                    TRUE
pga_aggregate_limit                                16106127360                                                  TRUE
nls_sort                                           BINARY                                                       TRUE
nls_comp                                           BINARY                                                       TRUE
nls_length_semantics                               CHAR                                                         TRUE
resource_manager_plan                                                                                           TRUE
cluster_interconnects                              192.168.33.1:192.168.33.2                                    TRUE
cluster_interconnects                              192.168.33.3:192.168.33.4                                    TRUE
_dlm_stats_collect                                 0                                                            TRUE
sga_target                                         8589934592                                                   TRUE
sga_target                                         10737418240                                                  TRUE
sga_target                                         10737418240                                                  TRUE
control_files                                      +DATA/PSIB1_02/CONTROLFILE/current.5757.1017924935           TRUE
control_files                                      +RECO/PSIB1_02/CONTROLFILE/current.1714.1017924937           TRUE
db_file_name_convert                               +DGPSIB                                                      TRUE
db_file_name_convert                               +DATA                                                        TRUE
log_file_name_convert                              +DGPSIB                                                      TRUE
log_file_name_convert                              +DATA                                                        TRUE
log_file_name_convert                              +DGPFRA1                                                     TRUE
log_file_name_convert                              +RECO                                                        TRUE
control_file_record_keep_time                      15                                                           TRUE
db_ultra_safe                                      DATA_ONLY                                                    TRUE
db_block_size                                      8192                                                         TRUE
db_cache_size                                      1572864000                                                   TRUE
compatible                                         12.2.0.1                                                     TRUE
log_archive_dest_1                                 location=USE_DB_RECOVERY_FILE_DEST                           TRUE
log_archive_dest_2                                 service="(DESCRIPTION=(LOAD_BALANCE=ON)(ADDRESS=(PROTOCOL=TC TRUE
                                                   P)(HOST=prodcl311-scan.oracle.rabobank.nl)(PORT=39000))(CONN
                                                   ECT_DATA=(SERVICE_NAME=PSIB1_01)))"

log_archive_dest_2                                 ASYNC NOAFFIRM delay=0 optional compression=disable max_fail TRUE
                                                   ure=0 max_connections=1 reopen=300 db_unique_name="PSIB1_01"
                                                    net_timeout=30

log_archive_dest_2                                 valid_for=(online_logfile,all_roles)                         TRUE
log_archive_dest_3                                 service="(DESCRIPTION=(LOAD_BALANCE=ON)(ADDRESS=(PROTOCOL=TC TRUE
                                                   PS)(HOST=prodcl305-scan.oracle.rabobank.nl)(PORT=39022))(CON
                                                   NECT_DATA=(SERVICE_NAME=PSIB1_03)))"

log_archive_dest_3                                 ASYNC NOAFFIRM delay=0 optional compression=disable max_fail TRUE
                                                   ure=0 max_connections=1 reopen=300 db_unique_name="PSIB1_03"
                                                    net_timeout=30

log_archive_dest_3                                 valid_for=(online_logfile,all_roles)                         TRUE
log_archive_dest_4                                                                                              TRUE
log_archive_dest_6                                                                                              TRUE
log_archive_dest_state_1                           ENABLE                                                       TRUE
log_archive_dest_state_2                           ENABLE                                                       TRUE
log_archive_dest_state_3                           ENABLE                                                       TRUE
log_archive_dest_state_4                           ENABLE                                                       TRUE
log_archive_dest_state_5                           ENABLE                                                       TRUE
log_archive_dest_state_6                           ENABLE                                                       TRUE
log_archive_min_succeed_dest                       1                                                            TRUE
fal_server                                                                                                      TRUE
log_archive_trace                                  0                                                            TRUE
log_archive_trace                                  0                                                            TRUE
log_archive_trace                                  0                                                            TRUE
data_guard_sync_latency                            0                                                            TRUE
log_archive_config                                 dg_config=(PSIB1_02,PSIB1_01,PSIB1_03)                       TRUE
log_archive_format                                 log_%t_%S_%r.arc                                             TRUE
log_archive_format                                 log_%t_%S_%r.arc                                             TRUE
log_archive_format                                 log_%t_%S_%r.arc                                             TRUE
log_archive_max_processes                          4                                                            TRUE
log_buffer                                         268435456                                                    TRUE
archive_lag_target                                 0                                                            TRUE
cluster_database                                   TRUE                                                         TRUE
cluster_database_instances                         4                                                            TRUE
db_create_file_dest                                +DATA                                                        TRUE
db_recovery_file_dest                              +RECO                                                        TRUE
db_recovery_file_dest_size                         3221225472000                                                TRUE
standby_file_management                            AUTO                                                         TRUE
thread                                             1                                                            TRUE
thread                                             2                                                            TRUE
fast_start_mttr_target                             300                                                          TRUE
db_flashback_retention_target                      120                                                          TRUE
undo_retention                                     5400                                                         TRUE
resumable_timeout                                  3600                                                         TRUE
instance_number                                    1                                                            TRUE
instance_number                                    2                                                            TRUE
_use_cached_asm_free_space                         TRUE                                                         TRUE
recyclebin                                         OFF                                                          TRUE
ldap_directory_access                              SSL                                                          TRUE
ldap_directory_sysauth                             yes                                                          TRUE
remote_login_passwordfile                          exclusive                                                    TRUE
audit_sys_operations                               TRUE                                                         TRUE
global_names                                       TRUE                                                         TRUE
dispatchers                                        (PROTOCOL=TCP) (SERVICE=PSIB1XDB)                            TRUE
local_listener                                     LISTENER_LOCAL                                               TRUE
java_jit_enabled                                   TRUE                                                         TRUE
job_queue_processes                                50                                                           TRUE
cursor_sharing                                     EXACT                                                        TRUE
audit_file_dest                                    /u01/app/oracle/admin/PSIB1_02/adump                         TRUE
audit_syslog_level                                 LOCAL2.DEBUG                                                 TRUE
audit_trail                                        OS                                                           TRUE
db_name                                            PSIB1                                                        TRUE
db_unique_name                                     PSIB1_02                                                     TRUE
open_cursors                                       300                                                          TRUE
sql92_security                                     TRUE                                                         TRUE
pga_aggregate_target                               6442450944                                                   TRUE
deferred_segment_creation                          FALSE                                                        TRUE
optimizer_capture_sql_plan_baselines               FALSE                                                        TRUE
optimizer_use_sql_plan_baselines                   FALSE                                                        TRUE
parallel_force_local                               TRUE                                                         TRUE
dg_broker_start                                    TRUE                                                         TRUE
dg_broker_config_file1                             +DATA/PSIB1_02/dr1PSIB1.dat                                  TRUE
dg_broker_config_file2                             +DATA/PSIB1_02/dr2PSIB1.dat                                  TRUE
awr_snapshot_time_offset                           1000000                                                      TRUE
diagnostic_dest                                    /u01/app/oracle/                                             TRUE
max_dump_file_size                                 UNLIMITED                                                    TRUE

102 rows selected.

RABO_USER @ srv0psib101 >