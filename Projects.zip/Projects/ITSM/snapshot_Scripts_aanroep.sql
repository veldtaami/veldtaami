wordt oracle: oracle SwitchStandbyDbRole12C.sh

als ORACLE op de 3501

/orabackup1/PSIB1/scripts/Switch_Standby_Role/SwitchStandbyDbRole12C.sh -d PSIB1_03 -a PHYSICAL   -- om het een standby db te maken. 
/orabackup1/PSIB1/scripts/Switch_Standby_Role/SwitchStandbyDbRole12C.sh -d PSIB1_03 -a SNAPSHOT   -- om het een snapshot db te maken. status is : PSIB1_03 - Snapshot standby database

 /appl/sib/prod/bin/switch_database_restart_only_scripts.sh owner_sm1 SRVPSIB1SNA2 SNAPSHOT> /appl/sib/prod/logs/switchdatabaselog/switch_database_"`date +\%d\%m\%y_\%H\%M\%S`".log 
 
 
 
 
voor G: 
wordt oracle: oracle SwitchStandbyDbRole12C.sh
/orabackup1/GSIB1/scripts/Switch_Standby_Role/SwitchStandbyDbRole12C.sh -d GSIB1_05 -a PHYSICAL
/orabackup1/GSIB1/scripts/Switch_Standby_Role/SwitchStandbyDbRole12C.sh -d GSIB1_05 -a SNAPSHOT

Configuration - PSIB1_06

  Protection Mode: MaxAvailability
  Members:
  PSIB1_02 - Primary database
    Error: ORA-16810: multiple errors or warnings detected for the member

    PSIB1_01 - Physical standby database
    PSIB1_03 - Snapshot standby database
      Error: ORA-16613: initialization in progress for member

Fast-Start Failover: DISABLED

Configuration Status:
ERROR   (status updated 65 seconds ago)

DGMGRL> exit



./SwitchStandbyDbRole12C.sh -d GSIB1_05 -a PHYSICAL



vanaf de 2410  (productie applicatie server)
wordt psib

physical maken is dat het weer standby db wordt en gaat bijwerken. 

40 2 * * * /appl/sib/prod/bin/switch_database_new.sh owner_sm1 SRVPSIB1SNA2 SNAPSHOT> /appl/sib/prod/logs/switchdatabaselog/switch_database_"`date +\%d\%m\%y_\%H\%M\%S`".log 2>&1
#40 5 * * * /appl/sib/prod/bin/switch_database_new.sh user_sm1 SRVPSIB1SNA2 PHYSICAL> /appl/sib/prod/logs/switchdatabaselog/switch_database_"`date +\%d\%m\%y_\%H\%M\%S`".log 2>&1

MA%0KkNcN9M'   '








EMCLI:

SIBDIR=/appl/sib/prod

EMCLIDIR=${SIBDIR}/emcli134

EMDIR: /appl/sib/prod/emcli134

/appl/sib/prod/emcli134/emcli setup -url="https://poem13.oracle.rabobank.nl/em" -username=TEAM_CSS_ISA_DFA -password='@Team_ITSM_2019' -nocertvalidate -autologin -dir="/home/sibp" -localdirans="yes" -trustall -novalidate
/appl/sib/prod/emcli134/emcli login -username="TEAM_CSS_ISA_DFA" -password='@Team_ITSM_2019'

SEQ1_SIB_SNAP=`cat ${EMCLIDIR}/SEQ1_SIB_SNAP.lis`
let SEQ1_SIB_SNAP=${SEQ1_SIB_SNAP}+1
echo ${SEQ1_SIB_SNAP} > ${EMCLIDIR}/SEQ1_SIB_SNAP.lis
SNJOBNAME="APP_PSIB_SWITCH_DB_ROLE_${SWITCHTO}.${SEQ1_SIB_SNAP}"



. ${EMCLIDIR}/setenv_emcli.sh
echo "We gaan nu switchen naar ${SWITCHTO}"
echo "de emclidir is:   ${EMCLIDIR}"
${EMCLIDIR}/emcli create_job -input_file=property_file:${SIBBIN}/switchdatdabase.txt






















