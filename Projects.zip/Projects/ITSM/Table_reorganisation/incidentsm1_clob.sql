RABO_USER@PSIB11 SQL> select count(*) from owner_smr.incidentsm1;

  COUNT(*)
----------
    474093

select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(UPDATE_ACTION) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(UPDATE_ACTION_ESS) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(AGREEMENT_IDS) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(RN_WORK_INSTRUCTION) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(DESCRIPTION)>=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(RESOLUTION)>=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(TEMP_UPDATE) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(RN_INCIDENT_INSTRUCTIONS) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(UPDATE_ACTION) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(UPDATE_ACTION_ESS) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(AGREEMENT_IDS) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(RN_WORK_INSTRUCTION) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(DESCRIPTION) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(RESOLUTION) >=4000;
select count(*) from owner_smr.incidentsm1 where dbms_lob.getlength(TEMP_UPDATE) >=4000;

  COUNT(*)
----------
     32902


  COUNT(*)
----------
     32890


  COUNT(*)
----------
         0


  COUNT(*)
----------
     34533


  COUNT(*)
----------
      1327


  COUNT(*)
----------
      1593


  COUNT(*)
----------
         0


  COUNT(*)
----------
        39


  COUNT(*)
----------
     32904


  COUNT(*)
----------
     32892


  COUNT(*)
----------
         0


  COUNT(*)
----------
     34534


  COUNT(*)
----------
      1327


  COUNT(*)
----------
      1593


  COUNT(*)
----------
         0

