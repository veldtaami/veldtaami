declare
  lengte	number;
begin
select max(dbms_lob.getlength(AGREEMENT_IDS)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(ACTION)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(RESOLUTION)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(AFFECTED)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(KEY_WORDS)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(XREFERENCE)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(UPDATE_ACTION)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(CALLBACK_LIST)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(CLOSING_COMMENTS)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(THIRD_PARTY_NAME)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(THIRD_PARTY_REFERENCE)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(THIRD_PARTY_REFERRED)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(THIRD_PARTY_REFERRED_BY)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(EXPD_RESPONSE_TIME)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(EXPLANATION)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(DUMP)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(AFFECTED_SERVICES)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(RN_INCIDENT_INSTRUCTIONS)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(THIRD_PARTY_NAME)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(THIRD_PARTY_REFERENCE)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(THIRD_PARTY_REFERRED)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(THIRD_PARTY_REFERRED_BY)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(EXPD_RESPONSE_TIME)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(EXPLANATION)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(DUMP)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(AFFECTED_SERVICES)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(AGREEMENT_IDS)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(ACTION)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(RESOLUTION)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(AFFECTED)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(KEY_WORDS)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(XREFERENCE)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(UPDATE_ACTION)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(CALLBACK_LIST)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(CLOSING_COMMENTS)) into lengte from owner_smr.probsummarym1;
dbms_output.put_line( lengte );
end;
/

RABO_USER@PSIB11 SQL> @get_clob_length_probsummarym1.sql
4
227630
123166
0
0
0
373299
0
123166
6
8
17
0
0
533
0
0
4718
6
8
17
0
0
533
0
0
4
227630
123166
0
0
0
373299
0
123166

PL/SQL procedure successfully completed.

