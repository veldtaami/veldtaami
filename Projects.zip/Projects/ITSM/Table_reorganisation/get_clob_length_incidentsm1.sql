declare
  lengte	number;
begin
select max(dbms_lob.getlength(UPDATE_ACTION)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(UPDATE_ACTION_ESS)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(AGREEMENT_IDS)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(RN_WORK_INSTRUCTION)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(DESCRIPTION)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(RESOLUTION)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(TEMP_UPDATE)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(RN_INCIDENT_INSTRUCTIONS)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(UPDATE_ACTION)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(UPDATE_ACTION_ESS)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(AGREEMENT_IDS)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(RN_WORK_INSTRUCTION)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(DESCRIPTION)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(RESOLUTION)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
select max(dbms_lob.getlength(TEMP_UPDATE)) into lengte from owner_smr.incidentsm1;
dbms_output.put_line( lengte );
end;
/

RABO_USER@PSIB11 SQL> @get_clob_length_incidentsm1.sql
747719
747719
3
16234
104266
131985
0
4718
747719
747719
3
16234
104266
131985
0

PL/SQL procedure successfully completed.

