# Onderstaande script is ten behoeve van de refresh van de A omgeving - draait maandagnacht om 01:00
00 01 * * 1 /appl/sib/prod/refresh/refresh/refresh_environment.sh -e prod -f SRV0PSIB101 > /appl/sib/prod/logs/export_environment.log 2>&1



File logs_export_schema.sql.tar.gz created

/appl/sib/prod/refresh/refresh/run_sql.sh
${EXPDIR}/refresh/refresh/run_sql.sh ${EUSER} ${FRDATABASE} export_schema.sql


set serveroutput on
declare
  v_str varchar2(50);
begin
  v_str := fotdba.export_schema_fnc( i_schema => 'OWNER_SM1',
                                     i_directory => 'REFRESH_SMR',
                                     i_file_name => 'SIB1_expdp_OWNER_SM1_%U.dmp',
                                     i_parallel => 8,
                                     i_logdir => 'REFRESH_SMR',
                                     i_logfile => 'PSIB1_expdp_OWNER_SM1.log');
  dbms_output.put_line('Export: '|| v_str );
end;
/
~







exec fotdba.DROP_ALL_SCHEMA_OBJECTS('OWNER_S11');


export ORACLE_PDB_SID=GSIB1

impdp

userid="/ as sysdba"
dumpfile=SIB1_expdp_OWNER_SM1_%U.dmp
LOGFILE=SIB1_impd_OWNER_SM1_1511.log 
directory=REFRESH_SMR
REMAP_SCHEMA=owner_sm1:owner_s11 
REMAP_TABLESPACE=SM1D:S11D
REMAP_TABLESPACE=SM1X:S11X
REMAP_TABLESPACE=SM1D_01:S11D
REMAP_TABLESPACE=SM1D_02:S11D


